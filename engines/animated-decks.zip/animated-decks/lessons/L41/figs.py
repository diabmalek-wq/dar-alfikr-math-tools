import sys; sys.path.insert(0, '/home/claude/lib')
from figlib import *
import numpy as np
LT = '#7FE0D8'; DO = '#B8530F'
def hyp(ax, f, x0, x1, color, lw=3.2, ymin=-1e9, ymax=1e9, h=0.0, ls='-'):
    # two branches around vertical asymptote x=h
    eps = 0.04
    curve(ax, f, x0, h - eps, color, lw, ymin, ymax, ls=ls)
    curve(ax, f, h + eps, x1, color, lw, ymin, ymax, ls=ls)
def hero():
    F = Fig('s1', 5.6, 3.9, (-4, 6), (-3.6, 4.8), dark=True)
    F.layer('0', lambda ax, F: grid_axes(ax, F, [-3,-2,-1,1,2,3,4,5], [-3,-2,-1,1,2,3,4], labels=False, gridalpha=.15))
    def l1(ax, F):
        hyp(ax, lambda x: 2/x, -4, 6, LT, 3.4, -3.6, 4.8)
        lab(ax, (-3.3, -1.2), r'$y=\dfrac{k}{x}$', LT, 16)
    F.layer('1', l1)
    def l2(ax, F):
        ax.plot([-4, 6], [1.5, 1.5], color=GOLD, lw=1.8, ls=(0, (4, 3)), zorder=3)
        ax.plot([1.5, 1.5], [-3.6, 4.8], color=GOLD, lw=1.8, ls=(0, (4, 3)), zorder=3)
        hyp(ax, lambda x: 2/(x-1.5)+1.5, -4, 6, GOLD, 3.4, -3.6, 4.8, h=1.5)
        lab(ax, (4.5, 3.6), r'$\dfrac{1}{x-h}+k$', GOLD, 15)
    F.layer('2', l2)
    F.layer('3', lambda ax, F: (lab(ax, (2.5, -2.9), r'$x=h$', 'white', 13), lab(ax, (-3.2, 2.0), r'$y=k$', 'white', 13)))
hero()
def dvi():
    F = Fig('dv', 2.65, 3.2, (-0.8, 9.5), (-1.2, 11.5))
    F.layer('0', lambda ax, F: grid_axes(ax, F, [2,4,6,8], [2,4,6,8,10], fs=8))
    def l1(ax, F):
        ax.plot([0, 8], [0, 12*8/8*1.0], color=TEAL, lw=3, zorder=4, alpha=0)  # placeholder
        curve(ax, lambda x: 1.5*x, 0, 7.4, TEAL, 3.2)
        for p in [(2,3),(4,6),(6,9)]: pdot(ax, p, ORG)
        lab(ax, (1.2, 8.6), r'$y=1.5x$', TEAL, 12, ha='left')
    F.layer('1', l1)
    G = Fig('iv', 2.65, 3.2, (-0.8, 9.5), (-1.2, 14.5))
    G.layer('0', lambda ax, F: grid_axes(ax, F, [2,4,6,8], [2,4,6,8,10,12], fs=8))
    def i1(ax, F):
        curve(ax, lambda x: 24/x, 1.8, 9.2, NAVY, 3.2, -1, 14.5)
        for p in [(2,12),(4,6),(6,4)]: pdot(ax, p, ORG)
        lab(ax, (5.0, 11.2), r'$y=\dfrac{24}{x}$', NAVY, 12, ha='left')
    G.layer('1', i1)
dvi()
def md():
    F = Fig('md', 5.4, 4.0, (-1.5, 17), (-1.8, 17))
    F.layer('0', lambda ax, F: (grid_axes(ax, F, [4,8,12,16], [4,8,12,16], fs=9), lab(ax, (16.8, 1.3), r'machines $m$', INK, 12, ha='right'), lab(ax, (0.4, 16.2), r'days $d$', INK, 12, ha='left')))
    F.layer('1', lambda ax, F: curve(ax, lambda m: 60/m, 3.8, 16.5, NAVY, 3.2, -1, 17))
    def l2(ax, F):
        for m, d in [(5,12),(8,7.5)]:
            ax.plot([m, m], [0, d], color=GREY, lw=1.2, ls=(0, (3, 3)), zorder=3); ax.plot([0, m], [d, d], color=GREY, lw=1.2, ls=(0, (3, 3)), zorder=3)
            pdot(ax, (m, d), ORG)
        lab(ax, (5.2, 12.9), r'$(5,\,12)$', DO, 13, ha='left'); lab(ax, (8.3, 8.5), r'$(8,\,7.5)$', DO, 13, ha='left')
    F.layer('2', l2)
    def l3(ax, F):
        ax.plot([12, 12], [0, 5], color=GREY, lw=1.2, ls=(0, (3, 3)), zorder=3); ax.plot([0, 12], [5, 5], color=GREY, lw=1.2, ls=(0, (3, 3)), zorder=3)
        pdot(ax, (12, 5), GOLD, ms=9); lab(ax, (12.3, 6.0), r'$(12,\,5)$', '#7A5200', 13, ha='left')
    F.layer('3', l3)
md()
def s7():
    F = Fig('hyp', 5.4, 4.3, (-6.2, 6.2), (-4.9, 4.9))
    F.layer('0', lambda ax, F: grid_axes(ax, F, [-4,-2,2,4], [-4,-2,2,4], fs=9))
    def l1(ax, F):
        ax.plot([0, 0], [-4.9, 4.9], color=GOLD, lw=2.4, ls=(0, (4, 3)), zorder=2); ax.plot([-6.2, 6.2], [0, 0], color=GOLD, lw=2.4, ls=(0, (4, 3)), zorder=2)
        lab(ax, (0.15, -4.5), r'$x=0$', '#7A5200', 13, ha='left', bg='white'); lab(ax, (5.9, 0.5), r'$y=0$', '#7A5200', 13, ha='right', bg='white')
    F.layer('1', l1)
    def l2(ax, F):
        hyp(ax, lambda x: 4/x, -6.2, 6.2, NAVY, 3.2, -4.9, 4.9)
        for p in [(1,4),(2,2),(4,1),(-2,-2)]: pdot(ax, p, ORG)
        lab(ax, (3.3, 3.2), r'$y=\dfrac{4}{x}$', NAVY, 14)
    F.layer('2', l2)
    def l3(ax, F):
        hyp(ax, lambda x: -4/x, -6.2, 6.2, TEAL, 3.2, -4.9, 4.9)
        for p in [(1,-4),(2,-2),(-2,2)]: pdot(ax, p, ORG)
        lab(ax, (-3.6, 3.2), r'$y=-\dfrac{4}{x}$', '#0E7A75', 14)
    F.layer('3', l3)
s7()
def s8():
    F = Fig('sh', 5.5, 4.3, (-3.0, 7.5), (-3.2, 7.4))
    F.layer('0', lambda ax, F: grid_axes(ax, F, [-2,2,4,6], [-2,2,4,6], fs=9))
    F.layer('1', lambda ax, F: (hyp(ax, lambda x: 1/x, -3, 7.5, TEAL, 2.4, -3.2, 7.4, ls=(0, (1, 0))), lab(ax, (-2.3, -1.2), r'$y=\dfrac{1}{x}$', '#0E7A75', 13)))
    def l2(ax, F):
        ax.plot([2, 2], [-3.2, 7.4], color=ORG, lw=2.2, ls=(0, (4, 3)), zorder=3); ax.plot([-3, 7.5], [3, 3], color=ORG, lw=2.2, ls=(0, (4, 3)), zorder=3)
        lab(ax, (2.15, -2.7), r'$x=2$', DO, 13, ha='left', bg='white'); lab(ax, (7.3, 3.45), r'$y=3$', DO, 13, ha='right', bg='white')
    F.layer('2', l2)
    F.layer('3', lambda ax, F: (hyp(ax, lambda x: 1/(x-2)+3, -3, 7.5, NAVY, 3.4, -3.2, 7.4, h=2), lab(ax, (5.0, 4.9), r'$y=\dfrac{1}{x-2}+3$', NAVY, 13, bg='white')))
    def l4(ax, F):
        pdot(ax, (0, 2.5), ORG, ms=8); pdot(ax, (5/3, 0), ORG, ms=8)
        lab(ax, (-0.2, 1.7), r'$(0,\,\frac{5}{2})$', DO, 12, ha='right', bg='white'); lab(ax, (1.8, -0.8), r'$(\frac{5}{3},\,0)$', DO, 12, ha='left', bg='white')
    F.layer('4', l4)
s8()
def cs():
    F = Fig('cs', 7.0, 4.3, (-6, 85), (-12, 142))
    F.layer('0', lambda ax, F: (grid_axes(ax, F, [20,40,60,80], [20,40,60,80,100,120], fs=9), lab(ax, (84, 8), r'students $n$', INK, 12, ha='right'), lab(ax, (-4, 136), r'cost per student $c$ (SAR)', INK, 12, ha='left')))
    def l1(ax, F):
        curve(ax, lambda n: 1800/n, 17, 84, TEAL, 3.2, -10, 135)
        for p in [(30,60),(45,40)]:
            ax.plot([p[0], p[0]], [0, p[1]], color=GREY, lw=1.1, ls=(0,(3,3))); pdot(ax, p, ORG)
        lab(ax, (27, 50), r'$(30,\,60)$', DO, 12, ha='right', bg='white'); lab(ax, (47, 29), r'$(45,\,40)$', DO, 12, ha='left', bg='white')
        lab(ax, (50, 98), r'$c=\dfrac{1800}{n}$', '#0E7A75', 15, ha='left')
    F.layer('1', l1)
    def l2(ax, F):
        ax.plot([-6, 85], [20, 20], color=ORG, lw=2.2, ls=(0, (4, 3)), zorder=3)
        curve(ax, lambda n: 1800/n + 20, 17, 84, NAVY, 3.4, -10, 135)
        lab(ax, (-4, 27), r'$c=20$', DO, 13, ha='left', bg='white')
        lab(ax, (50, 122), r'$c=\dfrac{1800}{n}+20$', NAVY, 15, ha='left')
    F.layer('2', l2)
    def l3(ax, F):
        ax.plot([0, 60], [50, 50], color=GREY, lw=1.2, ls=(0,(3,3))); ax.plot([60, 60], [0, 50], color=GREY, lw=1.2, ls=(0,(3,3)))
        pdot(ax, (60, 50), GOLD, ms=10); lab(ax, (62, 63), r'$(60,\,50)$', '#7A5200', 13, ha='left', bg='white')
    F.layer('3', l3)
cs()
save()
