const L = require('/home/claude/lib/lib.js')({ codes: 'HSA.CED.A.2 · (+)HSF.IF.C.7.D · HSF.BF.B.3', title: 'Lesson 4-1 Inverse Variation and the Reciprocal Function (Grade 10, Week 12)' });
const { C, txt, card, pill, disc, math, fig, chrome, banner, whatif, cue, notes, pres, sh } = L;
const { TEAL, ORG, NAVY, DKG, GOLD, GREY, BORDER, INK, WHITE, GOLDBG, BROWN } = C;

L.title(1, { kicker: 'GRADE 10  ·  ALGEBRA II  ·  TOPIC 4', lesson: 'Lesson 4-1', lines: 'Inverse Variation\nand the Reciprocal\nFunction', fs: 40, sub: 'When one quantity rises, the other falls', upnext: 'Up next: 4-2 Graphing Rational Functions',
  hero(s) {
    fig(s, 's1', '0', 7.05, 1.8, 'd900_fade_axes'); fig(s, 's1', '1', 7.05, 1.8, 'd1300_wipe_p');
    fig(s, 's1', '2', 7.05, 1.8, 'd2300_wipe_q'); fig(s, 's1', '3', 7.05, 1.8, 'd3200_fade_lab');
    math(s, 's1_f', 8.2, 5.75, { s: 1.2, name: 'd3600_fade_lf' });
  } });
L.journey(2, ['Three no-calculator checks', 'Direct vs inverse, equations, the graph of y = k/x, shifts', 'Practice, Apply, Investigate', 'A school trip to the Red Sea coast', '3 of 3 unlocks the last station', 'Create one, then Time to Check']);
L.objectives(3, ['Distinguish between direct and inverse variation.', 'Write equations that represent inverse variation, including reciprocal functions.', 'Graph equations that represent inverse variation.', 'Describe the effects of transformations on the graph of the reciprocal function f(x) = (1/x − h)+ k.'], ['asymptote', 'constant of variation', 'inverse variation', 'reciprocal function'],
  [['HSA.CED.A.2', 'Create equations in two or more variables to represent relationships between quantities; graph equations on coordinate axes with labels and scales.'], ['(+)HSF.IF.C.7.D', 'Graph rational functions, identifying zeros and asymptotes when suitable factorizations are available, and showing end behavior.'], ['HSF.BF.B.3', 'Identify the effect on the graph of replacing f(x) by f(x) + k, k f(x), f(kx), and f(x + k) for specific values of k (both positive and negative); find the value of k given the graphs. Experiment with cases and illustrate an explanation of the effects on the graph using technology. Include recognizing even and odd functions from their graphs and algebraic expressions for them.']]);
L.diagnose(4, ['s4_c1', 's4_c2', 's4_c3'], ['s4_a1', 's4_a2', 's4_a3'], 'All three answers are written without a calculator, and you can say what the numbers 2 and 3 do to the graph of absolute value of x.', '>30% miss Q1 rehearse y = kx and k = y/x before slide 5; Q2 practise substituting negatives before slide 7; Q3 redo shifts of absolute value before slide 8.');

// 5 direct vs inverse
{
  const s = pres.addSlide(); const n = 5;
  chrome(s, n, 2, 'Direct and inverse variation');
  card(s, 0.4, 1.85, 5.8, 4.95, { objectName: 'c1_fade_dcard' });
  pill(s, 'DIRECT', 0.65, 2.0, 0.95, 0.3, TEAL, WHITE, 11, { objectName: 'c1_fade_pd' });
  pill(s, 'INVERSE', 3.4, 2.0, 1.05, 0.3, NAVY, WHITE, 11, { objectName: 'c1_fade_pi' });
  fig(s, 'dv', '0', 0.55, 2.4, 'c1_fade_dv0'); fig(s, 'iv', '0', 3.3, 2.4, 'c1_fade_iv0');
  fig(s, 'dv', '1', 0.55, 2.4, 'c2_wipe_dv1'); fig(s, 'iv', '1', 3.3, 2.4, 'c3_wipe_iv1');
  math(s, 's5_cap1', 0.7, 5.85, { s: 1.3, name: 'c2_fade_cap1' }); math(s, 's5_cap2', 3.45, 5.85, { s: 1.3, name: 'c3_fade_cap2' });
  banner(s, 6.4, 1.85, 6.45, 0.85, [['s5_f1', 1.0], ['s5_f2', 1.0]], { name: 'c1_fade_ban' });
  card(s, 6.4, 2.85, 6.45, 1.75, { objectName: 'c1_fade_ea' });
  pill(s, 'EXAMPLE A', 6.6, 2.97, 1.3, 0.3, TEAL, WHITE, 11, { objectName: 'c1_fade_eal' });
  math(s, 's5_a0', 8.05, 3.12, { s: 1.15, vc: true, name: 'c1_fade_ea0' });
  math(s, 's5_a1', 6.6, 3.5, { s: 1.3, name: 'c2_fade_ea1' });
  math(s, 's5_a2', 6.6, 4.05, { s: 1.3, name: 'c3_fade_ea2' });
  // Example B table tiles
  card(s, 6.4, 4.75, 6.45, 1.3, { objectName: 'c3_fade_eb' });
  pill(s, 'EXAMPLE B', 6.6, 4.85, 1.3, 0.3, ORG, WHITE, 11, { objectName: 'c3_fade_ebl' });
  math(s, 's5_b0', 8.05, 5.0, { s: 1.0, vc: true, name: 'c3_fade_eb0' });
  const T = [[2, 12], [4, 6], [6, 4]];
  [['s5_x', 5.3], ['s5_y', 5.57], ['s5_xy', 5.84]].forEach(([k, y], r) => {
    math(s, k, 6.65, y + 0.1, { s: 1.0, vc: true, name: 'c3_fade_tl' + r });
  });
  T.forEach(([a, b], j) => {
    const x = 7.5 + j * 0.9;
    [[a, 5.3], [b, 5.57]].forEach(([v, y], r) => txt(s, String(v), x, y, 0.7, 0.24, { fontSize: 13, align: 'center', valign: 'middle', objectName: 'c3_fade_t' + r + j }));
    pill(s, String(a * b), x + 0.05, 5.82, 0.6, 0.24, GOLD, DKG, 12, { objectName: 'c4_fade_p' + j });
  });
  math(s, 's5_b1', 10.3, 5.58, { s: 1.0, name: 'c4_fade_eb1', vc: true });
  whatif(s, 6.4, 6.12, 6.45, 0.75, 'Table (1, 3), (2, 6), (4, 12): direct or inverse?', 's5_w', 'c5', { tw: 3.7, fs: 11.5, ms: 1.0 });
  cue(n, 'click 1 formulas, both axes, Example A | click 2 the direct line and its points (y/x constant) | click 3 the inverse curve and Example A solved, Example B table | click 4 the three products are all 24 | click 5 What if (1,3),(2,6),(4,12): predict first. Route: >30% test the wrong quantity -> say "direct: divide, inverse: multiply".');
  notes(s, n);
}
// 6 writing equations
{
  const s = pres.addSlide(); const n = 6;
  chrome(s, n, 2, 'Writing inverse variation equations');
  card(s, 0.4, 1.85, 5.8, 4.95, { objectName: 'c1_fade_dcard' });
  fig(s, 'md', '0', 0.6, 2.2, 'c1_fade_ax'); fig(s, 'md', '1', 0.6, 2.2, 'c4_wipe_curve');
  fig(s, 'md', '2', 0.6, 2.2, 'c5_fade_pts'); fig(s, 'md', '3', 0.6, 2.2, 'c6_fade_wip');
  txt(s, 'Example B: machines and days', 0.65, 6.3, 5.4, 0.35, { fontSize: 12, italic: true, color: GREY, objectName: 'c4_fade_cap' });
  banner(s, 6.4, 1.85, 6.45, 0.8, [['s6_f1', 1.1], ['s6_f2', 1.1]], { name: 'c1_fade_ban' });
  card(s, 6.4, 2.8, 6.45, 1.75, { objectName: 'c1_fade_ea' });
  pill(s, 'EXAMPLE A', 6.6, 2.92, 1.3, 0.3, TEAL, WHITE, 11, { objectName: 'c1_fade_eal' });
  math(s, 's6_a0', 6.6, 3.3, { s: 1.0, name: 'c1_fade_ea0' });
  math(s, 's6_a1', 6.6, 3.62, { s: 1.3, name: 'c2_fade_ea1' });
  math(s, 's6_a2', 9.6, 3.68, { s: 1.3, name: 'c3_fade_ea2' });
  card(s, 6.4, 4.7, 6.45, 1.2, { objectName: 'c4_fade_eb' });
  pill(s, 'EXAMPLE B', 6.6, 4.82, 1.3, 0.3, ORG, WHITE, 11, { objectName: 'c4_fade_ebl' });
  math(s, 's6_b0', 8.05, 4.97, { s: 1.1, vc: true, name: 'c4_fade_eb0' });
  math(s, 's6_b1', 6.6, 5.3, { s: 1.35, name: 'c5_fade_eb1' });
  whatif(s, 6.4, 6.05, 6.45, 0.8, 'What if you want the job done in 5 days? Predict the machines.', 's6_w', 'c6', { tw: 3.2, fs: 11, ms: 1.0 });
  cue(n, 'click 1 formulas and Example A givens | click 2 find k from one pair | click 3 solve for x | click 4 Example B: the hyperbola draws | click 5 the two points sit on it: 5x12 = 8x7.5 | click 6 What if 5 days: the gold point (12, 5). Route: >30% get d = 19.2 -> ask "should more machines take more days?".');
  notes(s, n);
}
// 7 graph y = k/x
{
  const s = pres.addSlide(); const n = 7;
  chrome(s, n, 2, 'Graphing y = k/x');
  card(s, 0.4, 1.85, 5.8, 4.95, { objectName: 'c1_fade_dcard' });
  fig(s, 'hyp', '0', 0.6, 2.2, 'c1_fade_ax'); fig(s, 'hyp', '1', 0.6, 2.2, 'c2_wipe_asy');
  fig(s, 'hyp', '2', 0.6, 2.2, 'c3_wipe_pos'); fig(s, 'hyp', '3', 0.6, 2.2, 'c4_wipe_neg');
  banner(s, 6.4, 1.85, 6.45, 0.85, [['s7_f1', 1.1], ['s7_f2', 1.1]], { name: 'c1_fade_ban' });
  card(s, 6.4, 2.85, 6.45, 1.55, { objectName: 'c3_fade_ea' });
  pill(s, 'EXAMPLE A', 6.6, 2.97, 1.3, 0.3, TEAL, WHITE, 11, { objectName: 'c3_fade_eal' });
  math(s, 's7_a0', 8.2, 3.12, { s: 1.35, vc: true, name: 'c3_fade_ea0' });
  math(s, 's7_a1', 6.6, 3.55, { s: 1.3, name: 'c3_fade_ea1' });
  math(s, 's7_a2', 6.6, 3.95, { s: 1.3, name: 'c3_fade_ea2' });
  card(s, 6.4, 4.55, 6.45, 1.55, { objectName: 'c4_fade_eb' });
  pill(s, 'EXAMPLE B', 6.6, 4.67, 1.3, 0.3, ORG, WHITE, 11, { objectName: 'c4_fade_ebl' });
  math(s, 's7_b0', 8.2, 4.82, { s: 1.35, vc: true, name: 'c4_fade_eb0' });
  math(s, 's7_b1', 6.6, 5.25, { s: 1.3, name: 'c4_fade_eb1' });
  math(s, 's7_b2', 6.6, 5.65, { s: 1.3, name: 'c4_fade_eb2' });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 6.4, y: 6.25, w: 6.45, h: 0.6, rectRadius: 0.1, fill: { color: GOLDBG }, line: { color: GOLD, width: 1.25 }, objectName: 'c5_fade_ins' });
  txt(s, 'NOTICE', 6.6, 6.25, 1.0, 0.6, { fontSize: 11, bold: true, color: BROWN, charSpacing: 2, valign: 'middle', objectName: 'c5_fade_insl' });
  math(s, 's7_n', 7.7, 6.55, { s: 1.0, vc: true, name: 'c5_fade_insm' });
  cue(n, 'click 1 formulas, axes | click 2 the axes light up as asymptotes: ask what y is when x = 0 | click 3 y = 4/x draws in quadrants I and III with Example A | click 4 y = -4/x in II and IV | click 5 end behaviour. Route: branches joined through the origin -> return to the table.');
  notes(s, n);
}
// 8 transformations
{
  const s = pres.addSlide(); const n = 8;
  chrome(s, n, 2, 'Transformations of the reciprocal function');
  card(s, 0.4, 1.85, 5.8, 4.95, { objectName: 'c1_fade_dcard' });
  fig(s, 'sh', '0', 0.55, 2.2, 'c1_fade_ax'); fig(s, 'sh', '1', 0.55, 2.2, 'c1_wipe_par');
  fig(s, 'sh', '2', 0.55, 2.2, 'c3_wipe_asy'); fig(s, 'sh', '3', 0.55, 2.2, 'c4_wipe_new'); fig(s, 'sh', '4', 0.55, 2.2, 'c5_fade_ints');
  banner(s, 6.4, 1.85, 6.45, 0.85, [['s8_f1', 1.2], ['s8_f2', 1.0]], { name: 'c1_fade_ban' });
  card(s, 6.4, 2.85, 6.45, 2.1, { objectName: 'c1_fade_ea' });
  pill(s, 'EXAMPLE A', 6.6, 2.97, 1.3, 0.3, TEAL, WHITE, 11, { objectName: 'c1_fade_eal' });
  math(s, 's8_a0', 8.25, 3.12, { s: 1.3, vc: true, name: 'c1_fade_ea0' });
  math(s, 's8_a1', 6.6, 3.5, { s: 1.25, name: 'c2_fade_ea1' });
  math(s, 's8_a2', 6.6, 3.95, { s: 1.25, name: 'c2_fade_ea2' });
  math(s, 's8_a3', 6.6, 4.4, { s: 1.25, name: 'c2_fade_ea3' });
  card(s, 6.4, 5.1, 6.45, 1.7, { objectName: 'c3_fade_eb' });
  pill(s, 'EXAMPLE B', 6.6, 5.22, 1.3, 0.3, ORG, WHITE, 11, { objectName: 'c3_fade_ebl' });
  math(s, 's8_b0', 8.25, 5.37, { s: 1.3, vc: true, name: 'c3_fade_eb0' });
  math(s, 's8_b1', 6.6, 5.8, { s: 1.3, name: 'c3_fade_eb1' });
  math(s, 's8_b2', 6.6, 6.28, { s: 1.3, name: 'c5_fade_eb2' });
  cue(n, 'click 1 formulas, parent y = 1/x, Example A (text) | click 2 Example A solved | click 3 Example B: the asymptotes move to x = 2 and y = 3 | click 4 the whole curve slides to the new asymptotes | click 5 the two intercepts. Route: x + 3 read as right -> "which x makes the denominator 0?".');
  notes(s, n);
}
L.practice(9, [
  ['PRACTICE', 'Secure the method', TEAL, [['s9_p1', 'slide 6'], ['s9_p2', 'slide 7']], 'k comes from the product x times y, the equation is y equals k over x, and the asymptotes are written as equations of lines.'],
  ['APPLY', 'Use it in context', ORG, [['s9_a1', 'slide 5'], ['s9_a2', 'slide 8']], 'you test the product or the ratio before deciding, and each intercept is checked by substituting it back.'],
  ['INVESTIGATE', 'Find out why', NAVY, [['s9_i1', 'slide 7'], ['s9_i2', 'slide 8']], 'your argument names the value that is excluded, and a numerical check (a table value or a substitution) supports it.']], 'Each "stuck?" tag is the slide to return to.');
L.production(10, 'Production: A school trip to the Red Sea coast', {
  left(s) {
    fig(s, 'cs', '0', 0.5, 1.9, 'c1_fade_ax'); fig(s, 'cs', '1', 0.5, 1.9, 'c2_wipe_c1');
    fig(s, 'cs', '2', 0.5, 1.9, 'c3_wipe_c2'); fig(s, 'cs', '3', 0.5, 1.9, 'c4_fade_t');
    math(s, 's10_chk', 0.65, 6.5, { s: 1.0, name: 'c6_fade_chk' });
  },
  model: 'A Jeddah school hires one coach for a Vision 2030 tourism visit to the Red Sea coast (model values only, not real data). The coach costs 1 800 SAR, shared equally by the n students who go. Each student also pays a fixed 20 SAR for snacks.',
  tasks: ['Write the cost per student for the coach alone as an inverse variation. State the constant of variation and its meaning; find the cost for 30 and for 45 students.', 'Write the total cost with snacks as a transformation of the reciprocal function. State both asymptotes and what the horizontal one means.', 'Each student pays exactly 50 SAR in total. Find n, and explain why the total can never fall below 20 SAR.'],
  hint: 'Hint: subtract 20 from 50 first, then solve 30 = 1800 over n.', wiText: 'WHAT IF the coach costs 2 400 SAR for 60 students?', wiMath: 's10_wi',
  cue: 'click 1 the model and axes | click 2 the coach-only curve c = 1800/n with 30 and 45 students | click 3 the curve lifts 20 SAR: new asymptote c = 20 | click 4 the 50 SAR target gives n = 60 | click 5 hint and What if | click 6 check your answers. Route: >30% cannot start Task 1 -> slides 5 and 6.' });
L.gate(11, [['s11_1', 'slide 6', TEAL], ['s11_2', 'slide 5', ORG], ['s11_3', 'slide 8', NAVY]], 'Q1 missed -> slide 6; Q2 -> slide 5; Q3 -> slide 8.');
L.smart(12, ['Choose whole numbers h and k and write your own reciprocal function of the form 1 over (x minus h) plus k.', 'Swap with a partner: state the asymptotes, domain and range, then find both intercepts and sketch the graph.', 'Add a What if...? question (change the sign of h or of k, or use a numerator of 2) with a prediction and a test.'], [0.8, 0.95, 0.95],
  'your function has two correct asymptotes, your partner finds both intercepts, and your What if...? question has a prediction and a test.', ['s12_1', 's12_2'], '4-2 Graphing Rational Functions', 'Exit 1 missed -> slide 8 Example B next lesson; Exit 2 missed -> slide 6 Example A.');
L.exam(13, [
  ['SAT', 'Advanced Math · grid-in', NAVY, 's13_s0', ['s13_s1', 's13_s2', 's13_s3'], 'Trap: a direct proportion gives 4/15 x 6 = 1.6.'],
  ['GAT', 'Qudurat · quantitative comparison', TEAL, 's13_g0', ['s13_g1', 's13_g2', 's13_g3'], 'Trap: multiplying instead of dividing, or treating it as direct (y = 36).'],
  ['SAAT', 'Tahsili · four options', ORG, 's13_a0', ['s13_a1', 's13_a2', 's13_a3'], 'Trap: B is the DOMAIN (x not 3); D has the wrong sign of k.']], 'SAT miss -> slide 6 Example A; GAT -> slide 6 Example B; SAAT -> slide 8.');
L.complete(14, 'Inverse variation is y equals k over x with xy constant; its graph has the axes as asymptotes, and 1 over (x minus h) plus k moves the asymptotes to x equals h and y equals k.', 'Next lesson: 4-2 Graphing Rational Functions');
L.write('raw.pptx').then(f => console.log('wrote', f));
