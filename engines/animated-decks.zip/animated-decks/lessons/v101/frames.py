import json, math, os, shutil
from PIL import Image
FI = json.load(open('f/info.json')); DPI = 220
OUT = 'fr'; shutil.rmtree(OUT, ignore_errors=True); os.makedirs(OUT)
def ease(t): return t * t * (3 - 2 * t)
MAN = {}
def frames(name, rotname, start_delta, spin):
    R = FI[rotname]; src = Image.open(R['layers'][0]['file']).convert('RGBA')
    K = (round(spin / 3) if spin <= 45 else round(spin / 4)) + 1
    out = []
    for k in range(K):
        ang = start_delta + spin * ease(k / (K - 1))
        im = src.rotate(ang, resample=Image.BICUBIC) if abs(ang) > 1e-6 else src.copy()
        bb = im.getchannel('A').point(lambda v: 255 if v > 8 else 0).getbbox()
        c = im.crop(bb); p = f'{OUT}/{name}_{k:03d}.png'; c.save(p)
        ox = R['origin'][0] - R['w'] / 2; oy = R['origin'][1] - R['h'] / 2
        out.append({'file': p, 'x': ox + bb[0] / DPI, 'y': oy + bb[1] / DPI, 'w': c.width / DPI, 'h': c.height / DPI})
    MAN[name] = out; print(name, K, 'frames')
frames('s1', 's1r', 0, 33.69)
frames('s7a', 's7r', 0, 30)
frames('s7b', 's7g', 0, 120)
for n in ('s9a', 's9b', 's9c'):
    frames(n, n + 'r', 0, FI[n + 'r']['spin'])
json.dump(MAN, open(f'{OUT}/manifest.json', 'w'))
