import re, os, shutil, zipfile, sys, json
SRC, DST = 'raw.pptx', 'out.pptx'
X = 'x2'
shutil.rmtree(X, ignore_errors=True)
zipfile.ZipFile(SRC).extractall(X)
MORPH = ('<mc:AlternateContent xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006">'
 '<mc:Choice xmlns:p159="http://schemas.microsoft.com/office/powerpoint/2015/09/main" xmlns:p14="http://schemas.microsoft.com/office/powerpoint/2010/main" Requires="p159">'
 '<p:transition spd="slow" p14:dur="1600"><p159:morph option="byObject"/></p:transition></mc:Choice>'
 '<mc:Fallback><p:transition spd="slow"><p:fade/></p:transition></mc:Fallback></mc:AlternateContent>')
FADE_T = '<p:transition spd="med"><p:fade/></p:transition>'
NAME = re.compile(r'^(c([1-9]\d*)|d(\d+))_(fade|wipe|vid|rot(-?[\d.]+)|fr(\d+)o(\d+))(?:@(\d+))?_')

class Ids:
    def __init__(s): s.n = 2
    def __call__(s): s.n += 1; return s.n

def vid_eff(ids, spid, node, delay):
    a, b, c, d = ids(), ids(), ids(), ids()
    return (f'<p:par><p:cTn id="{a}" presetID="1" presetClass="entr" presetSubtype="0" fill="hold" nodeType="{node}"><p:stCondLst><p:cond delay="{delay}"/></p:stCondLst><p:childTnLst>'
            f'<p:set><p:cBhvr><p:cTn id="{b}" dur="1" fill="hold"><p:stCondLst><p:cond delay="0"/></p:stCondLst></p:cTn><p:tgtEl><p:spTgt spid="{spid}"/></p:tgtEl><p:attrNameLst><p:attrName>style.visibility</p:attrName></p:attrNameLst></p:cBhvr><p:to><p:strVal val="visible"/></p:to></p:set>'
            f'</p:childTnLst></p:cTn></p:par>'
            f'<p:par><p:cTn id="{c}" presetID="1" presetClass="mediacall" presetSubtype="0" fill="hold" nodeType="withEffect"><p:stCondLst><p:cond delay="{delay + 50}"/></p:stCondLst><p:childTnLst>'
            f'<p:cmd type="call" cmd="playFrom(0.0)"><p:cBhvr><p:cTn id="{d}" dur="1" fill="hold"/><p:tgtEl><p:spTgt spid="{spid}"/></p:tgtEl></p:cBhvr></p:cmd></p:childTnLst></p:cTn></p:par>')

def appear(ids, spid, node, delay, hide=False):
    a, b = ids(), ids()
    cls, pv = ('exit', 'hidden') if hide else ('entr', 'visible')
    return (f'<p:par><p:cTn id="{a}" presetID="1" presetClass="{cls}" presetSubtype="0" fill="hold" nodeType="{node}"><p:stCondLst><p:cond delay="{delay}"/></p:stCondLst><p:childTnLst>'
            f'<p:set><p:cBhvr><p:cTn id="{b}" dur="1" fill="hold"><p:stCondLst><p:cond delay="0"/></p:stCondLst></p:cTn><p:tgtEl><p:spTgt spid="{spid}"/></p:tgtEl><p:attrNameLst><p:attrName>style.visibility</p:attrName></p:attrNameLst></p:cBhvr><p:to><p:strVal val="{pv}"/></p:to></p:set>'
            f'</p:childTnLst></p:cTn></p:par>')

STEP = 60
def effect(ids, spid, eff, node, delay=0, dur=500):
    if eff.startswith('fr'):
        k, K = map(int, re.match(r'fr(\d+)o(\d+)', eff).groups())
        x = appear(ids, spid, node if k == 0 else 'withEffect', delay + k * STEP)
        if k < K - 1: x += appear(ids, spid, 'withEffect', delay + (k + 1) * STEP, hide=True)
        return x
    if eff == 'vid':
        return vid_eff(ids, spid, node, delay)
    if eff.startswith('rot'):
        deg = float(eff[3:])
        return effect(ids, spid, 'fade', node, delay, 300) + spin(ids, spid, deg, delay + 300)
    a, b, c = ids(), ids(), ids()
    if eff == 'wipe':
        preset, sub, filt = 22, 8, 'wipe(left)'
    else:
        preset, sub, filt = 10, 0, 'fade'
    return (f'<p:par><p:cTn id="{a}" presetID="{preset}" presetClass="entr" presetSubtype="{sub}" fill="hold" grpId="0" nodeType="{node}">'
            f'<p:stCondLst><p:cond delay="{delay}"/></p:stCondLst><p:childTnLst>'
            f'<p:set><p:cBhvr><p:cTn id="{b}" dur="1" fill="hold"><p:stCondLst><p:cond delay="0"/></p:stCondLst></p:cTn>'
            f'<p:tgtEl><p:spTgt spid="{spid}"/></p:tgtEl><p:attrNameLst><p:attrName>style.visibility</p:attrName></p:attrNameLst></p:cBhvr>'
            f'<p:to><p:strVal val="visible"/></p:to></p:set>'
            f'<p:animEffect transition="in" filter="{filt}"><p:cBhvr><p:cTn id="{c}" dur="{dur}"/><p:tgtEl><p:spTgt spid="{spid}"/></p:tgtEl></p:cBhvr></p:animEffect>'
            f'</p:childTnLst></p:cTn></p:par>')

def spin(ids, spid, deg, delay):
    a, b = ids(), ids()
    dur = int(800 + abs(deg) * 10)
    return (f'<p:par><p:cTn id="{a}" presetID="8" presetClass="emph" presetSubtype="0" accel="50000" decel="50000" fill="hold" nodeType="withEffect">'
            f'<p:stCondLst><p:cond delay="{delay}"/></p:stCondLst><p:childTnLst>'
            f'<p:animRot by="{int(deg * 60000)}"><p:cBhvr><p:cTn id="{b}" dur="{dur}" fill="hold"/><p:tgtEl><p:spTgt spid="{spid}"/></p:tgtEl>'
            f'<p:attrNameLst><p:attrName>r</p:attrName></p:attrNameLst></p:cBhvr></p:animRot></p:childTnLst></p:cTn></p:par>')

def build_timing(items):
    # items: list of (spid, kind sp|pic, grp('c3' or 'd500'), eff)
    ids = Ids(); pars = []; bld = []
    seen = set()
    for spid, kind, g, eff, ex in items:
        if kind == 'sp' and spid not in seen:
            bld.append(f'<p:bldP spid="{spid}" grpId="0" animBg="1"/>'); seen.add(spid)
    autos = [i for i in items if i[2][0] == 'd']
    clicks = {}
    for i in items:
        if i[2][0] == 'c': clicks.setdefault(int(i[2][1:]), []).append(i)
    if autos:
        o, inn = ids(), ids()
        eff_xml = ''
        for k, (spid, kind, g, eff, ex) in enumerate(autos):
            eff_xml += effect(ids, spid, eff, 'afterEffect' if k == 0 else 'withEffect', delay=int(g[1:]) + ex, dur=600)
        pars.append(f'<p:par><p:cTn id="{o}" fill="hold"><p:stCondLst><p:cond delay="indefinite"/><p:cond evt="onBegin" delay="0"><p:tn val="2"/></p:cond></p:stCondLst><p:childTnLst>'
                    f'<p:par><p:cTn id="{inn}" fill="hold"><p:stCondLst><p:cond delay="0"/></p:stCondLst><p:childTnLst>{eff_xml}</p:childTnLst></p:cTn></p:par></p:childTnLst></p:cTn></p:par>')
    for kk in sorted(clicks):
        o, inn = ids(), ids()
        eff_xml = ''
        for k, (spid, kind, g, eff, ex) in enumerate(clicks[kk]):
            eff_xml += effect(ids, spid, eff, 'clickEffect' if k == 0 else 'withEffect', delay=ex)
        pars.append(f'<p:par><p:cTn id="{o}" fill="hold"><p:stCondLst><p:cond delay="indefinite"/></p:stCondLst><p:childTnLst>'
                    f'<p:par><p:cTn id="{inn}" fill="hold"><p:stCondLst><p:cond delay="0"/></p:stCondLst><p:childTnLst>{eff_xml}</p:childTnLst></p:cTn></p:par></p:childTnLst></p:cTn></p:par>')
    bl = f'<p:bldLst>{"".join(bld)}</p:bldLst>' if bld else ''
    return ('<p:timing><p:tnLst><p:par><p:cTn id="1" dur="indefinite" restart="never" nodeType="tmRoot"><p:childTnLst>'
            '<p:seq concurrent="1" nextAc="seek"><p:cTn id="2" dur="indefinite" nodeType="mainSeq"><p:childTnLst>' + ''.join(pars) +
            '</p:childTnLst></p:cTn><p:prevCondLst><p:cond evt="onPrev" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:prevCondLst>'
            '<p:nextCondLst><p:cond evt="onNext" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:nextCondLst></p:seq>'
            f'</p:childTnLst></p:cTn></p:par></p:tnLst>{bl}</p:timing>')

d = f'{X}/ppt/slides'
tot = 0
for fn in sorted(os.listdir(d), key=lambda f: int(re.sub(r'\D', '', f) or 0)):
    if not fn.endswith('.xml'): continue
    n = int(re.sub(r'\D', '', fn))
    p = f'{d}/{fn}'; xml = open(p, encoding='utf8').read()
    VN = json.load(open('vidnames.json')).get(str(n), [])
    if VN:
        it = iter(VN)
        def ren(m):
            blk = m.group(0)
            if 'videoFile' not in blk: return blk
            try: nm = next(it)
            except StopIteration: return blk
            return re.sub(r'(<p:cNvPr id="\d+" name=")[^"]*(")', lambda q: q.group(1) + nm + q.group(2), blk, count=1)
        xml = re.sub(r'<p:pic>.*?</p:pic>', ren, xml, flags=re.S)
    items = []
    for m in re.finditer(r'<p:cNvPr id="(\d+)" name="([^"]*)"', xml):
        mm = NAME.match(m.group(2))
        if not mm: continue
        pre = xml[:m.start()]
        kind = 'pic' if pre.rfind('<p:pic>') > pre.rfind('<p:sp>') else 'sp'
        grp = ('c' + mm.group(2)) if mm.group(2) else ('d' + mm.group(3))
        items.append((m.group(1), kind, grp, mm.group(4), int(mm.group(8) or 0)))
    trans = FADE_T if n == 1 else MORPH
    xml = re.sub(r'<p:transition.*?</p:transition>', '', xml, flags=re.S)
    xml = re.sub(r'<p:timing>.*?</p:timing>', '', xml, flags=re.S)
    add = trans + (build_timing(items) if items else '')
    if '</p:clrMapOvr>' in xml:
        xml = xml.replace('</p:clrMapOvr>', '</p:clrMapOvr>' + add, 1)
    else:
        xml = xml.replace('</p:cSld>', '</p:cSld>' + add, 1)
    open(p, 'w', encoding='utf8').write(xml)
    print(fn, len(items), 'animated'); tot += len(items)
if os.path.exists(DST): os.remove(DST)
with zipfile.ZipFile(DST, 'w', zipfile.ZIP_DEFLATED) as z:
    # content types first
    z.write(f'{X}/[Content_Types].xml', '[Content_Types].xml')
    for root, _, files in os.walk(X):
        for f in files:
            full = os.path.join(root, f); rel = os.path.relpath(full, X)
            if rel == '[Content_Types].xml': continue
            z.write(full, rel)
print('total', tot)
