const pptxgen = require('pptxgenjs');
const fs = require('fs');
const M = JSON.parse(fs.readFileSync('m/manifest.json'));
const FI = JSON.parse(fs.readFileSync('f/info.json'));
const NOTES = JSON.parse(fs.readFileSync('notes.json'));

const TEAL = '17A199', ORG = 'E8762C', NAVY = '1F3864', DKG = '0E4F4C', GOLD = 'F0B323', BG = 'F4F8F7', GREY = '5A6B69', BORDER = 'DDE6E4', INK = '1B2B2A', WHITE = 'FFFFFF', DEEP = '0B3331', GOLDBG = 'FFF4D6', BROWN = '7A5200';
const CODES = '(+)HSN.VM.A.1 · (+)HSN.VM.A.2 · (+)HSN.VM.A.3 · (+)HSN.VM.B.4 · (+)HSN.VM.B.4.A · (+)HSN.VM.B.4.B · (+)HSN.VM.B.4.C · (+)HSN.VM.B.5 · (+)HSN.VM.B.5.A · (+)HSN.VM.B.5.B';
const STN = ['DIAGNOSE', 'TARGETED INSTRUCTION', 'PRACTICE', 'PRODUCTION', 'MASTERY GATE', 'SMART PRODUCTION'];
const MIN = [6, 18, 12, 12, 6, 6];

const pres = new pptxgen();
pres.layout = 'LAYOUT_WIDE';
pres.title = 'Lesson 10-1 Introduction to Vectors (Grade 11, Week 12)';
pres.author = 'Mr Malek Thiab';

const sh = () => ({ type: 'outer', color: '000000', opacity: 0.13, blur: 7, offset: 2, angle: 90 });
const ANIM = {}; // slide number -> cue lines
const cue = (n, s) => { (ANIM[n] = ANIM[n] || []).push(s); };

function txt(s, t, x, y, w, h, o = {}) {
  s.addText(t, Object.assign({ x, y, w, h, isTextBox: true, margin: 0, fontFace: 'Calibri', fontSize: 14, color: INK, valign: 'top' }, o));
}
function card(s, x, y, w, h, o = {}) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, Object.assign({ x, y, w, h, rectRadius: 0.12, fill: { color: WHITE }, line: { color: BORDER, width: 1 }, shadow: sh() }, o));
}
function pill(s, t, x, y, w, h, fill, color = WHITE, fs = 11, o = {}) {
  s.addText(t, Object.assign({ x, y, w, h, shape: pres.shapes.ROUNDED_RECTANGLE, rectRadius: 0.5, fill: { color: fill }, color, fontFace: 'Calibri', fontSize: fs, bold: true, align: 'center', valign: 'middle', margin: 0, isTextBox: true }, o));
}
function math(s, key, x, y, o = {}) {
  const m = M[key]; const sc = o.s || 1.3;
  const w = m.w * sc, h = m.h * sc;
  let xx = x;
  if (o.align === 'c') xx = x - w / 2; else if (o.align === 'r') xx = x - w;
  let yy = y; if (o.vc) yy = y - h / 2;
  const opts = { path: m.file, x: xx, y: yy, w, h };
  if (o.name) opts.objectName = o.name;
  s.addImage(opts);
  return { w, h };
}
function fig(s, name, key, x, y, objName) {
  const F = FI[name]; const L = F.layers.find(l => l.key === key);
  const opts = { path: L.file, x, y, w: F.w, h: F.h };
  if (objName) opts.objectName = objName;
  s.addImage(opts);
}
const VIDN = {};
const FR = JSON.parse(fs.readFileSync('fr/manifest.json'));
function frames(s, key, px, py, g, nm, ex) {
  const L = FR[key]; const K = L.length;
  L.forEach((f, k) => s.addImage({ path: f.file, x: px + f.x, y: py + f.y, w: f.w, h: f.h, objectName: `${g}_fr${k}o${K}${ex ? '@' + ex : ''}_${nm}` }));
  return K;
}
function vid(s, n, key, x, y, w, h, objName) {
  const cover = 'image/png;base64,' + fs.readFileSync(`vid/${key}_cover.png`).toString('base64');
  s.addMedia({ type: 'video', path: `vid/${key}.mp4`, cover, x, y, w, h });
  (VIDN[n] = VIDN[n] || []).push(objName);
}
function rot(s, name, px, py, objName) {
  const F = FI[name]; const L = F.layers[0];
  s.addImage({ path: L.file, x: px + F.origin[0] - F.w / 2, y: py + F.origin[1] - F.h / 2, w: F.w, h: F.h, objectName: objName });
}
function dots(s, cur, dark) {
  for (let i = 0; i < 6; i++) {
    const on = i + 1 === cur;
    const d = on ? 0.2 : 0.12;
    s.addShape(pres.shapes.OVAL, { x: 5.77 + i * 0.32 + 0.1 - d / 2, y: 0.38 - d / 2 + 0.0, w: d, h: d, fill: { color: on ? ORG : (dark ? '6FA9A5' : 'B9CFCC') }, line: { color: on ? WHITE : (dark ? '6FA9A5' : 'B9CFCC'), width: on ? 1.5 : 0 }, objectName: '!!dot' + (i + 1) });
  }
}
function chrome(s, n, stn, title, o = {}) {
  s.background = { color: o.dark ? DEEP : BG };
  s.addImage({ path: o.dark ? 'assets/dept_w.png' : 'assets/dept.png', x: 0.4, y: 0.2, w: 1.6, h: 0.49, objectName: '!!logo_dept' });
  s.addImage({ path: o.dark ? 'assets/school_w.png' : 'assets/school.png', x: 12.33, y: 0.17, w: 0.62, h: 0.62, objectName: '!!logo_school' });
  if (stn) {
    dots(s, stn, o.dark);
    txt(s, `STATION ${stn}  ·  ${STN[stn - 1]}  ·  ${MIN[stn - 1]} MIN`, 0.5, 0.88, 9, 0.26, { fontSize: 12, bold: true, color: ORG, charSpacing: 1.5, objectName: '!!tag' });
  }
  txt(s, title, 0.5, 1.12, 12.3, 0.6, { fontFace: 'Cambria', fontSize: 30, bold: true, color: o.dark ? WHITE : NAVY, valign: 'middle', objectName: '!!title' });
  txt(s, CODES, 0.5, 7.02, 8.7, 0.34, { fontSize: 8, color: o.dark ? '8FB5B1' : GREY, valign: 'top' });
  txt(s, 'FAITH, RIGHTEOUSNESS AND WISDOM', 8.9, 7.02, 2.5, 0.2, { fontSize: 8, bold: true, color: o.dark ? '8FB5B1' : GREY, align: 'right' });
  txt(s, `Mr Malek Thiab  ·  ${n}`, 11.5, 7.02, 1.33, 0.2, { fontSize: 9, bold: true, color: o.dark ? WHITE : NAVY, align: 'right' });
}
function banner(s, x, y, w, h, items, o = {}) {
  // dark formula banner; items: [key, scale]
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.12, fill: { color: DKG }, line: { color: DKG }, shadow: sh(), objectName: o.name });
  let tot = items.reduce((a, [k, sc]) => a + M[k].w * (sc || 1.2), 0);
  const gap = (w - 0.5 - tot) / Math.max(1, items.length - 1);
  let cx = x + 0.25;
  const nm = o.name;
  items.forEach(([k, sc]) => {
    const r = math(s, k, cx, y + h / 2, { s: sc || 1.2, vc: true, name: nm ? nm + '_f' : undefined });
    cx += r.w + (items.length > 1 ? Math.min(gap, 1.2) : 0);
  });
}
function notes(s, n) {
  s.addNotes((NOTES[n] || '') + '\n\nANIMATION CUES (click to advance): ' + (ANIM[n] || ['none']).join(' | '));
}

// =================================================================== 1 title
{
  const s = pres.addSlide(); const n = 1;
  s.background = { color: BG };
  s.addImage({ path: 'assets/dept.png', x: 0.45, y: 0.22, w: 1.7, h: 0.52, objectName: '!!logo_dept' });
  s.addImage({ path: 'assets/cognia.png', x: 6.13, y: 0.12, w: 1.0, h: 0.75 });
  s.addImage({ path: 'assets/school.png', x: 12.2, y: 0.15, w: 0.7, h: 0.7, objectName: '!!logo_school' });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.5, y: 1.05, w: 12.33, h: 5.55, rectRadius: 0.2, fill: { color: DKG }, line: { color: DKG }, shadow: sh(), objectName: 'd0_fade_hero' });
  txt(s, 'GRADE 11  ·  ALGEBRA II  ·  TOPIC 10', 0.95, 1.55, 6, 0.3, { fontSize: 13, bold: true, color: GOLD, charSpacing: 2, objectName: 'd400_fade_kick' });
  txt(s, 'Lesson 10-1', 0.95, 1.95, 6, 0.5, { fontFace: 'Cambria', fontSize: 24, color: 'BFE3DF', objectName: 'd700_fade_l' });
  txt(s, 'Introduction\nto Vectors', 0.95, 2.45, 6.2, 1.9, { fontFace: 'Cambria', fontSize: 50, bold: true, color: WHITE, valign: 'top', lineSpacingMultiple: 0.95, objectName: 'd900_wipe_h1' });
  pill(s, 'Journey of 6 stations, 60 minutes', 0.95, 4.55, 3.6, 0.45, ORG, WHITE, 14, { objectName: 'd1500_fade_pill' });
  txt(s, 'Magnitude, direction and the arithmetic of arrows', 0.95, 5.15, 6, 0.35, { fontSize: 15, color: 'BFE3DF', italic: true, objectName: 'd1700_fade_sub' });
  txt(s, 'Mr Malek Thiab  ·  Dar Al Fikr School', 0.95, 5.9, 6, 0.3, { fontSize: 13, bold: true, color: WHITE, objectName: 'd1900_fade_by' });
  txt(s, 'Up next: Matrices', 0.95, 6.22, 4, 0.25, { fontSize: 11, color: '8FB5B1', objectName: 'd1900_fade_up' });
  // hero diagram
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 7.05, y: 1.8, w: 5.6, h: 3.9, rectRadius: 0.15, fill: { color: '0A3F3C' }, line: { color: '1D6E69', width: 1 }, objectName: 'd600_fade_panel' });
  fig(s, 's1', '0', 7.05, 1.8, 'd900_fade_axes');
  fig(s, 's1', '1', 7.05, 1.8, 'd900_fade_dot');
  frames(s, 's1', 7.05, 1.8, 'd', 'vec', 1100);
  fig(s, 's1', '2', 7.05, 1.8, 'd1900_fade_comp');
  fig(s, 's1', '3', 7.05, 1.8, 'd2300_fade_ang');
  math(s, 's1_v', 7.4, 6.0, { s: 1.5, name: 'd2700_fade_lv' });
  math(s, 's1_m', 9.7, 6.0, { s: 1.5, name: 'd3100_fade_lm' });
  txt(s, 'FIKR Model  ·  Flipped PBL', 0.5, 7.0, 6, 0.25, { fontSize: 9, bold: true, color: GREY });
  cue(n, 'the whole opening plays by itself when the slide appears (about 4 seconds): hero card, title, axes, then the vector rotates from θ = 0 up to its angle, followed by components, angle and labels. No click needed.');
  notes(s, n);
}

// =================================================================== 2 journey map
{
  const s = pres.addSlide(); const n = 2;
  s.background = { color: DEEP };
  s.addImage({ path: 'assets/dept_w.png', x: 0.4, y: 0.2, w: 1.6, h: 0.49, objectName: '!!logo_dept' });
  s.addImage({ path: 'assets/school_w.png', x: 12.33, y: 0.17, w: 0.62, h: 0.62, objectName: '!!logo_school' });
  txt(s, "Today's journey", 0.5, 1.0, 12.3, 0.7, { fontFace: 'Cambria', fontSize: 34, bold: true, color: WHITE, objectName: '!!title' });
  txt(s, 'Six stations. Each one zooms in as we arrive.', 0.5, 1.7, 9, 0.35, { fontSize: 16, color: 'BFE3DF', italic: true });
  // faint rings
  [[10.5, 5.2, 4.2], [2.0, 6.2, 3.0]].forEach(([cx, cy, d]) => s.addShape(pres.shapes.OVAL, { x: cx - d / 2, y: cy - d / 2, w: d, h: d, fill: { color: DEEP, transparency: 100 }, line: { color: '17A199', width: 0.75, transparency: 70 } }));
  const xs = [1.4, 3.53, 5.66, 7.79, 9.92, 12.05];
  const ys = [3.15, 4.05, 3.15, 4.05, 3.15, 4.05];
  const desc = ['Three no-calculator checks', 'Vectors, components, direction, operations, dot product', 'Practice, Apply, Investigate', 'Navigating from Jeddah to NEOM', '3 of 3 unlocks the last station', 'Create one, then Time to Check'];
  const grp = [1, 1, 2, 2, 3, 3];
  for (let i = 0; i < 5; i++) {
    s.addShape(pres.shapes.LINE, { x: xs[i], y: Math.min(ys[i], ys[i + 1]), w: xs[i + 1] - xs[i], h: Math.abs(ys[i + 1] - ys[i]), flipV: ys[i + 1] < ys[i], line: { color: GOLD, width: 2.5, dashType: 'dash' }, objectName: `c${grp[i + 1]}_wipe_path${i}` });
  }
  for (let i = 0; i < 6; i++) {
    const d = 1.05, g = grp[i];
    s.addText(String(i + 1), { x: xs[i] - d / 2, y: ys[i] - d / 2, w: d, h: d, shape: pres.shapes.OVAL, fill: { color: i % 2 ? ORG : TEAL }, line: { color: WHITE, width: 3 }, color: WHITE, fontFace: 'Cambria', fontSize: 30, bold: true, align: 'center', valign: 'middle', margin: 0, isTextBox: true, shadow: sh(), objectName: `!!stn${i + 1}` });
    txt(s, STN[i], xs[i] - 1.0, ys[i] + 0.65, 2.0, 0.5, { fontSize: 14, bold: true, color: WHITE, align: 'center', valign: 'top', objectName: `c${g}_fade_n${i}` });
    pill(s, `${MIN[i]} min`, xs[i] - 0.4, ys[i] + 1.2, 0.8, 0.3, GOLD, DEEP, 12, { objectName: `c${g}_fade_m${i}` });
    txt(s, desc[i], xs[i] - 1.0, ys[i] + 1.6, 2.0, 0.8, { fontSize: 12, color: 'BFE3DF', align: 'center', objectName: `c${g}_fade_d${i}` });
  }
  txt(s, 'Total: 6 + 18 + 12 + 12 + 6 + 6 = 60 minutes', 0.5, 6.55, 12.3, 0.3, { fontSize: 13, color: GOLD, bold: true, align: 'center', objectName: 'c4_fade_total' });
  txt(s, CODES, 0.5, 7.02, 8.7, 0.34, { fontSize: 8, color: '8FB5B1' });
  txt(s, 'Mr Malek Thiab  ·  2', 11.5, 7.02, 1.33, 0.2, { fontSize: 9, bold: true, color: WHITE, align: 'right' });
  cue(n, 'click 1 stations 1-2 | click 2 stations 3-4 | click 3 stations 5-6 | click 4 total time');
  notes(s, n);
}

// =================================================================== 3 objectives
{
  const s = pres.addSlide(); const n = 3;
  chrome(s, n, 0, 'What we are learning');
  const obj = ['Define vectors and their properties for representing quantities with magnitude and direction.', 'Use position vectors for determining displacement.', 'Perform addition, subtraction, and scalar multiplication of vectors.', 'Calculate the dot product of vectors for use in geometric relationships.'];
  const pos = [[0.5, 1.95], [4.35, 1.95], [0.5, 4.45], [4.35, 4.45]];
  const col = [TEAL, ORG, NAVY, DKG];
  txt(s, 'OBJECTIVES', 0.5, 1.72, 4, 0.25, { fontSize: 11, bold: true, color: GREY, charSpacing: 2 });
  obj.forEach((o, i) => {
    const [x, y] = [pos[i][0], pos[i][1] + 0.12];
    card(s, x, y, 3.7, 2.3, { objectName: `c${i + 1}_fade_oc${i}` });
    s.addText(String(i + 1), { x: x + 0.2, y: y + 0.2, w: 0.6, h: 0.6, shape: pres.shapes.OVAL, fill: { color: col[i] }, color: WHITE, fontFace: 'Cambria', fontSize: 22, bold: true, align: 'center', valign: 'middle', margin: 0, isTextBox: true, objectName: `c${i + 1}_fade_on${i}` });
    txt(s, o, x + 0.2, y + 0.95, 3.3, 1.25, { fontSize: 15, color: INK, objectName: `c${i + 1}_fade_ot${i}` });
  });
  // vocabulary panel
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 8.3, y: 1.72, w: 4.55, h: 4.95, rectRadius: 0.15, fill: { color: DKG }, line: { color: DKG }, shadow: sh(), objectName: 'c5_fade_vp' });
  txt(s, 'VOCABULARY', 8.6, 1.95, 4, 0.25, { fontSize: 12, bold: true, color: GOLD, charSpacing: 2, objectName: 'c5_fade_vh' });
  const vocab = ['Vectors', 'Magnitude', 'Direction', 'direction angle', 'Components', 'component form', 'initial point', 'terminal point', 'displacement vector', 'equal vectors', 'opposite vector', 'zero vector', 'Scalar', 'scalar multiple', 'unit vector', 'dot product'];
  let cx = 8.6, cy = 2.4; const maxX = 12.6;
  vocab.forEach((v, i) => {
    const w = 0.2 + v.length * 0.092 + 0.12;
    if (cx + w > maxX) { cx = 8.6; cy += 0.5; }
    pill(s, v, cx, cy, w, 0.36, i % 3 === 0 ? TEAL : (i % 3 === 1 ? '1B6F6A' : '2A8A84'), WHITE, 12, { objectName: `c5_fade_v${i}` });
    cx += w + 0.1;
  });
  cue(n, 'click 1-4 objectives one at a time (ask which one feels least secure) | click 5 vocabulary');
  notes(s, n);
}

// =================================================================== 4 standards
{
  const s = pres.addSlide(); const n = 4;
  chrome(s, n, 0, 'Standards');
  const cols = [
    ['(+)HSN.VM.A: Represent and model', TEAL, [['(+)HSN.VM.A.1', 'Recognize vector quantities as having both magnitude and direction. Represent vector quantities by directed line segments, and use appropriate symbols for vectors and their magnitudes (e.g., v, │v│, ││v││, v).'], ['(+)HSN.VM.A.2', 'Find the components of a vector by subtracting the coordinates of an initial point from the coordinates of a terminal point.'], ['(+)HSN.VM.A.3', 'Solve problems involving velocity and other quantities that can be represented by vectors.']]],
    ['(+)HSN.VM.B.4: Add and subtract', ORG, [['(+)HSN.VM.B.4', 'Add and subtract vectors.'], ['(+)HSN.VM.B.4.A', 'Add vectors end-to-end, component-wise, and by the parallelogram rule. Understand that the magnitude of a sum of two vectors is typically not the sum of the magnitudes.'], ['(+)HSN.VM.B.4.B', 'Given two vectors in magnitude and direction form, determine the magnitude and direction of their sum.'], ['(+)HSN.VM.B.4.C', 'Understand vector subtraction v – w as v + (–w), where –w is the additive inverse of w, with the same magnitude as w and pointing in the opposite direction. Represent vector subtraction graphically by connecting the tips in the appropriate order, and perform vector subtraction component-wise and perform vector subtraction component-wise.']]],
    ['(+)HSN.VM.B.5: Multiply by a scalar', NAVY, [['(+)HSN.VM.B.5', 'Multiply a vector by a scalar.'], ['(+)HSN.VM.B.5.A', 'Represent scalar multiplication graphically by scaling vectors and possibly reversing their direction; perform scalar multiplication component-wise, e.g., as c(vx, vy) = (cvx, cvy).'], ['(+)HSN.VM.B.5.B', 'Compute the magnitude of a scalar multiple cv using ││cv││ = │c│v. Compute the direction of cv knowing that when │c│v ≠ 0, the direction of cv is either along v (for c > 0) or against v (for c < 0).']]],
  ];
  const xs = [0.5, 4.65, 8.8]; const ws = [3.95, 4.05, 4.05];
  cols.forEach(([h, c, items], i) => {
    card(s, xs[i], 1.9, ws[i], 4.95, { objectName: `c${i + 1}_fade_sc${i}` });
    pill(s, h, xs[i] + 0.15, 2.02, ws[i] - 0.3, 0.38, c, WHITE, 12, { objectName: `c${i + 1}_fade_sh${i}` });
    const runs = [];
    items.forEach(([code, t], j) => {
      runs.push({ text: code + '  ', options: { bold: true, color: c === ORG ? 'B8531A' : c, fontSize: 13 } });
      runs.push({ text: t, options: { color: INK, fontSize: 13, breakLine: j < items.length - 1 } });
    });
    txt(s, runs, xs[i] + 0.18, 2.55, ws[i] - 0.36, 4.2, { fontSize: 13, paraSpaceAfter: 9, objectName: `c${i + 1}_fade_st${i}` });
  });
  cue(n, 'click 1 column A | click 2 column B | click 3 column C. Standards are quoted verbatim, including the source duplicate in B.4.C.');
  notes(s, n);
}

// =================================================================== 5 diagnose
{
  const s = pres.addSlide(); const n = 5;
  chrome(s, n, 1, 'Start here: three quick checks');
  const keys = ['s5_c1', 's5_c2', 's5_c3'], ans = ['s5_a1', 's5_a2', 's5_a3'];
  const cols = [TEAL, ORG, NAVY];
  for (let i = 0; i < 3; i++) {
    const x = 0.5 + i * 4.15;
    card(s, x, 1.95, 3.95, 3.0, { objectName: `c0_x` });
  }
  // (c0 prefix is ignored by animate.py; static cards)
  for (let i = 0; i < 3; i++) {
    const x = 0.5 + i * 4.15;
    s.addText(String(i + 1), { x: x + 0.2, y: 2.15, w: 0.6, h: 0.6, shape: pres.shapes.OVAL, fill: { color: cols[i] }, color: WHITE, fontFace: 'Cambria', fontSize: 22, bold: true, align: 'center', valign: 'middle', margin: 0, isTextBox: true });
    pill(s, 'no calculator', x + 2.55, 2.28, 1.2, 0.32, 'E8F3F2', DKG, 11);
    const m = M[keys[i]]; const sc = Math.min(1.45, 3.55 / m.w);
    math(s, keys[i], x + 0.2, 3.05, { s: sc });
    // answer chip
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: x + 0.2, y: 3.95, w: 3.55, h: 0.75, rectRadius: 0.1, fill: { color: cols[i] }, line: { color: cols[i] }, objectName: `c1_fade_ac${i}` });
    txt(s, 'Answer', x + 0.4, 4.07, 1.2, 0.5, { fontSize: 13, bold: true, color: WHITE, valign: 'middle', objectName: `c1_fade_al${i}` });
    math(s, ans[i], x + 3.55, 4.32, { s: 1.45, align: 'r', vc: true, name: `c1_fade_am${i}` });
  }
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.5, y: 5.3, w: 12.3, h: 1.35, rectRadius: 0.12, fill: { color: GOLDBG }, line: { color: GOLD, width: 1.25 }, objectName: 'c2_fade_dw' });
  txt(s, 'DONE WHEN', 0.8, 5.5, 3, 0.3, { fontSize: 12, bold: true, color: BROWN, charSpacing: 2, objectName: 'c2_fade_dwl' });
  txt(s, 'All three answers are written without a calculator, and you can say which of them you will need when you find the length of a vector.', 0.8, 5.85, 11.7, 0.7, { fontSize: 16, color: INK, objectName: 'c2_fade_dwt' });
  cue(n, 'click 1 reveal the three answers | click 2 "Done when". Route: >30% miss Q1 rehearse distance before slide 6; Q2 draw 30-60-90 before slide 7; Q3 signed products before slide 9.');
  notes(s, n);
}

// =================================================================== 6 components & magnitude
{
  const s = pres.addSlide(); const n = 6;
  chrome(s, n, 2, 'Vectors, components and magnitude');
  card(s, 0.4, 1.85, 5.55, 4.95, { objectName: 'c1_fade_dcard' });
  const fx = 0.6, fy = 2.05;
  fig(s, 's6', '0', fx, fy, 'c1_fade_axes');
  fig(s, 's6', '1', fx, fy, 'c1_fade_pts');
  fig(s, 's6', '2', fx, fy, 'c2_wipe_arrow');
  fig(s, 's6', '3', fx, fy, 'c3_fade_legs');
  fig(s, 's6', '4', fx, fy, 'c4_fade_len');
  banner(s, 6.2, 1.85, 6.65, 0.85, [['s6_f1', 1.3], ['s6_f2', 1.3]], { name: 'c1_fade_ban' });
  // example A
  card(s, 6.2, 2.85, 6.65, 1.95, { objectName: 'c1_fade_ea' });
  pill(s, 'EXAMPLE A', 6.4, 3.0, 1.3, 0.32, TEAL, WHITE, 11, { objectName: 'c1_fade_eal' });
  math(s, 's6_a0', 7.9, 3.16, { s: 1.35, vc: true, name: 'c1_fade_ea0' });
  math(s, 's6_a1', 6.45, 3.55, { s: 1.4, name: 'c2_fade_ea1' });
  math(s, 's6_a2', 6.45, 4.1, { s: 1.4, name: 'c3_fade_ea2' });
  // example B
  card(s, 6.2, 4.95, 6.65, 1.85, { objectName: 'c5_fade_eb' });
  pill(s, 'EXAMPLE B', 6.4, 5.1, 1.3, 0.32, ORG, WHITE, 11, { objectName: 'c5_fade_ebl' });
  math(s, 's6_b0', 7.9, 5.26, { s: 1.35, vc: true, name: 'c5_fade_eb0' });
  math(s, 's6_b1', 6.45, 5.65, { s: 1.4, name: 'c5_fade_eb1' });
  math(s, 's6_b2', 6.45, 6.2, { s: 1.4, name: 'c5_fade_eb2' });
  cue(n, 'click 1 formulas, Example A givens, points P and Q | click 2 the vector arrow, head minus tail | click 3 legs 6 and 8, magnitude | click 4 |PQ| = 10 on the graph | click 5 Example B. Route: reversed subtraction -> say "head minus tail".');
  notes(s, n);
}

// =================================================================== 7 direction & unit vectors
{
  const s = pres.addSlide(); const n = 7;
  chrome(s, n, 2, 'Direction and unit vectors');
  card(s, 0.4, 1.85, 5.8, 3.65, { objectName: 'c1_fade_dcard' });
  const fx = 0.6, fy = 1.95;
  fig(s, 's7', '0', fx, fy, 'c1_fade_axes');
  frames(s, 's7a', fx, fy, 'c2', 'orange');
  fig(s, 's7', '1', fx, fy, 'c2_fade@900_arcs');
  fig(s, 's7', '2', fx, fy, 'c3_fade_comp');
  frames(s, 's7b', fx, fy, 'c5', 'gold');
  fig(s, 's7', '3', fx, fy, 'c5_fade@2200_ghostd');
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.4, y: 5.65, w: 5.8, h: 1.2, rectRadius: 0.12, fill: { color: GOLDBG }, line: { color: GOLD, width: 1.25 }, objectName: 'c5_fade_wi' });
  txt(s, 'WHAT IF...?', 0.6, 5.75, 3, 0.25, { fontSize: 11, bold: true, color: BROWN, charSpacing: 2, objectName: 'c5_fade_wil' });
  txt(s, 'What if the angle is 150° with the same magnitude 20? Predict which component changes sign, then test.', 0.6, 6.02, 5.4, 0.5, { fontSize: 12, color: INK, objectName: 'c5_fade_wit' });
  math(s, 's7_w', 0.6, 6.55, { s: 1.0, name: 'c5_fade_wim' });
  banner(s, 6.4, 1.85, 6.45, 0.8, [['s7_f1', 1.15], ['s7_f2', 1.15], ['s7_f3', 1.15]], { name: 'c1_fade_ban' });
  card(s, 6.4, 2.8, 6.45, 1.95, { objectName: 'c1_fade_ea' });
  pill(s, 'EXAMPLE A', 6.6, 2.93, 1.3, 0.3, TEAL, WHITE, 11, { objectName: 'c1_fade_eal' });
  math(s, 's7_a0', 8.1, 3.08, { s: 1.3, vc: true, name: 'c1_fade_ea0' });
  math(s, 's7_a1', 6.6, 3.38, { s: 1.3, name: 'c2_fade_ea1' });
  math(s, 's7_a2', 6.6, 3.8, { s: 1.0, name: 'c3_fade_ea2' });
  math(s, 's7_a3', 9.6, 3.9, { s: 1.35, name: 'c3_fade_ea3' });
  card(s, 6.4, 4.9, 6.45, 1.95, { objectName: 'c4_fade_eb' });
  pill(s, 'EXAMPLE B', 6.6, 5.03, 1.3, 0.3, ORG, WHITE, 11, { objectName: 'c4_fade_ebl' });
  math(s, 's7_b0', 8.1, 5.18, { s: 1.3, vc: true, name: 'c4_fade_eb0' });
  math(s, 's7_b1', 6.6, 5.5, { s: 1.3, name: 'c4_fade_eb1' });
  math(s, 's7_b2', 6.6, 5.95, { s: 1.15, name: 'c4_fade_eb2' });
  math(s, 's7_b3', 10.2, 5.5, { s: 1.25, name: 'c4_fade_eb3' });
  cue(n, 'click 1 formulas + Example A givens | click 2 the vector rotates from 0° up to 30° (built from still frames so it works in PowerPoint and Keynote) | click 3 components 10√3 and 10 | click 4 Example B (unit vector) | click 5 What if 150°: ask for a prediction first, then the gold vector keeps rotating on to 150°. Route: swapped cos/sin -> sketch the right triangle.');
  notes(s, n);
}

// =================================================================== 8 add, subtract, scale
{
  const s = pres.addSlide(); const n = 8;
  chrome(s, n, 2, 'Adding, subtracting and scaling vectors');
  banner(s, 0.45, 1.8, 12.43, 0.7, [['s8_f1', 1.3], ['s8_f2', 1.3], ['s8_f3', 1.3]], { name: 'c1_fade_ban' });
  // A
  card(s, 0.45, 2.65, 6.1, 3.65, { objectName: 'c1_fade_ca' });
  fig(s, 's8a', '0', 0.55, 2.85, 'c1_fade_ga0');
  fig(s, 's8a', '1', 0.55, 2.85, 'c1_fade_ga1');
  fig(s, 's8a', '2', 0.55, 2.85, 'c2_wipe_ga2');
  fig(s, 's8a', '3', 0.55, 2.85, 'c3_wipe_ga3');
  pill(s, 'EXAMPLE A', 0.65, 2.78, 1.3, 0.3, TEAL, WHITE, 11, { objectName: 'c1_fade_cal' });
  math(s, 's8_a0', 3.95, 3.25, { s: 1.0, name: 'c1_fade_ma0' });
  math(s, 's8_a1', 3.95, 3.85, { s: 1.15, name: 'c2_fade_ma1' });
  math(s, 's8_a2', 3.95, 4.65, { s: 1.15, name: 'c3_fade_ma2' });
  // B
  card(s, 6.78, 2.65, 6.1, 3.65, { objectName: 'c4_fade_cb' });
  fig(s, 's8b', '0', 6.88, 2.85, 'c4_fade_gb0');
  fig(s, 's8b', '1', 6.88, 2.85, 'c4_wipe_gb1');
  fig(s, 's8b', '2', 6.88, 2.85, 'c5_wipe_gb2');
  fig(s, 's8b', '3', 6.88, 2.85, 'c6_wipe_gb3');
  pill(s, 'EXAMPLE B', 6.98, 2.78, 1.3, 0.3, ORG, WHITE, 11, { objectName: 'c4_fade_cbl' });
  math(s, 's8_b0', 10.3, 3.2, { s: 1.4, name: 'c4_fade_mb0' });
  math(s, 's8_b1', 10.3, 3.95, { s: 1.2, name: 'c5_fade_mb1' });
  math(s, 's8_b2', 10.3, 4.65, { s: 1.35, name: 'c6_fade_mb2' });
  // insight strip
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.45, y: 6.4, w: 12.43, h: 0.55, rectRadius: 0.1, fill: { color: GOLDBG }, line: { color: GOLD, width: 1.25 }, objectName: 'c3_fade_ins' });
  txt(s, 'NOTICE', 0.65, 6.4, 1.1, 0.55, { fontSize: 11, bold: true, color: BROWN, charSpacing: 2, valign: 'middle', objectName: 'c3_fade_insl' });
  math(s, 's8_w', 1.75, 6.675, { s: 1.15, vc: true, name: 'c3_fade_insm' });
  txt(s, 'the magnitude of a sum is typically not the sum of the magnitudes', 6.5, 6.4, 6.2, 0.55, { fontSize: 12, italic: true, color: INK, valign: 'middle', objectName: 'c3_fade_inst' });
  cue(n, 'click 1 formulas, Example A vectors u and v | click 2 tip-to-tail copy of v | click 3 the sum + parallelogram + the magnitude insight | click 4 Example B: 2u | click 5 add -v | click 6 result <5,0>. Route: adding magnitudes -> compare 7.21 and 7.74.');
  notes(s, n);
}

// =================================================================== 9 dot product
{
  const s = pres.addSlide(); const n = 9;
  chrome(s, n, 2, 'The dot product');
  banner(s, 0.45, 1.8, 12.43, 0.7, [['s9_f1', 1.4], ['s9_f2', 1.4], ['s9_f3', 1.4]], { name: 'c1_fade_ban' });
  const P = [['s9a', 'EXAMPLE A', TEAL, 's9_a1', 's9_a2', 'c2'], ['s9b', 'EXAMPLE B', ORG, 's9_b1', 's9_b2', 'c3'], ['s9c', 'WHAT IF...? the dot product is negative', '9A6B00', 's9_c1', 's9_c2', 'c4']];
  P.forEach(([f, lab, col, m1, m2, g], i) => {
    const x = 0.45 + i * 4.19;
    card(s, x, 2.65, 4.05, 4.3, { objectName: `${g}_fade_pc${i}`, fill: { color: i === 2 ? 'FFFBEF' : WHITE }, line: { color: i === 2 ? GOLD : BORDER, width: i === 2 ? 1.25 : 1 } });
    pill(s, lab, x + 0.15, 2.77, i === 2 ? 3.75 : 1.3, 0.3, col, WHITE, 11, { objectName: `${g}_fade_pl${i}` });
    fig(s, f, '0', x + 0.08, 3.12, `${g}_fade_pg${i}`);
    fig(s, f, '1', x + 0.08, 3.12, `${g}_fade_pu${i}`);
    const K9 = frames(s, f, x + 0.08, 3.12, g, 'pv' + i);
    fig(s, f, '2', x + 0.08, 3.12, `${g}_fade@${K9 * 60 + 150}_pa${i}`);
    math(s, m1, x + 0.2, 6.15, { s: 1.15, name: `${g}_fade_pm1${i}` });
    math(s, m2, x + 0.2, 6.45, { s: 1.15, name: `${g}_fade_pm2${i}` });
  });
  cue(n, 'click 1 formulas | click 2 Example A: vector v swings away from u to show the angle (acute, 11) | click 3 Example B (perpendicular, 0) | click 4 What if: ask acute or obtuse first, then reveal -10. Route: "a dot product is a single number".');
  notes(s, n);
}

// =================================================================== 10 practice/apply/investigate
{
  const s = pres.addSlide(); const n = 10;
  chrome(s, n, 3, 'Give it a go: Practice, Apply, Investigate');
  const C = [
    ['PRACTICE', 'Secure the method', TEAL, [['s10_p1', 'slide 6'], ['s10_p2', 'slide 8']], 'head minus tail is used for the components, every component is scaled and combined, and the magnitude is a square root of a sum of squares.'],
    ['APPLY', 'Use it in context', ORG, [['s10_a1', 'slide 7'], ['s10_a2', 'slide 9']], 'cosine goes with the x component and sine with the y component, and the perpendicular condition is written as a dot product equal to zero.'],
    ['INVESTIGATE', 'Find out why', NAVY, [['s10_i1', 'slide 8'], ['s10_i2', 'slide 9']], 'both magnitudes are computed exactly, you state when the two sides could be equal, and your explanation uses the angle between the vectors or their dot product.'],
  ];
  C.forEach(([h, sub, col, ps, dw], i) => {
    const x = 0.5 + i * 4.15, g = `c${i + 1}`;
    card(s, x, 1.9, 3.95, 4.95, { objectName: `${g}_fade_rc${i}` });
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: x + 0.12, y: 2.02, w: 3.71, h: 0.75, rectRadius: 0.1, fill: { color: col }, line: { color: col }, objectName: `${g}_fade_rh${i}` });
    txt(s, h, x + 0.3, 2.08, 3.3, 0.38, { fontSize: 18, bold: true, color: WHITE, charSpacing: 2, objectName: `${g}_fade_rht${i}` });
    txt(s, sub, x + 0.3, 2.44, 3.3, 0.28, { fontSize: 13, italic: true, color: WHITE, objectName: `${g}_fade_rhs${i}` });
    ps.forEach(([k, st], j) => {
      const y = 2.95 + j * 1.2;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: x + 0.15, y, w: 3.65, h: 1.08, rectRadius: 0.1, fill: { color: 'F1F7F6' }, line: { color: BORDER }, objectName: `${g}_fade_pb${i}${j}` });
      s.addText(String(j + 1), { x: x + 0.27, y: y + 0.12, w: 0.34, h: 0.34, shape: pres.shapes.OVAL, fill: { color: col }, color: WHITE, fontFace: 'Cambria', fontSize: 13, bold: true, align: 'center', valign: 'middle', margin: 0, isTextBox: true, objectName: `${g}_fade_pn${i}${j}` });
      math(s, k, x + 0.75, y + 0.54, { s: 1.0, vc: true, name: `${g}_fade_pm${i}${j}` });
      txt(s, `stuck? ${st}`, x + 2.7, y + 0.1, 1.0, 0.25, { fontSize: 10, color: GREY, align: 'right', italic: true, objectName: `${g}_fade_ps${i}${j}` });
    });
    txt(s, [{ text: 'DONE WHEN  ', options: { bold: true, color: i === 1 ? 'B8531A' : col, fontSize: 12.5 } }, { text: dw, options: { color: INK, fontSize: 12.5 } }], x + 0.2, 5.4, 3.55, 1.35, { objectName: `${g}_fade_dw${i}` });
  });
  cue(n, 'click 1 Practice | click 2 Apply | click 3 Investigate. Students choose the route that fits; finishers of Apply move to Investigate. Each "stuck?" tag is the slide to return to.');
  notes(s, n);
}

// =================================================================== 11 production
{
  const s = pres.addSlide(); const n = 11;
  chrome(s, n, 4, 'Production: Navigating from Jeddah to NEOM');
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.4, y: 1.78, w: 7.2, h: 5.2, rectRadius: 0.12, fill: { color: WHITE }, line: { color: BORDER }, shadow: sh() });
  const cover = 'image/png;base64,' + fs.readFileSync('clip_cover.png').toString('base64');
  s.addMedia({ type: 'video', path: 'voyage.mp4', cover, x: 0.5, y: 1.88, w: 7.0, h: 5.0 });
  card(s, 7.8, 1.78, 5.08, 1.45, { objectName: 'c1_fade_mod' });
  pill(s, 'THE MODEL', 7.98, 1.9, 1.2, 0.26, DKG, WHITE, 10, { objectName: 'c1_fade_modl' });
  txt(s, 'A research vessel leaves Jeddah Islamic Port toward a NEOM port. Distances in km on a map grid (model values only). Fuel: SAR 15 per km.', 7.98, 2.2, 4.75, 0.5, { fontSize: 11, color: INK, objectName: 'c1_fade_modt' });
  math(s, 's11_v', 7.98, 2.78, { s: 1.0, name: 'c1_fade_modv' });
  math(s, 's11_c', 10.5, 2.78, { s: 1.0, name: 'c1_fade_modc' });
  const T = [['TASK 1', 'Find the ground velocity v + c and the vessel\'s speed over the ground. Compare it with the speed in still water.'], ['TASK 2', 'Find the position of the vessel after 2 hours and the distance it has travelled from Jeddah.'], ['TASK 3', 'Find the displacement vector from that position to N, its length to the nearest 0.1 km, and the fuel cost of that remaining distance to the nearest SAR.']];
  T.forEach(([h, t], i) => {
    const y = 3.35 + i * 0.95, g = `c${i + 2}`;
    card(s, 7.8, y, 5.08, 0.85, { objectName: `${g}_fade_tk${i}` });
    pill(s, h, 7.95, y + 0.12, 0.85, 0.28, [TEAL, ORG, NAVY][i], WHITE, 10, { objectName: `${g}_fade_tkl${i}` });
    txt(s, t, 8.95, y + 0.07, 3.85, 0.75, { fontSize: 11, color: INK, valign: 'middle', objectName: `${g}_fade_tkt${i}` });
  });
  txt(s, 'Hint: add component by component, then find the lengths.', 7.8, 6.22, 5.08, 0.25, { fontSize: 11, italic: true, color: GREY, objectName: 'c5_fade_hint' });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 7.8, y: 6.5, w: 5.08, h: 0.5, rectRadius: 0.1, fill: { color: GOLDBG }, line: { color: GOLD, width: 1.25 }, objectName: 'c5_fade_wi' });
  txt(s, 'WHAT IF the current doubles?', 7.95, 6.5, 2.4, 0.5, { fontSize: 11, bold: true, color: BROWN, valign: 'middle', objectName: 'c5_fade_wil' });
  math(s, 's11_wi', 10.4, 6.75, { s: 1.0, vc: true, name: 'c5_fade_wim' });
  cue(n, 'the video is on the slide from the start: click it to play (about 19 s) and pause on the last frame | click 1 the model | click 2-4 tasks 1-3 | click 5 hint and What if (predict first: does ground speed rise or fall?). Early finishers: the single constant velocity J to N in 4 h.');
  notes(s, n);
}

// =================================================================== 12 mastery gate
{
  const s = pres.addSlide(); const n = 12;
  chrome(s, n, 5, 'Mastery Gate: three questions to pass');
  const Q = [['s12_1', 'slide 6', TEAL], ['s12_2', 'slide 8', ORG], ['s12_3', 'slide 9', NAVY]];
  Q.forEach(([k, st, col], i) => {
    const x = 0.5 + i * 4.15, g = `c${i + 1}`;
    card(s, x, 1.95, 3.95, 2.75, { objectName: `${g}_fade_qc${i}` });
    s.addText('Q' + (i + 1), { x: x + 0.2, y: 2.15, w: 0.8, h: 0.55, shape: pres.shapes.ROUNDED_RECTANGLE, rectRadius: 0.5, fill: { color: col }, color: WHITE, fontFace: 'Cambria', fontSize: 20, bold: true, align: 'center', valign: 'middle', margin: 0, isTextBox: true, objectName: `${g}_fade_qn${i}` });
    math(s, k, x + 0.25, 3.15, { s: 1.45, name: `${g}_fade_qm${i}` });
    txt(s, `missed it? return to ${st}`, x + 0.25, 4.25, 3.5, 0.3, { fontSize: 12, italic: true, color: GREY, objectName: `${g}_fade_qs${i}` });
  });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.5, y: 5.0, w: 12.3, h: 1.75, rectRadius: 0.15, fill: { color: DKG }, line: { color: DKG }, shadow: sh(), objectName: 'c4_fade_pm' });
  s.addText('3/3', { x: 0.8, y: 5.3, w: 1.6, h: 1.15, shape: pres.shapes.OVAL, fill: { color: GOLD }, color: DEEP, fontFace: 'Cambria', fontSize: 32, bold: true, align: 'center', valign: 'middle', margin: 0, isTextBox: true, objectName: 'c4_fade_pc' });
  txt(s, 'PASS MARK', 2.8, 5.25, 4, 0.3, { fontSize: 12, bold: true, color: GOLD, charSpacing: 2, objectName: 'c4_fade_pt' });
  txt(s, '3 of 3 correct unlocks Station 6. Fewer than that: return to the slide for the question you missed, redo it, then re-take the gate.', 2.8, 5.6, 9.7, 0.9, { fontSize: 17, color: WHITE, objectName: 'c4_fade_pd' });
  cue(n, 'click 1-3 reveal Q1-Q3 (students answer on mini whiteboards or paper) | click 4 pass mark. Two or more missed: join the teacher group for the create step.');
  notes(s, n);
}

// =================================================================== 13 smart production
{
  const s = pres.addSlide(); const n = 13;
  chrome(s, n, 6, 'Smart Production: make one, then check it');
  card(s, 0.5, 1.9, 6.6, 3.85, { objectName: 'c1_fade_cc' });
  pill(s, 'CREATE', 0.7, 2.05, 1.1, 0.32, TEAL, WHITE, 12, { objectName: 'c1_fade_ccl' });
  const steps = ['Choose a start point and an end point somewhere on a map of the Red Sea coast. Write the displacement vector and its length.', 'Add a current vector. Find the ground velocity and the position after 3 hours, and write the dot product test that checks whether your path is perpendicular to the coastline direction you chose.', 'Add a What if...? question (change the current or reverse a vector) with a prediction and a test.'];
  const hs = [0.95, 1.3, 0.95]; let yy = 2.5;
  steps.forEach((t, i) => {
    s.addText(String(i + 1), { x: 0.7, y: yy, w: 0.42, h: 0.42, shape: pres.shapes.OVAL, fill: { color: TEAL }, color: WHITE, fontFace: 'Cambria', fontSize: 15, bold: true, align: 'center', valign: 'middle', margin: 0, isTextBox: true, objectName: `c${i + 1}_fade_cn${i}` });
    txt(s, t, 1.3, yy - 0.03, 5.6, hs[i], { fontSize: 13, color: INK, objectName: `c${i + 1}_fade_ct${i}` });
    yy += hs[i] + 0.12;
  });
  // exit ticket
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 7.4, y: 1.9, w: 5.45, h: 3.85, rectRadius: 0.12, fill: { color: WHITE }, line: { color: BORDER }, shadow: sh(), objectName: 'c4_fade_tc' });
  pill(s, 'TIME TO CHECK', 7.6, 2.05, 1.7, 0.32, ORG, WHITE, 12, { objectName: 'c4_fade_tcl' });
  txt(s, 'Exit ticket: write your answer on a sticky note and place it on the door.', 7.6, 2.5, 5.05, 0.5, { fontSize: 12, italic: true, color: GREY, objectName: 'c4_fade_tct' });
  [[8.6, 3.1, 's13_1', -2], [8.95, 4.45, 's13_2', 2]].forEach(([x, y, k, rot], i) => {
    s.addShape(pres.shapes.RECTANGLE, { x: x - 1.1, y, w: 4.2, h: 1.15, fill: { color: 'FFF3B0' }, line: { color: 'EAD36B', width: 0.75 }, shadow: sh(), rotate: rot, objectName: `c4_fade_sn${i}` });
    math(s, k, x - 0.9, y + 0.57, { s: 1.3, vc: true, name: `c4_fade_sm${i}` });
  });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.5, y: 5.95, w: 8.2, h: 0.95, rectRadius: 0.12, fill: { color: GOLDBG }, line: { color: GOLD, width: 1.25 }, objectName: 'c5_fade_dw' });
  txt(s, [{ text: 'DONE WHEN  ', options: { bold: true, color: BROWN } }, { text: 'your displacement is head minus tail, the ground velocity is a component-wise sum, and your What if...? question has a prediction and a test.', options: { color: INK } }], 0.7, 5.95, 7.85, 0.95, { fontSize: 12, valign: 'middle', objectName: 'c5_fade_dwt' });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 8.9, y: 5.95, w: 3.95, h: 0.95, rectRadius: 0.12, fill: { color: NAVY }, line: { color: NAVY }, objectName: 'c6_fade_nx' });
  txt(s, [{ text: 'NEXT LESSON\n', options: { bold: true, color: GOLD, fontSize: 10 } }, { text: '10-2 Introduction to Matrices', options: { bold: true, color: WHITE, fontSize: 15 } }], 9.1, 5.95, 3.6, 0.95, { valign: 'middle', objectName: 'c6_fade_nxt' });
  cue(n, 'click 1-3 the three create steps | click 4 Time to Check sticky notes | click 5 Done when | click 6 next lesson. Route: Exit 1 missed -> slide 7 Example B next lesson; Exit 2 missed -> slide 7 Example A.');
  notes(s, n);
}

// =================================================================== 14 exam connections
{
  const s = pres.addSlide(); const n = 14;
  chrome(s, n, 0, 'Exam connections');
  const E = [
    ['SAT', 'Advanced Math · coordinate geometry', NAVY, 's14_s0', ['s14_s1', 's14_s2', 's14_s3'], 'Trap: adding the components to get 23, or a sign slip with the negative y-coordinate.'],
    ['GAT', 'Qudurat · quantitative comparison', TEAL, 's14_g0', ['s14_g1', 's14_g2', 's14_g3'], 'Trap: multiplying the components but not adding, or stopping at 6 and choosing A.'],
    ['SAAT', 'Tahsili · four options', ORG, 's14_a0', ['s14_a1', 's14_a2', 's14_a3'], 'Trap: option C is the sum of the two magnitudes; option A comes from using only one component.'],
  ];
  E.forEach(([h, sub, col, q, st, trap], i) => {
    const x = 0.5 + i * 4.15;
    card(s, x, 1.85, 3.95, 5.05);
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: x + 0.12, y: 1.97, w: 3.71, h: 0.7, rectRadius: 0.1, fill: { color: col }, line: { color: col } });
    txt(s, h, x + 0.3, 2.0, 1.5, 0.64, { fontFace: 'Cambria', fontSize: 24, bold: true, color: WHITE, valign: 'middle' });
    txt(s, sub, x + 1.5, 2.0, 2.25, 0.64, { fontSize: 11, color: WHITE, valign: 'middle', align: 'right' });
    math(s, q, x + 0.25, 2.85, { s: 1.25 });
    txt(s, 'STEPS', x + 0.25, 3.8, 2, 0.25, { fontSize: 11, bold: true, color: GREY, charSpacing: 2 });
    st.forEach((k, j) => {
      const y = 4.12 + j * 0.5;
      s.addText(String(j + 1), { x: x + 0.25, y, w: 0.34, h: 0.34, shape: pres.shapes.OVAL, fill: { color: col }, color: WHITE, fontFace: 'Cambria', fontSize: 13, bold: true, align: 'center', valign: 'middle', margin: 0, isTextBox: true, objectName: `c${j + 1}_fade_xn${i}${j}` });
      math(s, k, x + 0.75, y + 0.17, { s: 1.25, vc: true, name: `c${j + 1}_fade_xm${i}${j}` });
    });
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: x + 0.15, y: 5.75, w: 3.65, h: 0.95, rectRadius: 0.1, fill: { color: 'FDEFE6' }, line: { color: 'F2C9AE' }, objectName: `c4_fade_tb${i}` });
    txt(s, trap, x + 0.3, 5.75, 3.35, 0.95, { fontSize: 11, color: '7A3410', valign: 'middle', objectName: `c4_fade_tt${i}` });
  });
  cue(n, 'click 1 step 1 in all three columns | click 2 step 2 | click 3 step 3 | click 4 the traps. Let students try each item before step 1. Route: SAT miss -> slide 6; GAT -> slide 9; SAAT -> slide 8.');
  notes(s, n);
}

// =================================================================== 15 journey complete
{
  const s = pres.addSlide(); const n = 15;
  s.background = { color: DEEP };
  s.addImage({ path: 'assets/dept_w.png', x: 0.4, y: 0.2, w: 1.6, h: 0.49, objectName: '!!logo_dept' });
  s.addImage({ path: 'assets/school_w.png', x: 12.33, y: 0.17, w: 0.62, h: 0.62, objectName: '!!logo_school' });
  txt(s, 'Journey complete', 0.5, 1.0, 12.3, 0.8, { fontFace: 'Cambria', fontSize: 38, bold: true, color: WHITE, objectName: '!!title' });
  const names = ['Diagnose', 'Targeted Instruction', 'Practice', 'Production', 'Mastery Gate', 'Smart Production'];
  names.forEach((nm, i) => {
    const col = i % 3, row = Math.floor(i / 3);
    const x = 0.5 + col * 4.15, y = 2.1 + row * 1.15;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w: 3.95, h: 0.95, rectRadius: 0.12, fill: { color: '13504C' }, line: { color: '1D6E69' }, objectName: `d${300 + i * 400}_fade_k${i}` });
    s.addText('✓', { x: x + 0.2, y: y + 0.2, w: 0.55, h: 0.55, shape: pres.shapes.OVAL, fill: { color: i % 2 ? ORG : TEAL }, color: WHITE, fontFace: 'Calibri', fontSize: 20, bold: true, align: 'center', valign: 'middle', margin: 0, isTextBox: true, objectName: `d${500 + i * 400}_fade_kc${i}` });
    txt(s, nm, x + 0.95, y, 2.9, 0.95, { fontSize: 18, bold: true, color: WHITE, valign: 'middle', objectName: `d${500 + i * 400}_fade_kt${i}` });
  });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.5, y: 4.65, w: 12.3, h: 1.65, rectRadius: 0.15, fill: { color: '0A3F3C' }, line: { color: GOLD, width: 1.5 }, objectName: 'c1_fade_rc' });
  txt(s, 'ONE-SENTENCE RECAP', 0.8, 4.8, 5, 0.28, { fontSize: 11, bold: true, color: GOLD, charSpacing: 2, objectName: 'c1_fade_rl' });
  txt(s, 'A vector has magnitude and direction; subtract the initial point from the terminal point to get its components, add and scale component by component, and the dot product multiplies matching components and adds them, giving zero exactly when the vectors are perpendicular.', 0.8, 5.12, 11.7, 1.1, { fontSize: 15, color: WHITE, objectName: 'c1_fade_rt' });
  pill(s, 'Next lesson: 10-2 Introduction to Matrices', 0.5, 6.5, 4.4, 0.4, ORG, WHITE, 13, { objectName: 'c2_fade_nx' });
  txt(s, 'FAITH, RIGHTEOUSNESS AND WISDOM', 8.9, 7.02, 2.5, 0.2, { fontSize: 8, bold: true, color: '8FB5B1', align: 'right' });
  txt(s, 'Mr Malek Thiab  ·  15', 11.5, 7.02, 1.33, 0.2, { fontSize: 9, bold: true, color: WHITE, align: 'right' });
  cue(n, 'the six stations check themselves off automatically (about 3 seconds) | click 1 recap sentence | click 2 next lesson. Collect the Time to Check notes at the door.');
  notes(s, n);
}

fs.writeFileSync('vidnames.json', JSON.stringify(VIDN));
pres.writeFile({ fileName: 'raw.pptx' }).then(f => console.log('wrote', f));
