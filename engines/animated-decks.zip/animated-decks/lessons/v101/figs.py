import os, json, math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Arc, Circle, Polygon

plt.rcParams.update({'font.family': 'serif', 'mathtext.fontset': 'cm', 'font.size': 12})
OUT = '/home/claude/v101/f'
os.makedirs(OUT, exist_ok=True)
TEAL, ORG, NAVY, DKG, GOLD, INK, GREY = '#17A199', '#E8762C', '#1F3864', '#0E4F4C', '#F0B323', '#1B2B2A', '#5A6B69'
LIGHT = '#FFFFFF'
INFO = {}


def lim(cx,cy,sc,w,h):
    return (cx-w*sc/2,cx+w*sc/2),(cy-h*sc/2,cy+h*sc/2)


class Fig:
    def __init__(self, name, w, h, xlim, ylim, dark=False, dpi=220):
        self.name, self.w, self.h, self.xlim, self.ylim, self.dpi, self.dark = name, w, h, xlim, ylim, dpi, dark
        self.layers = []
        self.fg = '#FFFFFF' if dark else INK
        self.grid = '#FFFFFF' if dark else '#7A8C8A'

    def layer(self, key, fn):
        fig = plt.figure(figsize=(self.w, self.h), dpi=self.dpi)
        ax = fig.add_axes([0, 0, 1, 1])
        ax.set_xlim(*self.xlim); ax.set_ylim(*self.ylim)
        ax.axis('off')
        fig.patch.set_alpha(0); ax.patch.set_alpha(0)
        fn(ax, self)
        path = f'{OUT}/{self.name}_{key}.png'
        fig.savefig(path, transparent=True, dpi=self.dpi)
        plt.close(fig)
        self.layers.append(key)
        INFO.setdefault(self.name, {'w': self.w, 'h': self.h, 'layers': []})['layers'].append({'key': key, 'file': path})

    def px(self, ax):  # points per data unit (x) for sizing
        return self.w * 72 / (self.xlim[1] - self.xlim[0])


def arrow(ax, p, q, color, lw=2.6, ms=16, ls='-', z=5, alpha=1):
    a = FancyArrowPatch(p, q, arrowstyle='-|>', mutation_scale=ms, lw=lw, color=color, ls=ls, zorder=z,
                        shrinkA=0, shrinkB=0, alpha=alpha, capstyle='round', joinstyle='round')
    ax.add_patch(a)


def grid_axes(ax, F, xt, yt, xlab=True, ylab=True, fs=11, axes_arrow=True, gridalpha=0.22):
    x0, x1 = F.xlim; y0, y1 = F.ylim
    for x in xt:
        ax.plot([x, x], [y0, y1], color=F.grid, lw=0.8, alpha=gridalpha, zorder=0)
    for y in yt:
        ax.plot([x0, x1], [y, y], color=F.grid, lw=0.8, alpha=gridalpha, zorder=0)
    if x0 < 0 < x1:
        arrow(ax, (x0 + 0.1, 0), (x1 - 0.02, 0), F.fg, lw=1.6, ms=12, z=1)
    else:
        arrow(ax, (x0, y0 + 0.0), (x1 - 0.02, y0), F.fg, lw=1.6, ms=12, z=1)
    if y0 < 0 < y1:
        arrow(ax, (0, y0 + 0.1), (0, y1 - 0.02), F.fg, lw=1.6, ms=12, z=1)
    else:
        arrow(ax, (x0, y0), (x0, y1 - 0.02), F.fg, lw=1.6, ms=12, z=1)
    ax0 = 0 if y0 < 0 < y1 else y0
    ay0 = 0 if x0 < 0 < x1 else x0
    if xlab:
        for x in xt:
            if x != 0:
                ax.text(x, ax0 - (y1 - y0) * 0.035, f'{x}', ha='center', va='top', color=F.fg, fontsize=fs, alpha=.85)
    if ylab:
        for y in yt:
            if y != 0:
                ax.text(ay0 - (x1 - x0) * 0.012, y, f'{y}', ha='right', va='center', color=F.fg, fontsize=fs, alpha=.85)


def dot(ax, p, color, r=0.11, z=7, ec='white'):
    ax.add_patch(Circle(p, r, fc=color, ec=ec, lw=1.6, zorder=z))


def lab(ax, p, s, color, fs=13, ha='center', va='center', bold=False, z=9, bg=None):
    t = ax.text(p[0], p[1], s, color=color, fontsize=fs, ha=ha, va=va, zorder=z, weight='bold' if bold else 'normal')
    if bg:
        t.set_bbox(dict(fc=bg, ec='none', pad=1.5, alpha=.92))
    return t



def rot_arrow(name, P, length, ang, color, lw=4.0, ms=22, dot_=False):
    """square canvas centred on the origin of parent P; arrow drawn at angle ang (deg). For PowerPoint spin."""
    sc = (P.xlim[1] - P.xlim[0]) / P.w
    S = 2 * (length + 0.8) / sc
    F = Fig(name, S, S, *lim(0, 0, sc, S, S))
    def l(ax, F):
        a = math.radians(ang)
        arrow(ax, (0, 0), (length * math.cos(a), length * math.sin(a)), color, lw=lw, ms=ms)
        if dot_: dot(ax, (0, 0), 'white', r=.12)
    F.layer('a', l)
    ox = (0 - P.xlim[0]) / (P.xlim[1] - P.xlim[0]) * P.w
    oy = (P.ylim[1] - 0) / (P.ylim[1] - P.ylim[0]) * P.h
    INFO[name]['origin'] = [ox, oy]
    return F

# =============================================================== slide 1 hero (dark card) 5.6 x 3.9
def build_s1():
    F = Fig('s1', 5.6, 3.9, *lim(3.3,2.05,1.5,5.6,3.9), dark=True)
    v = (6.0, 4.0)
    F.layer('0', lambda ax, F: grid_axes(ax, F, [1, 2, 3, 4, 5, 6, 7], [1, 2, 3, 4], fs=10, gridalpha=.16, xlab=False, ylab=False))
    def l1(ax, F):
        dot(ax, (0, 0), 'white', r=.12)
    F.layer('1', l1)
    rot_arrow('s1r', F, math.hypot(6, 4), 0, GOLD, lw=4.2, ms=22)
    def l2(ax, F):
        ax.plot([0, 6], [0, 0], color=TEAL, lw=3.2, ls=(0, (4, 3)), zorder=4)
        ax.plot([6, 6], [0, 4], color=ORG, lw=3.2, ls=(0, (4, 3)), zorder=4)
        lab(ax, (3, -0.5), r'$a$', TEAL, 18)
        lab(ax, (6.45, 2), r'$b$', ORG, 18)
    F.layer('2', l2)
    def l3(ax, F):
        a = Arc((0, 0), 2.2, 2.2, theta1=0, theta2=33.69, color='white', lw=1.8, zorder=6)
        ax.add_patch(a)
        lab(ax, (1.55, 0.45), r'$\theta$', 'white', 16)
    F.layer('3', l3)
    return F


# =============================================================== slide 6  (6.0 x 4.7)
def build_s6():
    F = Fig('s6', 5.2, 4.6, *lim(4.9,4.4,2.3,5.2,4.6))
    P, Q = (2, 1), (8, 9)
    F.layer('0', lambda ax, F: grid_axes(ax, F, list(range(1, 11)), list(range(1, 10)), fs=10, gridalpha=.2))
    def l1(ax, F):
        dot(ax, P, NAVY); dot(ax, Q, NAVY)
        lab(ax, (P[0] - .55, P[1] - .5), r'$P(2,1)$', NAVY, 13)
        lab(ax, (Q[0] + 1.2, Q[1] - .05), r'$Q(8,9)$', NAVY, 13)
    F.layer('1', l1)
    F.layer('2', lambda ax, F: arrow(ax, P, Q, ORG, lw=4, ms=22))
    def l3(ax, F):
        ax.plot([2, 8], [1, 1], color=TEAL, lw=3, ls=(0, (4, 3)), zorder=4)
        ax.plot([8, 8], [1, 9], color=TEAL, lw=3, ls=(0, (4, 3)), zorder=4)
        lab(ax, (5, 0.35), r'$6$', TEAL, 15, bold=True)
        lab(ax, (8.5, 5), r'$8$', TEAL, 15, bold=True)
    F.layer('3', l3)
    def l4(ax, F):
        lab(ax, (4.55, 6.0), r'$|\vec{PQ}|=10$', ORG, 15, bg='white')
    F.layer('4', l4)
    return F


# =============================================================== slide 7  (5.2 x 4.5)
def build_s7():
    F = Fig('s7', 5.4, 3.4, *lim(0,4.7,4.6,5.4,3.4))
    # scale: |v|=20 drawn as radius 11
    R = 11.0
    def l0(ax, F):
        grid_axes(ax, F, [], [], fs=10)
        ax.add_patch(Circle((0, 0), R, fc='none', ec=GREY, lw=1.2, ls=(0, (3, 3)), zorder=1, alpha=.7))
    F.layer('0', l0)
    th = math.radians(30)
    v = (R * math.cos(th), R * math.sin(th))
    def l1(ax, F):
        ax.add_patch(Arc((0, 0), 5, 5, theta1=0, theta2=30, color=NAVY, lw=2, zorder=6))
        lab(ax, (3.6, 0.95), r'$30^\circ$', NAVY, 13)
        lab(ax, (v[0] / 2 - 1.2, v[1] / 2 + 1.3), r'$|\vec v|=20$', ORG, 14, bg='white')
    F.layer('1', l1)
    def l2(ax, F):
        ax.plot([0, v[0]], [0, 0], color=TEAL, lw=3, ls=(0, (4, 3)), zorder=4)
        ax.plot([v[0], v[0]], [0, v[1]], color=TEAL, lw=3, ls=(0, (4, 3)), zorder=4)
        lab(ax, (v[0] / 2, -1.2), r'$10\sqrt{3}$', TEAL, 14, bold=True)
        lab(ax, (v[0] + 1.6, v[1] / 2), r'$10$', TEAL, 14, bold=True)
    F.layer('2', l2)
    th2 = math.radians(150)
    w = (R * math.cos(th2), R * math.sin(th2))
    def l3(ax, F):
        ax.add_patch(Arc((0, 0), 7, 7, theta1=0, theta2=150, color=GOLD, lw=1.6, ls=(0, (3, 2)), zorder=3))
        lab(ax, (w[0] + 0.2, w[1] + 1.1), r'$150^\circ$', '#7A5200', 13, bg='white')
        lab(ax, (w[0] / 2 - 1.5, -1.2), r'$-10\sqrt{3}$', '#7A5200', 13, bold=True)
        ax.plot([0, w[0]], [0, 0], color=GOLD, lw=2.6, ls=(0, (4, 3)), zorder=4)
        ax.plot([w[0], w[0]], [0, w[1]], color=GOLD, lw=2.6, ls=(0, (4, 3)), zorder=4)
    F.layer('3', l3)
    rot_arrow('s7r', F, R, 0, ORG)
    rot_arrow('s7g', F, R, 30, GOLD)
    return F


# =============================================================== slide 8: two cards
def build_s8a():
    F = Fig('s8a', 3.3, 3.45, *lim(2.5,3.1,2.2,3.3,3.45))
    u, v = (3, 2), (1, 4)
    F.layer('0', lambda ax, F: grid_axes(ax, F, [1, 2, 3, 4, 5], [1, 2, 3, 4, 5, 6], fs=9, gridalpha=.18))
    def l1(ax, F):
        arrow(ax, (0, 0), u, NAVY, lw=3.4, ms=19)
        lab(ax, (1.75, .55), r'$\vec u$', NAVY, 15, bg=None)
        arrow(ax, (0, 0), v, TEAL, lw=3.4, ms=19)
        lab(ax, (0.2, 2.5), r'$\vec v$', TEAL, 15)
    F.layer('1', l1)
    def l2(ax, F):
        arrow(ax, u, (4, 6), TEAL, lw=3, ms=17, ls=(0, (4, 2)))
        arrow(ax, v, (4, 6), NAVY, lw=2, ms=1, ls=(0, (2, 3)), alpha=.7)
        lab(ax, (3.9, 4.2), r'$\vec v$', TEAL, 13)
    F.layer('2', l2)
    def l3(ax, F):
        arrow(ax, (0, 0), (4, 6), ORG, lw=4.2, ms=22)
        lab(ax, (1.7, 3.5), r'$\vec u+\vec v$', ORG, 14, bg='white')
    F.layer('3', l3)
    return F


def build_s8b():
    F = Fig('s8b', 3.3, 3.45, *lim(2.8,0.05,3.0,3.3,3.45))
    u = (3, 2)
    F.layer('0', lambda ax, F: grid_axes(ax, F, [1, 2, 3, 4, 5, 6, 7], [-4, -3, -2, -1, 1, 2, 3, 4], fs=9, gridalpha=.18))
    def l1(ax, F):
        arrow(ax, (0, 0), (6, 4), NAVY, lw=3.4, ms=19)
        lab(ax, (2.6, 2.7), r'$2\vec u$', NAVY, 14, bg='white')
    F.layer('1', l1)
    def l2(ax, F):
        arrow(ax, (6, 4), (5, 0), TEAL, lw=3.2, ms=18, ls=(0, (4, 2)))
        lab(ax, (6.9, 1.9), r'$-\vec v$', TEAL, 14)
    F.layer('2', l2)
    def l3(ax, F):
        arrow(ax, (0, 0), (5, 0), ORG, lw=4.2, ms=22)
        lab(ax, (2.5, 0.75), r'$\langle5,0\rangle$', ORG, 14, bg='white')
    F.layer('3', l3)
    return F


# =============================================================== slide 9 panels (3.6 x 2.7 each)
def panel(name, a, b, c, sc, an_txt, col2, arcr, txt):
    F = Fig(name, 3.9, 3.0, *lim(c[0], c[1], sc, 3.9, 3.0))
    def l0(ax, F):
        grid_axes(ax, F, [], [], fs=9)
    F.layer('0', l0)
    def lu(ax, F):
        arrow(ax, (0, 0), a, NAVY, lw=3.2, ms=18)
        lab(ax, (a[0] * 1.05 + 0.35, a[1] * 1.05 + (0.4 if a[1] > 0 else -0.1)), txt[0], NAVY, 14)
    F.layer('1', lu)
    def l1(ax, F):
        t1 = math.degrees(math.atan2(a[1], a[0])); t2 = math.degrees(math.atan2(b[1], b[0]))
        lo, hi = sorted([t1, t2])
        ax.add_patch(Arc((0, 0), arcr * 2, arcr * 2, theta1=lo, theta2=hi, color=GOLD, lw=2.6, zorder=6))
        mid = math.radians((lo + hi) / 2)
        lab(ax, ((arcr + 0.7) * math.cos(mid), (arcr + 0.7) * math.sin(mid)), an_txt, '#7A5200', 12, bold=True)
        lab(ax, (b[0] * 1.05 + 0.4, b[1] * 1.05 + 0.4), txt[1], col2, 14)
    F.layer('2', l1)
    ta = math.degrees(math.atan2(a[1], a[0])); tb = math.degrees(math.atan2(b[1], b[0]))
    rot_arrow(name + 'r', F, math.hypot(*b), ta, col2, lw=3.2, ms=18)
    INFO[name + 'r']['spin'] = tb - ta
    return F


def build_s9():
    return [
        panel('s9a', (3, 2), (1, 4), (1.7, 1.95), 2.0, r'$42.3^\circ$', TEAL, 1.5, (r'$\vec u$', r'$\vec v$')),
        panel('s9b', (2, -3), (6, 4), (3, 0.5), 2.9, r'$90^\circ$', TEAL, 1.2, (r'$\vec u$', r'$\vec v$')),
        panel('s9c', (3, 2), (-4, 1), (-0.5, 0.8), 2.2, r'$132.3^\circ$', TEAL, 1.4, (r'$\vec u$', r'$\vec v$')),
    ]


if __name__ == '__main__':
    build_s1(); build_s6(); build_s7(); build_s8a(); build_s8b(); build_s9()
    json.dump(INFO, open(f'{OUT}/info.json', 'w'), indent=1)
    print(list(INFO))
