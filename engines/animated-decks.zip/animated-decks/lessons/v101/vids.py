import json, math, os, shutil, subprocess
from PIL import Image
FI = json.load(open('f/info.json')); DPI = 220; FPS = 30
OUT = 'vid'; shutil.rmtree(OUT, ignore_errors=True); os.makedirs(OUT)
def ease(t): return t * t * (3 - 2 * t)
def load(p): return Image.open(p).convert('RGBA')
def base(parent, keys, bg):
    P = FI[parent]; im = Image.new('RGBA', (round(P['w'] * DPI), round(P['h'] * DPI)), bg)
    for k in keys: im.alpha_composite(load(next(l['file'] for l in P['layers'] if l['key'] == k)))
    return im
def put(im, rotname, delta):
    R = FI[rotname]; a = load(R['layers'][0]['file'])
    if abs(delta) > 1e-6: a = a.rotate(delta, resample=Image.BICUBIC)
    x = round((R['origin'][0] - R['w'] / 2) * DPI); y = round((R['origin'][1] - R['h'] / 2) * DPI)
    big = Image.new('RGBA', im.size, (0, 0, 0, 0)); big.paste(a, (x, y), a); im.alpha_composite(big)
def clip(name, parent, keys, bg, statics, rotname, spin):
    """statics: [(rotname, delta)] drawn fixed; rotating arrow rotname by 0..spin degrees ccw"""
    dur = (800 + abs(spin) * 10) / 1000.0; n = max(2, round(dur * FPS)) + 1
    d = f'{OUT}/{name}'; os.makedirs(d)
    for i in range(n):
        t = ease(i / (n - 1)); im = base(parent, keys, bg)
        for rn, dl in statics: put(im, rn, dl)
        put(im, rotname, spin * t)
        im.convert('RGB').save(f'{d}/f{i:04d}.png')
    shutil.copy(f'{d}/f{n-1:04d}.png', f'{OUT}/{name}_cover.png')
    shutil.copy(f'{d}/f0000.png', f'{OUT}/{name}_first.png')
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-framerate', str(FPS), '-i', f'{d}/f%04d.png', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '17', '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2', f'{OUT}/{name}.mp4'], check=True)
    shutil.rmtree(d)
    print(name, n, 'frames', round(dur, 2), 's')
WHITE = (255, 255, 255, 255)
clip('s1', 's1', ['0', '1'], (10, 63, 60, 255), [], 's1r', 33.69)
clip('s7a', 's7', ['0'], WHITE, [], 's7r', 30)
clip('s7b', 's7', ['0', '1', '2'], WHITE, [('s7r', 30)], 's7g', 120)
for nm, bg in (('s9a', WHITE), ('s9b', WHITE), ('s9c', (255, 251, 239, 255))):
    clip(nm, nm, ['0', '1'], bg, [], nm + 'r', FI[nm + 'r']['spin'])
