import subprocess, json, os, re, shutil
from PIL import Image

OUT = '/home/claude/v101/m'
os.makedirs(OUT, exist_ok=True)

# key -> (latex body in TEXT mode, colour hex, base font pt)
INK = '1B2B2A'
S = {}
def add(k, body, col=INK, pt=14):
    S[k] = (body, col, pt)

# ---------- slide 1
add('s1_v', r'$\vec v=\langle a,\,b\rangle$', 'FFFFFF', 18)
add('s1_m', r'$|\vec v|=\sqrt{a^{2}+b^{2}}$', 'FFFFFF', 16)
# ---------- slide 5 diagnose
add('s5_c1', r'Distance between $(1,-2)$ and $(4,2)$')
add('s5_c2', r'Find the exact value of $20\cos 30^\circ$')
add('s5_c3', r'Evaluate $3(-2)+(-4)(5)$')
add('s5_a1', r'$5$', 'FFFFFF', 18)
add('s5_a2', r'$10\sqrt{3}$', 'FFFFFF', 18)
add('s5_a3', r'$-26$', 'FFFFFF', 18)
# ---------- slide 6
add('s6_f1', r'$\overrightarrow{PQ}=\langle x_2-x_1,\;y_2-y_1\rangle$', 'FFFFFF', 15)
add('s6_f2', r'$|\vec v|=\sqrt{v_1^{2}+v_2^{2}}$', 'FFFFFF', 15)
add('s6_a0', r'$P(2,1),\;\;Q(8,9)$')
add('s6_a1', r'$\overrightarrow{PQ}=\langle 8-2,\;9-1\rangle=\langle 6,\,8\rangle$')
add('s6_a2', r'$|\overrightarrow{PQ}|=\sqrt{6^{2}+8^{2}}=\sqrt{100}=10$')
add('s6_b0', r'initial $(-3,4)$, terminal $(2,-8)$')
add('s6_b1', r'$\vec v=\langle 2-(-3),\;-8-4\rangle=\langle 5,\,-12\rangle$')
add('s6_b2', r'$|\vec v|=\sqrt{25+144}=13$')
# ---------- slide 7
add('s7_f1', r'$\vec v=|\vec v|\,\langle\cos\theta,\;\sin\theta\rangle$', 'FFFFFF', 15)
add('s7_f2', r'$\hat u=\dfrac{\vec v}{|\vec v|}$', 'FFFFFF', 15)
add('s7_f3', r'$|\hat u|=1$', 'FFFFFF', 15)
add('s7_a0', r'$|\vec v|=20,\;\;\theta=30^\circ$')
add('s7_a1', r'$\vec v=20\,\langle\cos30^\circ,\;\sin30^\circ\rangle$')
add('s7_a2', r'$=\left\langle 20\cdot\dfrac{\sqrt3}{2},\;20\cdot\dfrac12\right\rangle$')
add('s7_a3', r'$=\langle 10\sqrt3,\;10\rangle$')
add('s7_b0', r'Unit vector of $\langle -6,\,8\rangle$')
add('s7_b1', r'$|\vec v|=\sqrt{36+64}=10$')
add('s7_b2', r'$\hat u=\left\langle-\dfrac{6}{10},\;\dfrac{8}{10}\right\rangle=\left\langle-\dfrac35,\;\dfrac45\right\rangle$')
add('s7_b3', r'check: $\dfrac{9}{25}+\dfrac{16}{25}=1$')
add('s7_w', r'$\theta=150^\circ:\;\;\vec v=\langle -10\sqrt3,\;10\rangle$', '7A5200', 15)
# ---------- slide 8
add('s8_f1', r'$\langle a,b\rangle\pm\langle c,d\rangle=\langle a\pm c,\;b\pm d\rangle$', 'FFFFFF', 14)
add('s8_f2', r'$k\langle a,b\rangle=\langle ka,\;kb\rangle$', 'FFFFFF', 14)
add('s8_f3', r'$|k\vec v|=|k|\,|\vec v|$', 'FFFFFF', 14)
add('s8_a0', r'$\vec u=\langle3,2\rangle,\;\;\vec v=\langle1,4\rangle$')
add('s8_a1', r'$\vec u+\vec v=\langle 3+1,\;2+4\rangle$\\ $\phantom{\vec u+\vec v}=\langle4,\,6\rangle$')
add('s8_a2', r'$|\vec u+\vec v|=\sqrt{16+36}$\\ $=2\sqrt{13}\approx7.21$')
add('s8_b0', r'$2\vec u-\vec v$')
add('s8_b1', r'$=\langle6,4\rangle+\langle-1,-4\rangle$')
add('s8_b2', r'$=\langle5,\,0\rangle$')
add('s8_w', r'$|\vec u+\vec v|\approx7.21\;<\;|\vec u|+|\vec v|\approx3.61+4.12=7.73$', '7A5200', 14)
# ---------- slide 9
add('s9_f1', r'$\vec u\cdot\vec v=u_1v_1+u_2v_2$', 'FFFFFF', 14)
add('s9_f2', r'$\vec u\cdot\vec v=|\vec u|\,|\vec v|\cos\theta$', 'FFFFFF', 14)
add('s9_f3', r'$\vec u\cdot\vec v=0\iff\vec u\perp\vec v$', 'FFFFFF', 14)
add('s9_a1', r'$\langle3,2\rangle\cdot\langle1,4\rangle=3(1)+2(4)=11$', INK, 13)
add('s9_a2', r'$\cos\theta=\dfrac{11}{\sqrt{13}\sqrt{17}}\;\Rightarrow\;\theta\approx42.3^\circ$', INK, 13)
add('s9_b1', r'$\langle2,-3\rangle\cdot\langle6,4\rangle=12-12=0$', INK, 13)
add('s9_b2', r'$\cos\theta=0\;\Rightarrow\;\theta=90^\circ$', INK, 13)
add('s9_c1', r'$\langle3,2\rangle\cdot\langle-4,1\rangle=-12+2=-10$', INK, 13)
add('s9_c2', r'$\cos\theta<0\;\Rightarrow\;\theta\approx132.3^\circ$', INK, 13)
# ---------- slide 10
add('s10_p1', r'$P(-2,3)$ to $Q(1,-1)$:\\ components and magnitude', INK, 14)
add('s10_p2', r'$\vec u=\langle4,-1\rangle,\;\vec v=\langle-2,5\rangle$.\\ Find $3\vec u-2\vec v$', INK, 14)
add('s10_a1', r'$|\vec v|=50,\;\theta=60^\circ$.\\ Write $\vec v$ in component form', INK, 14)
add('s10_a2', r'Find $k$ so that $\langle k,6\rangle$\\ is perpendicular to $\langle3,-4\rangle$', INK, 14)
add('s10_i1', r'$\vec u=\langle3,4\rangle,\;\vec v=\langle5,12\rangle$.\\ Compare $|\vec u+\vec v|$ with $|\vec u|+|\vec v|$', INK, 14)
add('s10_i2', r'$\vec u=\langle3,4\rangle,\;\vec v=\langle-4,3\rangle$.\\ Compare $|\vec u+\vec v|$ and $|\vec u-\vec v|$', INK, 14)
# ---------- slide 11 chips
add('s11_j', r'$J(0,0)$', INK, 14)
add('s11_n', r'$N(60,50)$', INK, 14)
add('s11_v', r'vessel $\vec v=\langle18,24\rangle$ km/h', INK, 14)
add('s11_c', r'current $\vec c=\langle3,-4\rangle$ km/h', INK, 14)
add('s11_wi', r'$\vec c=\langle6,-8\rangle$ km/h', '7A5200', 14)
# ---------- slide 12 gate
add('s12_1', r'$P(3,-2)$ to $Q(-2,10)$:\\ components and magnitude', INK, 15)
add('s12_2', r'$\vec u=\langle5,-2\rangle,\;\vec v=\langle1,3\rangle$.\\ Find $2\vec u-3\vec v$', INK, 15)
add('s12_3', r'Find $\cos\theta$ between\\ $\langle3,4\rangle$ and $\langle5,12\rangle$', INK, 15)
# ---------- slide 13 exit
add('s13_1', r'Unit vector in the direction\\ of $\langle8,-6\rangle$', INK, 14)
add('s13_2', r'$|\vec v|=12,\;\theta=120^\circ$.\\ Write $\vec v$ in component form', INK, 14)
# ---------- slide 14 exams
add('s14_s0', r'$A(2,-1),\;B(10,14)$\\ What is the length of $\overrightarrow{AB}$?', INK, 13)
add('s14_s1', r'$\overrightarrow{AB}=\langle8,\,15\rangle$')
add('s14_s2', r'$\sqrt{64+225}$')
add('s14_s3', r'$\sqrt{289}=17$')
add('s14_g0', r'Which quantity is greater?\\ A: $\langle2,3\rangle\cdot\langle3,-2\rangle$\quad B: $0$', INK, 13)
add('s14_g1', r'$2(3)+3(-2)$')
add('s14_g2', r'$6-6=0$')
add('s14_g3', r'$A=B$ (equal)')
add('s14_a0', r'$\vec a=\langle3,-4\rangle,\;\vec b=\langle-1,2\rangle$\\ Find $|\vec a+\vec b|$', INK, 13)
add('s14_a1', r'$\vec a+\vec b=\langle2,-2\rangle$')
add('s14_a2', r'$\sqrt{4+4}$')
add('s14_a3', r'$2\sqrt2$')

def build():
    tex = [r'\documentclass[multi={snip},border=3pt]{standalone}',
           r'\usepackage{amsmath,amssymb,xcolor}',
           r'\begin{document}']
    keys = list(S)
    for k in keys:
        body, col, pt = S[k]
        lead = round(pt * 1.25, 1)
        if r'\\' in body:
            body = r'\begin{tabular}{l}' + body + r'\end{tabular}'
        tex.append(r'\begin{snip}\definecolor{c}{HTML}{%s}\color{c}\fontsize{%s}{%s}\selectfont %s\end{snip}' % (col, pt, lead, body))
    tex.append(r'\end{document}')
    open(f'{OUT}/m.tex', 'w').write('\n'.join(tex))
    r = subprocess.run(['xelatex', '-interaction=nonstopmode', '-halt-on-error', 'm.tex'], cwd=OUT, capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout[-2500:]); raise SystemExit('latex failed')
    for f in os.listdir(OUT):
        if f.startswith('p-') and f.endswith('.png'):
            os.remove(f'{OUT}/{f}')
    subprocess.run(['pdftocairo', '-png', '-transp', '-r', '300', f'{OUT}/m.pdf', f'{OUT}/p'], check=True)
    files = sorted(f for f in os.listdir(OUT) if f.startswith('p-') and f.endswith('.png'))
    assert len(files) == len(keys), (len(files), len(keys))
    man = {}
    for k, f in zip(keys, files):
        im = Image.open(f'{OUT}/{f}')
        dst = f'{OUT}/{k}.png'
        shutil.move(f'{OUT}/{f}', dst)
        man[k] = {'file': dst, 'w': im.size[0] / 300, 'h': im.size[1] / 300}
    json.dump(man, open(f'{OUT}/manifest.json', 'w'), indent=1)
    print('snippets', len(man))

if __name__ == '__main__':
    build()
