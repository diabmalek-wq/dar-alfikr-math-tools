import os, math, shutil, subprocess
import numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Circle, Polygon
plt.rcParams.update({'font.family':'serif','mathtext.fontset':'cm'})
TEAL,ORG,NAVY,DKG,GOLD,INK='#17A199','#E8762C','#1F3864','#0E4F4C','#F0B323','#1B2B2A'
W,H,DPI,FPS=7.0,5.0,200,20
D=19.0
xr=(-12,76); sc=(xr[1]-xr[0])/W; cy=25; yr=(cy-H*sc/2,cy+H*sc/2)
out='/home/claude/v101/clip'; shutil.rmtree(out,ignore_errors=True); os.makedirs(out)
def ease(t): t=min(max(t,0),1); return t*t*(3-2*t)
def seg(t,a,b): return ease((t-a)/(b-a))
J=(0,0);N=(60,50);V=(18,24);C=(3,-4);G=(21,20)
def arr(ax,p,q,c,lw=3.2,ms=18,ls='-',z=6):
    ax.add_patch(FancyArrowPatch(p,q,arrowstyle='-|>',mutation_scale=ms,lw=lw,color=c,ls=ls,zorder=z,shrinkA=0,shrinkB=0))
def lerp(p,q,s): return (p[0]+(q[0]-p[0])*s,p[1]+(q[1]-p[1])*s)
def frame(i):
    t=i/FPS
    fig=plt.figure(figsize=(W,H),dpi=DPI); ax=fig.add_axes([0,0,1,1]); ax.set_xlim(*xr); ax.set_ylim(*yr); ax.axis('off')
    ax.add_patch(plt.Rectangle((xr[0],yr[0]),xr[1]-xr[0],yr[1]-yr[0],fc='#D6EEF0',ec='none',zorder=0))
    for x in range(-10,80,10): ax.plot([x,x],yr,color='white',lw=.8,alpha=.7,zorder=1)
    for y in range(-10,70,10): ax.plot(xr,[y,y],color='white',lw=.8,alpha=.7,zorder=1)
    land=[(xr[0],yr[0]),(xr[0],-5),(0,0),(18,14),(38,29),(60,50),(xr[1],54),(xr[1],yr[0])]
    ax.add_patch(Polygon(land,fc='#EFE3C6',ec='#CDBB92',lw=1.6,zorder=2))
    ax.text(18,42,'Red Sea',style='italic',color='#4F8E96',fontsize=13,zorder=2,ha='center')
    ax.text(48,2,'Saudi Arabia',style='italic',color='#9A8A5E',fontsize=12,zorder=3,ha='center')
    sp=seg(t,0.0,1.5)
    ax.plot([J[0],lerp(J,N,sp)[0]],[J[1],lerp(J,N,sp)[1]],color=NAVY,lw=1.8,ls=(0,(4,3)),zorder=3)
    for P,l,dx,dy in [(J,'J  Jeddah Islamic Port',2,-5),(N,'N  NEOM port',-3,4.5)]:
        ax.add_patch(Circle(P,1.5,fc=NAVY,ec='white',lw=1.8,zorder=8))
    ax.text(3.2,-3.2,'Jeddah Islamic Port  $J(0,0)$',fontsize=10.5,color=NAVY,zorder=8,va='center')
    ax.text(57.5,54.5,'NEOM port  $N(60,50)$',fontsize=10.5,color=NAVY,zorder=8,ha='right',va='center')
    # vessel vector (scaled x1.5 for visibility: 1 h of drift)
    if 2<=t:
        s=seg(t,2,3.4); q=lerp(J,V,s); arr(ax,J,q,ORG)
        if s>.95: ax.text(V[0]-6.5,V[1]+1.5,r'vessel $\langle18,24\rangle$',color=ORG,fontsize=11.5,ha='center',bbox=dict(fc='white',ec='none',pad=1.2,alpha=.9),zorder=9)
    if 5<=t:
        s=seg(t,5,6.2); q=lerp(V,(V[0]+C[0],V[1]+C[1]),s); arr(ax,V,q,TEAL)
        if s>.95: ax.text(V[0]+9.5,V[1]-4,r'current $\langle3,-4\rangle$',color=TEAL,fontsize=11.5,ha='center',bbox=dict(fc='white',ec='none',pad=1.2,alpha=.9),zorder=9)
    if 7.5<=t:
        s=seg(t,7.5,9); q=lerp(J,G,s); arr(ax,J,q,GOLD,lw=4.2,ms=22,z=7)
        if s>.95: ax.text(8,17,r'ground $\langle21,20\rangle$',color='#7A5200',fontsize=11.5,ha='center',bbox=dict(fc='white',ec='none',pad=1.2,alpha=.9),zorder=9)
    # ship moves
    ts=seg(t,10,14.5)
    pos=lerp(J,(42,40),ts) if t>=10 else None
    if t>=10:
        ax.plot([J[0],pos[0]],[J[1],pos[1]],color=GOLD,lw=3.4,zorder=5,alpha=.85)
        ang=math.degrees(math.atan2(G[1],G[0]))
        ship=np.array([[4.2,0],[-3.0,2.4],[-1.8,0],[-3.0,-2.4]])
        r=math.radians(ang); R=np.array([[math.cos(r),-math.sin(r)],[math.sin(r),math.cos(r)]])
        ax.add_patch(Polygon(ship@R.T+np.array(pos),fc=DKG,ec='white',lw=1.4,zorder=9))
        hrs=2*ts
        ax.text(xr[0]+2,yr[1]-4.5,f't = {hrs:.1f} h',fontsize=15,color=DKG,weight='bold',va='center',zorder=10,bbox=dict(fc='white',ec=TEAL,boxstyle='round,pad=.35',lw=1.5))
    if t>=14.8:
        s=seg(t,14.8,16.3); arr(ax,(44.4,41.3),lerp((44.4,41.3),N,s),'#C2410C',lw=3.8,ms=20,z=7)
        if s>.95: ax.text(46,48.8,r'to $N$: $\langle18,10\rangle$',color='#C2410C',fontsize=12,ha='center',bbox=dict(fc='white',ec='none',pad=1.2,alpha=.9),zorder=9)
        ax.text(40,35.5,r'$(42,\,40)$',color=DKG,fontsize=11,ha='right',zorder=9,bbox=dict(fc='white',ec='none',pad=1,alpha=.85))
    fig.savefig(f'{out}/f{i:04d}.png',dpi=DPI); plt.close(fig)
n=int(D*FPS)
for i in range(n): frame(i)
shutil.copy(f'{out}/f{int(17.5*FPS):04d}.png','/home/claude/v101/clip_cover.png')
subprocess.run(['ffmpeg','-y','-loglevel','error','-framerate',str(FPS),'-i',f'{out}/f%04d.png','-c:v','libx264','-pix_fmt','yuv420p','-crf','20','-movflags','+faststart','/home/claude/v101/voyage.mp4'],check=True)
print('done',n)
