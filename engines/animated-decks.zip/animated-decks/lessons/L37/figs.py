import sys; sys.path.insert(0, '/home/claude/lib')
from figlib import *
import numpy as np
LT = '#7FE0D8'
# ---- hero (dark)
def hero():
    F = Fig('s1', 5.6, 3.9, (-3.6, 4.8), (-3.3, 4.6), dark=True)
    f = lambda x: x**3 - 3*x
    F.layer('0', lambda ax, F: grid_axes(ax, F, [-3,-2,-1,1,2,3,4], [-3,-2,-1,1,2,3,4], labels=False, gridalpha=.15))
    F.layer('1', lambda ax, F: (curve(ax, f, -2.2, 2.2, LT, 3.4, -3.3, 4.6), lab(ax, (-2.55, -2.6), r'$f(x)$', LT, 16)))
    F.layer('2', lambda ax, F: (curve(ax, lambda x: f(x-2)+1.5, -0.2, 4.2, '#F0B323', 3.4, -3.3, 4.6), lab(ax, (4.2, 3.9), r'$g(x)$', '#F0B323', 16)))
    def l3(ax, F):
        arrow(ax, (-1, 2), (1, 3.5), 'white', lw=1.8, ms=14, ls=(0, (4, 3)))
        lab(ax, (-0.1, 3.55), r'$f(x-2)+1.5$', 'white', 12)
    F.layer('3', l3)
hero()
# ---- even / odd mini graphs
def evod():
    F = Fig('ev', 2.6, 3.3, (-2.4, 2.4), (-3.6, 4.8))
    F.layer('0', lambda ax, F: grid_axes(ax, F, [-2,-1,1,2], [-3,-2,-1,1,2,3,4], fs=8))
    F.layer('1', lambda ax, F: curve(ax, lambda x: x**4-3*x**2, -2.2, 2.2, TEAL, 3, -3.6, 4.8))
    def l2(ax, F):
        ax.plot([-1, 1], [-2, -2], color=ORG, lw=1.8, ls=(0, (3, 2)), zorder=5)
        pdot(ax, (-1, -2), ORG); pdot(ax, (1, -2), ORG)
        lab(ax, (0, -2.95), r'mirror pair', ORG, 11)
    F.layer('2', l2)
    G = Fig('od', 2.6, 3.3, (-2.4, 2.4), (-4.6, 4.6))
    G.layer('0', lambda ax, F: grid_axes(ax, F, [-2,-1,1,2], [-4,-3,-2,-1,1,2,3,4], fs=8))
    G.layer('1', lambda ax, F: curve(ax, lambda x: x**3-4*x, -2.3, 2.3, NAVY, 3, -4.6, 4.6))
    def o2(ax, F):
        ax.plot([-1, 1], [3, -3], color=ORG, lw=1.8, ls=(0, (3, 2)), zorder=5)
        pdot(ax, (-1, 3), ORG); pdot(ax, (1, -3), ORG); pdot(ax, (0, 0), GOLD, ms=8)
        lab(ax, (1.3, 1.2), r'half-turn', ORG, 11)
    G.layer('2', o2)
evod()
# ---- translations
def s6():
    F = Fig('s6', 5.3, 4.1, (-3.2, 4.6), (-5.2, 8.5))
    f = lambda x: x**3 - 2*x
    F.layer('0', lambda ax, F: grid_axes(ax, F, [-3,-2,-1,1,2,3,4], [-4,-2,2,4,6,8], fs=9))
    F.layer('1', lambda ax, F: (curve(ax, f, -2.4, 2.4, TEAL, 3.2, -5.2, 8.5), lab(ax, (-3.15, -4.5), r'$f(x)$', TEAL, 15, ha='left')))
    def l2(ax, F):
        curve(ax, lambda x: f(x)+3, -2.4, 2.1, ORG, 3.2, -5.2, 8.5)
        arrow(ax, (-1, 1), (-1, 4), 'black', lw=1.8, ms=13, ls=(0, (3, 2)))
        lab(ax, (-1.3, 2.5), r'$+3$', '#B8530F', 15, bold=True, bg='white')
        lab(ax, (1.1, 7.4), r'$f(x)+3$', ORG, 15, ha='right')
    F.layer('2', l2)
    def l3(ax, F):
        curve(ax, lambda x: f(x-2), -0.4, 4.4, NAVY, 3.2, -5.2, 8.5)
        arrow(ax, (-1, 1), (1, 1), 'black', lw=1.8, ms=13, ls=(0, (3, 2)))
        lab(ax, (0.0, 1.6), r'$2$', NAVY, 15, bold=True, bg='white')
        lab(ax, (2.9, -3.3), r'$f(x-2)$', NAVY, 15, ha='left')
    F.layer('3', l3)
s6()
# ---- reflections and stretches
def s7():
    F = Fig('s7', 5.5, 4.1, (-1.7, 1.7), (-2.4, 4.6))
    f = lambda x: x**4 - x**2
    F.layer('0', lambda ax, F: grid_axes(ax, F, [-1, 1], [-2, -1, 1, 2, 3, 4], fs=9))
    F.layer('1', lambda ax, F: (curve(ax, f, -1.4, 1.4, TEAL, 3.2, -2.4, 4.6), lab(ax, (1.3, 0.55), r'$f(x)$', TEAL, 15, ha='left')))
    F.layer('2', lambda ax, F: (curve(ax, lambda x: 3*f(x), -1.45, 1.45, ORG, 3.2, -2.4, 4.6), lab(ax, (1.3, 2.7), r'$3f(x)$', ORG, 15, ha='left')))
    F.layer('3', lambda ax, F: (curve(ax, lambda x: f(2*x), -1.0, 1.0, NAVY, 3.2, -2.4, 4.6), lab(ax, (0.92, 3.9), r'$f(2x)$', NAVY, 15, ha='left')))
    F.layer('4', lambda ax, F: (curve(ax, lambda x: -f(x), -1.4, 1.4, '#B8860B', 3.0, -2.4, 4.6, ls=(0, (4, 2))), lab(ax, (1.1, -1.5), r'$-f(x)$', '#7A5200', 13)))
s7()
# ---- combining
def s8():
    F = Fig('s8', 5.5, 4.2, (-3.6, 2.6), (-4.2, 8.6))
    g = lambda x: -2*(x+1)**3 + 3
    F.layer('0', lambda ax, F: grid_axes(ax, F, [-3,-2,-1,1,2], [-4,-2,2,4,6,8], fs=9))
    def l1(ax, F):
        curve(ax, lambda x: x**3, -2.0, 2.0, TEAL, 3.0, -4.2, 8.6)
        for p in [(-1,-1),(0,0),(1,1)]: pdot(ax, p, TEAL)
        lab(ax, (0.55, 6.2), r'$f(x)=x^3$', TEAL, 15, ha='left')
    F.layer('1', l1)
    def l2(ax, F):
        for a, b in [((-1,-1),(-2,5)), ((0,0),(-1,3)), ((1,1),(0,1))]:
            arrow(ax, a, b, '#444444', lw=1.5, ms=11, ls=(0, (3, 2)), alpha=.8)
            pdot(ax, b, ORG)
    F.layer('2', l2)
    F.layer('3', lambda ax, F: (curve(ax, g, -3.3, 1.0, ORG, 3.2, -4.2, 8.6), lab(ax, (-3.45, -3.0), r'$g(x)=-2(x+1)^3+3$', '#B8530F', 13, ha='left', bg='white')))
s8()
# ---- production walkway
def s11():
    F = Fig('s11', 7.0, 4.3, (-5.4, 5.4), (-6.0, 8.4))
    p = lambda x: x**4 - 4*x**2
    r = lambda x: -p(x) + 3
    w = lambda x: r(x/2)
    s2 = np.sqrt(2)
    F.layer('0', lambda ax, F: (grid_axes(ax, F, [-4,-2,2,4], [2,4,6,8], fs=9), lab(ax, (5.0, 0.6), r'$x$ (m)', INK, 12), lab(ax, (-5.3, 8.0), r'height (m)', INK, 12, ha='left')))
    F.layer('1', lambda ax, F: (curve(ax, p, -2.0, 2.0, TEAL, 2.4, -4.6, 8.4, ls=(0, (4, 2))), lab(ax, (-2.9, -2.3), r'$p(x)$', TEAL, 15)))
    def l2(ax, F):
        curve(ax, r, -2.0, 2.0, ORG, 3.4, -6, 8.4)
        for sx in (-2, 2):
            ax.plot([sx, sx], [0, 3], color=ORG, lw=4.5, solid_capstyle='round', zorder=6)
        for sx in (-s2, s2): pdot(ax, (sx, 7), ORG)
        arrow(ax, (-2, -4.8), (2, -4.8), ORG, lw=1.8, ms=12); arrow(ax, (2, -4.8), (-2, -4.8), ORG, lw=1.8, ms=12)
        lab(ax, (2.35, -4.8), r'$4$ m', '#B8530F', 14, bold=True, ha='left')
        lab(ax, (0, 5.4), r'$r(x)$', '#B8530F', 15, bg='white')
    F.layer('2', l2)
    def l3(ax, F):
        curve(ax, w, -4.0, 4.0, NAVY, 3.4, -6, 8.4)
        for sx in (-4, 4):
            ax.plot([sx, sx], [0, 3], color=NAVY, lw=4.5, solid_capstyle='round', zorder=6)
        arrow(ax, (-4, -5.6), (4, -5.6), NAVY, lw=1.8, ms=12); arrow(ax, (4, -5.6), (-4, -5.6), NAVY, lw=1.8, ms=12)
        lab(ax, (4.35, -5.6), r'$8$ m', NAVY, 14, bold=True, ha='left')
        lab(ax, (3.7, 7.0), r'$w(x)$', NAVY, 15)
    F.layer('3', l3)
s11()
save()
