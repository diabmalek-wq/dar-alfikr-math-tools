const L = require('/home/claude/lib/lib.js')({ codes: 'HSF.BF.B.3', title: 'Lesson 3-7 Transformations of Polynomials (Grade 10, Week 12)' });
const { C, txt, card, pill, disc, math, fig, chrome, banner, whatif, cue, notes, pres, sh } = L;
const { TEAL, ORG, NAVY, DKG, GOLD, GREY, BORDER, INK, WHITE, GOLDBG, BROWN } = C;

// 1 title
L.title(1, { kicker: 'GRADE 10  ·  ALGEBRA II  ·  TOPIC 3', lesson: 'Lesson 3-7', lines: 'Transformations\nof Polynomials', sub: 'Slide, flip and stretch any graph', upnext: 'Up next: 4-1 Inverse Variation and the Reciprocal Function',
  hero(s) {
    fig(s, 's1', '0', 7.05, 1.8, 'd900_fade_axes');
    fig(s, 's1', '1', 7.05, 1.8, 'd1300_wipe_f');
    fig(s, 's1', '2', 7.05, 1.8, 'd2300_wipe_g');
    fig(s, 's1', '3', 7.05, 1.8, 'd3300_fade_arr');
    math(s, 's1_f', 7.4, 5.85, { s: 1.5, name: 'd3700_fade_lf' });
  } });
// 2 journey
L.journey(2, ['Three no-calculator checks', 'Even and odd, shifts, reflections, stretches, combining', 'Practice, Apply, Investigate', 'A shaded walkway at the Red Sea', '3 of 3 unlocks the last station', 'Create one, then Time to Check']);
// 3 objectives
L.objectives(3, ['Identify even and odd functions.', 'Graph transformations of polynomial functions.'], ['even function', 'odd function'],
  [['HSF.BF.B.3', 'Identify the effect on the graph of replacing f(x) by f(x) + k, k f(x), f(kx), and f(x + k) for specific values of k (both positive and negative); find the value of k given the graphs. Experiment with cases and illustrate an explanation of the effects on the graph using technology. Include recognizing even and odd functions from their graphs and algebraic expressions for them.']]);
// 4 diagnose
L.diagnose(4, ['s4_c1', 's4_c2', 's4_c3'], ['s4_a1', 's4_a2', 's4_a3'], 'All three answers are written without a calculator, and you can say which way the graph moves when x is replaced by x minus 3.', '>30% miss Q1 rehearse substitution with brackets before slide 5; Q2 expand with the binomial pattern; Q3 redo shifts of a parabola before slide 6.');

// 5 even and odd
{
  const s = pres.addSlide(); const n = 5;
  chrome(s, n, 2, 'Even and odd functions');
  card(s, 0.4, 1.85, 5.55, 4.95, { objectName: 'c1_fade_dcard' });
  pill(s, 'EVEN', 0.65, 2.0, 0.9, 0.3, TEAL, WHITE, 11, { objectName: 'c1_fade_pe' });
  pill(s, 'ODD', 3.35, 2.0, 0.9, 0.3, NAVY, WHITE, 11, { objectName: 'c1_fade_po' });
  fig(s, 'ev', '0', 0.5, 2.4, 'c1_fade_ev0'); fig(s, 'od', '0', 3.2, 2.4, 'c1_fade_od0');
  fig(s, 'ev', '1', 0.5, 2.4, 'c2_wipe_ev1'); fig(s, 'ev', '2', 0.5, 2.4, 'c2_fade@900_ev2');
  fig(s, 'od', '1', 3.2, 2.4, 'c3_wipe_od1'); fig(s, 'od', '2', 3.2, 2.4, 'c3_fade@900_od2');
  math(s, 's5_cap1', 0.65, 5.85, { s: 1.3, name: 'c2_fade_cap1' }); math(s, 's5_cap2', 3.35, 5.85, { s: 1.3, name: 'c3_fade_cap2' });
  banner(s, 6.2, 1.85, 6.65, 0.85, [['s5_f1', 1.3], ['s5_f2', 1.3]], { name: 'c1_fade_ban' });
  const R = [['EXAMPLE A', TEAL, 's5_a0', 's5_a1', 'EVEN', TEAL, 'c2'], ['EXAMPLE B', ORG, 's5_b0', 's5_b1', 'ODD', NAVY, 'c3'], ['EXAMPLE C', NAVY, 's5_c0', 's5_c1', 'NEITHER', ORG, 'c4']];
  R.forEach(([lab, col, k0, k1, v, vc, g], i) => {
    const y = 2.85 + i * 1.35;
    card(s, 6.2, y, 6.65, 1.25, { objectName: `${g}_fade_ec${i}` });
    pill(s, lab, 6.4, y + 0.12, 1.3, 0.3, col, WHITE, 11, { objectName: `${g}_fade_el${i}` });
    math(s, k0, 7.9, y + 0.27, { s: 1.15, vc: true, name: `${g}_fade_e0${i}` });
    math(s, k1, 6.4, y + 0.62, { s: 1.15, name: `${g}_fade_e1${i}` });
    pill(s, v, 11.45, y + 0.12, 1.2, 0.34, vc, WHITE, 12, { objectName: `${g}_fade_ev${i}` });
  });
  cue(n, 'click 1 formulas, both axes | click 2 the even curve draws, the mirror pair appears, Example A | click 3 the odd curve and its half-turn pair, Example B | click 4 Example C (neither). Route: >30% drop brackets around -x -> redo Example A.');
  notes(s, n);
}
// 6 translations
{
  const s = pres.addSlide(); const n = 6;
  chrome(s, n, 2, 'Translations: up, down, left, right');
  card(s, 0.4, 1.85, 5.8, 4.95, { objectName: 'c1_fade_dcard' });
  fig(s, 's6', '0', 0.65, 2.3, 'c1_fade_ax'); fig(s, 's6', '1', 0.65, 2.3, 'c1_wipe_par');
  fig(s, 's6', '2', 0.65, 2.3, 'c2_wipe_up'); fig(s, 's6', '3', 0.65, 2.3, 'c3_wipe_rt');
  banner(s, 6.4, 1.85, 6.45, 0.85, [['s6_f1', 1.5], ['s6_f2', 1.5]], { name: 'c1_fade_ban' });
  card(s, 6.4, 2.85, 6.45, 2.5, { objectName: 'c1_fade_ea' });
  pill(s, 'EXAMPLE A', 6.6, 2.98, 1.3, 0.3, TEAL, WHITE, 11, { objectName: 'c1_fade_eal' });
  math(s, 's6_a0', 8.15, 3.13, { s: 1.25, vc: true, name: 'c1_fade_ea0' });
  math(s, 's6_a1', 6.6, 3.55, { s: 1.3, name: 'c2_fade_ea1' });
  math(s, 's6_a2', 6.6, 4.1, { s: 1.3, name: 'c3_fade_ea2' });
  math(s, 's6_a3', 7.1, 4.6, { s: 1.3, name: 'c3_fade_ea3' });
  card(s, 6.4, 5.5, 6.45, 1.3, { objectName: 'c4_fade_eb' });
  pill(s, 'EXAMPLE B', 6.6, 5.62, 1.3, 0.3, ORG, WHITE, 11, { objectName: 'c4_fade_ebl' });
  math(s, 's6_b0', 8.15, 5.77, { s: 1.25, vc: true, name: 'c4_fade_eb0' });
  math(s, 's6_b1', 6.6, 6.2, { s: 1.35, name: 'c4_fade_eb1' });
  math(s, 's6_b2', 10.0, 6.2, { s: 1.35, name: 'c4_fade_eb2' });
  cue(n, 'click 1 formulas, f(x) draws | click 2 the graph lifts 3 units (f(x)+3) | click 3 the graph slides 2 units RIGHT (f(x-2)): ask which way before it moves | click 4 Example B. Route: x+k read as right -> ask "which x makes the bracket zero?".');
  notes(s, n);
}
// 7 reflections and stretches
{
  const s = pres.addSlide(); const n = 7;
  chrome(s, n, 2, 'Reflections and stretches');
  card(s, 0.4, 1.85, 5.8, 4.95, { objectName: 'c1_fade_dcard' });
  fig(s, 's7', '0', 0.55, 2.3, 'c1_fade_ax'); fig(s, 's7', '1', 0.55, 2.3, 'c1_wipe_par');
  fig(s, 's7', '2', 0.55, 2.3, 'c3_wipe_st'); fig(s, 's7', '3', 0.55, 2.3, 'c4_wipe_sq');
  banner(s, 6.4, 1.85, 6.45, 0.75, [['s7_f1', 1.05], ['s7_f2', 1.05], ['s7_f3', 1.05], ['s7_f4', 1.05]], { name: 'c1_fade_ban' });
  card(s, 6.4, 2.75, 6.45, 1.45, { objectName: 'c2_fade_ea' });
  pill(s, 'EXAMPLE A', 6.6, 2.87, 1.3, 0.3, TEAL, WHITE, 11, { objectName: 'c2_fade_eal' });
  math(s, 's7_a0', 8.15, 3.02, { s: 1.25, vc: true, name: 'c2_fade_ea0' });
  math(s, 's7_a1', 6.6, 3.33, { s: 1.3, name: 'c2_fade_ea1' });
  math(s, 's7_a2', 6.6, 3.75, { s: 1.3, name: 'c2_fade_ea2' });
  pill(s, 'x-axis', 10.2, 3.38, 1.1, 0.28, TEAL, WHITE, 10, { objectName: 'c2_fade_t1' });
  pill(s, 'y-axis', 10.2, 3.8, 1.1, 0.28, NAVY, WHITE, 10, { objectName: 'c2_fade_t2' });
  card(s, 6.4, 4.32, 6.45, 1.45, { objectName: 'c3_fade_eb' });
  pill(s, 'EXAMPLE B', 6.6, 4.44, 1.3, 0.3, ORG, WHITE, 11, { objectName: 'c3_fade_ebl' });
  math(s, 's7_b0', 8.15, 4.59, { s: 1.25, vc: true, name: 'c3_fade_eb0' });
  math(s, 's7_b1', 6.6, 4.9, { s: 1.3, name: 'c3_fade_eb1' });
  math(s, 's7_b2', 6.6, 5.32, { s: 1.3, name: 'c4_fade_eb2' });
  pill(s, 'taller x3', 10.2, 4.97, 1.3, 0.28, ORG, WHITE, 10, { objectName: 'c3_fade_t3' });
  pill(s, 'narrower x1/2', 10.2, 5.39, 1.55, 0.28, NAVY, WHITE, 10, { objectName: 'c4_fade_t4' });
  whatif(s, 6.4, 5.9, 6.45, 0.95, 'What if the input is halved? Predict wider or narrower, then test.', 's7_w', 'c5', { tw: 3.2, fs: 12, ms: 1.0 });
  cue(n, 'click 1 formulas, f(x) draws | click 2 Example A (reflections, text only) | click 3 Example B and the graph stretches vertically (3f) | click 4 f(2x) squashes horizontally by 1/2 | click 5 What if f(x/2): predict first. Route: f(2x) read as wider -> test x = 1 in f(2x).');
  notes(s, n);
}
// 8 combining
{
  const s = pres.addSlide(); const n = 8;
  chrome(s, n, 2, 'Combining transformations');
  card(s, 0.4, 1.85, 5.8, 4.95, { objectName: 'c1_fade_dcard' });
  fig(s, 's8', '0', 0.55, 2.25, 'c1_fade_ax'); fig(s, 's8', '1', 0.55, 2.25, 'c1_fade_par');
  fig(s, 's8', '2', 0.55, 2.25, 'c2_fade_mp'); fig(s, 's8', '3', 0.55, 2.25, 'c3_wipe_g');
  banner(s, 6.4, 1.85, 6.45, 0.75, [['s8_f1', 1.15]], { name: 'c1_fade_ban' });
  txt(s, 'stretch and reflect first, then shift', 9.4, 1.85, 3.3, 0.75, { fontSize: 13, italic: true, color: 'BFE3DF', valign: 'middle', objectName: 'c1_fade_bt' });
  card(s, 6.4, 2.75, 6.45, 2.3, { objectName: 'c1_fade_ea' });
  pill(s, 'EXAMPLE A', 6.6, 2.87, 1.3, 0.3, TEAL, WHITE, 11, { objectName: 'c1_fade_eal' });
  math(s, 's8_a0', 8.15, 3.02, { s: 1.0, vc: true, name: 'c1_fade_ea0' });
  math(s, 's8_a1', 6.6, 3.45, { s: 1.35, name: 'c2_fade_ea1' });
  math(s, 's8_a2', 6.6, 3.9, { s: 1.35, name: 'c2_fade_ea2' });
  math(s, 's8_a3', 6.6, 4.35, { s: 1.35, name: 'c2_fade_ea3' });
  card(s, 6.4, 5.2, 6.45, 1.6, { objectName: 'c4_fade_eb' });
  pill(s, 'EXAMPLE B', 6.6, 5.32, 1.3, 0.3, ORG, WHITE, 11, { objectName: 'c4_fade_ebl' });
  math(s, 's8_b0', 8.15, 5.47, { s: 1.2, vc: true, name: 'c4_fade_eb0' });
  math(s, 's8_b1', 6.6, 5.85, { s: 1.3, name: 'c4_fade_eb1' });
  math(s, 's8_b2', 9.5, 5.85, { s: 1.3, name: 'c5_fade_eb2' });
  math(s, 's8_b3', 6.6, 6.3, { s: 1.4, name: 'c5_fade_eb3' });
  cue(n, 'click 1 formulas, f(x) = x^3 with three key points | click 2 each key point moves (stretch and reflect, then shift) | click 3 the new curve g draws | click 4 Example B | click 5 solve for a using the point (4, 0). Route: shift before stretch -> check one key point.');
  notes(s, n);
}
// 9 practice
L.practice(9, [
  ['PRACTICE', 'Secure the method', TEAL, [['s9_p1', 'slide 5'], ['s9_p2', 'slide 6']], 'the input is replaced by its opposite, put in brackets, and compared with both the original function and its negative, and the shift direction is checked against the new zero or vertex.'],
  ['APPLY', 'Use it in context', ORG, [['s9_a1', 'slide 7'], ['s9_a2', 'slide 5']], 'the input change and the output change are kept separate, and the classification comes from comparing the new function with the original and its negative.'],
  ['INVESTIGATE', 'Find out why', NAVY, [['s9_i1', 'slide 5'], ['s9_i2', 'slide 5']], 'your argument starts from f of negative x, and a numerical example such as x squared and x cubed backs it up.']],
  'Each "stuck?" tag is the slide to return to.');
// 10 routes / judge the claim
{
  const s = pres.addSlide(); const n = 10;
  chrome(s, n, 3, 'Which route? Judge the claim');
  const R = [['ALGEBRA TEST', TEAL, 's10_r1', 'Proves it for every x.', 'Needs careful signs.'], ['GRAPH SYMMETRY', NAVY, 's10_r2', 'Fast visual check.', 'A rough sketch can mislead.'], ['TABLE OF VALUES', ORG, 's10_r3', 'Quick test with numbers.', 'Can disprove, cannot prove.']];
  R.forEach(([h, col, k, pro, con], i) => {
    const x = 0.5 + i * 2.67, g = `c${i + 1}`;
    card(s, x, 1.85, 2.55, 2.3, { objectName: `${g}_fade_rc${i}`, line: { color: col, width: 1.5 } });
    pill(s, h, x + 0.12, 1.97, 2.31, 0.34, col, WHITE, 11, { objectName: `${g}_fade_rh${i}` });
    math(s, k, x + 1.275, 2.65, { s: Math.min(1.0, 2.3 / L.M[k].w), align: 'c', vc: true, name: `${g}_fade_rm${i}` });
    txt(s, [{ text: '+  ' + pro, options: { color: '0E7A5F', breakLine: true } }, { text: '–  ' + con, options: { color: 'A33A12' } }], x + 0.18, 3.1, 2.25, 0.95, { fontSize: 11.5, objectName: `${g}_fade_rt${i}` });
  });
  card(s, 8.55, 1.85, 4.3, 2.3, { objectName: 'c4_fade_jc', line: { color: GOLD, width: 1.5 } });
  txt(s, 'JUDGE THE CLAIM', 8.75, 1.95, 3, 0.25, { fontSize: 11, bold: true, color: BROWN, charSpacing: 2, objectName: 'c4_fade_jl' });
  txt(s, 'Every polynomial of even degree is an even function.', 8.75, 2.25, 3.9, 0.7, { fontSize: 15, bold: true, color: INK, objectName: 'c4_fade_jt' });
  [['TRUE', TEAL], ['FALSE', ORG], ['SOMETIMES', NAVY]].forEach(([t, col], i) => pill(s, t, 8.75 + i * 1.3, 3.05, i === 2 ? 1.4 : 1.2, 0.34, col, WHITE, 11, { objectName: `c4_fade_jp${i}` }));
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 8.75, y: 3.5, w: 3.9, h: 0.55, rectRadius: 0.08, fill: { color: GOLDBG }, line: { color: GOLD }, objectName: 'c5_fade_ck' });
  txt(s, 'Check the assumption: did you test a mix of even and odd powers?', 8.85, 3.5, 2.2, 0.55, { fontSize: 10, color: INK, valign: 'middle', objectName: 'c5_fade_ckt' });
  math(s, 's10_cl', 12.55, 3.78, { s: 0.95, align: 'r', vc: true, name: 'c5_fade_ckm' });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.5, y: 4.3, w: 7.9, h: 2.55, rectRadius: 0.12, fill: { color: GOLD }, line: { color: GOLD }, shadow: sh(), objectName: 'c6_fade_sp' });
  txt(s, 'SPOTLIGHT: STEAL THIS SHORTCUT', 0.75, 4.45, 6, 0.28, { fontSize: 12, bold: true, color: '5C3F00', charSpacing: 2, objectName: 'c6_fade_spl' });
  txt(s, 'Look at the exponents: all even (a constant counts) means even, all odd means odd, a mix means neither.', 0.75, 4.85, 7.3, 0.8, { fontSize: 16, color: INK, objectName: 'c6_fade_spt' });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.75, y: 5.85, w: 7.4, h: 0.75, rectRadius: 0.1, fill: { color: WHITE }, line: { color: WHITE }, objectName: 'c6_fade_spb' });
  math(s, 's10_sp', 4.45, 6.225, { s: 1.3, align: 'c', vc: true, name: 'c6_fade_spm' });
  whatif(s, 8.55, 4.3, 4.3, 2.55, 'What if the polynomial is x cubed plus x? Predict even, odd or neither, then test.', 's10_wi', 'c7', { fs: 13, mx: 12.55, my: 6.2 });
  cue(n, 'click 1-3 the three routes | click 4 the claim (students vote TRUE / FALSE / SOMETIMES) | click 5 the counterexample x^2 + x | click 6 the exponent shortcut | click 7 What if x^3 + x. Route: >30% say TRUE -> test x^2 + x numerically.');
  notes(s, n);
}
// 11 production
L.production(11, 'Production: A shaded walkway at the Red Sea', {
  left(s) {
    fig(s, 's11', '0', 0.5, 1.9, 'c1_fade_ax'); fig(s, 's11', '1', 0.5, 1.9, 'c2_wipe_p');
    fig(s, 's11', '2', 0.5, 1.9, 'c3_wipe_r'); fig(s, 's11', '3', 0.5, 1.9, 'c4_wipe_w');
    math(s, 's11_m', 0.65, 6.28, { s: 1.15, name: 'c1_fade_fm' });
    math(s, 's11_chk', 0.65, 6.6, { s: 0.95, name: 'c6_fade_chk' });
  },
  model: 'A model shaded walkway at a Red Sea tourism resort (model values only, not real data). The canopy height profile is the quartic p, x in metres from the centre line. Designers flip it, raise it onto 3 m posts, then widen it. Cover costs SAR 800 per metre of post-to-post width.',
  tasks: ['Show that p is even and explain what that means for the two halves of the canopy.', 'Write r in expanded form. Find r(0) and r(2), and the greatest height of the canopy.', 'Widen the canopy by a factor of 2 horizontally: write w in terms of r. Find the new post positions and the cost in SAR before and after.'],
  hint: 'Hint: a horizontal stretch by 2 replaces x by x over 2.', wiText: 'WHAT IF the widening factor is 3?', wiMath: 's11_wi',
  cue: 'click 1 the model and axes | click 2 p draws: ask why the two halves match | click 3 r = -p + 3 flips and lifts, with 3 m posts at x = +/-2 | click 4 w stretches to posts at x = +/-4, 8 m wide | click 5 hint and What if | click 6 check your answers. Route: >30% cannot start Task 1 -> slide 5.' });
// 12 gate
L.gate(12, [['s12_1', 'slide 5', TEAL], ['s12_2', 'slides 6 and 7', ORG], ['s12_3', 'slide 8', NAVY]], 'Q1 missed -> slide 5; Q2 -> slides 6-7; Q3 -> slide 8.');
// 13 smart
L.smart(13, ['Write an even function and an odd function of your own, each with at least three terms, and prove each one by finding f of negative x.', 'Swap with a partner: shift your function and ask your partner to decide whether the shifted graph is still even, odd or neither.', 'Add a What if...? question (a reflection or a stretch) with a prediction and a test.'], [1.0, 1.0, 0.8],
  'both proofs use f of negative x, your partner\'s decision about the shifted graph is justified, and your What if...? question has a prediction and a test.', ['s13_1', 's13_2'], '4-1 Inverse Variation and the Reciprocal Functions', 'Exit 1 missed -> slide 5 Example A; Exit 2 missed -> slide 5 Example C.');
// 14 exam
L.exam(14, [
  ['SAT', 'Advanced Math · functions', NAVY, 's14_s0', ['s14_s1', 's14_s2', 's14_s3'], 'Trap: shifting right instead of left gives zeros 3 and 7, not -3 and 1.'],
  ['GAT', 'Qudurat · quantitative comparison', TEAL, 's14_g0', ['s14_g1', 's14_g2', 's14_g3'], 'Trap: treating f as even gives 14 and makes A look greater.'],
  ['SAAT', 'Tahsili · four options', ORG, 's14_a0', ['s14_a1', 's14_a2', 's14_a3'], 'Trap: option D looks odd, but the constant 1 breaks the symmetry.']], 'SAT miss -> slide 6; GAT -> slide 5; SAAT -> slide 5.');
// 15 complete
L.complete(15, 'A polynomial is even or odd when f of negative x equals f(x) or minus f(x), and every graph follows the pattern y = a f(x - h) + k: stretch and reflect first, then shift.', 'Next lesson: 4-1 Inverse Variation and the Reciprocal Function');
L.write('raw.pptx').then(f => console.log('wrote', f));
