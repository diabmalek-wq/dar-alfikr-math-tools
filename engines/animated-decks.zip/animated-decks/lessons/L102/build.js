const L = require('/home/claude/lib/lib.js')({ codes: '(+)HSN.VM.C.6 · (+)HSN.VM.C.7 · (+)HSN.VM.C.8', title: 'Lesson 10-2 Introduction to Matrices (Grade 11, Week 12)' });
const { C, txt, card, pill, disc, math, fig, chrome, banner, whatif, cue, notes, pres, sh } = L;
const { TEAL, ORG, NAVY, DKG, GOLD, GREY, BORDER, INK, WHITE, GOLDBG, BROWN } = C;
const fmt = v => (typeof v === 'number' && v < 0) ? '−' + Math.abs(v) : String(v);

// native animated matrix grid. data: rows of numbers; o: {cw,ch,g (click token or 'c0'),stag,nm,fs,hl:{'r,c':color},fill,dark}
function mgrid(s, x, y, data, o = {}) {
  const cw = o.cw || 0.5, ch = o.ch || 0.42, R = data.length, Cc = data[0].length, g = o.g || 'c0', st = o.stag || 0, nm = o.nm || 'm';
  const nameOf = (i, base) => g === 'c0' ? undefined : `${g}_fade@${(o.delay || 0) + i * st}_${nm}${base}`;
  let i = 0;
  data.forEach((row, r) => row.forEach((v, c) => {
    if (o.only && !o.only.includes(r + ',' + c)) return;
    const hl = o.hl && o.hl[r + ',' + c];
    const f = hl || (o.fillRow ? o.fillRow(r, c) : (o.fill || 'E4F1EF'));
    const strong = hl || o.fillRow;
    s.addText(fmt(v), { x: x + 0.1 + c * cw, y: y + r * ch, w: cw - 0.04, h: ch - 0.04, shape: pres.shapes.ROUNDED_RECTANGLE, rectRadius: 0.06, fill: { color: f }, color: strong ? WHITE : INK, fontFace: 'Cambria', fontSize: o.fs || 13, bold: true, align: 'center', valign: 'middle', margin: 0, isTextBox: true, objectName: nameOf(i++, 'c') });
  }));
  const H = R * ch - 0.04, bx = (xx, dir) => {
    const lc = o.dark ? WHITE : NAVY;
    s.addShape(pres.shapes.LINE, { x: xx, y, w: 0, h: H, line: { color: lc, width: 2 }, objectName: nameOf(i++, 'b') });
    s.addShape(pres.shapes.LINE, { x: dir > 0 ? xx - 0.08 : xx, y, w: 0.08, h: 0, line: { color: lc, width: 2 }, objectName: nameOf(i++, 'b') });
    s.addShape(pres.shapes.LINE, { x: dir > 0 ? xx - 0.08 : xx, y: y + H, w: 0.08, h: 0, line: { color: lc, width: 2 }, objectName: nameOf(i++, 'b') });
  };
  if (!o.only) { bx(x + 0.04, -1); bx(x + 0.1 + Cc * cw + 0.0, 1); }
  return { w: Cc * cw + 0.2, h: R * ch };
}

L.title(1, { kicker: 'GRADE 11  ·  ALGEBRA II  ·  TOPIC 10', lesson: 'Lesson 10-2', lines: 'Introduction\nto Matrices', sub: 'Data in rows and columns', upnext: 'Up next: 10-3 Matrix Operations in Depth',
  hero(s) {
    const d = [[3, -1, 0], [2, 4, 7]];
    // column and row labels
    ['col 1', 'col 2', 'col 3'].forEach((t, c) => txt(s, t, 8.4 + c * 0.95, 2.35, 0.9, 0.3, { fontSize: 12, color: 'BFE3DF', align: 'center', objectName: 'd1000_fade_cl' + c }));
    ['row 1', 'row 2'].forEach((t, r) => txt(s, t, 7.4, 3.0 + r * 0.8, 0.9, 0.55, { fontSize: 12, color: 'BFE3DF', valign: 'middle', objectName: 'd1000_fade_rl' + r }));
    mgrid(s, 8.2, 2.95, d, { cw: 0.95, ch: 0.8, g: 'd1100', stag: 200, nm: 'h', fs: 22, dark: true, fill: 'E4F1EF' });
    txt(s, [{ text: 'a', options: { italic: true } }, { text: '23', options: { subscript: true } }, { text: ' = 7', options: {} }], 8.2, 4.8, 3.0, 0.5, { fontFace: 'Cambria', fontSize: 20, color: GOLD, objectName: 'd3400_fade_a23' });
    math(s, 's1_f', 8.2, 5.2, { s: 1.5, name: 'd3700_fade_lf' });
  } });
L.journey(2, ['Three no-calculator checks', 'Notation, scalar multiples, sums and differences, transpose', 'Practice, Apply, Investigate', 'Visitors on the Red Sea coast', '3 of 3 unlocks the last station', 'Create one, then Time to Check']);
L.objectives(3, ['Perform scalar multiplication to create a new matrix.', 'Add and subtract matrices by combining corresponding elements.', 'Calculate the transpose of a matrix.'],
  ['Column', 'column vector', 'diagonal matrix', 'Dimensions', 'Entries', 'main diagonal', 'Matrix', 'matrix notation', 'Row', 'row vector', 'Scalar', 'scalar multiple', 'square matrix', 'transpose'],
  [['(+)HSN.VM.C.6', 'Use matrices to represent and manipulate data, e.g., to represent payoffs or incidence relationships in a network.'], ['(+)HSN.VM.C.7', 'Multiply matrices by scalars to produce new matrices, e.g., as when all of the payoffs in a game are doubled.'], ['(+)HSN.VM.C.8', 'Add, subtract, and multiply matrices of appropriate dimensions.']]);
L.diagnose(4, ['s4_c1', 's4_c2', 's4_c3'], ['s4_a1', 's4_a2', 's4_a3'], 'All three answers are written without a calculator, and you can say which operation is done to every component of a vector.', '>30% miss Q1 or Q2 spend two minutes on signed arithmetic before slide 5; Q3 redo one vector example and say "every component" before slide 6.');

// 5 notation
{
  const s = pres.addSlide(); const n = 5;
  chrome(s, n, 2, 'Matrix notation and dimensions');
  banner(s, 0.5, 1.85, 12.35, 0.8, [['s5_f1', 1.1], ['s5_f2', 1.1]], { name: 'c1_fade_ban' });
  const X = [0.5, 4.8, 8.9], Wd = [4.2, 4.0, 3.95];
  const lab = [['EXAMPLE A', TEAL], ['EXAMPLE B', ORG], ['EXAMPLE C', NAVY]];
  lab.forEach(([t, c], i) => { card(s, X[i], 2.8, Wd[i], 4.0, { objectName: `c1_fade_ec${i}` }); pill(s, t, X[i] + 0.2, 2.92, 1.3, 0.3, c, WHITE, 11, { objectName: `c1_fade_el${i}` }); });
  // A
  const A = [[3, -1, 0, 5], [2, 4, 7, -2]];
  math(s, 's5_aL', 0.7, 4.15, { s: 1.2, vc: true, name: 'c1_fade_aL' });
  mgrid(s, 1.3, 3.65, A, { cw: 0.6, ch: 0.55, g: 'c1', nm: 'A', fs: 15 });
  mgrid(s, 1.3, 3.65, A, { cw: 0.6, ch: 0.55, g: 'c2', nm: 'Ah', fs: 15, hl: { '1,2': ORG, '0,3': TEAL }, only: ['1,2', '0,3'] });
  math(s, 's5_a1', 0.7, 5.05, { s: 1.15, name: 'c2_fade_a1' }); math(s, 's5_a2', 0.7, 5.6, { s: 1.15, name: 'c2_fade_a2' });
  // B
  const B = [[1, 0, 0], [0, 5, 0], [0, 0, -2]];
  math(s, 's5_bL', 5.0, 4.3, { s: 1.2, vc: true, name: 'c1_fade_bL' });
  mgrid(s, 5.5, 3.45, B, { cw: 0.6, ch: 0.5, g: 'c1', nm: 'B', fs: 15 });
  mgrid(s, 5.5, 3.45, B, { cw: 0.6, ch: 0.5, g: 'c3', nm: 'Bh', fs: 15, hl: { '0,0': GOLD, '1,1': GOLD, '2,2': GOLD }, only: ['0,0', '1,1', '2,2'] });
  math(s, 's5_b1', 5.0, 5.05, { s: 1.15, name: 'c3_fade_b1' }); math(s, 's5_b2', 5.0, 5.6, { s: 1.15, name: 'c3_fade_b2' });
  // C
  math(s, 's5_cL', 9.1, 3.85, { s: 1.2, vc: true, name: 'c1_fade_cL' });
  mgrid(s, 9.6, 3.6, [[4, -2, 9]], { cw: 0.6, ch: 0.5, g: 'c1', nm: 'R', fs: 15 });
  math(s, 's5_cL2', 9.1, 4.7, { s: 1.2, vc: true, name: 'c1_fade_cL2' });
  mgrid(s, 9.6, 4.35, [[7], [0]], { cw: 0.6, ch: 0.5, g: 'c1', nm: 'Cv', fs: 15 });
  math(s, 's5_c1', 9.1, 5.55, { s: 1.15, name: 'c4_fade_c1' }); math(s, 's5_c2', 9.1, 6.05, { s: 1.15, name: 'c4_fade_c2' });
  cue(n, 'click 1 formulas and all four matrices | click 2 Example A: dimensions 2x4, a23 = 7 (orange) and a14 = 5 (teal): "rows first, then columns" | click 3 Example B: the main diagonal lights up | click 4 Example C: row vector and column vector. Route: dimensions reversed -> redo Example A.');
  notes(s, n);
}
// 6 scalar
{
  const s = pres.addSlide(); const n = 6;
  chrome(s, n, 2, 'Scalar multiplication');
  banner(s, 0.5, 1.85, 12.35, 0.8, [['s6_f1', 1.2], ['s6_f2', 1.2]], { name: 'c1_fade_ban' });
  const P = [[0.5, TEAL, 'EXAMPLE A', 's6_a0', 's6_aT', [[2, -1], [0, 4]], [[6, -3], [0, 12]], 's6_a1'], [6.75, ORG, 'EXAMPLE B', 's6_b0', 's6_bT', [[8, -6], [4, 2]], [[-4, 3], [-2, -1]], 's6_b1']];
  P.forEach(([x, col, lab, k0, kT, M0, M1, kw], i) => {
    const g1 = i === 0 ? 'c1' : 'c3', g2 = i === 0 ? 'c2' : 'c4';
    card(s, x, 2.8, 6.1, 3.0, { objectName: `${g1}_fade_ec${i}` });
    pill(s, lab, x + 0.2, 2.92, 1.3, 0.3, col, WHITE, 11, { objectName: `${g1}_fade_el${i}` });
    mgrid(s, x + 0.3, 3.55, M0, { cw: 0.6, ch: 0.5, g: g1, nm: 'M0' + i, fs: 15 });
    math(s, kT, x + 2.1, 4.05, { s: 1.1, vc: true, name: `${g2}_fade_kt${i}` });
    s.addShape(pres.shapes.LINE, { x: x + 2.55, y: 4.05, w: 0.7, h: 0, line: { color: GOLD, width: 3, endArrowType: 'triangle' }, objectName: `${g2}_wipe_ar${i}` });
    mgrid(s, x + 3.5, 3.55, M1, { cw: 0.7, ch: 0.5, g: g2, nm: 'M1' + i, fs: 15, stag: 250, fill: 'FFF4D6' });
    math(s, kw, x + 0.3, 4.85, { s: 1.15, name: `${g2}_fade_wk${i}` });
  });
  whatif(s, 0.5, 5.95, 12.35, 0.9, 'What if the scalar is 0? Predict the result, then test.', 's6_w', 'c5', { fs: 13, ms: 1.2 });
  cue(n, 'click 1 formula and the matrix A | click 2 ×3 and the new matrix: every entry is multiplied (the dimensions do not change) | click 3 Example B matrix | click 4 ×(−1/2): negative changes every sign, one half halves every entry | click 5 What if 0: the zero matrix. Route: only one entry multiplied -> say "every entry gets the scalar".');
  notes(s, n);
}
// 7 add / subtract
{
  const s = pres.addSlide(); const n = 7;
  chrome(s, n, 2, 'Adding and subtracting matrices');
  banner(s, 0.5, 1.85, 12.35, 0.8, [['s7_f1', 1.2], ['s7_f2', 1.1]], { name: 'c1_fade_ban' });
  card(s, 0.5, 2.8, 6.1, 4.0, { objectName: 'c1_fade_ea' });
  pill(s, 'EXAMPLE A', 0.7, 2.92, 1.3, 0.3, TEAL, WHITE, 11, { objectName: 'c1_fade_eal' });
  const A = [[3, -2], [1, 5]], Bm = [[4, 0], [-6, 2]];
  const rowDo = (y, sym, res, g, capk) => {
    mgrid(s, 0.6, y, A, { cw: 0.55, ch: 0.5, g: 'c1', nm: 'A' + capk, fs: 14 });
    math(s, sym, 1.95, y + 0.5, { s: 1.0, vc: true, align: 'c', name: 'c1_fade_sy' + capk });
    mgrid(s, 2.3, y, Bm, { cw: 0.6, ch: 0.5, g: 'c1', nm: 'B' + capk, fs: 14 });
    math(s, 's7_Ae', 3.8, y + 0.5, { s: 1.0, vc: true, align: 'c', name: `${g}_fade_eq${capk}` });
    mgrid(s, 4.05, y, res, { cw: 0.7, ch: 0.5, g, nm: 'R' + capk, fs: 14, stag: 200, fill: 'FFF4D6' });
  };
  rowDo(3.5, 's7_Ap', [[7, -2], [-5, 7]], 'c2', 'p'); rowDo(5.1, 's7_Am', [[-1, -2], [7, 3]], 'c3', 'm');
  math(s, 's7_cap1', 4.3, 4.6, { s: 1.0, name: 'c2_fade_cp' }); math(s, 's7_cap2', 4.3, 6.2, { s: 1.0, name: 'c3_fade_cm' });
  card(s, 6.75, 2.8, 6.1, 2.15, { objectName: 'c4_fade_eb' });
  pill(s, 'EXAMPLE B', 6.95, 2.92, 1.3, 0.3, ORG, WHITE, 11, { objectName: 'c4_fade_ebl' });
  math(s, 's7_b0', 8.5, 3.07, { s: 1.1, vc: true, name: 'c4_fade_eb0' });
  const T3A = [[3, 12], [-6, 0]], T2B = [[4, -2], [6, 10]];
  mgrid(s, 6.85, 3.45, T3A, { cw: 0.55, ch: 0.5, g: 'c4', nm: 'X', fs: 14 });
  math(s, 's7_Am', 8.25, 3.95, { s: 1.0, vc: true, align: 'c', name: 'c4_fade_sx' });
  mgrid(s, 8.45, 3.45, T2B, { cw: 0.55, ch: 0.5, g: 'c4', nm: 'Y', fs: 14 });
  math(s, 's7_Ae', 9.85, 3.95, { s: 1.0, vc: true, align: 'c', name: 'c5_fade_eqb' });
  mgrid(s, 10.05, 3.45, [[-1, 14], [-12, -10]], { cw: 0.75, ch: 0.5, g: 'c5', nm: 'Z', fs: 14, stag: 200, fill: 'FFF4D6' });
  card(s, 6.75, 5.1, 6.1, 1.7, { objectName: 'c6_fade_ec' });
  pill(s, 'EXAMPLE C', 6.95, 5.22, 1.3, 0.3, NAVY, WHITE, 11, { objectName: 'c6_fade_ecl' });
  math(s, 's7_c0', 6.95, 5.7, { s: 1.15, name: 'c6_fade_c0' }); math(s, 's7_c1', 6.95, 6.15, { s: 1.15, name: 'c6_fade_c1' });
  pill(s, 'not defined', 10.9, 5.9, 1.7, 0.4, 'C0392B', WHITE, 13, { objectName: 'c6_fade_nd' });
  cue(n, 'click 1 formula, A and B | click 2 A + B: matching positions are added | click 3 A − B: watch 1 − (−6) = 7 | click 4 Example B: 3A and 2B (scalar multiples first) | click 5 the subtraction result | click 6 Example C: different dimensions, so there are no matching entries. Route: >30% miss 1 − (−6) -> "subtract a negative = add".');
  notes(s, n);
}
// 8 transpose
{
  const s = pres.addSlide(); const n = 8;
  chrome(s, n, 2, 'The transpose of a matrix');
  banner(s, 0.5, 1.85, 12.35, 0.8, [['s8_f1', 1.0], ['s8_f2', 1.0], ['s8_f3', 1.0]], { name: 'c1_fade_ban' });
  card(s, 0.5, 2.8, 5.9, 4.0, { objectName: 'c1_fade_dc' });
  const A = [[2, 5, 1], [4, 0, 3]];
  const rowCol = (r) => r === 0 ? TEAL : ORG;
  math(s, 's8_A', 0.8, 3.0, { s: 1.0, name: 'c1_fade_cA' });
  mgrid(s, 0.7, 3.5, A, { cw: 0.6, ch: 0.6, g: 'c1', nm: 'A', fs: 16, fillRow: (r, c) => rowCol(r) });
  s.addShape(pres.shapes.LINE, { x: 2.95, y: 4.1, w: 0.8, h: 0, line: { color: NAVY, width: 3, endArrowType: 'triangle' }, objectName: 'c2_wipe_arr' });
  txt(s, 'transpose', 2.85, 3.75, 1.0, 0.3, { fontSize: 11, italic: true, color: GREY, align: 'center', objectName: 'c2_fade_tl' });
  math(s, 's8_AT', 4.2, 3.0, { s: 1.0, name: 'c2_fade_cAT' });
  const AT = [[2, 4], [5, 0], [1, 3]];
  // column 1 (row 1 of A) then column 2
  [0, 1].forEach(cc => {
    const g = cc === 0 ? 'c2' : 'c3';
    AT.forEach((row, r) => s.addText(fmt(row[cc]), { x: 4.3 + cc * 0.6, y: 3.5 + r * 0.6, w: 0.56, h: 0.56, shape: pres.shapes.ROUNDED_RECTANGLE, rectRadius: 0.06, fill: { color: cc === 0 ? TEAL : ORG }, color: WHITE, fontFace: 'Cambria', fontSize: 16, bold: true, align: 'center', valign: 'middle', margin: 0, isTextBox: true, objectName: `${g}_fade@${r * 200}_t${cc}${r}` }));
  });
  [4.2 + 0.04, 4.2 + 0.04 + 1.2 + 0.1].forEach((xx, k) => {
    const lc = NAVY, y = 3.5, H = 3 * 0.6 - 0.04;
    const dir = k === 0 ? 1 : -1;
    s.addShape(pres.shapes.LINE, { x: xx, y, w: 0, h: H, line: { color: lc, width: 2 }, objectName: 'c2_fade_tb' + k });
    s.addShape(pres.shapes.LINE, { x: k === 0 ? xx : xx - 0.08, y, w: 0.08, h: 0, line: { color: lc, width: 2 }, objectName: 'c2_fade_tc' + k });
    s.addShape(pres.shapes.LINE, { x: k === 0 ? xx : xx - 0.08, y: y + H, w: 0.08, h: 0, line: { color: lc, width: 2 }, objectName: 'c2_fade_td' + k });
  });
  math(s, 's8_c1', 0.8, 5.5, { s: 1.0, name: 'c2_fade_k1' }); math(s, 's8_c2', 0.8, 5.9, { s: 1.0, name: 'c3_fade_k2' });
  math(s, 's8_c3', 0.8, 6.3, { s: 1.0, name: 'c3_fade_k3' });
  card(s, 6.55, 2.8, 6.3, 1.5, { objectName: 'c4_fade_ea' });
  pill(s, 'EXAMPLE A', 6.75, 2.92, 1.3, 0.3, TEAL, WHITE, 11, { objectName: 'c4_fade_eal' });
  math(s, 's8_a1', 6.75, 3.45, { s: 1.15, name: 'c4_fade_a1' });
  card(s, 6.55, 4.45, 6.3, 2.35, { objectName: 'c5_fade_eb' });
  pill(s, 'EXAMPLE B', 6.75, 4.57, 1.3, 0.3, ORG, WHITE, 11, { objectName: 'c5_fade_ebl' });
  math(s, 's8_b0', 6.75, 5.05, { s: 1.2, name: 'c5_fade_b0' }); math(s, 's8_b1', 6.75, 5.85, { s: 1.2, name: 'c6_fade_b1' });
  cue(n, 'click 1 formulas, A with row 1 teal and row 2 orange | click 2 transpose: row 1 becomes column 1 | click 3 row 2 becomes column 2: a 2x3 becomes 3x2 | click 4 Example A in symbols | click 5 Example B: the main diagonal stays in place | click 6 C + C^T is unchanged by transposing. Route: dimensions of A^T wrong -> "how many rows does A have? that is the number of columns of A^T".');
  notes(s, n);
}
L.practice(9, [
  ['PRACTICE', 'Secure the method', TEAL, [['s9_p1', 'slides 5, 8'], ['s9_p2', 'slides 6, 7']], 'the dimensions are written rows by columns, the entry is read from the right row and column, and every entry of both scalar multiples is combined with its matching entry.'],
  ['APPLY', 'Use it in context', ORG, [['s9_a1', 'slide 6'], ['s9_a2', 'slide 8']], 'matching entries are set equal or combined, the dimensions are checked before subtracting, and the answer states its dimensions.'],
  ['INVESTIGATE', 'Find out why', NAVY, [['s9_i1', 'slide 8'], ['s9_i2', 'slide 8']], 'your argument refers to entry positions (a_ij and a_ji), and a numerical example supports it.']], 'Each "stuck?" tag is the slide to return to.');
// 10 production: native matrices
L.production(10, 'Production: Visitors on the Red Sea coast', {
  left(s) {
    const o = { cw: 0.58, ch: 0.38, fs: 12 };
    const Q1 = [[12, 5], [9, 7], [15, 4]], Q2 = [[14, 6], [10, 9], [18, 5]], T = [[26, 11], [19, 16], [33, 9]];
    const Sx = [[39, 16.5], [28.5, 24], [49.5, 13.5]], G = [[2, 1], [1, 2], [3, 1]];
    ['Dom', 'Int'].forEach((t, c) => txt(s, t, 1.05 + c * 0.58, 2.12, 0.6, 0.22, { fontSize: 9, color: GREY, align: 'center', objectName: 'c1_fade_h' + c }));
    ['A', 'B', 'C'].forEach((t, r) => txt(s, 'Resort ' + t, 0.45, 2.56 + r * 0.38, 0.65, 0.3, { fontSize: 9, color: GREY, valign: 'middle', objectName: 'c1_fade_rr' + r }));
    math(s, 's10_Q1', 1.3, 1.8, { s: 0.9, align: 'c', name: 'c1_fade_ql1' }); 
    mgrid(s, 1.05, 2.38, Q1, Object.assign({ g: 'c1', nm: 'Q1' }, o));
    math(s, 's10_pl', 2.55, 2.96, { s: 0.9, vc: true, align: 'c', name: 'c1_fade_p' });
    math(s, 's10_Q2', 3.45, 1.8, { s: 0.9, align: 'c', name: 'c1_fade_ql2' });
    mgrid(s, 2.7, 2.38, Q2, Object.assign({ g: 'c1', nm: 'Q2' }, o));
    math(s, 's10_eq', 4.15, 2.96, { s: 0.9, vc: true, align: 'c', name: 'c2_fade_e' });
    math(s, 's10_T', 5.0, 1.8, { s: 0.9, align: 'c', name: 'c2_fade_tl' });
    mgrid(s, 4.3, 2.38, T, Object.assign({ g: 'c2', nm: 'T', stag: 150, fill: 'FFF4D6' }, o));
    math(s, 's10_S', 6.4, 1.8, { s: 0.9, align: 'c', name: 'c3_fade_sl' });
    mgrid(s, 5.7, 2.38, Sx, Object.assign({ g: 'c3', nm: 'S', stag: 150, fill: 'FFF4D6' }, o, { cw: 0.6 }));
    math(s, 's10_G', 1.3, 3.95, { s: 0.9, align: 'c', name: 'c4_fade_gl' });
    mgrid(s, 0.7, 4.25, G, Object.assign({ g: 'c4', nm: 'G', hl: { '2,0': ORG } }, o));
    math(s, 's10_GT', 3.5, 3.95, { s: 0.9, align: 'c', name: 'c4_fade_gtl' });
    mgrid(s, 2.7, 4.25, [[2, 1, 3], [1, 2, 1]], Object.assign({ g: 'c4', nm: 'GT', stag: 150, hl: { '0,2': ORG } }, o));
    txt(s, 'Largest growth: 3 thousand domestic visitors at Resort C', 4.9, 4.3, 2.5, 0.9, { fontSize: 11, italic: true, color: 'B8530F', objectName: 'c4_fade_note' });
    math(s, 's10_lab', 0.65, 5.7, { s: 1.0, name: 'c1_fade_formulas' });
    math(s, 's10_chk', 0.65, 6.4, { s: 0.85, name: 'c6_fade_chk' });
  },
  model: 'A Vision 2030 tourism pilot tracks three model Red Sea resorts (model values only, not real data). Matrices record visitors in thousands: rows are Resorts A, B, C; column 1 domestic, column 2 international. Q1 is the first quarter, Q2 the second. Average spend: SAR 1,500 per visitor, so 1 thousand visitors spend SAR 1.5 million.',
  tasks: ['Find T, the visitors in both quarters. State its dimensions and say in words what the entry in row 3, column 2 means.', 'Find S, the model spending in SAR million, and explain what its first entry means. Add all entries of S for the total.', 'Find G and then G transposed. State the dimensions of the transpose and the resort and visitor type with the largest growth.'],
  hint: 'Hint: same position to add; every entry to scale.', wiText: 'WHAT IF spend rises to SAR 2,000 per visitor?', wiMath: 's10_wi',
  cue: 'click 1 the model and the two quarter matrices | click 2 T = Q1 + Q2 | click 3 S = 1.5 T | click 4 G = Q2 - Q1 and its transpose, the largest growth is highlighted | click 5 hint and What if | click 6 check your answers. Route: >30% cannot start Task 1 -> slide 7 Example A.' });
L.gate(11, [['s11_1', 'slide 5', TEAL, 1.15], ['s11_2', 'slides 6 and 7', ORG, 1.15], ['s11_3', 'slide 8', NAVY, 0.9]], 'Q1 missed -> slide 5; Q2 -> slides 6-7; Q3 -> slide 8.');
L.smart(12, ['Choose a table of real data about Jeddah or your school with 3 rows and 2 columns (for example, students and teachers in three year groups). Write it as a matrix D and as a second matrix E for another term.', 'Swap with a partner: they compute D + E, 2D and the transpose of D + E, and state each set of dimensions.', 'Add a What if...? question (a different scalar, or a subtraction) with a prediction and a test.'], [1.1, 0.8, 0.7],
  'both matrices are 3 by 2, your partner\'s three answers match yours, every set of dimensions is stated, and your What if...? question has a prediction and a test.', ['s12_1', 's12_2'], '10-3 Matrix Operations in Depth', 'Exit 1 missed -> slide 8 Example A; Exit 2 missed -> slide 7 Example A and slide 6 Example A.');
L.exam(13, [
  ['SAT', 'Advanced Math · matrices', NAVY, 's13_s0', ['s13_s1', 's13_s2', 's13_s3'], 'Trap: solving 2x = 9 and forgetting the second matrix gives x = 9/2.'],
  ['GAT', 'Qudurat · quantitative comparison', TEAL, 's13_g0', ['s13_g1', 's13_g2', 's13_g3'], 'Trap: doubling only one entry gives 14 and makes B look greater.'],
  ['SAAT', 'Tahsili · four options', ORG, 's13_a0', ['s13_a1', 's13_a2', 's13_a3'], 'Trap: A forgets the swap, C multiplies 3 x 5, D adds 3 + 5.']], 'SAT miss -> slide 7 Example A; GAT -> slide 6 Example A; SAAT -> slide 8 Example A.');
L.complete(14, 'A matrix is a rectangle of entries named by its dimensions (rows by columns); scalar multiples change every entry, sums and differences need equal dimensions and combine matching entries, and the transpose turns rows into columns.', 'Next lesson: 10-3 Matrix Operations in Depth');
L.write('raw.pptx').then(f => console.log('wrote', f));
