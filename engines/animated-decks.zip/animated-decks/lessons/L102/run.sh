set -e
cd "$(dirname "$0")"
python3 math.py && node build.js && python3 /home/claude/lib/animate.py | tail -3
V=/root/.claude/skills/synced/6d298923-714b-49f3-a001-d0048c23790a_76b2c490-423e-4dce-9177-99a8bff7b1bb/pptx/scripts/office
python3 $V/validate.py out.pptx | tail -3
python3 $V/soffice.py --headless --convert-to pdf out.pptx >/dev/null 2>&1
rm -rf r; mkdir r; pdftoppm -jpeg -r 80 out.pdf r/s
ls r | wc -l
