# Animated FIKR decks (approved style, 16 Nov 2026)

Pipeline: math.py (xelatex snippets -> PNG) + figs.py (matplotlib layered diagrams) -> build.js (pptxgenjs, uses lib/lib.js) -> lib/animate.py (injects click animations and Morph) -> validate -> LibreOffice render.

- lib/: shared engine (lib.js templates, figlib.py, mathlib.py, mknotes.py, animate.py). Copy to /home/claude/lib.
- shared-assets/: logos each lesson folder expects in its own assets/ folder.
- lessons/: Week 12 builds. L37 = Gr10 3-7, L41 = Gr10 4-1, L102 = Gr11 10-2, v101 = Gr11 10-1 (also has rotating-arrow frames and the voyage clip).

objectName grammar: cN_<fade|wipe>[@ms]_label = click group N; dMS_... = auto after MS ms; !!name = Morph match.
Viewer note: Keynote/other viewers ignore Spin and video autoplay; use frame-by-frame builds.
Run: bash run.sh inside a lesson folder (after copying lib and assets).
