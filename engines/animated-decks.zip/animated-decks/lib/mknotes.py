import re, json, sys
src, dst = sys.argv[1], sys.argv[2]
t = open(src).read()
parts = re.split(r'<!-- Slide number: (\d+) -->', t)
N = {}
for i in range(1, len(parts), 2):
    n = int(parts[i]); body = parts[i+1]
    if '### Notes:' in body:
        N[n] = body.split('### Notes:', 1)[1].strip()
json.dump(N, open(dst, 'w'), indent=1, ensure_ascii=False)
print(len(N))
