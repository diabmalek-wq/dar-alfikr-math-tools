import os, json, math, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Arc, Circle
plt.rcParams.update({'font.family': 'serif', 'mathtext.fontset': 'cm', 'font.size': 12})
OUT = os.path.join(os.getcwd(), 'f'); os.makedirs(OUT, exist_ok=True)
TEAL, ORG, NAVY, DKG, GOLD, INK, GREY = '#17A199', '#E8762C', '#1F3864', '#0E4F4C', '#F0B323', '#1B2B2A', '#5A6B69'
INFO = {}
class Fig:
    def __init__(self, name, w, h, xlim, ylim, dark=False, dpi=220):
        self.name, self.w, self.h, self.xlim, self.ylim, self.dpi, self.dark = name, w, h, xlim, ylim, dpi, dark
        self.fg = '#FFFFFF' if dark else INK
        self.grid = '#FFFFFF' if dark else '#7A8C8A'
    def layer(self, key, fn):
        fig = plt.figure(figsize=(self.w, self.h), dpi=self.dpi)
        ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(*self.xlim); ax.set_ylim(*self.ylim); ax.axis('off')
        fig.patch.set_alpha(0); ax.patch.set_alpha(0)
        fn(ax, self)
        path = f'{OUT}/{self.name}_{key}.png'
        fig.savefig(path, transparent=True, dpi=self.dpi); plt.close(fig)
        INFO.setdefault(self.name, {'w': self.w, 'h': self.h, 'layers': []})['layers'].append({'key': key, 'file': path})
def arrow(ax, p, q, color, lw=2.6, ms=16, ls='-', z=5, alpha=1):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle='-|>', mutation_scale=ms, lw=lw, color=color, ls=ls, zorder=z, shrinkA=0, shrinkB=0, alpha=alpha, capstyle='round', joinstyle='round'))
def grid_axes(ax, F, xt, yt, fs=10, gridalpha=0.2, labels=True, xs=1, ys=1):
    x0, x1 = F.xlim; y0, y1 = F.ylim
    for x in xt: ax.plot([x, x], [y0, y1], color=F.grid, lw=0.8, alpha=gridalpha, zorder=0)
    for y in yt: ax.plot([x0, x1], [y, y], color=F.grid, lw=0.8, alpha=gridalpha, zorder=0)
    arrow(ax, (x0 + 0.01*(x1-x0), 0), (x1 - 0.005*(x1-x0), 0), F.fg, lw=1.6, ms=12, z=1)
    arrow(ax, (0, y0 + 0.01*(y1-y0)), (0, y1 - 0.005*(y1-y0)), F.fg, lw=1.6, ms=12, z=1)
    if labels:
        for x in xt:
            if x != 0: ax.text(x, -(y1-y0)*0.03, f'{x}', ha='center', va='top', color=F.fg, fontsize=fs, alpha=.85)
        for y in yt:
            if y != 0: ax.text(-(x1-x0)*0.012, y, f'{y}', ha='right', va='center', color=F.fg, fontsize=fs, alpha=.85)
def dot(ax, p, color, r=0.11, z=7, ec='white'):
    ax.add_patch(Circle(p, r, fc=color, ec=ec, lw=1.6, zorder=z))
def pdot(ax, p, color, ms=7, z=7, ec='white'):
    ax.plot([p[0]], [p[1]], 'o', ms=ms, mfc=color, mec=ec, mew=1.4, zorder=z)
def lab(ax, p, s, color, fs=13, ha='center', va='center', bold=False, z=9, bg=None):
    t = ax.text(p[0], p[1], s, color=color, fontsize=fs, ha=ha, va=va, zorder=z, weight='bold' if bold else 'normal')
    if bg: t.set_bbox(dict(fc=bg, ec='none', pad=1.5, alpha=.92))
    return t
def curve(ax, f, x0, x1, color, lw=3.0, ymin=-1e9, ymax=1e9, ls='-', z=4, n=900, alpha=1, skip=None):
    x = np.linspace(x0, x1, n); y = f(x)
    y = np.where((y < ymin) | (y > ymax), np.nan, y)
    if skip is not None: y = np.where(np.abs(x - skip) < 1e-3, np.nan, y)
    ax.plot(x, y, color=color, lw=lw, ls=ls, zorder=z, alpha=alpha, solid_capstyle='round')
def save():
    json.dump(INFO, open(f'{OUT}/info.json', 'w'), indent=1)
