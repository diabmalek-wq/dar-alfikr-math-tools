import subprocess, json, os, shutil, sys
from PIL import Image
OUT = os.path.join(os.getcwd(), 'm'); os.makedirs(OUT, exist_ok=True)
INK = '1B2B2A'
S = {}
def add(k, body, col=INK, pt=14): S[k] = (body, col, pt)
def build():
    tex = [r'\documentclass[multi={snip},border=3pt]{standalone}', r'\usepackage{amsmath,amssymb,xcolor}', r'\begin{document}']
    keys = list(S)
    for k in keys:
        body, col, pt = S[k]
        lead = round(pt * 1.25, 1)
        if body.startswith('@@'):
            body = r'\begin{tabular}{l}' + body[2:] + r'\end{tabular}'
        tex.append(r'\begin{snip}\definecolor{c}{HTML}{%s}\color{c}\fontsize{%s}{%s}\selectfont %s\end{snip}' % (col, pt, lead, body))
    tex.append(r'\end{document}')
    open(f'{OUT}/m.tex', 'w').write('\n'.join(tex))
    r = subprocess.run(['xelatex', '-interaction=nonstopmode', '-halt-on-error', 'm.tex'], cwd=OUT, capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout[-2500:]); raise SystemExit('latex failed')
    for f in os.listdir(OUT):
        if f.startswith('p-') and f.endswith('.png'): os.remove(f'{OUT}/{f}')
    subprocess.run(['pdftocairo', '-png', '-transp', '-r', '300', f'{OUT}/m.pdf', f'{OUT}/p'], check=True)
    files = sorted(f for f in os.listdir(OUT) if f.startswith('p-') and f.endswith('.png'))
    assert len(files) == len(keys), (len(files), len(keys))
    man = {}
    for k, f in zip(keys, files):
        im = Image.open(f'{OUT}/{f}'); dst = f'{OUT}/{k}.png'
        shutil.move(f'{OUT}/{f}', dst)
        man[k] = {'file': dst, 'w': im.size[0] / 300, 'h': im.size[1] / 300}
    json.dump(man, open(f'{OUT}/manifest.json', 'w'), indent=1)
    print('snippets', len(man))
