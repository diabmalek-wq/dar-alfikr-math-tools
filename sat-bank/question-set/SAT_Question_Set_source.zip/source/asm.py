import re
B='../B/'
def rd(f): return open(B+f).read()
def cut(t,start,end=None):
    i=t.index(start); j=t.index(end) if end else len(t)
    return t[i:j]
p1=rd('part1.tex'); p2=rd('part2.tex'); p3=rd('part3.tex'); p4=rd('part4.tex'); p5=rd('part5.tex')
def split_mod(t,m1,m2,end=None):
    a=t.index(m1); b=t.index(m2)
    e=t.index(end) if end else len(t)
    return t[a+len(m1):b], t[b+len(m2):e]
S={}
S[1]=split_mod(p1,'\\section*{Section 2 --- Module 1: Math}','\\section*{Section 2 --- Module 2: Math}')
S[2]=split_mod(p2,'\\section*{Section 2, Module 1: Math}','\\section*{Section 2, Module 2: Math}')
S[3]=split_mod(p3,'\\section*{Section 2, Module 1: Math}','\\section*{Section 2, Module 2: Math}')
S[4]=(open('oct1.tex').read(),open('oct2.tex').read())
j1=p4.index('\\subsection*{Module 1}',p4.index('\\section*{June 2023 International Math}'))
j2=p4.index('\\subsection*{June 2023 International Math --- Module 2}')
je=p4.index('\\clearpage',j2)
S[5]=(p4[j1+len('\\subsection*{Module 1}'):j2],p4[j2+len('\\subsection*{June 2023 International Math --- Module 2}'):je])
S[6]=(p5[p5.index('\\QL{A1}'):],'')
def fix(t):
    t=re.sub(r'\\clearpage','',t)
    t=t.replace('\\newcommand{\\QL}[1]{\\par\\medskip\\Needspace{4.2cm}\\noindent\\textbf{#1.}\\ }','')
    return t
# ---- additions
def rep(set_,mod,old,new,count=1):
    t=S[set_][mod-1]
    assert old in t,(set_,mod,old[:50])
    t=t.replace(old,new,count)
    S[set_]=(t,S[set_][1]) if mod==1 else (S[set_][0],t)
rep(2,1,"given right triangle?\n","given right triangle?\n\\figRTri\n")
rep(2,1,"Find $k$.\n","Find $k$.\n\\figCone\n")
rep(3,1,"Find $m\\angle SKL$.","Find $m\\angle SKL$.\n\\figRST{$39\\dg$}{$z\\dg$}{$(5z-3)\\dg$}")
rep(5,1,"Find $\\angle SKL$.","Find $\\angle SKL$.\n\\figRST{$10\\dg$}{}{$50\\dg$}")
tab=lambda hdr,rows:"\\begin{center}\\renewcommand{\\arraystretch}{1.5}\\begin{tabular}{|c|"+"c|"*len(rows[0])+"}\\hline\\rowcolor{black!7}"+hdr+"\\\\\\hline "+"\\\\\\hline ".join(" & ".join(r) if False else r for r in [""])+"\\end{tabular}\\end{center}"
def mktab(xs,ys,yn='y'):
    n=len(xs)
    return ("\\begin{center}\\renewcommand{\\arraystretch}{1.5}\\begin{tabular}{|c|"+"c|"*n+"}\\hline\\rowcolor{black!7}$x$ & "+" & ".join(xs)+"\\\\\\hline $"+yn+"$ & "+" & ".join(ys)+"\\\\\\hline\\end{tabular}\\end{center}")
rep(6,1,"A table shows $(-6,48),(-3,39),(3,21),(6,12)$.","A table shows four values of $x$ and their corresponding values of $y$.\n"+mktab(['$-6$','$-3$','$3$','$6$'],['48','39','21','12']))
rep(6,1,"The table $4000,2400,1440,864$ for $x=1,2,3,4$ describes","The table gives values of $y$ for $x=1,2,3,4$. It describes")
rep(6,1,"describes what kind of function?","describes what kind of function?\n"+mktab(['1','2','3','4'],['4000','2400','1440','864']),)
rep(6,1,"a table contains $x=1,2,3$ and $y=22,36,a$. Find $a$.","a table contains the values shown. Find $a$.\n"+mktab(['1','2','3'],['22','36','$a$']))
rep(6,1,"right angle $Z$. Find $\\tan X$.","right angle $Z$. Find $\\tan X$.\n\\figXYZ")
rep(6,1,"Find $\\angle J$.","Find $\\angle J$.\n\\figJKL")

exec(open('fix.py').read())
def oldfig(txt):
    for m in re.finditer(r'\\begin\{center\}.*?\\end\{center\}',txt,flags=re.S):
        if 'tikzpicture' in m.group(0): return m.group(0)
    m=re.search(r'\\fig[A-Za-z]+',txt)
    return m.group(0) if m else ''
def process(sn,md,text):
    parts=re.split(r'(?=\\Q\{|\\QL\{)',text)
    out=[];cnt=0
    for p in parts:
        m=re.match(r'\\(Q|QL)\{([^}]*)\}',p)
        if not m: continue
        lab=m.group(2)
        key=(sn,md,int(lab) if m.group(1)=='Q' else lab)
        if key in F:
            nt=F[key]
            if nt is None: continue
            nt=nt.replace('@OF',oldfig(p))
        else:
            nt=p
        # notes
        def nn(mm):
            s=mm.group(1)
            return '\\note{Figure not drawn to scale.}' if 'scale' in s else ''
        nt=re.sub(r'\\note\{((?:[^{}]|\{[^{}]*\})*)\}',nn,nt)
        nt=nt.replace('\\Needspace{9cm}','').replace('\\Needspace{8cm}','').replace('\\Needspace{7cm}','')
        if '\\begin{ch}' not in nt and '\\sprline' not in nt and '\\fourtab' not in nt:
            nt=nt.rstrip()+'\n\\sprline'
        if m.group(1)=='Q':
            cnt+=1
            nt=re.sub(r'^\\Q\{[^}]*\}',lambda _m:'\\Q{%d}'%cnt,nt)
        out.append(nt.strip()+'\n')
    return '\n'.join(out)
for n in S:
    S[n]=(process(n,1,S[n][0]),process(n,2,S[n][1]) if S[n][1] else '')
# ---- headings
def head(n,m): return "\\clearpage\n\\banner{Set %d \\textperiodcentered\\ Module %d}\n"%(n,m)
out=[open('pre.tex').read(),"\\input{figs.tex}\\input{figs2.tex}\\input{figs3.tex}\n"]
# title block
out.append(r"""{\Large\bfseries\color{NAVY}SAT Math \textperiodcentered\ Complete Question Set}\hfill{\small\color{GREY}__COUNT__}\par
\vspace{2pt}\noindent Name\ \rule{6.2cm}{0.3pt}\hfill Class\ \rule{2.2cm}{0.3pt}\hfill Date\ \rule{2.8cm}{0.3pt}\par\vspace{4pt}\hrule\vspace{4pt}
""")
for n in range(1,6):
    for m in (1,2):
        out.append(("" if (n==1 and m==1) else "\\clearpage\n")+"\\banner{Set %d \\textperiodcentered\\ Module %d}\n"%(n,m)+fix(S[n][m-1]))
out.append("\\clearpage\n\\banner{Set 6 \\textperiodcentered\\ Question Bank}\n"+fix(S[6][0]))
out.append("\n\\end{document}\n")
doc="".join(out)
# ---- option layout
def lay(m):
    inner=m.group(1)
    items=re.split(r'\\item(?![a-zA-Z])',inner)
    items=[i.strip() for i in items[1:]]
    items=[('\\ob' if i=='\\ob' else i.replace('\\frac','\\dfrac')) for i in items]
    if len(items)!=4: return m.group(0)
    plain=[re.sub(r'\\(dfrac|tfrac|frac|sqrt|left|right|pm|le|ge|dg|mathrm|text)|[\\${}^_]','',i) for i in items]
    mx=max(len(p) for p in plain)
    tall=any(re.search(r'\\dfrac|\\sqrt|\\frac',i) for i in items)
    one=(mx<=22)
    if one: return ('\\optrowT' if tall else '\\optrow')+''.join('{%s}'%i for i in items)
    return ('\\optlistT' if tall else '\\optlist')+''.join('{%s}'%i for i in items)
doc=re.sub(r'\\begin\{ch\}(.*?)\\end\{ch\}',lay,doc,flags=re.S)
# fractions in Oct plain \frac inside options become display via tall
doc=re.sub(r'\\begin\{tikzpicture\}\[x=0\.0',lambda m:'\\begin{tikzpicture}[scale=0.6,x=0.0',doc)
nq=len(re.findall(r'\\Q\{|\\QL\{',doc))
doc=doc.replace('__COUNT__','%d questions \\textperiodcentered\\ 6 sets'%nq)
open('SAT.tex','w').write(doc)
print(nq)
