# overrides: (set,mod,num) -> block text ; None = delete
def ch(*o): return '\\begin{ch}'+''.join('\\item '+x for x in o)+'\\end{ch}'
def blk(stem,opts=None,fig='',lab=None):
    s=('\\QL{%s}'%lab if lab else '\\Q{@}')+stem
    if fig: s+='\n'+fig
    s+='\n'+(ch(*opts) if opts else '\\sprline')
    return s
def tb(xs,ys,yn='f(x)'):
    return ('\\begin{tabular}{|c|'+'c'*len(xs)+'|}\\hline $x$ & '+' & '.join(xs)+'\\\\\\hline $'+yn+'$ & '+' & '.join(ys)+'\\\\\\hline\\end{tabular}')
def tabopts(rows,yn='f(x)'):
    xs=rows[0]
    ts=[tb(xs,r,yn) for r in rows[1:]]
    return '\\fourtab{'+'}{'.join(ts)+'}'
def tbl2(title,xs,ys):
    return '\\begin{tabular}{|c|c|}\\multicolumn{2}{c}{\\textbf{%s}}\\\\\\hline $x$ & $y$\\\\\\hline '%title+'\\\\ '.join('%s & %s'%(a,b) for a,b in zip(xs,ys))+'\\\\\\hline\\end{tabular}'
F={}
# ---------------- SET 1
F[(1,1,1)]=blk("The graph of a system of two linear equations is shown. The solution to the system is $(x,y)$. What is the value of $y$?",["$-5$","$-4$","$2$","$3$"],'\\figSIa')
F[(1,1,5)]=blk("One of the two equations in a system of linear equations is given by $y=\\dfrac{3}{4}x+2$. The system has infinitely many solutions. If the second equation is $y=mx+b$, where $m$ and $b$ are constants, what is the value of $b$?",["$-2$","$0$","$1$","$2$"])
F[(1,1,6)]=None
F[(1,1,8)]=blk("The table shows the amount of time it took a participant in a study to complete each of $5$ tasks. What was the mean time, in minutes, for this participant to complete a task?\n\\begin{center}\\renewcommand{\\arraystretch}{1.3}\\begin{tabular}{|c|c|}\\hline\\rowcolor{black!7}Task & Time (min)\\\\\\hline 1 & 7\\\\\\hline 2 & 9\\\\\\hline 3 & 10\\\\\\hline 4 & 12\\\\\\hline 5 & 12\\\\\\hline\\end{tabular}\\end{center}",["$8$","$9$","$10$","$11$"])
F[(1,1,10)]=blk("Which of the following is closest to the slope of the line of best fit shown?",["$-11.19$","$-0.84$","$0.84$","$11.19$"],'\\figSIb')
F[(1,1,11)]=blk("In the figure, line $q$ is parallel to line $r$, and both lines are intersected by line $s$. If $y=3x+16$, what is the value of $x$?",["$33$","$41$","$49$","$59$"],'\\figParX')
F[(1,1,18)]=blk("The solution to the given system of equations is $(x,y)$. What is the value of $10x$?\n\\[\\begin{aligned}2x+5(y-14)&=41\\\\ x+5(y-14)&=29\\end{aligned}\\]")
F[(1,2,1)]=blk("In the right triangle shown, what is the value of $a$?",["$24$","$66$","$90$","$114$"],'@OF')
F[(1,2,6)]=blk("The function $g$ is defined by $g(x)=\\dfrac{x+1}{5}$. What is the $y$-intercept of the graph of $y=g(x)$ in the $xy$-plane?",["$(0,0)$","$\\left(0,\\dfrac{1}{5}\\right)$","$(0,5)$","$(0,1)$"])
F[(1,2,7)]=None
F[(1,2,9)]=None
F[(1,2,12)]=blk("If $x>0$ and $x$ is $33\\%$ of $y$, which expression represents $y$ in terms of $x$?",["$\\dfrac{100}{33}x$","$\\dfrac{33}{100}x$","$\\dfrac{67}{100}x$","$\\dfrac{133}{100}x$"])
F[(1,2,13)]=blk("In the equation $\\left(z^{m}\\right)^{\\frac{7}{10}}=\\sqrt{z}$, $m$ is a constant and $z>1$. What is the value of $m$?")
F[(1,2,16)]=blk("The graph of $y=f(x)+11$ is a decreasing line. If $c,d>0$, which equation could define $f$?",["$f(x)=-d-cx$","$f(x)=d+cx$","$f(x)=-d+cx$","$f(x)=d-cx$"],'\\figSIc')
F[(1,2,19)]=blk("The quadratic expression $7(x-5)(x+3)$ can be rewritten as $ax^{2}+bx+c$, where $a$, $b$, and $c$ are constants. What is the value of $a+b+c$?",["$-112$","$-56$","$-28$","$-7$"])
F[(1,2,22)]=blk("Points $A$, $B$, $C$, and $E$ lie on a circle, and $\\overline{BE}$ is a diameter with length $175$. Chord $\\overline{AC}$ is perpendicular to $\\overline{BE}$ at $D$, and $BD=63$. What is the length of $\\overline{AB}$?",None,'\\figSId')
# ---------------- SET 2
F[(2,1,1)]=blk("The equation $s=6t+18$ gives the speed $s$, in miles per hour, of a certain car $t$ seconds after it began to accelerate. What is the speed, in miles per hour, $4$ seconds after it began to accelerate?",["$40$","$42$","$48$","$54$"])
F[(2,1,3)]=blk("The histogram shows $20$ lengths, in feet. Which choice could be the median of the data set?",["$69$","$119$","$169$","$219$"],'\\figSIIa')
F[(2,1,6)]=None
F[(2,1,7)]=None
F[(2,1,8)]=blk("The scatterplot shows the relationship between $x$ and $y$ and a line of best fit. Which equation best represents the line of best fit?",["$y=-x+16.3$","$y=x-2.3$","$y=x+2.3$","$y=-x+2.3$"],'\\figSIIb')
F[(2,1,10)]=blk("At what point $(x,y)$ do the equations $y=6x-2$ and $2x+y=14$ intersect in the $xy$-plane?",["$(6,5)$","$(5,6)$","$(2,10)$","$(10,2)$"])
F[(2,1,12)]=blk("For the linear function $f(x)=2x+29$, which table gives three $x$-values and their corresponding $f(x)$-values?",None,'')
F[(2,1,12)]=F[(2,1,12)].replace('\\sprline',tabopts([['$0$','$1$','$2$'],['$29$','$31$','$33$'],['$29$','$30$','$31$'],['$2$','$31$','$60$'],['$29$','$58$','$87$']]))
F[(2,1,14)]=blk("In the $xy$-plane, the circle $(x-3)^{2}+(y+2)^{2}=100$ is inscribed in a square. What is the perimeter of the square?",["$4$","$20$","$80$","$320$"])
F[(2,1,16)]=blk("The exponential function $f(x)=24(2)^{x/6}$ is given. Which table gives four $x$-values and their corresponding $f(x)$-values for the function?",None,'')
F[(2,1,16)]=F[(2,1,16)].replace('\\sprline',tabopts([['$-6$','$0$','$6$','$12$'],['$12$','$24$','$48$','$96$'],['$12$','$24$','$36$','$48$'],['$48$','$24$','$12$','$6$'],['$6$','$24$','$96$','$384$']]))
F[(2,1,17)]=None
F[(2,1,20)]=blk("What is the sum of the solutions to the equation $\\sqrt{2}\\,x^{2}-84\\sqrt{2}\\,x+14=0$?",["$0$","$7$","$42$","$84$"])
F[(2,2,1)]=blk("The graph shows the height above ground, in meters, of a ball $x$ seconds after launch. Which statement best interprets the marked point $(1.0,\\,3.9)$?",["$1.0$ second after launch, the height is $3.9$ meters.","$3.9$ seconds after launch, the height is $1.0$ meter.","The initial height is $1.0$ meter and the initial velocity is $3.9$ m/s.","The ball lands $3.9$ meters from where it was launched."],'\\figSIIc')
F[(2,2,3)]=blk("Which list has the smallest standard deviation?",["$44,\\,45,\\,47,\\,49,\\,50$","$45,\\,45,\\,47,\\,49,\\,49$","$45,\\,46,\\,47,\\,48,\\,49$","$46,\\,47,\\,47,\\,47,\\,48$"])
F[(2,2,5)]=blk("A convention center has $375$ visitors in rooms $A$, $B$, or $C$. $P(A)=0.64$ and $P(B)=0.32$. How many visitors are in room $C$?",["$4$","$15$","$120$","$150$"])
F[(2,2,6)]=blk("The solution to the system of equations $x+2y=14$ and $3x-y=7$ is $(x,y)$. What is the value of $2x+3y$?",["$26$","$20$","$14$","$23$"])
F[(2,2,7)]=blk("In $5$ days, a polar bear ate $22.0$ pounds of fat. Which equation describes the amount $y$, in pounds, the bear ate per day, assuming a constant rate?",["$y=22+5$","$y=22$","$y=\\dfrac{22}{5}$","$y=22(5)$"])
F[(2,2,12)]=blk("The shaded region shown represents the solutions to $rx+ty>-44$, where $r$ and $t$ are constants. The boundary line passes through $(-11,0)$ and $(0,-4)$. What is the value of $r+t$?",["$-4$","$7$","$15$","$44$"],'\\figSIId')
F[(2,2,13)]=blk("The function $f$ is defined by $f(x)=3x^{2}$. If $f(a)=9a$ and $a>0$, what is the value of $a$?",["$1$","$3$","$9$","$27$"])
F[(2,2,14)]=blk("In the equation $t^{4}=p^{-12}$, $p>1$ and $0<t<1$. If $t=p^{-n}$, where $n$ is a constant, what is the value of $n$?")
F[(2,2,15)]=blk("Quadratic function $f$ has vertex $(1,6)$ and passes through $(2,40)$ and $(-1,142)$. What is the value of $f(-2)-f(0)$?",["$108$","$204$","$272$","$312$"])
F[(2,2,16)]=None
F[(2,2,17)]=blk("The graph of $y=f(x)+2$ is shown. Which equation defines $f$?",["$f(x)=-5x^{2}+1$","$f(x)=-25x^{2}+3$","$f(x)=-5x^{2}+4$","$f(x)=-5x^{2}+5$"],'\\figSIIe')
F[(2,2,19)]=blk("In the equation $7x^{2}(4x-13)(4x-u)=0$, $u$ is a positive constant. The sum of the distinct solutions to the equation is $6$. What is the value of $u$?")
# ---------------- SET 3
for n in (1,2,6,7,9,15,20): F[(3,1,n)]=None
F[(3,1,3)]=blk("The scatterplot shows the relationship between $x$ and $y$. A line of best fit is also shown. Which equation best represents the line of best fit?",["$y=0.6-1.5x$","$y=0.6+1.5x$","$y=-0.6+1.5x$","$y=-0.6-1.5x$"],'\\figSIIIa')
F[(3,1,4)]=blk("In the system of equations $y=x^{2}-6x+10$ and $y=2x-a$, $a$ is a positive integer constant. The system has no real solution. What is the least possible value of $a$?")
F[(3,1,8)]=blk("The function $f$ is defined by $f(x)=3(x-1)$. Which point is the $y$-intercept of the graph of $y=f(x)$ in the $xy$-plane?",["$(0,-4)$","$(0,-3)$","$(0,0)$","$(0,3)$"])
F[(3,1,11)]=blk("Which expression is equivalent to $(158y)^{\\frac{1}{2}}$, where $y>1$?",["$158\\sqrt{y}$","$\\sqrt{158}-y$","$\\sqrt{158y}$","$\\dfrac{158}{\\sqrt{y}}$"])
F[(3,1,12)]=blk("A convention center has $275$ visitors in rooms $A$, $B$, or $C$. $P(A)=0.68$ and $P(B)=0.24$. How many visitors are in room $C$?",["$8$","$22$","$121$","$55$"])
F[(3,1,13)]=blk("Line $t$ is defined by $y=4x+15$. Line $s$ is perpendicular to line $t$. What is the slope of line $s$?",["$15$","$4$","$-4$","$-\\dfrac{1}{4}$"])
F[(3,1,14)]=blk("The exponential function $f(x)=-10(2)^{x/3}$ is given. Which table gives four $x$-values and their corresponding $f(x)$-values for the function?",None,'')
F[(3,1,14)]=F[(3,1,14)].replace('\\sprline',tabopts([['$-3$','$0$','$3$','$6$'],['$-5$','$-10$','$-20$','$-40$'],['$-5$','$-10$','$-15$','$-20$'],['$-20$','$-10$','$-5$','$-2.5$'],['$5$','$10$','$20$','$40$']]))
F[(3,1,18)]=blk("The difference between the measures of angle $A$ and angle $B$ is $\\dfrac{3\\pi}{5}$ radians. Which expression gives the difference, in degrees?",["$\\dfrac{3\\pi}{5}\\cdot\\dfrac{180}{\\pi}$","$\\dfrac{3\\pi}{5}\\cdot\\dfrac{\\pi}{180}$","$\\dfrac{3\\pi}{5}\\cdot 180\\pi$","$\\dfrac{3\\pi}{5}\\cdot\\dfrac{360}{\\pi}$"])
F[(3,1,22)]=blk("Quadratic function $f$ has vertex $(1,7)$ and passes through $(2,53)$ and $(-1,191)$. What is the value of $f(-2)-f(0)$?",["$145$","$237$","$276$","$368$"])
F[(3,2,3)]=blk("The equation $34qr=8s$ relates the positive numbers $q$, $r$, and $s$. Which equation correctly expresses $q$ in terms of $r$ and $s$?",["$q=\\dfrac{8s}{34r}$","$q=\\dfrac{8-34r}{s}$","$q=s+34r$","$q=\\dfrac{34rs}{8}$"])
F[(3,2,4)]=blk("The shaded region shown represents the solutions to $y\\ge 2x-3$. Which ordered pair is a solution to the inequality?",["$(0,5)$","$(2,0)$","$(0,-5)$","$(3,2)$"],'\\figSIIIb')
F[(3,2,6)]=blk("If $5(x+4)=4(x+4)+39$, what is the value of $x+4$?",["$-4$","$35$","$39$","$43$"])
F[(3,2,7)]=blk("The solution to the system of equations $3x+y=19$ and $x-y=1$ is $(x,y)$. What is the value of $2x$?",["$10$","$24$","$6$","$14$"])
F[(3,2,10)]=blk("What are all solutions to the equation $x^{3}+2x^{2}=0$?",["$0$","$0$ and $-2$","$0$ and $2$","$-2$ only"])
F[(3,2,12)]=blk("The graph of a linear relationship in the $xy$-plane is shown. It passes through $(0,1.5)$ and $(3,0)$. Which equation represents the graph, where $R>0$?",["$Rx+12y=18$","$Rx-12y=18$","$Rx+12y=-18$","$12x+Ry=18$"],'\\figSIIIc')
F[(3,2,13)]=blk("The shaded region shown represents the solutions to $rx+ty\\ge -36$, where $r$ and $t$ are constants. The boundary line passes through $(-9,0)$ and $(0,-4)$. What is the value of $r+t$?",["$13$","$5$","$-13$","$36$"],'\\figSIIId')
F[(3,2,14)]=blk("The edge length of cube $Y$ is $3$ times the edge length of cube $X$. The surface area of cube $Y$ is $n$ times the surface area of cube $X$. What is the value of $n$?",["$9$","$27$","$3$","$6$"])
F[(3,2,15)]=blk("The graph of $y=f(x)+1$ is shown. Which equation defines $f$?",["$f(x)=-6^{x}+1$","$f(x)=-6^{x}+3$","$f(x)=-6^{x}+4$","$f(x)=-6^{x}+5$"],'\\figSIIIe')
F[(3,2,16)]=blk("Which expression is equivalent to $5(3x+2)$?",["$15x+10$","$15x+2$","$8x+10$","$15x+25$"])
F[(3,2,18)]=blk("In the system of equations $y=-6(x-12)^{2}$ and $y=c$, $c$ is a constant and the system has two distinct real solutions. Which value could $c$ be?",["$7$","$11$","$17$","$-24$"])
F[(3,2,21)]=blk("The function $f$ is defined by $f(x)=2^{x/a}-16$, where $a<0$. What is the value of $f(4a)\\cdot f(9a)$?")
# ---------------- SET 4 (October)
F[(4,2,7)]=blk("$y<4x+15$\n\nFor which of the following tables are all the values of $x$ and their corresponding values of $y$ solutions to the given inequality?",None,'')
F[(4,2,7)]=F[(4,2,7)].replace('\\sprline','\\fourtab{'+tbl2('Table A',['2','4','6'],['22','29','35'])+'}{'+tbl2('Table B',['2','4','6'],['23','31','39'])+'}{'+tbl2('Table C',['2','4','6'],['25','30','36'])+'}{'+tbl2('Table D',['2','4','6'],['20','33','38'])+'}')
F[(4,1,7)]=blk("The graph of a system of linear equations is shown. What is the solution $(x,y)$ to the system?",["$(4,4)$","$(3,4)$","$(2,4)$","$(0,4)$"],'\\figOct')
F[(4,2,12)]=blk("The histogram summarizes the distribution of an original data set that represents the number of points per game a basketball team has scored in the last $50$ games played. If the team scores $17$ points in the next game and this game is added to the original data set to create a new data set of $51$ values, which of the following must be true?\n\\figOctH\nI. The median number of points per game for the new data set is less than the median number of points per game for the original data set.\n\nII. The mean number of points per game for the new data set is less than the mean number of points per game for the original data set.",["I only","II only","I and II","Neither I nor II"])
F[(4,2,20)]=blk("Line $k$ is shown in the $xy$-plane. Line $n$ (not shown) is perpendicular to line $k$ and passes through the point $(2,7)$. Which equation defines line $n$?",["$y=-\\dfrac{3}{2}x+4$","$y=-\\dfrac{3}{2}x+10$","$y=\\dfrac{2}{3}x+\\dfrac{17}{3}$","$y=\\dfrac{3}{2}x+4$"],'\\figOctK')
F[(4,2,21)]=blk("The scatterplot shows the relationship between two variables, $x$ and $y$. A line of best fit for the data is also shown. For how many of the $9$ data points is the actual $y$-value greater than the $y$-value predicted by the line of best fit?",["$2$","$5$","$7$","$8$"],'\\figOctS')
# ---------------- SET 5 (June)
F[(5,1,6)]=blk("Which equation is the most appropriate linear model for the scatterplot?",["$y=-6x+28$","$y=6-28x$","$y=28+6x$","$y=28-6x$"],'\\figJa')
F[(5,1,7)]=blk("A $900$ g soil sample contains $189$ g of water. What percent of the sample is water?",["$9\\%$","$9.9\\%$","$21\\%$","$4.76\\%$"])
F[(5,1,8)]=blk("Line $k$ is perpendicular to line $n$ shown. What is the slope of line $k$?",["$-5$","$-\\dfrac{1}{5}$","$\\dfrac{1}{5}$","$5$"],'\\figJb')
F[(5,1,13)]=blk("A cylinder has a height of $4$ m and a base radius of $18$ m. What is the volume of the cylinder?",["$72\\pi$","$288\\pi$","$1{,}296\\pi$","$5{,}184\\pi$"])
F[(5,1,17)]=blk("Which of the following points is NOT a solution to the inequality $y>2x-3$?",["$(0,0)$","$(1,0)$","$(2,2)$","$(3,3)$"])
F[(5,1,21)]=blk("The expression $\\sqrt[3]{x^{2}}\\cdot x^{\\frac{10}{3}}$ is equivalent to $x^{c}$, where $x>0$. What is the value of $c$?",["$4$","$12$","$\\dfrac{2}{3}$","$7$"])
F[(5,2,1)]=blk("A bird's speed was measured as $49$ kilometers per hour. What is the bird's speed, in miles per hour, to the nearest tenth? (Use $1$ mile $=1.6$ km.)",["$30.6$","$47.4$","$50.6$","$78.4$"])
F[(5,2,2)]=blk("Which expression is equivalent to $(3x^{3}-x^{2}+4)(5x^{2}+8x)$?",["$15x^{5}+19x^{4}-8x^{3}+20x^{2}+32x$","$15x^{5}+19x^{4}-8x^{3}-20x^{2}+32x$","$15x^{5}+29x^{4}-8x^{3}+20x^{2}+32x$","$15x^{5}+19x^{4}+8x^{3}+20x^{2}+32x$"])
F[(5,2,4)]=blk("The graph shows the concentration of bacteria in a sample over time. At what time, in minutes, is the concentration $35$ million cells/mL?",["$25$","$40$","$55$","$70$"],'\\figJc')
F[(5,2,5)]=blk("If $(x+3)^{2}=48$, what is the value of $x^{2}+6x$?",["$30$","$39$","$48$","$57$"])
F[(5,2,7)]=blk("The function $f$ is defined by $f(x)=171-16x$. For which value of $k$ does $f(k)=3k$?",["$3$","$6$","$9$","$12$"])
F[(5,2,15)]=blk("The solution to the equation $3x-k=87$ is $x=174$, where $k$ is a constant. What is the value of $k$?")
F[(5,2,21)]=blk("For each real number $r$, which of the following points lies on the graphs of both $y=rx+5$ and $y=2rx+5$ in the $xy$-plane?",["$(0,5)$","$(5,0)$","$(r,5)$","$(1,5+r)$"])
F[(5,2,22)]=blk("Lines $a$ and $b$ are parallel and are intersected by transversal $t$. If $z=49$, which of the following must be true?",["$z+w=90$","$z+w=180$","$w=z$","$w=2z$"],'\\figJd')
# ---------------- SET 6 (bank)
def QL(l,stem,opts=None,fig=''): F[(6,1,l)]=blk(stem,opts,fig,lab=l)
QL('A3',"Solve $4p-5p=14$.",["$-15$","$-14$","$14$","$70$"])
QL('A6',"If $3-2x=42$, what is the value of $6(3-2x)$?",["$6$","$36$","$42$","$252$"])
QL('A7',"The ratio $72{:}m$ is equal to the ratio $4{:}24$. What is the value of $m$?",["$12$","$24$","$144$","$432$"])
QL('A18',"Triangle $TUV$ is dilated by a scale factor of $2$ to form triangle $T'U'V'$. If $\\angle V=26\\dg$, what is the measure of $\\angle V'$?",["$26\\dg$","$52\\dg$","$13\\dg$","$104\\dg$"])
QL('A19',"$f(x)=4x^{2}+16x+22$ and $h(x)=f(x)+9$. What is the minimum value of $h$?",["$3$","$15$","$24$","$6$"])
QL('A20',"The system $7(5x)+9(8y)=189$ and $7(5x)-9(8y)=-819$ has solution $(x,y)$. What is the value of $5x+8y$?",["$101$","$26$","$11$","$56$"])
QL('B5',"Which exponential model best fits the scatterplot shown?",["$y=34(1.04)^{-x}$","$y=34(1.04)^{x}$","$y=34(0.04)^{x}$","$y=34+1.04x$"],'\\figBa')
QL('B11',"What is the range of the data set $4,\\ 4,\\ 12,\\ 25,\\ 25$?",["$12$","$14$","$21$","$29$"])
QL('B13',"If $7(x-3)^{2}=252$, what is the value of $x^{2}-6x$?",["$18$","$27$","$36$","$45$"])
F[(6,1,'B21')]=blk("For which of the following tables are all the pairs $(x,y)$ solutions to $y<14x+12$?",None,'',lab='B21').replace('\\sprline','\\fourtab{'+tbl2('Table A',['1','2','3'],['25','39','53'])+'}{'+tbl2('Table B',['1','2','3'],['26','40','54'])+'}{'+tbl2('Table C',['1','2','3'],['20','41','50'])+'}{'+tbl2('Table D',['1','2','3'],['30','35','60'])+'}')
QL('H3',"A linear graph lies entirely in quadrants I and II. Which function could define the graph?",["$h(x)=18x-36$","$h(x)=16x$","$h(x)=16$","$h(x)=-x-16$"])
QL('H4',"Which quadratic function best models the downward-opening scatterplot shown, whose vertex is near $(50,35)$?",["$y=-0.007(x-50)^{2}+35$","$y=-0.007(x-35)^{2}+50$","$y=0.007(x-50)^{2}+35$","$y=-0.007(x+50)^{2}+35$"],'\\figHa')
QL('H14',"The function $f(x)=6000(1.003)^{2x}$ models the balance, in dollars, of a bank account $x$ years after it was opened. Which is the best interpretation of $1.003$ in this context?",["Every $2$ years the balance rises by \\$3","Every $6$ months the balance rises by $0.3\\%$","Every $2$ years the balance rises by $0.3\\%$","Every year the balance rises by $0.3\\%$"])
F[(5,1,22)]=blk("Triangles $ABC$ and $DEF$ are similar right triangles, where $A$ corresponds to $D$ and $\\angle B$ and $\\angle E$ are right angles. $AB=2.4(DE)$ and $\\tan A=\\dfrac{3}{4}$. What is the value of $\\sin D$?")
F[(5,1,19)]=blk("An auditorium's revenue, in dollars, is modeled by $R(x)=-5x^{2}+240x+1000$, where $x$ is the increase, in dollars, in the ticket price. At what ticket-price increase is the revenue maximized?",["$8$","$24$","$32$","$40$"])
F[(5,1,9)]=blk("The graphs of $mx+ky=-83$ and $2x+ky=-22$ intersect at $(5,y)$ in the $xy$-plane. What is the value of $m$?")
F[(5,2,20)]=blk("A model estimates the noise level, in decibels, at a distance of $d$ meters from a speaker by $N(d)=47-0.4d$. Which is the best interpretation of $47$ in this context?",["The estimated noise level at $0$ meters","The estimated decrease in noise level for each meter","The estimated noise level at $47$ meters","The distance at which the noise level reaches $0$"])
F[(5,2,12)]=blk("A square-based rectangular prism has a volume of $2{,}448$ cm$^{3}$ and a base area of $144$ cm$^{2}$. What is the height, in cm, of the prism?",["$17$","$20$","$24$","$34$"])
F[(5,2,13)]=blk("The system of equations $y=5(x-2)^{2}$ and $y=10(x-2)+c$, where $c$ is a constant, has the solution $(3,5)$. What is the value of $c$?",["$-5$","$5$","$10$","$15$"])
