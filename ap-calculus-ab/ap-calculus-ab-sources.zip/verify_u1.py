#!/usr/bin/env python3
"""Independent numeric verification for Unit 1 (Limits and Continuity). numpy/scipy only."""
import math, numpy as np
from scipy.optimize import brentq
from scipy.integrate import quad  # (imported for completeness; no integrals needed in Unit 1)

N = 0
FAIL = []
def ok(name, cond, info=""):
    global N
    N += 1
    if not cond:
        FAIL.append(f"{name} {info}")
        print("FAIL:", name, info)
def close(name, a, b, tol=1e-3):
    ok(name, abs(a - b) <= tol, f"got {a}, expected {b}")

H = (1e-4, 1e-5, 1e-6)
def lim(f, a, side=0):
    """numerical limit: side=+1 right, -1 left, 0 both (must agree). returns float or +-inf or nan (DNE)"""
    def one(s):
        v = [f(a + s * h) for h in H]
        if abs(v[-1]) > 1e3 and abs(v[-1]) > 5 * abs(v[0]) * 0.9 and np.sign(v[-1]) == np.sign(v[0]):
            return math.inf * np.sign(v[-1])
        if abs(v[-1] - v[-2]) < 5e-3 * (1 + abs(v[-1])):
            return v[-1]
        return math.nan
    if side != 0:
        return one(side)
    l, r = one(-1), one(1)
    if (math.isinf(l) and math.isinf(r) and l == r):
        return l
    if math.isnan(l) or math.isnan(r) or math.isinf(l) or math.isinf(r) or abs(l - r) > 5e-3:
        return math.nan
    return 0.5 * (l + r)
def lim_inf(f, sgn=1):
    v = [f(sgn * 1e5), f(sgn * 1e6), f(sgn * 1e7)]
    if abs(v[-1]) > 1e4: return math.inf * np.sign(v[-1])
    return v[-1]
def isdne(x): return isinstance(x, float) and math.isnan(x)

# ---------------------------------------------------------------- running functions
def h(x):
    if x == -2: return 4.0
    if x < 1: return x + 4
    if x == 1: return 5.0
    return 8 / (x - 3) ** 2
def F(x):
    if x < 0: return x + 3
    if x == 0: return 1.0
    if x < 3: return 3 + x * (3 - x) / 3
    if x == 3: return 4.0
    return 1 + 3 / (x - 2)

# ================================================================ 1.1
for hh, v in [(1, 3), (0.5, 2.5), (0.1, 2.1), (0.01, 2.01), (0.001, 2.001)]:
    close(f"1.1 ex1 h={hh}", ((1 + hh) ** 2 - 1) / hh, v, 1e-9)
close("1.1 ex1 inst (limit of averages)", lim(lambda hh: ((1 + hh) ** 2 - 1) / hh, 0), 2.0)
D = lambda t: 0.1 * t * t
for t, v in zip([0, 2, 4, 6, 8, 10], [0, 0.4, 1.6, 3.6, 6.4, 10]): close("1.1 table D", D(t), v, 1e-12)
close("1.1 ex2a", (D(6) - D(2)) / 4, 0.8); close("1.1 ex2b left", (D(6) - D(4)) / 2, 1.0)
close("1.1 ex2b right", (D(8) - D(6)) / 2, 1.4); close("1.1 ex2b mean", ((D(6) - D(4)) / 2 + (D(8) - D(6)) / 2) / 2, 1.2)
close("1.1 ex2b [4,8]", (D(8) - D(4)) / 4, 1.2); close("1.1 true D'(6)", (D(6 + 1e-6) - D(6 - 1e-6)) / 2e-6, 1.2)
s = lambda t: 3 * t * t + t
close("1.1 chk1", (s(3) - s(1)) / 2, 13)
s2 = lambda t: t * t + t
for hh in (0.1, 0.01):
    close("1.1 chk2 5+h", (s2(2 + hh) - s2(2)) / hh, 5 + hh, 1e-9)
# figure: tangent y=2x-1 at (1,1); secants
close("1.1 fig tangent slope", 2.0, (1.0001 ** 2 - 0.9999 ** 2) / 0.0002)
close("1.1 fig secant PQ slope", (4 - 1) / (2 - 1), 3); close("1.1 fig secant PQ' slope", (2.25 - 1) / 0.5, 2.5)
ok("1.1 fig secant lines through P", 3 * 1 - 2 == 1 and 2.5 * 1 - 1.5 == 1 and 2 * 1 - 1 == 1 and 3 * 2 - 2 == 4 and 2.5 * 1.5 - 1.5 == 2.25)

# ================================================================ 1.2
f12 = lambda x: 2 * x + 1 if x < 3 else (5 if x == 3 else 10 - x)
close("1.2 ex1 left", lim(f12, 3, -1), 7); close("1.2 ex1 right", lim(f12, 3, 1), 7); close("1.2 ex1 both", lim(f12, 3), 7); ok("1.2 f(3)=5", f12(3) == 5)
g12 = lambda x: abs(x - 2) / (x - 2)
close("1.2 ex2 left", lim(g12, 2, -1), -1); close("1.2 ex2 right", lim(g12, 2, 1), 1); ok("1.2 ex2 DNE", isdne(lim(g12, 2)))
ok("1.2 ex3 1/x^2", lim(lambda x: 1 / x ** 2, 0) == math.inf)
ok("1.2 ex3 1/x right", lim(lambda x: 1 / x, 0, 1) == math.inf); ok("1.2 ex3 1/x left", lim(lambda x: 1 / x, 0, -1) == -math.inf); ok("1.2 ex3 1/x DNE", isdne(lim(lambda x: 1 / x, 0)))
c12 = lambda x: x * x - 1 if x < 2 else (6 if x == 2 else 7 - x)
close("1.2 chk1 left", lim(c12, 2, -1), 3); close("1.2 chk1 right", lim(c12, 2, 1), 5); ok("1.2 chk1 DNE", isdne(lim(c12, 2)))
ok("1.2 chk2", lim(lambda x: 1 / x, 0, -1) == -math.inf and lim(lambda x: 1 / x ** 2, 0) == math.inf)

# ================================================================ 1.3
close("1.3 lim h(-2)", lim(h, -2), 2); ok("1.3 h(-2)=4", h(-2) == 4)
close("1.3 lim h 1-", lim(h, 1, -1), 5); close("1.3 lim h 1+", lim(h, 1, 1), 2); ok("1.3 lim h 1 DNE", isdne(lim(h, 1)))
ok("1.3 lim h 3 = inf", lim(h, 3) == math.inf)
close("1.3 lim h inf", lim_inf(h, 1), 0, 1e-6); ok("1.3 lim h -inf", lim_inf(h, -1) == -math.inf)
close("1.3 lim h(0)", lim(h, 0), 4); close("1.3 chk1 sum", lim(h, 1, 1) + lim(h, -2), 4)
hh_ = lambda x: h(h(x))
close("1.3 ex2 comp -2", lim(hh_, -2), 8); close("1.3 ex2 comp 1-", lim(hh_, 1, -1), 2)
close("1.3 h(4)", h(4), 8)
# oscillation: sin(1/x)
ok("1.3 sin(1/x) values at 1/(n pi) ~0", all(abs(math.sin(1 / (1 / (n * math.pi)))) < 1e-8 for n in range(1, 50)))
ok("1.3 sin(1/x) =1 at 1/(pi/2+2n pi)", all(abs(math.sin(math.pi / 2 + 2 * n * math.pi) - 1) < 1e-8 for n in range(1, 50)))
# figure range: h plot cut points stay within ymax=9, ymin=-2
ok("1.3 fig h cuts", 8 / (2.05 - 3) ** 2 < 9 and 8 / (3.95 - 3) ** 2 < 9 and -5 + 4 > -2)

# ================================================================ 1.4
fa = lambda x: (math.sqrt(x + 4) - 2) / x
for x, v in zip([-0.1, -0.01, -0.001, 0.001, 0.01, 0.1], [0.25158, 0.25016, 0.25002, 0.24998, 0.24984, 0.24846]): close(f"1.4 ex1 {x}", fa(x), v, 6e-6)
close("1.4 ex1 limit", lim(fa, 0), 0.25, 1e-4)
fb = lambda x: x * x + 2 * x + 4
for x, v in zip([1.9, 1.99, 1.999, 2.001, 2.01, 2.1], [11.41, 11.9401, 11.994001, 12.006001, 12.0601, 12.61]): close(f"1.4 ex2 {x}", fb(x), v, 1e-9)
close("1.4 ex2 (x^3-8)/(x-2)=x^2+2x+4", (2.01 ** 3 - 8) / (2.01 - 2), fb(2.01), 1e-9); close("1.4 ex2 limit", lim(fb, 2), 12)
gl = lambda x: 2 * x - 1; gr = lambda x: 2 * x + 1
for x, v in zip([2.9, 2.99, 2.999], [4.8, 4.98, 4.998]): close("1.4 ex3 left", gl(x), v, 1e-9)
for x, v in zip([3.001, 3.01, 3.1], [7.002, 7.02, 7.2]): close("1.4 ex3 right", gr(x), v, 1e-9)
close("1.4 ex3 limits", gl(3), 5); close("1.4 ex3 limr", gr(3), 7)
for x, v in zip([4.9, 4.99, 4.999, 5.001, 5.01, 5.1], [9.9, 9.99, 9.999, 10.001, 10.01, 10.1]): close("1.4 chk1", x + 5, v, 1e-9)
for x, v in zip([0.9, 0.99, 0.999], [2.9, 2.99, 2.999]): close("1.4 chk2 left", x + 2, v, 1e-9)
ok("1.4 chk2 right (-(x+2))", all(abs(-(x + 2) - v) < 1e-9 for x, v in zip([1.001, 1.01, 1.1], [-3.001, -3.01, -3.1])))
ok("1.4 sin(pi/x) at 1/n zero; at 2/(4n+1) one", all(abs(math.sin(math.pi * n)) < 1e-9 for n in range(1, 30)) and all(abs(math.sin(math.pi * (4 * n + 1) / 2) - 1) < 1e-9 for n in range(1, 30)))

# ================================================================ 1.5
close("1.5 ex1a", 3 + 2 * -4, -5); close("1.5 ex1b", 3 * -4, -12); close("1.5 ex1c", 3 / -4, -0.75); close("1.5 ex1d", 9 + 4, 13)
close("1.5 ex2a", lim(lambda x: (x * x + 1) / (x ** 3 - 3), 2), 1); close("1.5 ex2b", lim(lambda x: math.sqrt(x * x + 7) / (x - 1), 3), 2)
close("1.5 chk1a", 2 * 4 + 3 * -2, 2); close("1.5 chk1b", 4 / -2, -2); close("1.5 chk1c", (-2) ** 2, 4)
close("1.5 chk2", lim(lambda x: (x ** 3 + 2 * x) / (x * x + 4), -1), -3 / 5); close("1.5 chk3", lim(lambda x: math.sqrt(x * x - 7) / (x - 2), 4), 1.5)

# ================================================================ 1.6
f6 = lambda x: (x * x - x - 6) / (x * x - 9)
close("1.6 ex1", lim(f6, 3), 5 / 6); close("1.6 ex2", lim(lambda x: (math.sqrt(x + 9) - 3) / x, 0), 1 / 6, 1e-4)
close("1.6 ex3", lim(lambda x: (1 / (x + 2) - 0.5) / x, 0), -0.25, 1e-3)
close("1.6 ex4a", lim(lambda x: math.sin(5 * x) / (3 * x), 0), 5 / 3); close("1.6 ex4b", lim(lambda x: math.tan(x) / x, 0), 1)
close("1.6 chk1", lim(lambda x: (x * x - 25) / (x * x - 3 * x - 10), 5), 10 / 7); close("1.6 chk2", lim(lambda x: (math.sqrt(x + 25) - 5) / x, 0), 0.1, 1e-4)
close("1.6 chk3", lim(lambda x: math.tan(4 * x) / (8 * x), 0), 0.5)
# figure (x+2)/(x+3): cuts and hole
q = lambda x: (x + 2) / (x + 3)
ok("1.6 fig cuts", abs(q(-3.2)) < 6.5 and abs(q(-2.85)) < 6.5 and abs(q(-7)) < 6.5 and abs(f6(3.0001) - 5 / 6) < 1e-3 and q(3) == 5 / 6)

# ================================================================ 1.7
close("1.7 ex1", lim(lambda x: (x - 4) / (math.sqrt(x) - 2), 4), 4, 1e-3)
f7 = lambda x: (x * x - 4) / abs(x - 2)
close("1.7 ex2 right", lim(f7, 2, 1), 4); close("1.7 ex2 left", lim(f7, 2, -1), -4); ok("1.7 ex2 DNE", isdne(lim(f7, 2)))
ok("1.7 ex3 k", 1 + 1 - 2 == 0); close("1.7 ex3 limit", lim(lambda x: (x * x + x - 2) / (x - 1), 1), 3)
close("1.7 chk1", lim(lambda x: (x - 2) / (math.sqrt(x + 7) - 3), 2), 6, 1e-3)
ok("1.7 chk2", lim(lambda x: (x + 1) / (x + 3), -3, 1) == -math.inf)
ok("1.7 chk3 k", 4 + 2 * 3 - 10 == 0); close("1.7 chk3 limit", lim(lambda x: (x * x + 3 * x - 10) / (x - 2), 2), 7)

# ================================================================ 1.8
xs = np.concatenate([np.linspace(-1e-3, -1e-9, 2000), np.linspace(1e-9, 1e-3, 2000)])
ok("1.8 ex1 |x^2 sin(1/x)|<=x^2", np.all(np.abs(xs ** 2 * np.sin(1 / xs)) <= xs ** 2 + 1e-18)); ok("1.8 ex1 ->0", np.max(np.abs(xs ** 2 * np.sin(1 / xs))) < 1e-5)
xg = np.linspace(-5, 5, 100001)
ok("1.8 ex2 lower<=upper (diff=2(x-2)^2)", np.allclose((xg ** 2 - 4 * xg + 7) - (-xg ** 2 + 4 * xg - 1), 2 * (xg - 2) ** 2))
close("1.8 ex2 bounds at 2", (-4 + 8 - 1) - 3, 0); close("1.8 ex2 upper at 2", 4 - 8 + 7, 3)
close("1.8 sinx/x", lim(lambda x: math.sin(x) / x, 0), 1); close("1.8 (1-cos x)/x", lim(lambda x: (1 - math.cos(x)) / x, 0), 0, 1e-3)
th = np.linspace(0.001, 1.5, 3000)
ok("1.8 ex3 area ordering", np.all(np.sin(th) / 2 < th / 2) and np.all(th / 2 < np.tan(th) / 2)); ok("1.8 cos<sin/th<1", np.all(np.cos(th) < np.sin(th) / th) and np.all(np.sin(th) / th < 1))
ok("1.8 fig: tan(50deg)", abs(math.tan(math.radians(50)) - 1.19175) < 1e-4)
xs2 = np.linspace(-1e-3, 1e-3, 4001); xs2 = xs2[xs2 != 0]
ok("1.8 chk1 x cos(1/x^2)", np.max(np.abs(xs2 * np.cos(1 / xs2 ** 2))) <= 1e-3 + 1e-12)
ok("1.8 chk2 bounds", np.allclose((3 + 2 * (xg - 3) ** 2) - (3 - (xg - 3) ** 2), 3 * (xg - 3) ** 2) and np.all(3 * (xg - 3) ** 2 >= 0))
close("1.8 chk3", lim(lambda x: math.sin(7 * x) / math.sin(3 * x), 0), 7 / 3)

# ================================================================ 1.9
f9 = lambda x: (math.sqrt(x + 1) - 1) / x
for x, v in zip([-0.1, -0.01, 0.01, 0.1], [0.51317, 0.50126, 0.49876, 0.48809]): close("1.9 ex1 table", f9(x), v, 6e-6)
close("1.9 ex1 limit", lim(f9, 0), 0.5, 1e-3)
for x in [-0.5, 1, 3]: close("1.9 ex1 conj identity", f9(x), 1 / (math.sqrt(x + 1) + 1), 1e-12)
for x, v in zip([0.9, 0.99, 0.999, 1.001, 1.01, 1.1], [2.9, 2.99, 2.999, 3.001, 3.01, 3.1]): close("1.9 ex2 table", x + 2, v, 1e-9)
close("1.9 ex2 left", 3 * lim(h, 1, -1), 15); close("1.9 ex2 right", 3 * lim(h, 1, 1), 6)
close("1.9 chk1 limit", lim(lambda x: (x * x - 9) / (x - 3), 3), 6)
for x, v in zip([2.9, 2.99, 2.999, 3.001, 3.01, 3.1], [5.9, 5.99, 5.999, 6.001, 6.01, 6.1]): close("1.9 chk1 table", x + 3, v, 1e-9)

# ================================================================ 1.10
fx = lambda x: (x * x - 9) / ((x - 3) * (x + 1))
close("1.10 ex2 limit 3", lim(fx, 3), 1.5); ok("1.10 ex2 -1 inf", abs(fx(-1 + 1e-7)) > 1e6)
g10 = lambda x: x * x if x < 2 else 8 - x
close("1.10 ex3 left", lim(g10, 2, -1), 4); close("1.10 ex3 right", lim(g10, 2, 1), 6); ok("1.10 g(2)=6", g10(2) == 6)
close("1.10 chk1 limit at 2", lim(lambda x: 1 / (x + 2), 2), 0.25); ok("1.10 chk1 -2 inf", abs(1 / (-2 + 1e-7 + 2)) > 1e6)
close("1.10 chk2 jump", 6 - 4, 2); ok("1.10 chk3 inf", lim(lambda x: 1 / x ** 2, 0) == math.inf)
ok("1.10 fig infinite cuts <4", 0.5 / (1.62 - 2) ** 2 + 0.2 < 4 and 0.5 / (2.38 - 2) ** 2 + 0.2 < 4)

# ================================================================ 1.11
close("1.11 h(0)", h(0), lim(h, 0))
ok("1.11 ex1 -2 cond3 fails", h(-2) != lim(h, -2)); ok("1.11 ex1 1 left-cont", abs(h(1) - lim(h, 1, -1)) < 1e-3 and isdne(lim(h, 1)))
g11 = lambda k: (lambda x: 2 * x + k if x < 3 else x * x - 4)
close("1.11 ex2 k=-1 left", lim(g11(-1), 3, -1), 5); close("1.11 ex2 right", lim(g11(-1), 3, 1), 5); ok("1.11 g(3)=5", g11(-1)(3) == 5)
close("1.11 ex2 fig join", 2 * 3 - 1, 3 ** 2 - 4)
ex3 = lambda x: (x * x - 1) / (x - 1)
close("1.11 ex3a limit 2", lim(ex3, 1), 2); close("1.11 ex3b sqrt(x-1) right-limit", lim(lambda x: math.sqrt(x - 1), 1, 1), 0, 2e-2)
close("1.11 chk1", lim(ex3, 1), 2); close("1.11 chk2", 6 + (-1), 5)

# ================================================================ 1.12
cub = lambda x: 0.4 * x ** 3 - 3 * x ** 2 + 6 * x - 1
xg2 = np.linspace(0.5, 5, 900001); yv = cub(xg2)
ok("1.12 fig abs max at x=5 (=4)", abs(yv.max() - 4) < 1e-9 and abs(xg2[yv.argmax()] - 5) < 1e-9)
xm = xg2[yv.argmin()]; close("1.12 fig abs min x", xm, 3.6180, 1e-3); close("1.12 fig abs min y", yv.min(), 0.3820, 1e-3)
ok("1.12 fig y range 0..4.8", yv.min() > -0.7 and yv.max() < 4.8)
fe = lambda x: 1 / (x - 2)
close("1.12 ex2 f(3)", fe(3), 1); close("1.12 ex2 f(6)", fe(6), 0.25)
xx = np.linspace(3, 6, 10001); ok("1.12 ex2 max/min on [3,6]", abs((1 / (xx - 2)).max() - 1) < 1e-12 and abs((1 / (xx - 2)).min() - 0.25) < 1e-12)
f12b = lambda x: x * x if x < 2 else 6 - x
close("1.12 ex3 left", lim(f12b, 2, -1), 4); close("1.12 ex3 right", lim(f12b, 2, 1), 4); ok("1.12 ex3 f(2)", f12b(2) == 4)
ok("1.12 ex1 domain: sqrt(x+2) needs x>=-2", True)
# check 1: sqrt(x+5)/(x-2): domain x>=-5, x!=2 ; ln(x-3): x>3
ok("1.12 chk1 domains", True)

# ================================================================ 1.13
close("1.13 ex1 limit 5/6", lim(f6, 3), 5 / 6); ok("1.13 ex1 -3 infinite", abs(f6(-3 + 1e-7)) > 1e5)
close("1.13 ex2 k", lim(lambda x: (x * x - 5 * x + 6) / (x - 2), 2), -1)
f13 = lambda a, b: (lambda x: a * x + 2 if x <= 1 else (x * x + b if x < 3 else 2 * x + 5))
fa_ = f13(1, 2)
close("1.13 ex3 at 1 left", lim(fa_, 1, -1), 3); close("1.13 ex3 at 1 right", lim(fa_, 1, 1), 3); close("1.13 f(1)", fa_(1), 3)
close("1.13 ex3 at 3 left", lim(fa_, 3, -1), 11); close("1.13 ex3 at 3 right", lim(fa_, 3, 1), 11); close("1.13 f(3)", fa_(3), 11)
close("1.13 chk1", lim(lambda x: (x * x - 16) / (x - 4), 4), 8); close("1.13 chk2", lim(lambda x: (x ** 3 - 1) / (x - 1), 1), 3)
f13c = lambda x: 4 * x + 1 if x < 2 else (9 if x == 2 else x * x + 5)
close("1.13 chk3 left", lim(f13c, 2, -1), 9); close("1.13 chk3 right", lim(f13c, 2, 1), 9)
close("1.13 fig hole", lim(lambda x: (x * x - 5 * x + 6) / (x - 2), 2), 2 - 3)

# ================================================================ 1.14
f14 = lambda x: (x - 1) / (x * x - 4)
ok("1.14 ex1 2-", lim(f14, 2, -1) == -math.inf); ok("1.14 ex1 2+", lim(f14, 2, 1) == math.inf)
ok("1.14 ex1 -2-", lim(f14, -2, -1) == -math.inf); ok("1.14 ex1 -2+", lim(f14, -2, 1) == math.inf)
# sign table
for x, sg in [(-3, -1), (0, 1), (1.5, -1), (3, 1)]: ok(f"1.14 sign table x={x}", np.sign(f14(x)) == sg)
ok("1.14 fig cuts", all(abs(f14(x)) < 6.5 for x in [-2.13, -1.88, 1.96, 2.05, -5, 6]))
f14b = lambda x: (x * x - 4) / (x * x - 5 * x + 6)
close("1.14 ex2 hole limit at 2", lim(f14b, 2), -4); ok("1.14 ex2 3+", lim(f14b, 3, 1) == math.inf); ok("1.14 ex2 3-", lim(f14b, 3, -1) == -math.inf)
C14 = lambda p: 80 * p / (100 - p)
ok("1.14 ex3 inf", lim(C14, 100, -1) == math.inf); close("1.14 C(90)", C14(90), 720); close("1.14 C(99)", C14(99), 7920)
f14c = lambda x: (x + 2) / (x - 3)
ok("1.14 chk1", lim(f14c, 3, 1) == math.inf and lim(f14c, 3, -1) == -math.inf)
f14d = lambda x: (x - 1) / (x * x - x - 6)
ok("1.14 chk2 denominators", abs(f14d(3 + 1e-7)) > 1e5 and abs(f14d(-2 + 1e-7)) > 1e5 and (1 * 1 - 1 - 6) != 0)
ok("1.14 chk3 ln", math.log(1e-6) > math.log(1e-12) > math.log(1e-100) and math.log(1e-100) < -200); ok("1.14 chk3 tan", lim(math.tan, math.pi / 2, 1) == -math.inf and lim(math.tan, math.pi / 2, -1) == math.inf)

# ================================================================ 1.15
close("1.15 ex1", lim_inf(lambda x: (3 * x * x - 5 * x) / (2 * x * x + 1)), 1.5, 1e-5)
f15 = lambda x: math.sqrt(4 * x * x + 1) / (x + 3)
close("1.15 ex2 +inf", lim_inf(f15, 1), 2, 1e-4); close("1.15 ex2 -inf", lim_inf(f15, -1), -2, 1e-4)
f15c = lambda x: (3 * math.exp(x) + 4) / (math.exp(x) + 2)
close("1.15 ex3 +inf", f15c(30), 3, 1e-9); close("1.15 ex3 -inf", f15c(-30), 2, 1e-9); close("1.15 f(0)", f15c(0), 7 / 3, 1e-12)
xx = np.linspace(-6, 5, 5000); ok("1.15 fig range & monotone", np.all(np.diff([f15c(x) for x in xx]) > 0) and 1.4 < f15c(-6) and f15c(5) < 3.6)
close("1.15 chk1", lim_inf(lambda x: (4 * x * x - x) / (1 - 2 * x * x)), -2, 1e-5)
f15d = lambda x: (5 * x + 1) / math.sqrt(x * x + 1)
close("1.15 chk2 +", lim_inf(f15d, 1), 5, 1e-4); close("1.15 chk2 -", lim_inf(f15d, -1), -5, 1e-4)
ok("1.15 chk3a inf", lim_inf(lambda x: (x ** 3 - 2 * x) / (5 * x * x + 1)) == math.inf); close("1.15 chk3b", lim_inf(lambda x: (6 * x + 1) / (x * x + 4)), 0, 1e-5)

# ================================================================ 1.16
f16 = lambda x: x ** 3 + x - 5
close("1.16 ex1 f(1)", f16(1), -3); close("1.16 ex1 f(2)", f16(2), 5); close("1.16 ex1 root", brentq(f16, 1, 2), 1.5160, 1e-4)
ok("1.16 fig range", f16(0.8) > -4.5 and f16(2.2) < 8)
tab = [3, -1, 6, 2]; sc = sum(1 for a, b in zip(tab, tab[1:]) if a * b < 0); ok("1.16 ex2 zeros>=2", sc == 2)
ok("1.16 ex2 b: 4 between -1 and 6; 4 between 6 and 2", -1 < 4 < 6 and 2 < 4 < 6)
ok("1.16 chk1", (0 ** 5 + 0 - 1) < 0 < (1 + 1 - 1)); ok("1.16 chk2", 5 > 0 > -3 and not (-3 < 7 < 5))
tab3 = [2, -1, 4, 4]; ok("1.16 chk3", sum(1 for a, b in zip(tab3, tab3[1:]) if a * b < 0) == 2)

# ================================================================ PRACTICE: helper for MCQ
def mcq(n, vals, key_idx, true_val, tol=5e-3, label=""):
    """vals: list of 4 numeric values (inf allowed), key_idx 0..3, true_val computed independently."""
    ok(f"MCQ{n} 4 distinct options", len(set(vals)) == 4, str(vals))
    ok(f"MCQ{n} key value matches computed ({true_val})", (math.isinf(true_val) and vals[key_idx] == true_val) or (not math.isinf(true_val) and abs(vals[key_idx] - true_val) <= tol), f"{vals[key_idx]} vs {true_val}")
    for i, v in enumerate(vals):
        if i != key_idx:
            ok(f"MCQ{n} distractor {'ABCD'[i]} wrong", not ((math.isinf(true_val) and v == true_val) or (not math.isinf(true_val) and abs(v - true_val) <= tol)), f"{v}")
KEYS = {}
# 1
v1 = lim(F, 0); close("MCQ1 value", v1, 3); ok("MCQ1 distinct", len({1, 3, 4, "DNE"}) == 4); ok("MCQ1 key B", v1 == v1 and abs(v1 - 3) < 1e-3 and F(0) == 1)
# 2
l2, r2 = lim(F, 3, -1), lim(F, 3, 1); close("MCQ2 left", l2, 3); close("MCQ2 right", r2, 4); ok("MCQ2 DNE (key C)", isdne(lim(F, 3)) and abs((l2 + r2) / 2 - 3.5) < 1e-3)
# 3 (key A: c=3)
def right_cont(c): return abs(lim(F, c, 1) - F(c)) < 1e-3
def cont(c): return right_cont(c) and abs(lim(F, c, -1) - F(c)) < 1e-3
for c, expect in [(3, True), (0, False), (-2, False), (5, False)]:
    ok(f"MCQ3 c={c} right-cont&!cont == {expect}", (right_cont(c) and not cont(c)) == expect)
close("MCQ3 F(-2)", F(-2), 1); close("MCQ3 F(5)", F(5), 2)
# 4
f4 = lambda x: (x * x + x - 2) / (x + 2)
v4 = lim(f4, -2); close("MCQ4", v4, -3); ok("MCQ4 distinct+key D", len({0, 3, "DNE", -3}) == 4 and abs(v4 - (-3)) < 1e-3)
# 5
v5 = lim(lambda x: math.sin(4 * x) / (2 * x), 0); mcq(5, [2, 4, 0.5, 1], 0, v5)
# 6 squeeze
xs6 = np.linspace(0.999, 1.001, 2001)
fl = 4 + 0.99 * (xs6 - 1) ** 2  # a function satisfying |f-4|<=(x-1)^2
ok("MCQ6 example f within bounds -> 4", np.all(np.abs(fl - 4) <= (xs6 - 1) ** 2 + 1e-15) and abs(fl[0] - 4) < 2e-6)
ok("MCQ6 distinct", len({0, 1, 4, "cannot"}) == 4)
# 7
v7 = lim_inf(lambda x: (5 * x ** 3 - 2 * x) / (2 * x ** 3 + 7 * x ** 2)); mcq(7, [0, 5 / 2, 2 / 5, math.inf], 1, v7, 1e-4)
# 8
f8 = lambda x: (x * x - 4) / (x * x - 5 * x + 6)
ok("MCQ8 x=2 finite (hole)", abs(f8(2 + 1e-7)) < 10 and abs(f8(2 - 1e-7)) < 10); ok("MCQ8 x=3 infinite", abs(f8(3 + 1e-7)) > 1e5)
ok("MCQ8 x=-2 not asymptote (zero)", abs(f8(-2 + 1e-7)) < 1e-5)
# 9
f9_ = lambda x: (x + 2) / (x * x - 1); v9 = lim(f9_, 1, 1); mcq(9, [math.inf, -math.inf, 0, 1.5], 0, v9)
# 10
def f10(k): return lambda x: k * x - 1 if x < 2 else x * x + k
ks = [4, 5, 5 / 3, 3]
cont10 = [abs(lim(f10(k), 2, -1) - f10(k)(2)) < 1e-3 and abs(lim(f10(k), 2, 1) - f10(k)(2)) < 1e-3 for k in ks]
ok("MCQ10 only k=5 (B) works", cont10 == [False, True, False, False], str(cont10)); ok("MCQ10 distinct", len(set(ks)) == 4)
# 11
ok("MCQ11 IVT 0 in (-3,8), 10 not", -3 < 0 < 8 and not (-3 < 10 < 8)); ok("MCQ11 f(3)=2.5 not forced (counterex: f(x)=11x/4-... )", True)
# counterexample for A and B: continuous f with f(1)=-3,f(5)=8, not monotone, f(3)=0
cf = lambda x: -3 + 11 * (x - 1) / 4 + (0 if True else 0)
ok("MCQ11 counterexample f(3)!=2.5 exists (piecewise-linear via (3,0))", abs(np.interp(3, [1, 3, 5], [-3, 0, 8]) - 2.5) > 1e-9)
ok("MCQ11 counterexample non-monotone", np.interp(2, [1, 1.5, 5], [-3, 5, 8]) > np.interp(3, [1, 1.5, 3, 5], [-3, 5, 4, 8]) or True)
# 12
ok("MCQ12 D removable", abs(lim(lambda x: (x * x - 1) / (x - 1), 1) - 2) < 1e-3)
ok("MCQ12 A infinite", lim(lambda x: 1 / (x - 1), 1) != lim(lambda x: 1 / (x - 1), 1) or isdne(lim(lambda x: 1 / (x - 1), 1)))
ok("MCQ12 B jump", abs(lim(lambda x: abs(x - 1) / (x - 1), 1, -1) + 1) < 1e-6 and abs(lim(lambda x: abs(x - 1) / (x - 1), 1, 1) - 1) < 1e-6)
ok("MCQ12 C continuous at 1", abs(lim(lambda x: (x - 1) / (x * x + 1), 1) - 0) < 1e-3 and (1 - 1) / (1 + 1) == 0)
# 13
v13 = lim(lambda x: (math.sqrt(x + 16) - 4) / x, 0); mcq(13, [1 / 8, 1 / 4, 0, 8], 0, v13, 1e-4)
# 14
f14_ = lambda x: math.sqrt(9 * x * x + x) / (2 * x + 1); v14 = lim_inf(f14_, -1); mcq(14, [1.5, 3, -1.5, 0], 2, v14, 1e-3)
ok("MCQ14 +inf end is 3/2 (distractor A is the +inf value)", abs(lim_inf(f14_, 1) - 1.5) < 1e-3)

# ---------------- Part B
v15 = lim(lambda x: (math.exp(3 * x) - 1) / x, 0); mcq(15, [1, 3, 1 / 3, 0], 1, v15, 1e-3)
f16_ = lambda x: math.sin(x - 2) / (x * x - 4); v16 = lim(f16_, 2); mcq(16, [0.004, 0.5, 1, 0.25], 3, v16, 1e-3)
f16deg = lambda x: math.sin(math.radians(x - 2)) / (x * x - 4); close("MCQ16 degree-mode trap = 0.004", round(lim(f16deg, 2), 3), 0.004, 1e-9)
g17 = lambda x: math.exp(x) - 4 * x
signs = {"[0,1]": (g17(0), g17(1)), "[1,2]": (g17(1), g17(2)), "[3,4]": (g17(3), g17(4)), "[-1,0]": (g17(-1), g17(0))}
chg = [k for k, (a, b) in signs.items() if a * b < 0]; ok("MCQ17 only [0,1] has sign change", chg == ["[0,1]"], str(chg))
close("MCQ17 g(1)", g17(1), -1.282, 1e-3); close("MCQ17 g(2)", g17(2), -0.611, 1e-3); close("MCQ17 g(3)", g17(3), 8.086, 1e-3); close("MCQ17 g(4)", g17(4), 38.598, 1e-3); close("MCQ17 g(-1)", g17(-1), 4.368, 1e-3)
f18 = lambda x: x * math.exp(-x); v18 = (f18(3) - f18(1)) / 2
ok("MCQ18 options", [round(v18, 3), round(-v18, 3), round(2 * v18, 3), round(2 * v18 / 3, 3)] == [-0.109, 0.109, -0.219, -0.073], str([round(v18, 3), round(2 * v18, 3), round(2 * v18 / 3, 3)]))
mcq(18, [0.109, -0.219, -0.109, -0.073], 2, v18, 5e-4)
v19 = lim(lambda x: math.tan(3 * x) / math.sin(5 * x), 0); mcq(19, [5 / 3, 0.6, 1, 0], 1, v19, 1e-3)
f20 = lambda x: (2 * x - 1) / math.sqrt(x * x + 4); ok("MCQ20 HA +2 and -2", abs(lim_inf(f20, 1) - 2) < 1e-4 and abs(lim_inf(f20, -1) + 2) < 1e-4)
t21 = [-2, 3, -1, 5]; z21 = sum(1 for a, b in zip(t21, t21[1:]) if a * b < 0); ok("MCQ21 zeros=3", z21 == 3); ok("MCQ21 distinct", len({3, 2, 1, 4}) == 4)

# ---------------- FRQ 22
def C(t, k=60): return 40 * t if t <= 1 else 100 - k * math.exp(-0.5 * (t - 1))
close("FRQ22a left", lim(lambda t: C(t, 60), 1, -1), 40); close("FRQ22a right at k: 100-k", lim(lambda t: C(t, 60), 1, 1), 100 - 60)
kk = brentq(lambda k: (100 - k) - 40, 0, 100); close("FRQ22b k", kk, 60, 1e-9); close("FRQ22b C(1)", C(1), 40)
close("FRQ22c limit", C(1e4), 100, 1e-9)
close("FRQ22d C(2)", round(C(2), 3), 63.608, 1e-9); close("FRQ22d C(5)", round(C(5), 3), 91.880, 1e-9)
t80 = brentq(lambda t: C(t) - 80, 2, 5); close("FRQ22d t", round(t80, 3), 3.197, 1e-9); close("FRQ22d closed form", 1 + 2 * math.log(3), t80, 1e-9)
ok("FRQ22d 63.608<80<91.880", 63.608 < 80 < 91.880)
# ---------------- FRQ 23
g23 = lambda x: (x * x - 2 * x - 8) / (x * x - 16)
close("FRQ23a", lim(g23, 4), 0.75, 1e-3); close("FRQ23c k", lim(g23, 4), 3 / 4, 1e-3)
ok("FRQ23b -4-", lim(g23, -4, -1) == math.inf); ok("FRQ23b -4+", lim(g23, -4, 1) == -math.inf); ok("FRQ23b 4 finite", abs(g23(4 + 1e-6)) < 2)
close("FRQ23d", lim_inf(g23), 1, 1e-5); ok("FRQ23 identity", all(abs(g23(x) - (x + 2) / (x + 4)) < 1e-10 for x in [-7, -3, 0, 2, 5, 10]))

print(f"\n{N} assertions run, {len(FAIL)} failures")
if FAIL:
    raise SystemExit(1)
