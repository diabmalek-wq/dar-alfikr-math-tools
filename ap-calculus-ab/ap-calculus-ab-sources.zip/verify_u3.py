import numpy as np
from scipy.optimize import brentq, minimize_scalar
e=np.exp; pi=np.pi
H=1e-5
def d(f,x,h=H): return (f(x+h)-f(x-h))/(2*h)
def d2(f,x,h=1e-3): return (f(x+h)-2*f(x)+f(x-h))/h**2
def close(a,b,tol=1e-4,msg=''):
    assert abs(a-b)<tol*max(1,abs(b)),(msg,a,b); print('ok',msg,round(a,5))
def inv(f,y,lo=-10,hi=10): return brentq(lambda x:f(x)-y,lo,hi)
def invd(f,y): g=lambda t:inv(f,t); return d(g,y,1e-4)
# ---------- topic text examples
close(d(lambda x:(3*x*x-5*x+1)**4,1),-4,msg='3.1 ex1 f\'(1)')
close(d(lambda x:np.sin(4*x)**3,pi/12),12*np.sin(pi/3)**2*np.cos(pi/3),msg='3.1 ex2a')
close(d(lambda x:np.log(np.cos(3*x)),pi/12),-3,msg='3.1 ex2b')
# table chain rule (3.1 ex3): f',g,g' arrays
F={1:2,2:3,3:1};Fp={1:5,2:-2,3:4};G={1:3,2:1,3:2};Gp={1:-1,2:6,3:7}
assert Fp[G[2]]*Gp[2]==30 and Gp[F[2]]*Fp[2]==-14 and Fp[1]*2==10 and 3*G[3]**2*Gp[3]==84
assert Fp[G[3]]*Gp[3]==-14  # check 3.1 Q3
# circle
close(d(lambda x:np.sqrt(25-x*x),3),-0.75,msg='circle slope')
# folium
fol=lambda x,y:x**3+y**3-6*x*y
x0=16**(1/3);y0=x0**2/2;close(fol(x0,y0),0,msg='folium pt',tol=1e-9)
assert abs(x0-2.520)<1e-3 and abs(y0-3.175)<1e-3
# folium loop parametrization & slope at (3,3)
X=lambda t:6*t/(1+t**3);Y=lambda t:6*t*t/(1+t**3)
close(d(Y,1)/d(X,1),-1,msg='folium slope (3,3)')
# 3.2 ex3
close(-(2*2+1)/(2+2*1),-1.25,msg='x2+xy+y2')
x=np.sqrt(7/3);y=-2*x;close(x*x+x*y+y*y,7,msg='ex3 horiz')
# check yourself 3.2
y=lambda x:brentq(lambda t:e(t)-x-t,-5,5) if False else None
# e^y=x+y at x=2? just test formula 1/(e^y-1) at some x
x1=3.0;y1=brentq(lambda t:e(t)-x1-t,0.01,5);close(d(lambda x:brentq(lambda t:e(t)-x-t,0.01,5),x1),1/(e(y1)-1),msg='cy3.2.1')
yy=lambda x:(x+np.sqrt(12-3*x*x))/2  # x^2-xy+y^2=3, upper branch
close(yy(1),2,msg='cy3.2.2 pt');close(d(yy,1),0,msg='cy3.2.2 slope',tol=1e-4)
yb=lambda x:brentq(lambda t:x*t+np.log(t)-1,0.2,3);close(yb(1),1,msg='cy3.2.3 pt');close(d(yb,1),-0.5,msg='cy3.2.3')
# 3.3
f=lambda x:x**3+x
close(invd(f,2),0.25,msg='g\'(2)');close(invd(f,10),1/13,msg="g'(10)")
f5=lambda x:x**5+x**3+x;close(f5(1),3,msg='cy3.3.1 f(1)');close(invd(f5,3),1/9,msg='cy3.3.1')
assert 1/(0.5)==2 and 2*2*(1/2)==2
# 3.4
close(d(lambda x:np.arcsin(x**2),0.5),2*0.5/np.sqrt(1-0.5**4),msg='arcsin x2')
close(d(lambda x:np.arctan(np.sqrt(x)),2.0),1/(2*np.sqrt(2)*3),msg='arctan sqrt')
close(d(np.arcsin,0.5),2/np.sqrt(3),msg='arcsin tangent slope')
close(d(lambda t:np.arctan(t/4),3),0.16,msg='camera angle')
close(d(lambda x:np.arctan(e(x)),0.7),e(.7)/(1+e(1.4)),msg='cy3.4.1')
close(d(lambda x:np.arcsin(x/2),1),1/np.sqrt(3),msg='cy3.4.2')
close(d(lambda x:np.arccos(2*x),0),-2,msg='cy3.4.3')
# 3.5
close(d(lambda x:x*x*np.sin(3*x),0.8),2*.8*np.sin(2.4)+3*.64*np.cos(2.4),msg='x2 sin3x')
q=lambda x:e(2*x)/(1+x*x);close(d(q,0.4),2*e(.8)*(.16-.4+1)/(1.16)**2,msg='quot')
g=lambda x:x**np.sin(x);close(d(g,pi/2),1,msg='x^sinx at pi/2')
close(d(lambda x:x**3*np.log(2*x),1.3),3*1.69*np.log(2.6)+1.69,msg='cy3.5.1')
close(d(lambda x:np.cos(x)/(1+np.sin(x)),0.9),-1/(1+np.sin(.9)),msg='cy3.5.2')
close(d(lambda x:3**(x*x),0.7),3**.49*np.log(3)*1.4,msg='cy3.5.3')
# 3.6
fc=lambda x:x**3-6*x**2+9*x;close(fc(2),2,msg='f(2)');close(d(lambda x:3*x*x-12*x+9,2),0,msg="f'' (2)",tol=1e-3)
close(d2(lambda x:e(-x*x),0.6),(4*.36-2)*e(-.36),msg='e^-x2 f\'\'',tol=1e-4)
close(d2(lambda x:np.sin(2*x),0.4),-4*np.sin(.8),msg='sin2x f\'\'',tol=1e-4)
yc=lambda x:np.sqrt(25-x*x);close(d2(yc,3),-25/64,msg='circle y\'\'',tol=1e-4)
close(d2(lambda x:x**5-3*x**2,1.2),20*1.2**3-6,msg='cy3.6.1',tol=1e-4)
close(d2(lambda x:np.log(x*x+1),1),0,msg='cy3.6.2',tol=1e-3) if False else None
assert abs(d2(lambda x:np.log(x*x+1),1))<1e-4;print('ok cy3.6.2 = 0')
close(d2(lambda x:1/x,1),2,msg='cy3.6.3',tol=1e-4)
# ---------- cy 3.1
close(d(lambda x:np.cos(x**3),0.9),-3*.81*np.sin(.729),msg='cy3.1.1')
close(d(lambda x:np.sqrt(4-x*x),1.1),-1.1/np.sqrt(4-1.21),msg='cy3.1.2')
# ---------- Part A
A={}
close(d(lambda x:np.sin(5*x*x),0.7),10*.7*np.cos(5*.49),msg='Q1')
# Q2 table
f_={1:3,2:1,3:2};fp={1:-2,2:6,3:7};g_={1:2,2:3,3:1};gp={1:5,2:-4,3:3}
q2=fp[g_[2]]*gp[2];assert q2==-28;opts2=[7,-24,21,-28];assert len(set(opts2))==4 and opts2[3]==q2
assert fp[2]*gp[2]==-24 and fp[3]*gp[3]==21
# Q3 -(2x+y)/x
xs,ys=1.0,None
yq3=lambda x:brentq(lambda t:x*x+x*t-10,-100,100)
x=2.0;y=yq3(x);close(d(yq3,x),-(2*x+y)/x,msg='Q3')
f4=lambda x:2*x**3+3*x;close(f4(1),5,msg='Q4 f(1)');close(invd(f4,5),1/9,msg='Q4');assert len({1/5,9,1/9,1/153})==4
close(d(lambda x:np.arctan(x*x),1),1,msg='Q5')
close(d2(lambda x:x*x*e(x),1),7*e(1),msg='Q6',tol=1e-4); assert abs(3*e(1)-7*e(1))>1
assert -2*4==-8  # Q7 f'(4)*2*2 = -2*4
assert 3*4==12 and 3*2==6 # distractors 12 (f'(2)*2x), 
# Q8: x^3+y^3=9 at (1,2)
assert 1+8==9; close(-1/4,-1/4,msg='Q8 slope')
yq8=lambda x:np.cbrt(9-x**3);close(d(yq8,1),-0.25,msg='Q8')
close(d(lambda x:np.arcsin(np.sqrt(x)),0.5),1,msg='Q9')
close(d(lambda x:np.cos(x)/(1+np.sin(x)),pi/2),-0.5,msg='Q10')
close(d2(yc,3),-25/64,msg='Q11',tol=1e-4)
# Q12: f=1+16/x^2 ; f(2)=5 ; tangent through (3,1)
f12=lambda x:1+16/x**2;close(f12(2),5,msg='Q12 f(2)');close(d(f12,2),-4,msg='Q12 f\'(2)');close((1-5)/(3-2),-4,msg='Q12 chord slope')
close(invd(f12,5) if False else d(lambda t:np.sqrt(16/(t-1)),5),-0.25,msg='Q12 g\'(5)',tol=1e-4)
close(np.sqrt(16/(5-1)),2,msg='Q12 g(5)')
close(d(lambda x:e(np.arctan(x)),1),e(pi/4)/2,msg='Q13')
# Q14: x^2-2xy+2y^2=5 horizontal tangent
a=np.sqrt(5);b=a;close(a*a-2*a*b+2*b*b,5,msg='Q14 on curve')
yq14=lambda x:(x+np.sqrt(10-x*x))/1.0/2*1.0 if False else (2*x+np.sqrt(4*x*x-8*(x*x-5)))/4
close(yq14(a),a,msg='Q14 y=x');close(d(yq14,a-1e-3,1e-6),0,msg='Q14 slope~0',tol=0.05)
# max/min of yq14 over grid: horizontal tangent at max y
xs=np.linspace(-np.sqrt(10)+1e-6,np.sqrt(10)-1e-6,2000001) if False else np.linspace(-3,3,600001)
ys=yq14(xs);close(xs[np.argmax(ys)],a,msg='Q14 grid argmax',tol=1e-3)
# ---------- Part B
close(d(lambda x:np.sin(e(x)),1.2),-3.267,tol=1e-3,msg='Q15');
r={'15':np.cos(e(1.2))*e(1.2)}
yb16=brentq(lambda t:t+e(t)-6,0,3);v16=4/(1+e(yb16));close(v16,0.728,tol=1e-3,msg='Q16')
yq16=lambda x:brentq(lambda t:t+e(t)-x*x-2,0,5);close(d(yq16,2),v16,msg='Q16 FD')
v17=1/(2+e(inv(lambda x:2*x+e(x),6,0,3)));close(v17,0.182,tol=1e-3,msg='Q17')
g17=lambda t:inv(lambda x:2*x+e(x),t,-5,5);close(d(g17,6,1e-4),v17,msg='Q17 FD')
th=lambda t:np.arctan(3*t*t/40);close(d(th,4),0.246,tol=1e-3,msg='Q18')
s=lambda t:t*t*e(-t/2);close(d2(s,3,1e-3),-0.390,tol=2e-3,msg='Q19')
f20=lambda x:np.log(x*x+1)+np.arctan(x);r20=brentq(lambda x:d(f20,x)-0.8,0.01,10);close(r20,2.596,tol=1e-3,msg='Q20')
# unique solution for x>0
xs=np.linspace(0.001,50,200001);sl=(2*xs+1)/(1+xs**2)-0.8;assert np.sum(np.diff(np.sign(sl))!=0)==1
close(d(g,2),0.312,tol=2e-3,msg='Q21')
for name,v,opts in [('15',r['15'],[-0.984,0.590,3.315,-3.267]),('16',v16,[0.728,0.890,1.598,1.144]),('17',v17,[0.002,5.496,0.182,0.212]),('18',d(th,4),[0.600,0.246,0.273,9.836]),('19',d2(s,3),[0.112,0.335,-1.750,-0.390]),('20',r20,[0.500,1.225,2.596,0.570]),('21',d(g,2),[0.166,0.312,0.854,1.878])]:
    assert len(set(opts))==4,name
    k=[i for i,o in enumerate(opts) if abs(o-v)<2e-3]; assert len(k)==1,(name,v,opts); print('Q'+name,'key','ABCD'[k[0]])
# ---------- FRQ 22
h=lambda t:10*t*t;th=lambda t:np.arctan(h(t)/300)
t5=d(th,5);close(t5,300/1525,msg='22a');print('22a',round(t5,4))
close(60*5/(900+5**4),300/1525,msg='22a formula')
Tinv=lambda H:np.sqrt(H/10);close(d(Tinv,1000,1e-3),1/200,msg='22b');close(Tinv(1000),10,msg='22b T')
ts=np.linspace(0,20,2000001);v=d(th,ts,1e-6)
tm=ts[np.argmax(v)];close(tm,300**0.25,tol=1e-3,msg='22c t*');close(v.max(),60*300**0.25/1200,msg='22c max');print('22c max',v.max(),'theta\'(0)',60*0/900,'theta\'(20)',60*20/(900+20**4))
assert v.max()>1200/(900+160000)
# sign of theta'' around t*
tp=lambda t:60*t/(900+t**4);assert tp(4)<tp(4.16) and tp(4.17)>tp(4.5)
D=lambda t:np.sqrt(300**2+h(t)**2);close(d(D,5),25000/np.sqrt(152500),msg='22d');print('22d',d(D,5),np.sqrt(152500))
# ---------- FRQ 23
close(1+2+3,6,msg='23 pt')
yc23=lambda x:(-x+np.sqrt(x*x-3*(x*x-6)))/3   # 3y^2+2xy+x^2-6=0 -> y=(-x+sqrt(x^2-3(x^2-6)))/3
close(yc23(1),1,msg='23 branch');close(d(yc23,1),-0.5,msg='23b slope')
close(d2(yc23,1),-3/16,tol=1e-3,msg='23d y\'\'')
for x in (np.sqrt(3),-np.sqrt(3)):
    y=-x; close(x*x+2*x*y+3*y*y,6,msg='23c pt')
yup=lambda x:(-x+np.sqrt(18-2*x*x))/3
xs=np.linspace(-3,3,600001);assert abs(xs[np.argmax(yup(xs))]+np.sqrt(3))<1e-3 or True
xm=xs[np.argmax(yup(xs))];close(xm,-np.sqrt(3),tol=1e-3,msg='23c max at x=-sqrt3');close(yup(xm),np.sqrt(3),tol=1e-3,msg='23c ymax')
ylo=lambda x:(-x-np.sqrt(18-2*x*x))/3;xm=xs[np.argmin(ylo(xs))];close(xm,np.sqrt(3),tol=1e-3,msg='23c min');
# y'' formula -12/(x+3y)^3 at (1,1)
close(-12/(1+3)**3,-3/16,msg='23d formula')
print('ALL OK')
# option-set distinctness for Part A
import math
sets={2:[7,-24,21,-28],4:[1/5,9,1/9,1/153],5:[.5,1,2,4],6:[7*e(1),3*e(1),4*e(1),7],7:[-2,12,1,-8],8:[-4,.25,-.25,-.5],9:[1/math.sqrt(2),1,math.sqrt(2),2],10:[-.5,-2,.5,0],11:[-.75,25/64,-.25,-25/64],13:[e(pi/4)/2,e(pi/4),e(pi/4)/math.sqrt(2),2*e(pi/4)],14:[1,math.sqrt(10),math.sqrt(5),5]}
for k,v in sets.items(): assert len(set(round(a,9) for a in v))==4,k
# Q7 distractor definitions
assert (3*2*2,-2*1)==(12,-2) and 3+(-2)==1
# Q14 distractors: vertical tangent y=x/2 -> x^2=10; y=-x -> 5x^2=5
assert abs((1-2*0.5+2*0.25)-0.5)<1e-12
print('Part A key letters: B D A C B A D C B A D C A C')

# ---------- additions (second pass)
f1=lambda x:np.interp(x,[0,2,4,6],[0,4,3,5])
close(d(lambda x:f1(x)**2,3,1e-4),-3.5,msg='3.1 ex5a');close(d(lambda x:f1(2*x),1.5,1e-4),-1,msg='3.1 ex5b');close(d(lambda x:np.sqrt(f1(x)),5,1e-4),0.25,msg='3.1 ex5c')
close(d(lambda x:np.sqrt(x/(x+1)),1),np.sqrt(2)/8,msg='3.1 ex4b')
close(d(lambda x:(x*x+1)**-3,0.7),-6*.7/(1.49)**4,msg='3.1 ex4c');close(d(lambda x:e(np.sin(2*x)),0.4),e(np.sin(.8))*2*np.cos(.8),msg='3.1 ex4a')
close(d(lambda t:np.pi*(2*t)**2,3),24*np.pi,msg='3.1 ex6');close(24*np.pi,75.398,tol=1e-4,msg='24pi')
close(d(lambda t:20+60*e(-0.05*t),10),-3*e(-.5),msg='3.1 ex7');assert abs(-3*e(-.5)+1.820)<5e-4
# 3.2
close(-5/4,-5/4,msg='ex4 slope');xx=np.sqrt(7/3)
yq=lambda x:(-x+np.sqrt(28-3*x*x))/2   # upper branch of x^2+xy+y^2=7
close(yq(-2*xx),xx,tol=1e-9,msg='vertical pt on curve') if False else None
for (x,y) in [(-2*xx,xx),(2*xx,-xx)]:
    close(x*x+x*y+y*y,7,msg='3.2 ex4 vertical pt');assert abs(x+2*y)<1e-12
assert abs(2*xx-3.055)<1e-3 and abs(xx-1.528)<1e-3
close(2*np.sqrt(28/12)/1,2*np.sqrt(7/3),msg='ellipse extent')
th=np.linspace(0,2*np.pi,200001);X=np.sqrt(7)*np.cos(th)-0.5*np.sqrt(28/3)*np.sin(th);Y=np.sqrt(28/3)*np.sin(th)
close(np.max(np.abs(X**2+X*Y+Y**2-7)),0,tol=1e-9,msg='fig ellipse param');close(X.max(),3.055,tol=1e-3,msg='fig ellipse xmax');close(Y.max(),3.055,tol=1e-3,msg='fig ellipse ymax')
close(X[np.argmax(Y)],-1.5275,tol=1e-3,msg='ellipse top pt x')
yx=lambda x:brentq(lambda t:x*np.exp(t)+t-3,-5,5);close(yx(3),0,msg='ex5 pt',tol=1e-9);close(d(yx,3),-0.25,msg='3.2 ex5')
y6=lambda x:brentq(lambda t:t**3+x*t-10,-10,10);close(y6(1),2,msg='3.2 ex6 y');close(d(y6,1),-2/13,msg='3.2 ex6')
# 3.3
g4=lambda x:np.interp(x,[0,2,5,8],[1,4,6,7])
gi=lambda y:np.interp(y,[1,4,6,7],[0,2,5,8])
close(d(gi,5,1e-4),1.5,msg='3.3 ex4a');close(gi(5),3.5,msg='g(5)');close(d(gi,2,1e-4),2/3,msg='3.3 ex4b');close(gi(2),2/3,msg='g(2)')
fe=lambda x:x+e(x);close(invd(fe,1),0.5,msg='3.3 ex5 g\'(1)');close(invd(fe,1+e(1)),1/(1+e(1)),msg='g\'(1+e)');assert abs(1/(1+e(1))-0.269)<1e-3
dd_=lambda t:t**3+t;close(d(lambda y:inv(dd_,y,0,10),10,1e-4),1/13,msg='3.3 ex6');close(60/13,4.615,tol=1e-3,msg='4.6 s')
# 3.4
close(d(lambda x:np.arccos(2*x),0.25),-4/np.sqrt(3),msg='3.4 ex4a');close(d(lambda x:np.log(np.arctan(x)),1),2/np.pi,msg='3.4 ex4b')
close(d(np.arctan,1),0.5,msg='arctan tangent');xs=np.linspace(-5,5,100001);close(xs[np.argmax(1/(1+xs**2))],0,msg='max arctan slope')
# 3.5
p_=lambda x:0;
close(Fp[2]*G[2]+F[2]*Gp[2],16,msg='3.5 ex4a');close((Fp[3]*G[3]-F[3]*Gp[3])/G[3]**2,0.25,msg='3.5 ex4b');close(Fp[1]/F[1],2.5,msg='3.5 ex4c')
close(d(lambda x:np.log(x*x/np.sqrt(x*x+1)),1),1.5,msg='3.5 ex5')
x0=0.9
close(d(lambda x:x*np.exp(-x),x0),np.exp(-x0)*(1-x0),msg='spec1');close(d(lambda x:np.sqrt(x*x+4),x0),x0/np.sqrt(x0*x0+4),msg='spec2')
close(d(lambda x:np.log(x)/x**2,x0),(1-2*np.log(x0))/x0**3,msg='spec3');close(d(lambda x:e(x)*np.arctan(x),x0),e(x0)*(np.arctan(x0)+1/(1+x0*x0)),msg='spec4')
close(d(lambda x:np.sin(x)**x,x0),np.sin(x0)**x0*(np.log(np.sin(x0))+x0/np.tan(x0)),msg='spec5')
ys=lambda x:brentq(lambda t:x*x*t+t**3-5,-10,10);x0=1.3;close(d(ys,x0),-2*x0*ys(x0)/(x0*x0+3*ys(x0)**2),msg='spec6')
# 3.6
fp=lambda x:np.interp(x,[0,2,4,6],[3,-1,-1,2])
close(d(fp,1,1e-4),-2,msg='3.6 ex4 f\'\'(1)');close(d(fp,3,1e-4),0,msg='f\'\'(3)');close(d(fp,5,1e-4),1.5,msg='f\'\'(5)')
sp=lambda t:t**3-9*t*t+24*t;vv=lambda t:3*t*t-18*t+24;close(d(sp,1),9,msg='3.6 ex5 v');close(d(vv,1),-12,msg='3.6 ex5 a')
close(d2(lambda x:x*np.log(x),1.7),1/1.7,tol=1e-4,msg='3.6 ex7')
assert 100%4==0
print('ADDITIONS OK')

print('ALL OK (final)')
