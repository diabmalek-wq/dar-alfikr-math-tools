import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
pi=np.pi;fails=[];n=0
def chk(name,text,comp,tol=1e-6):
    global n;n+=1
    if abs(text-comp)>tol*max(1,abs(comp)): fails.append((name,text,comp))
def Q(f,a,b,pts=None): return quad(f,a,b,points=pts,limit=200)[0]
def num_der(f,x,h=1e-6): return (f(x+h)-f(x-h))/(2*h)
# ---------- 8.1
chk('8.1E1',Q(lambda x:x*x+1,0,3)/3,4);chk('8.1E1c',np.sqrt(3),1.7320508)
chk('8.1E2',(0.5*3*30+0.5*2*38+0.5*4*34),151);chk('8.1E2b',151/9,16.778,1e-4)
chk('8.1E3',Q(lambda x:x*np.exp(x*x),0,2)/2,(np.exp(4)-1)/4);chk('8.1E3b',(np.exp(4)-1)/4,13.400,1e-4)
chk('8.1c1',Q(lambda x:x**3,0,2)/2,2);chk('8.1c2',14/4,3.5)
fa=Q(np.sin,0,pi)/pi;chk('8.1c3a',fa,2/pi);c1=np.arcsin(fa);chk('8.1c3b',c1,0.6901,1e-4);chk('8.1c3c',pi-c1,2.4515,1e-4)
# ---------- 8.2
v=lambda t:t*t-4*t+3
chk('8.2E1disp',Q(v,0,4),4/3);chk('8.2E1dist',Q(lambda t:abs(v(t)),0,4,[1,3]),4)
chk('8.2E3',Q(v,0,4)/4,1/3);chk('8.2E3b',Q(lambda t:abs(v(t)),0,4,[1,3])/4,1)
vv=lambda t:t*t-4*t+6;chk('8.2E2v1',vv(1),3);chk('8.2E2',5+Q(vv,0,3),14);chk('8.2E2a1',2*1-4,-2);chk('8.2E2a3',2*3-4,2)
w=lambda t:3*t*t-12;chk('8.2c1',Q(w,0,3),-9);chk('8.2c1b',Q(lambda t:abs(w(t)),0,3,[2]),23)
v2=lambda t:-2+2*t*t;chk('8.2c2',3+Q(v2,0,3),15)
chk('8.2c3',(1-4)*(2*1-4),6)  # v(1)=-3, a(1)=-2 same sign
# ---------- 8.3
chk('8.3E1',100+Q(lambda t:12-3*t,0,4),124);chk('8.3E1b',100+Q(lambda t:12-3*t,0,8),100)
Nn=lambda t:6*np.sin(t/2)-2
A=lambda t:40+Q(Nn,0,t)
chk('8.3E2a',A(12),28-12*np.cos(6),1e-9);chk('8.3E2a2',A(12),16.478,1e-4)
t1=2*np.arcsin(1/3);t2=2*(pi-np.arcsin(1/3));chk('8.3E2t1',t1,0.680,1e-3);chk('8.3E2t2',t2,5.604,1e-4);chk('Nroot',Nn(t2),0,1e-9)
chk('8.3E2max',A(t2),52.107,1e-4);chk('8.3E2A0',A(0),40)
tt=np.linspace(0,12,120001);chk('8.3E2grid',tt[np.argmax([A(x) for x in tt[::100]])*100],5.604,1e-3)
chk('8.3E3',90-35,55)
chk('8.3c1',80-Q(lambda t:12-2*t,0,6),44)
# 8.3c3: R=(t-2)(t-4): + then - at 2
Rr=lambda t:t*t-6*t+8;chk('8.3c3+',float(Rr(1)>0),1);chk('8.3c3-',float(Rr(3)<0),1)
# ---------- 8.4
chk('8.4E1',Q(lambda x:6-x*x-x,-3,2),125/6);chk('8.4E1b',125/6,20.833,1e-4)
chk('8.4E2',Q(lambda x:np.exp(x)-x,0,1),np.e-1.5);chk('8.4E2b',np.e-1.5,1.218,1e-3)
chk('8.4E3',Q(lambda x:abs(np.sin(x)-np.cos(x)),0,pi/2,[pi/4]),2*(np.sqrt(2)-1));chk('8.4E3b',2*(np.sqrt(2)-1),0.828,1e-3)
chk('8.4c1',Q(lambda x:8-2*x*x,-2,2),64/3);chk('8.4c2',Q(lambda x:-x*x+x+2,-1,2),4.5)
# ---------- 8.5
chk('8.5E1',Q(lambda y:y+2-y*y,-1,2),4.5);chk('8.5E2',Q(lambda y:np.exp(y),0,2),np.e**2-1);chk('8.5E2b',np.e**2-1,6.389,1e-3)
chk('8.5c1',Q(lambda y:4-y*y,-2,2),32/3);chk('8.5c2',Q(lambda y:np.exp(y),0,1),np.e-1)
# ---------- 8.6
chk('8.6E1',Q(lambda x:abs(x**3-x),-1,1,[0]),0.5)
fx=lambda x:x**3-3*x-(x*x-1)
r=np.roots([1,-1,-3,1]);r.sort();chk('8.6r1',r[0],-1.481,1e-3);chk('8.6r2',r[1],0.311,1e-3);chk('8.6r3',r[2],2.170,1e-3)
a1=Q(lambda x:abs(fx(x)),r[0],r[1]);a2=Q(lambda x:abs(fx(x)),r[1],r[2]);chk('8.6E2a',a1,2.644,1e-3);chk('8.6E2b',a2,2.914,1e-3);chk('8.6E2',a1+a2,5.558,1e-3)
chk('8.6c1',Q(lambda x:abs(x**3-4*x),-2,2,[0]),8);chk('8.6c2',Q(lambda x:abs(x**3-2*x),-np.sqrt(2),np.sqrt(2),[0]),2)
# ---------- 8.7
chk('8.7E1',Q(lambda x:x,0,4),8)
chk('8.7E2',Q(lambda x:3*(x-x*x)**2,0,1),0.1)
chk('8.7E3',Q(lambda y:(4-y*y)**2,-2,2),512/15)
chk('8.7E4',0.5*2*(4+16)+0.5*3*(16+25)+0.5*3*(25+9),132.5)
chk('8.7c1',Q(lambda x:x*x,0,3),9);chk('8.7c2',5*Q(lambda x:x-x*x,0,1),5/6)
chk('8.7c3',0.5*1*(1+9)+0.5*2*(9+16)+0.5*1*(16+4),40)
# ---------- 8.8
chk('8.8E1',np.sqrt(3)/4*Q(lambda x:np.sin(x)**2,0,pi),np.sqrt(3)*pi/8);chk('8.8E1b',np.sqrt(3)*pi/8,0.680,1e-3)
chk('8.8E2',pi/8*Q(lambda x:(4-x*x)**2,-2,2),64*pi/15);chk('8.8E2b',64*pi/15,13.404,1e-4)
chk('8.8E3',Q(lambda x:(2*np.sqrt(9-x*x))**2/4,-3,3),36)
chk('8.8c1',pi/8*Q(lambda x:x,0,4),pi)
chk('8.8c2',np.sqrt(3)/4*Q(lambda x:(x-x*x)**2,0,1),np.sqrt(3)/120)
c3=pi/8*Q(lambda y:(y+2-y*y)**2,-1,2);chk('8.8c3',c3,81*pi/80)
# ---------- 8.9
chk('8.9E1',pi*Q(lambda x:x,0,4),8*pi);chk('8.9E1b',8*pi,25.133,1e-4)
chk('8.9E2',pi*Q(lambda y:y,0,9),81*pi/2);chk('8.9E2b',81*pi/2,127.235,1e-4)
ee=Q(lambda x:np.exp(-2*x*x),0,1);chk('8.9E3a',ee,0.5981,1e-3);chk('8.9E3',pi*ee,1.879,1e-3)
chk('8.9c1',pi*Q(lambda x:x*x,0,3),9*pi);chk('8.9c2',pi*Q(lambda y:y**(2/3),0,8),96*pi/5);chk('8.9c3',pi*Q(lambda x:np.sin(x)**2,0,pi),pi*pi/2)
# ---------- 8.10
chk('8.10E1',pi*Q(lambda x:(4-x*x)**2,0,2),256*pi/15);chk('8.10E1b',256*pi/15,53.617,1e-4)
chk('8.10E2',pi*Q(lambda y:(2-np.sqrt(y))**2,0,4),8*pi/3);chk('8.10E2b',8*pi/3,8.378,1e-3)
chk('8.10c1',pi*Q(lambda x:(1-x*x)**2,0,1),8*pi/15);chk('8.10c2',pi*Q(lambda y:(1-np.sqrt(y))**2,0,1),pi/6)
# ---------- 8.11
chk('8.11E1',pi*Q(lambda x:x-x*x/4,0,4),8*pi/3)
chk('8.11E2',pi*Q(lambda y:y-y*y,0,1),pi/6)
chk('8.11E3',pi*Q(lambda x:4*x*x-x**4,0,2),64*pi/15);chk('8.11E3b',64*pi/15,13.404,1e-4);chk('8.11E3wrong',pi*Q(lambda x:(2*x-x*x)**2,0,2),16*pi/15)
chk('8.11c1',pi*Q(lambda x:x*x-x**6,0,1),4*pi/21);chk('8.11c2',pi*Q(lambda y:y*y-y**4,0,1),2*pi/15);chk('8.11c3',pi*Q(lambda x:16-x**4,-2,2),256*pi/5)
# ---------- 8.12
chk('8.12E1',pi*Q(lambda x:(2-x*x)**2-(2-x)**2,0,1),8*pi/15);chk('8.12E1b',8*pi/15,1.676,1e-3)
chk('8.12E1exp',Q(lambda x:(2-x*x)**2-(2-x)**2-(x**4-5*x*x+4*x),0,1),0)
chk('8.12E2',pi*Q(lambda y:(np.sqrt(y)+1)**2-(y+1)**2,0,1),pi/2);chk('8.12E2b',pi/2,1.571,1e-3)
chk('8.12E3',pi*Q(lambda x:(np.sqrt(x)+1)**2-(x/2+1)**2,0,4),16*pi/3);chk('8.12E3b',16*pi/3,16.755,1e-3)
chk('8.12E3int',Q(lambda x:(np.sqrt(x)+1)**2-(x/2+1)**2-(2*np.sqrt(x)-x*x/4),0,4),0)
chk('8.12c1',pi*Q(lambda x:(x+1)**2-(x*x+1)**2,0,1),7*pi/15);chk('8.12c2',pi*Q(lambda y:(y+2)**2-(y*y+2)**2,0,1),4*pi/5)
# ---------- Part A
def opts(name,vals,key,correct,tol=1e-6):
    # vals: 4 values, key index 0-3; check distinct and correct
    global n;n+=1
    if len(set(np.round(vals,9)))!=4: fails.append((name,'options not distinct',vals))
    chk(name,vals[key],correct,tol)
f=lambda x:3*x*x-2*x
opts('A1',[(f(3)-f(1))/2,Q(f,1,3)/2,(f(1)+f(3))/2,Q(f,1,3)],1,9)
vA=lambda t:3*t*t-6*t
opts('A2',[Q(vA,0,2),Q(vA,0,3),-Q(vA,0,2),Q(lambda t:abs(vA(t)),0,3,[2])],3,8)
opts('A2b',[-4,0,4,8],3,8)
opts('A3',[Q(lambda x:x+2-x*x,-1,2),Q(lambda x:x+2-x*x,0,2),Q(lambda x:x*x-x-2,-1,2),Q(lambda x:x+2+x*x,-1,2)],0,4.5)
chk('A3vals',10/3,Q(lambda x:x+2-x*x,0,2));chk('A3v2',21/2,Q(lambda x:x+2+x*x,-1,2))
opts('A4',[pi*Q(lambda x:x**2,0,2),pi*32,pi*Q(lambda x:x**4,0,2),Q(lambda x:x**4,0,2)],2,32*pi/5)
chk('A4a',8*pi/3,pi*Q(lambda x:x**2,0,2));chk('A4d',32/5,Q(lambda x:x**4,0,2))
opts('A5',[pi*Q(lambda x:(x-x*x)**2,0,1),pi*Q(lambda x:x*x-x**4,0,1),pi*Q(lambda x:x-x*x,0,1),pi*Q(lambda x:x*x,0,1)],1,2*pi/15)
chk('A5a',pi/30,pi*Q(lambda x:(x-x*x)**2,0,1));chk('A5c',pi/6,pi*Q(lambda x:x-x*x,0,1));chk('A5d',pi/3,pi/3)
opts('A6',[Q(lambda y:y,0,4),Q(lambda y:2*np.sqrt(y),0,4),Q(lambda x:(4-x*x)**2,-2,2),Q(lambda y:4*y,0,4)],3,32)
chk('A6a',8,Q(lambda y:y,0,4));chk('A6b',32/3,Q(lambda y:2*np.sqrt(y),0,4));chk('A6c',512/15,Q(lambda x:(4-x*x)**2,-2,2))
tab_t=[0,3,5,9];tab_r=[4,6,5,7]
trap=sum(0.5*(tab_t[i+1]-tab_t[i])*(tab_r[i]+tab_r[i+1]) for i in range(3))
left=sum((tab_t[i+1]-tab_t[i])*tab_r[i] for i in range(3));right=sum((tab_t[i+1]-tab_t[i])*tab_r[i+1] for i in range(3))
opts('A7',[left,right,trap,2*trap],2,50)
chk('A7',trap,50);chk('A7l',44,left);chk('A7r',56,right)
chk('A9',(Q(lambda x:0*x,0,1)+3*12+2*3)/3,14);chk('A9a',38/3,(36+2)/3);chk('A9b',12,3*12/3)
opts('A10',[Q(lambda x:np.sqrt(x)-(x-2),0,4),Q(lambda y:y+2-y*y,0,2),Q(lambda y:y*y,0,2),Q(lambda y:y+2+y*y,0,2)],1,10/3)
chk('A10a',16/3,Q(lambda x:np.sqrt(x)-(x-2),0,4));chk('A10c',8/3,Q(lambda y:y*y,0,2));chk('A10d',26/3,Q(lambda y:y+2+y*y,0,2))
opts('A11',[pi*Q(lambda x:(np.sqrt(x)+1)**2,0,4),pi*Q(lambda x:(np.sqrt(x)-1)**2-1,0,4),pi*Q(lambda x:x,0,4),pi*Q(lambda x:(np.sqrt(x)+1)**2-1,0,4)],3,56*pi/3)
chk('A11a',68*pi/3,pi*Q(lambda x:(np.sqrt(x)+1)**2,0,4));chk('A11b',4*pi/3,pi*Q(lambda x:(np.sqrt(x)-1)**2,0,4));chk('A11b2',4*pi/3-0,pi*Q(lambda x:(np.sqrt(x)-1)**2,0,4))
# A12 piecewise linear
tp=[0,2,4,6,8];vp=[0,4,4,-4,0]
vf=lambda t:np.interp(t,tp,vp)
dist=Q(lambda t:abs(vf(t)),0,8,[2,4,5,6]);disp=Q(vf,0,8,[2,4,5,6]);pos=Q(lambda t:max(vf(t),0),0,8,[2,4,5,6]);neg=Q(lambda t:max(-vf(t),0),0,8,[2,4,5,6])
opts('A12',[disp,pos,neg,dist],3,20);chk('A12v',[8,14,6,20][0],disp);chk('A12p',14,pos);chk('A12n',6,neg)
# A13
x_v=lambda t:3*t*t-12*t+9;x_a=lambda t:6*t-12
res=[x_v(t)*x_a(t)>1e-9 for t in [0.5,1.5,2,2.5]];n+=1
if res!=[False,True,False,False]: fails.append(('A13',res,'expected only 1.5'))
chk('A13v',x_v(1.5),num_der(lambda t:t**3-6*t*t+9*t,1.5),1e-4)
# A14
Wp=lambda t:t*t-5*t+4;W=lambda t:Q(Wp,0,t)
cands={0:W(0),1:W(1),4:W(4),6:W(6)};n+=1
if max(cands,key=cands.get)!=6: fails.append(('A14',cands,6))
chk('A14W6',W(6),6);chk('A14W1',W(1),11/6)
# ---------- Part B
opts('B15',[Q(lambda x:np.exp(-x*x),0,2)/2,Q(lambda x:np.exp(-x*x),0,2),(np.exp(-4)-1)/2,(1+np.exp(-4))/2],0,0.441,1e-3)
chk('B15b',0.882,Q(lambda x:np.exp(-x*x),0,2),1e-3);chk('B15c',-0.491,(np.exp(-4)-1)/2,1e-3);chk('B15d',0.509,(1+np.exp(-4))/2,1e-3)
fE=lambda x:np.exp(x);gE=lambda x:4-x*x
a=brentq(lambda x:fE(x)-gE(x),-3,-1);b=brentq(lambda x:fE(x)-gE(x),0,2)
chk('B16a',a,-1.9646,1e-4);chk('B16b',b,1.0580,1e-4)
areaB=Q(lambda x:gE(x)-fE(x),a,b);chk('B16',areaB,6.428,1e-3)
chk('B16o1',1.957,Q(lambda x:gE(x)-fE(x),0,b),1e-3);chk('B16o2',9.442,Q(lambda x:abs(gE(x)-fE(x)),-2,2),1e-3);chk('B16o3',-6.428,-areaB,1e-3)
chk('B17',pi*Q(lambda x:np.log(x)**2,1,np.e),pi*(np.e-2),1e-9);chk('B17b',pi*(np.e-2),2.257,1e-3);chk('B17a',0.718,np.e-2,1e-3);chk('B17c',3.142,pi*Q(np.log,1,np.e),1e-3);chk('B17d',4.513,2*pi*(np.e-2),1e-3)
vB=lambda t:np.sin(t*t)
chk('B18',Q(lambda t:abs(vB(t)),0,2,[np.sqrt(pi)]),0.985,1e-3);chk('B18a',0.805,Q(vB,0,2),1e-3);chk('B18b',-0.757,vB(2),1e-3);chk('B18d',0.895,Q(vB,0,np.sqrt(pi)),1e-3)
chk('B19',80-Q(lambda t:10*np.exp(-0.3*t),0,5),54.104,1e-4);chk('B19b',25.896,Q(lambda t:10*np.exp(-0.3*t),0,5),1e-4);chk('B19c',105.896,80+Q(lambda t:10*np.exp(-0.3*t),0,5),1e-4);chk('B19d',77.769,80-10*np.exp(-1.5),1e-4)
chk('B20',Q(lambda x:np.log(x)**2,1,3),1.029,1e-3);chk('B20a',1.296,Q(np.log,1,3),1e-3);chk('B20b',1.679,Q(np.log,1,3)**2,1e-3);chk('B20c',3.233,pi*Q(lambda x:np.log(x)**2,1,3),1e-3)
a=(-1-np.sqrt(13))/2;b=(-1+np.sqrt(13))/2
chk('B21',pi*Q(lambda x:(3-x)**2-x**4,a,b),107.986,1e-4);chk('B21a',34.373,Q(lambda x:(3-x)**2-x**4,a,b),1e-4);chk('B21c',63.810,pi*Q(lambda x:(3-x-x*x)**2,a,b),1e-4);chk('B21d',151.029,pi*Q(lambda x:(3-x)**2,a,b),1e-4)
chk('B21x',(3-a)-(a*a),0,1e-9)
# ---------- FRQ 22
R=lambda t:12+8*np.cos(t/3);D=lambda t:t+3;Nf=lambda t:R(t)-D(t)
chk('F22a',Q(R,0,10),115.426,1e-5);chk('F22a2',120+24*np.sin(10/3),Q(R,0,10),1e-9)
chk('F22b',Nf(7),-3.526,1e-3);chk('F22b2',R(7),6.474,1e-3)
ts=brentq(Nf,0,10);chk('F22c',ts,5.904,1e-4)
grid=np.linspace(0,10,100001);Ag=50+np.array([Q(Nf,0,x) for x in grid[::1000]])
chk('F22cgrid',grid[::1000][np.argmax(Ag)],5.9,0.11)
dn=np.array([num_der(Nf,x) for x in grid]);n+=1
if not (dn<0).all(): fails.append(('F22 N monotone',))
chk('F22d',50+Q(Nf,0,ts),107.839,1e-5);chk('F22A10',50+Q(Nf,0,10),85.426,1e-5);chk('F22D',Q(D,0,10),80)
# ---------- FRQ 23
fF=lambda x:3*x-x*x;gG=lambda x:x
chk('F23x',brentq(lambda x:fF(x)-gG(x),1,3),2)
chk('F23a',Q(lambda x:fF(x)-gG(x),0,2),4/3);chk('F23b',Q(lambda x:(fF(x)-gG(x))**2,0,2),16/15)
chk('F23c',pi*Q(lambda x:fF(x)**2-gG(x)**2,0,2),56*pi/15)
chk('F23d',pi*Q(lambda x:(4-gG(x))**2-(4-fF(x))**2,0,2),104*pi/15);chk('F23d2',21.782,104*pi/15,1e-4)
chk('F23dexp',Q(lambda x:(4-gG(x))**2-(4-fF(x))**2-(-x**4+6*x**3-16*x*x+16*x),0,2),0)
print('checks run:',n);print('FAILS:',fails if fails else 'none')
