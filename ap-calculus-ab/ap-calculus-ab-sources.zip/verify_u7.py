import numpy as np
from scipy.integrate import solve_ivp, quad
from scipy.optimize import brentq
ok=0
def chk(name,cond,info=""):
    global ok
    assert cond, f"FAIL {name} {info}"
    ok+=1
def close(a,b,tol=1e-6): return abs(a-b)<tol
def d(f,x,h=1e-6): return (f(x+h)-f(x-h))/(2*h)
def d2(f,x,h=1e-4): return (f(x+h)-2*f(x)+f(x-h))/h**2
def ode(rhs,x0,y0,x1):
    s=solve_ivp(lambda x,y:[rhs(x,y[0])],[x0,x1],[y0],rtol=1e-11,atol=1e-12); return s.y[0,-1]

# ---------- 7.1 / 7.2 ----------
chk("7.1 eq P",close(0.04*500-20,0)); chk("7.1 dec",0.04*400-20==-4)
chk("tank eq",close(2-80/40,0)); chk("tank A=100",close(2-100/40,-0.5))
chk("fish table",[0.05*P-30 for P in (400,500,600,700,800)]==[-10,-5,0,5,10])
f=lambda x:3*np.exp(2*x)+x
for x in (-1,0,.7,2): chk("7.2 ex1",close(d(f,x),2*f(x)-2*x+1,1e-4))
f=lambda x:4*np.exp(-x*x)
for x in (-1,0.3,2): chk("7.2 ex2",close(d(f,x),-2*x*f(x),1e-5))
chk("7.2 ex2 ic",f(0)==4)
for c,ok_ in ((lambda x:x**3,1),(lambda x:3*x,0),(lambda x:x**3+5,0),(lambda x:-2*x**3,1)):
    x=1.7; chk("7.2 ex3",close(x*d(c,x),3*c(x),1e-4)==bool(ok_))
chk("7.2 ex4",all(close(k*k-k-6,0) for k in (3,-2)))
f=lambda x:np.exp(3*x)+x
for x in (-1,0,.5): chk("7.2 c1",close(d(f,x),3*f(x)-3*x+1,1e-3))
chk("7.2 c2",all(close(k*k-5*k+6,0) for k in (2,3)))
f=lambda x:1/(1-x)
for x in (-1,0,.5): chk("7.2 c3",close(d(f,x),f(x)**2,1e-4))
chk("7.2 c3 ic",f(0)==1)
# 7.1 check
chk("7.1 c2",close(4*0.3,1.2) and close(4/200,1/50))

# ---------- 7.3 ----------
tab=[[x-y for x in range(-2,3)] for y in (2,1,0,-1,-2)]
chk("7.3 table",tab[0]==[-4,-3,-2,-1,0] and tab[4]==[0,1,2,3,4])
sol=lambda x:x-1+2*np.exp(-x)
for x in (-1,0,1,2.5): chk("7.3 sol",close(d(sol,x),x-sol(x),1e-5))
chk("7.3 sol ic",close(sol(0),1)); xs=np.linspace(-1,3,400001); xm=xs[np.argmin(sol(xs))]
chk("7.3 min at ln2",close(xm,np.log(2),1e-4)); chk("7.3 min on y=x",close(sol(np.log(2)),np.log(2)))
chk("7.3 slopes",(1-3==-2) and (2-2==0) and (0+1==1))
g=lambda x:np.exp(x*x/2)
for x in (-1,0.4,1.5): chk("7.3 xy sol",close(d(g,x),x*g(x),1e-4))
chk("7.3 xy slopes",2*2==4 and 1*1==1)
h=lambda x:-2*np.tanh(x/2)
for x in (-2,0,1,2.5): chk("7.3 auto sol",close(d(h,x),(h(x)**2-4)/4,1e-5))
chk("7.3 auto table",[(y*y-4)/4 for y in range(-3,4)]==[1.25,0,-.75,-1,-.75,0,1.25])
chk("7.3 c1",[0+0,1-1,-2+1,2+3]==[0,0,-1,5])

# ---------- 7.4 ----------
chk("7.4 III slope 8",3*3-1==8)
for x in (-1,0.5,2): 
    f=lambda x:2-3*np.exp(-x); chk("7.4 ex2",close(d(f,x),2-f(x),1e-5)); chk("7.4 ex2 conc",d2(f,x)<0 and close(d2(f,x),f(x)-2,1e-3))
    f=lambda x:2+2*np.exp(-x); chk("7.4 teal",close(d(f,x),2-f(x),1e-5))
f=lambda x:2*np.exp(x)-x-1
for x in (-1,0,1): chk("7.4 ex3 sol",close(d(f,x),x+f(x),1e-4)); chk("7.4 ex3 y''",close(d2(f,x),1+x+f(x),1e-3))
chk("7.4 ex3 (0,1)",close(f(0),1) and close(1+0+1,2))
xs=np.linspace(-3,1.3,860001); xm=xs[np.argmin(f(xs))]
chk("7.4 min x=-ln2",close(xm,-np.log(2),1e-4)); chk("7.4 min val ln2",close(f(-np.log(2)),np.log(2)))
chk("7.4 c2",(1-1==0) and 1-(1-1)>0)
chk("7.4 c3",2-5<0)

# ---------- 7.6 ----------
for A in (-1,0.3,2):
    f=lambda x:A*np.exp(x*x/2)
    for x in (-1,0.7): chk("7.6 ex1",close(d(f,x),x*f(x),1e-4))
f=lambda x:np.cbrt(1.5*x*x+2.0)
for x in (-1,0.5,2): chk("7.6 ex2",close(d(f,x),x/f(x)**2,1e-4))
f=lambda x:3.2*x*x
for x in (0.5,2): chk("7.6 ex3",close(d(f,x),2*f(x)/x,1e-4))
f=lambda x:2.5*np.exp(x**3)
for x in (-.5,.8): chk("7.6 c1",close(d(f,x),3*x*x*f(x),1e-4))
f=lambda x:np.cbrt(3*np.exp(x)+4)
for x in (-1,0.5): chk("7.6 c2",close(d(f,x),np.exp(x)/f(x)**2,1e-5))
f=lambda x:1.7*x-1
for x in (.5,2): chk("7.6 c3",close(d(f,x),(f(x)+1)/x,1e-5))

# ---------- 7.7 ----------
f=lambda x:-np.sqrt(4*x*x+5)
for x in (-1,1,2): chk("7.7 ex1",close(d(f,x),4*x/f(x),1e-5))
chk("7.7 ex1 ic",close(f(1),-3))
f=lambda x:1/(1-x)
chk("7.7 ex2 numeric",close(ode(lambda x,y:y*y,0,1,0.8),f(0.8),1e-6))
f=lambda x:2*np.exp(np.sin(x))
for x in (0,1,2): chk("7.7 ex3",close(d(f,x),f(x)*np.cos(x),1e-5))
chk("7.7 ex3 val",close(f(np.pi/2),2*np.e))
f=lambda x:np.sqrt(4-x*x)
for x in (-1.5,0,1): chk("7.7 c1",close(d(f,x),-x/f(x),1e-5))
chk("7.7 c1 ic",f(0)==2)
f=lambda x:1/(2-np.exp(x))
chk("7.7 c2",all(close(d(f,x),np.exp(x)*f(x)**2,1e-4) for x in (-1,0,.5)) and close(f(0),1))
chk("7.7 c2 num",close(ode(lambda x,y:np.exp(x)*y*y,0,1,0.6),f(0.6),1e-6))
f=lambda x:5*np.exp(3*(x-1)); chk("7.7 c3",close(d(f,0.4),3*f(.4),1e-4) and close(f(1),5))

# ---------- 7.8 ----------
k=np.log(4)/3; B=lambda t:500*np.exp(k*t)
chk("7.8 ex1 k",close(k,0.462,5e-4)); chk("7.8 B3",close(B(3),2000))
t10=3*np.log(20)/np.log(4); chk("7.8 t",close(t10,6.483,5e-4) and close(B(t10),10000,1e-6))
chk("7.8 rate",close(k*B(3),924.2,0.06))
chk("7.8 B ode",close(ode(lambda t,y:k*y,0,500,3),2000,1e-5))
kc=-np.log(2)/5730; chk("7.8 kc",close(kc,-1.210e-4,5e-8))
chk("7.8 frac",close(np.exp(kc*2000),0.785,5e-4))
tc=np.log(0.3)/kc; chk("7.8 age",close(tc,9953,0.6))
T=lambda t:20+70*np.exp(-0.1*t)
chk("7.8 cool",close(d(T,3),-0.1*(T(3)-20),1e-5)); t=10*np.log(7/3); chk("7.8 cool t",close(t,8.473,5e-4) and close(T(t),50))
A=lambda t:80*(1-np.exp(-t/40)); chk("7.8 tank",close(d(A,5),2-A(5)/40,1e-5) and close(A(40),50.57,5e-3))
chk("7.8 c1",close(250*np.exp(0.3),337.465,5e-4))
chk("7.8 c2",close(12*np.log(8)/np.log(2),36))
chk("7.8 c3",close(10+20*np.exp(-1),17.358,5e-4) and close(ode(lambda t,T:-0.2*(T-10),0,30,5),10+20*np.exp(-1),1e-6))

# ---------- Practice ----------
keys={}; opts={}
def mcq(n,key,vals,truth,tol=5e-4):
    L="ABCD"; chk(f"Q{n} distinct",len(set(np.round(vals,6)))==4)
    chk(f"Q{n} key",close(vals[L.index(key)],truth,tol),f"{vals} {truth}"); keys[n]=key
keys[1]="C"  # item 1: k*sqrt(P) is the only option of that form
# A3
mcq(3,'A',[-5,-7,7,11],(-1)**2-2*3)
# A5: y''=y'-1 at (1,3)
mcq(5,'C',[2,3,1,-1],(3-1)-1)
# A7: numeric
f=lambda x:-np.sqrt(4*x*x+5); chk("A7",close(f(1),-3) and close(d(f,2),4*2/f(2),1e-5)); keys[7]='D'
# distractor checks: others fail
chk("A7 wrong",not close(np.sqrt(4+9),3) and not close(np.sqrt(2+7),-3) and close(np.sqrt(4+9),np.sqrt(13)))
chk("A7 B/C ic",abs(-np.sqrt(4+9))!=3 and abs(-np.sqrt(2+7))==3 and not close(d(lambda x:-np.sqrt(2*x*x+7),1,),4*1/-3,1e-3))
# A8
mcq(8,'B',[6*np.exp(2),6*np.exp(1),12,6+np.e],ode(lambda t,y:0.5*y,0,6,2),1e-5)
# A2
f=lambda x:x+1+2*np.exp(x)
chk("A2",close(d(f,0.7),f(0.7)-0.7,1e-5) and close(f(0),3)); keys[2]='B'
for g in (lambda x:np.exp(x)+2,lambda x:x+3*np.exp(x),lambda x:3*np.exp(x)):
    chk("A2 wrong",close(g(0),3) and not close(d(g,0.7),g(0.7)-0.7,1e-3))
# A4 field
chk("A4",(0-1==-1) and (0+1!=-1) and (1-0!=-1) and (0*1!=-1)); keys[4]='D'
# A6
f=lambda x:2.1*np.exp(x**3/3); chk("A6",close(d(f,.8),.64*f(.8),1e-5)); keys[6]='A'
chk("A6 wrong",not close(d(lambda x:2.1*np.exp(x**3),.8),.64*2.1*np.exp(.512),1e-3)); keys[6]='A'
# A9
rhs=lambda x,y:(y*y-4)/4
chk("A9 limit",close(ode(rhs,0,1,40),-2,1e-6)); chk("A9 sign",rhs(0,1)<0 and rhs(0,0)<0 and rhs(0,-1)<0 and rhs(0,-2)==0 and rhs(0,2)==0); keys[9]='A'
# A10
f=lambda x:np.exp(x*x/2); chk("A10",close(d2(f,0),1,1e-3) and close(d(f,0),0,1e-6)); keys[10]='B'
xx=ode(lambda x,y:x*y,0,1,0.0001); chk("A10 min",f(0.1)>f(0)<f(-0.1))
# A11
f=lambda t:10+20*np.exp(-t/2); chk("A11",close(f(2),10+20/np.e) and close(d(f,1),-0.5*(f(1)-10),1e-5)); keys[11]='C'
chk("A11 wrong",not close(30/np.e,10+20/np.e) and not close(20/np.e,10+20/np.e) and not close(10+20*np.exp(-.5),10+20/np.e))
# A12
chk("A12",close(ode(lambda t,A:3-A/50,0,0,2000),150,1e-6)); keys[12]='D'
# A13
y=ode(lambda x,y:y*y*np.cos(x),0,1,np.pi/6); chk("A13",close(y,2,1e-6)); keys[13]='C'
chk("A13 wrong",close(1/(np.sin(np.pi/6)+1),2/3) and close(np.exp(.5),np.sqrt(np.e)) and close(-1/(0.5+1),-2/3))
# A14
chk("A14",close(9-3-6,0) and 9+3-6!=0 and 9-3+6!=0 and 9-6!=0); keys[14]='B'
# A15
f=lambda x:1.3*np.exp(-1/x)
chk("A15",close(d(f,1.4),f(1.4)/1.4**2,1e-5)); chk("A15 wrong",not close(d(lambda x:np.exp(1/x),1.4),np.exp(1/1.4)/1.4**2,1e-3)); keys[15]='A'
# B16
t=np.log(30/75)/-0.08; chk("B16 t",close(t,11.454,5e-4))
chk("B16 alt",close(np.log(50/95)/-0.08,8.023,5e-4) and close(np.log(50/75)/-0.08,5.068,5e-4) and close(0.4/0.08,5.0))
chk("B16 num",close(ode(lambda t,T:-0.08*(T-20),0,95,t),50,1e-6)); keys[16]='A'
# B17
chk("B17",close(8*np.log(5)/np.log(2),18.575,5e-4) and close(8*np.log(5),12.876,5e-4) and close(np.log(5)/np.log(2),2.322,5e-4)); keys[17]='B'
# B18
y=ode(lambda x,y:x*np.exp(-y),0,0,2); chk("B18",close(y,np.log(3),1e-6) and close(np.log(3),1.099,5e-4)); keys[18]='D'
chk("B18 alt",close(np.log(2),0.693,5e-4) and close(np.log(5),1.609,5e-4)); 
# B19
Q=lambda t:50*(1-np.exp(-0.1*t)); chk("B19",close(Q(8),27.534,5e-4) and close(50*np.exp(-.8),22.466,5e-4) and close(ode(lambda t,q:5-0.1*q,0,0,8),Q(8),1e-6)); keys[19]='C'
# B20
y=ode(lambda x,y:1+y*y,0,0,1); chk("B20",close(y,np.tan(1)) and close(y,1.557,5e-4))
chk("B20 alt",close(np.arctan(1),0.785,5e-4)); r=brentq(lambda y:y+y**3/3-1,0,1); chk("B20 cubic",close(r,0.818,5e-4)); keys[20]='D'
# B21
P=lambda t:250*np.exp(0.03*t); chk("B21",close(0.03*P(10),10.124,5e-4) and close(P(10),337.465,5e-4) and close(0.03*250,7.5)); keys[21]='B'
# B22
kk=np.log(0.5)/5; chk("B22",close(kk,-0.139,5e-4) and close(np.log(50/80)/5,-0.094,5e-4) and close((50-80)/5/60,-0.1)); keys[22]='D'
chk("B22 num",close(20+60*np.exp(5*kk),50))
# FRQ 23
chk("F23a",close(-(90-22)/5,-13.6) and close(90-13.6,76.4))
T=lambda t:22+68*np.exp(-t/5)
chk("F23 sol",close(T(0),90) and all(close(d(T,t),-(T(t)-22)/5,1e-5) for t in (0,1,3)))
chk("F23b",all(close(d2(T,t),(T(t)-22)/25,1e-4) for t in (0,1,2)) and T(1)>76.4 and close(T(1),77.674,5e-4))
chk("F23d",close(5*np.log(68/18),6.646,5e-4) and close(T(5*np.log(68/18)),40))
# FRQ 24
chk("F24a",[ (x*(y-1)) for x in (-1,0,1) for y in (0,1,2)]==[1,0,-1,0,0,0,-1,0,1])
f=lambda x:1+2*np.exp(x*x/2)
chk("F24c",close(f(0),3) and all(close(d(f,x),x*(f(x)-1),1e-4) for x in (-1,0.5,2)))
chk("F24b",all(close(d2(f,x),(1+x*x)*(f(x)-1),1e-3) for x in (-1,0,.7)) and close(d2(f,0),2,1e-3) and close(d(f,0),0,1e-6))
chk("F24d",f(10)>1e20)
# balance
from collections import Counter
c=Counter(keys.values()); print(sorted(keys.items())); print(c)
chk("keys complete",set(keys)==set(range(1,23)),sorted(set(range(1,23))-set(keys)))
chk("balance",max(c.values())-min(c.values())<=2)
print("ALL OK",ok,"checks")
