import re, math, numpy as np
from scipy.integrate import quad
ok=0
def chk(name,a,b,tol=1e-6):
    global ok
    assert abs(a-b)<=tol*max(1,abs(b)),(name,a,b); ok+=1
Q=lambda f,a,b:quad(f,a,b,limit=200)[0]
def pl(pts):  # piecewise linear function
    xs,ys=zip(*pts); return lambda x:float(np.interp(x,xs,ys))
# ---- 6.1
R=pl([(0,0),(4,6),(8,6),(10,0)]); chk('6.1 ex1',Q(R,0,10,),42); 
v=lambda t:4-1.5*t
chk('6.1 net',Q(v,0,4),4); chk('6.1 dist',Q(lambda t:abs(v(t)),0,4,),20/3,1e-5) if False else None
chk('6.1 dist',Q(lambda t:abs(v(t)),0,4)-0,20/3,1e-5)
chk('6.1 chk1',Q(lambda t:2*t,0,5),25)
v2=lambda t:3-t; chk('6.1 chk2n',Q(v2,0,5),2.5); chk('6.1 chk2d',Q(lambda t:abs(v2(t)),0,5),6.5,1e-5)
# ---- 6.2
f=lambda x:1+x*x/4
L=sum(f(i) for i in range(4)); Rr=sum(f(i) for i in range(1,5)); M=sum(f(i+.5) for i in range(4)); T=(L+Rr)/2
chk('L4',L,7.5);chk('R4',Rr,11.5);chk('M4',M,9.25);chk('T4',T,9.5);chk('I',Q(f,0,4),28/3)
assert L<28/3<Rr and M<28/3<T; 
tt=[0,2,5,9,10]; rr=[3,5,8,6,4]; w=np.diff(tt)
Lt=sum(rr[i]*w[i] for i in range(4)); Rt=sum(rr[i+1]*w[i] for i in range(4)); Tt=sum((rr[i]+rr[i+1])/2*w[i] for i in range(4))
chk('tabL',Lt,59);chk('tabR',Rt,62);chk('tabT',Tt,60.5)
# ex3 ordering with f=4/x on [1,5]
g=lambda x:4/x; xs=np.linspace(1,5,5); h=1.0
L4=sum(g(x) for x in xs[:-1]);R4=sum(g(x) for x in xs[1:]);T4=(L4+R4)/2;M4=sum(g(x+.5) for x in xs[:-1]);I=Q(g,1,5)
assert L4>T4>I>R4 and M4<I; ok+=1
assert R4<I<T4<L4; ok+=1
sq=math.sqrt
chk('c1L',sum(sq(i) for i in range(4)),4.146,1e-3);chk('c1R',sum(sq(i) for i in range(1,5)),6.146,1e-3);chk('c1I',Q(sq,0,4),16/3)
chk('c2',2*(2+5)/2+1*(5+6)/2+4*(6+3)/2,30.5)
# ---- 6.3
f3=lambda x:1+x*(4-x)/2
chk('R4 f3',sum(f3(i) for i in range(1,5)),9); chk('R12',sum(f3(i/3) for i in range(1,13))/3,9.296,1e-4); chk('I3',Q(f3,0,4),28/3)
n=200000;chk('lim ex1',sum((2+3*i/n)**2*3/n for i in range(1,n+1)),39,1e-4); chk('ex1',Q(lambda x:x*x,2,5),39)
chk('ex2 R4',0.5*sum(math.log(1+i/2) for i in range(1,5)),1.557,1e-3); chk('ex2 I',Q(math.log,1,3),3*math.log(3)-2)
chk('semi',Q(lambda x:sq(9-x*x),-3,3),9*math.pi/2); chk('V',Q(lambda x:abs(x-3),0,6),9)
chk('c1 lim',sum(sq(i/n)/n for i in range(1,n+1)),2/3,1e-4); chk('c2',Q(lambda x:sq(4-x*x),-2,2),2*math.pi)
chk('c3',0.5*sum(math.exp(i/2) for i in range(1,5)),8.119,1e-3)
# ---- 6.4 figure
F=pl([(0,1),(2,3),(4,0),(6,-2),(8,-2)])
G=lambda x:Q(F,0,x)
for x,val in [(2,4),(4,7),(6,5),(8,1)]: chk('g%d'%x,G(x),val,1e-6)
def gform(x):
    if x<=2:return x+x*x/2
    if x<=4:return 4+3*(x-2)-.75*(x-2)**2
    if x<=6:return 7-(x-4)**2/2
    return 5-2*(x-6)
for x in np.linspace(0,8,41): chk('gform',gform(x),G(x),1e-6)
chk('f3',F(3),1.5); chk("f'(3)",(F(3.001)-F(2.999))/.002,-1.5)
chk("F'(1)",2*1*F(1),4); chk("F'(2)",2*2*F(4),0)
d=lambda fn,x,h=1e-4:(fn(x+h)-fn(x-h))/(2*h)
gg=lambda x:Q(lambda t:math.sqrt(t*t+3),1,x); chk('4a',d(gg,1.7),math.sqrt(1.7**2+3),1e-6)
hh=lambda x:Q(lambda t:1/(t*t+1),2,3*x); chk('4b',d(hh,.8),3/(9*.64+1),1e-6)
kk=lambda x:Q(lambda t:math.exp(t*t),x,2.5); chk('4c',d(kk,1.2,1e-4),-math.exp(1.44),1e-5)
mm=lambda x:Q(math.cos,0,x*x); chk('4d',d(mm,.9),2*.9*math.cos(.81),1e-6)
chk('c4-1',d(lambda x:Q(lambda t:math.log(t*t+1),1,x),2),math.log(5),1e-6)
cc=lambda x:Q(lambda t:math.sin(t*t),0,x**3); chk('c4-2',d(cc,.9),3*.81*math.sin(.9**6),1e-5)
chk('c4-3',F(6),-2)
# ---- 6.5: g on [0,8]
xs=np.linspace(0,8,8001);gv=np.array([gform(x) for x in xs])
assert abs(gv.max()-7)<1e-9 and abs(xs[gv.argmax()]-4)<1e-9 and gv.min()==0 and xs[gv.argmin()]==0; ok+=1
semi=lambda x:math.sqrt(max(0,4-(x-2)**2)) if x<=4 else (-(x-4) if x<=6 else -(8-x)) 
f65=lambda x:(math.sqrt(max(0,4-(x-2)**2)) if x<=4 else (-(x-4) if x<=6 else (x-8)))
chk('g65(4)',Q(f65,0,4),2*math.pi,1e-6); chk('g65(8)',Q(f65,0,8),2*math.pi-4,1e-6)
fc=lambda t:t*t-4
G1=lambda x:Q(fc,1,x); chk('c5-1 g crit',d(G1,2),0,1e-6); assert G1(2)<G1(1.9) and G1(2)<G1(2.1); ok+=1
chk('c5 g(2)',G1(2),-5/3)
# ---- 6.6
chk('6.6a',5-2,3)
f66=lambda x:(math.sqrt(max(0,4-x*x)) if x<=2 else (-1.5*(x-2) if x<=4 else -3))
chk('66 a',Q(f66,-2,6,),2*math.pi-9,1e-6); chk('66 b',Q(lambda x:abs(f66(x)),-2,6),2*math.pi+9,1e-6)
chk('66 c',Q(lambda x:f66(x)+2,-2,6),2*math.pi+7,1e-6)
chk('66 sym',Q(lambda x:x**3+5,-2,2),20); chk('c6-2',Q(lambda x:x**3+sq(9-x*x),-3,3),9*math.pi/2)
chk('c6-3',Q(lambda x:x*x,0,1)-Q(lambda x:x**3,0,1),1/12)
# ---- 6.7
chk('67 1',Q(lambda x:3*sq(x)-2/x**2,1,4),12.5)
chk('67 2',Q(lambda x:3*math.cos(x)+2*math.sin(x),0,math.pi/2),5)
chk('67 3a',3+Q(lambda x:2*x-1/x,1,4),18-2*math.log(2)); chk('67 3b',50+Q(lambda t:6*math.exp(-t/2),0,4),62-12*math.exp(-2))
chk('c7-1',Q(lambda x:x*x-2*x,-1,2),0,1e-6); chk('c7-2',Q(lambda x:1/math.cos(x)**2,0,math.pi/3),sq(3)); chk('c7-3',10+Q(lambda t:3*t*t,1,3),36)
# ---- 6.8
chk('68 a',Q(lambda x:(x*x+3)/sq(x),1,2),(0.4*2**2.5+6*sq(2))-(0.4+6))
Fa=lambda x:x**3/3-x-4; chk('68 F(3)',Fa(3),2); chk("68 F'",d(Fa,1.3),1.3**2-1,1e-6)
f2=lambda x:2*x**3-x+3; chk('68 f(1)',f2(1),4); chk("68 f'(0)",d(f2,0),-1,1e-6); chk("68 f''",d(lambda x:d(f2,x,1e-4),.7,1e-3),12*.7,1e-4)
f3c=lambda x:x**3+2*x-1; chk('c8-3',f3c(0),-1); chk('c8-3d',d(f3c,0),2,1e-6)
chk('c8-1',d(lambda x:x**4+2/x+3*math.sin(x),1.3),4*1.3**3-2/1.3**2+3*math.cos(1.3),1e-6)
chk('c8-2',d(lambda x:x*x/2+2*x+math.log(x),1.3),(1.3+1)**2/1.3,1e-6)
# ---- 6.9
chk('69 2',Q(lambda x:x*sq(1+3*x*x),0,1),7/9); chk('69 3',Q(math.tan,0,math.pi/4),.5*math.log(2))
chk('69 1',d(lambda x:.6*(x*x+1)**5,.8),6*.8*(.64+1)**4,1e-6)
chk('c9-1',d(lambda x:math.sin(x**3)/3,.8),.64*math.cos(.512),1e-6); chk('c9-2',Q(lambda x:math.log(x)**2/x,1,math.e),1/3); chk('c9-3',Q(lambda x:2*x/(x*x+4),0,2),math.log(2))
# ---- 6.10
chk('610 1',Q(lambda x:(x*x+3*x+5)/(x+1),0,1),2.5+3*math.log(2))
chk('610 a',d(lambda x:math.atan((x+2)/3)/3,.7),1/(.7**2+4*.7+13),1e-6); chk('610 b',d(lambda x:math.asin((x-3)/2),2.3),1/sq(-2.3**2+6*2.3-5),1e-6)
chk('c10-1',d(lambda x:x+7*math.log(abs(x-2)),3.1),(3.1+5)/(3.1-2),1e-6); chk('c10-2',d(lambda x:math.atan(x-3),3.4),1/(3.4**2-6*3.4+10),1e-6)
# ---- 6.14
chk('614 ex2',Q(lambda x:math.exp(x)*sq(1+math.exp(x)),0,math.log(2)),2/3*(3*sq(3)-2*sq(2))); chk('614 val',2/3*(3*sq(3)-2*sq(2)),1.578,1e-3)
for nm,fn,F in [('a',lambda x:(x**3-1)/x**2,lambda x:x*x/2+1/x),('b',lambda x:x/(x*x+1),lambda x:.5*math.log(x*x+1)),('c',lambda x:math.cos(x)*math.exp(math.sin(x)),lambda x:math.exp(math.sin(x))),
  ('d',lambda x:(x+5)/(x-2),lambda x:x+7*math.log(abs(x-2))),('e',lambda x:1/(x*x-6*x+10),lambda x:math.atan(x-3)),('f',lambda x:3/sq(1-x*x),lambda x:3*math.asin(x))]:
    chk('614'+nm,d(F,.45 if nm in 'ef' and nm=='f' else 3.3),fn(.45 if nm=='f' else 3.3),1e-5)
chk('c14a',d(lambda x:math.log(1+math.exp(x)),.4),math.exp(.4)/(1+math.exp(.4)),1e-6)
chk('c14b',d(lambda x:x**5/5+4*x**3/3+4*x,.9),(.81+2)**2,1e-6)
chk('c14c',d(lambda x:.5*math.atan((x+2)/2),.9),1/(.81+3.6+8),1e-6)
chk('c14 xe',d(lambda x:.5*math.exp(x*x),.7),.7*math.exp(.49),1e-6)

# ================= UNIT PRACTICE =================
items={}  # n: (options list of values, key index, computed value)
def reg(n,opts,key,computed,tol=1e-3):
    assert len(set(round(o,6) for o in opts))==4,('distinct',n,opts)
    assert abs(opts[key]-computed)<=tol*max(1,abs(computed)),(n,opts[key],computed)
    items[n]='ABCD'[key]
reg(1,[8,10,12,7],1,Q(lambda x:2*x+1,1,3))
Gp=lambda x:Q(lambda t:sq(t+5),0,x*x)
reg(2,[3,6,4*sq(7),12],3,d(Gp,2,1e-4),1e-6)
tt=[0,2,5,6]; ff=[4,7,9,11]; w=np.diff(tt)
T3=sum((ff[i]+ff[i+1])/2*w[i] for i in range(3)); Lf=sum(ff[i]*w[i] for i in range(3)); Rf=sum(ff[i+1]*w[i] for i in range(3))
chk('item3 L',Lf,38);chk('item3 R',Rf,52);chk('3 nohalf',2*T3,90)
reg(3,[45,38,52,90],0,T3)
# 4
fp=lambda x:2*x**3-2*x**2+2; chk('4 f(1)',fp(1),2); chk("4 f'",d(fp,1.1),6*1.1**2-4*1.1,1e-6)
reg(4,[8,4,10,16],2,fp(2)); chk('4B',(2*8-4*4)+4,4); chk('4D',6*4-8,16)
# 5
reg(5,[14/3,14/9,1/9,7/9],3,Q(lambda x:x*sq(1+3*x*x),0,1),1e-6)
chk('5C',(1/6)*(2/3),1/9)
# 6
reg(6,[20,16,8,32],0,2*4+12); chk('6D',2*(4+12),32)
# 7
f7=pl([(0,3),(2,0),(4,-2),(6,-2),(8,2)])
xs=np.linspace(0,8,80001); fx=np.array([f7(x) for x in xs]); dfx=np.gradient(fx,xs)
mask=(fx>1e-9)&(dfx>1e-6); xi=xs[mask]; assert abs(xi.min()-7)<1e-3 and abs(xi.max()-8)<1e-3; ok+=1
# options intervals: (0,2): f>0 and f'<0 ; (2,4) f<0,f'<0 ; (6,7) f<0,f'>0
for a,b,eg in [(0,2,(1,-1)),(2,4,(-1,-1)),(6,7,(-1,1))]:
    sel=(xs>a+.01)&(xs<b-.01); assert np.all(np.sign(fx[sel])==eg[0]) and np.all(np.sign(dfx[sel])==eg[1]),(a,b)
items[7]='C'
# 8
v8=lambda t:3*t*t-12*t+9
dist=Q(lambda t:abs(v8(t)),0,4,); chk('8 dist',dist,12,1e-5)
s=lambda t:t**3-6*t*t+9*t; chk('s3',s(3),0); chk('s4',s(4),4)
reg(8,[4,12,8,0],1,dist,1e-5)
# 9
n=400000; Sm=sum((1+3*k/n)**2*3/n for k in range(1,n+1)); reg(9,[9,63,64/3,21],3,Sm,1e-4)
chk('9A',Q(lambda x:x*x,0,3),9);chk('9C',Q(lambda x:x*x,0,4),64/3)
# 10
reg(10,[0,0,0,0],0,0) if False else None
chk('10',d(lambda x:.5*math.exp(x*x),.6),.6*math.exp(.36),1e-6); items[10]='A'
# 11
for ordr in ['R<I<T<L']: pass
assert R4<I<T4<L4 and not (R4<T4<I<L4) and not (L4<I<T4<R4) and not (I<R4<T4<L4); items[11]='C'; ok+=1
# also increasing-concave-up for option B: check
gi=lambda x:x*x; xs5=np.linspace(1,5,5); Li=sum(gi(x) for x in xs5[:-1]);Ri=sum(gi(x) for x in xs5[1:]);Ti=(Li+Ri)/2;Ii=Q(gi,1,5); assert Li<Ii<Ti<Ri; ok+=1
# 12
g12=lambda x:Q(lambda t:t*t-4*t,0,x); xs=np.linspace(-.99,5.99,70001)
gv=np.array([g12(x) for x in xs[::100]]); xx=xs[::100]
loc=[xx[i] for i in range(1,len(xx)-1) if gv[i]<gv[i-1] and gv[i]<gv[i+1]]; assert len(loc)==1 and abs(loc[0]-4)<0.02,loc; ok+=1
chk('12D',g12(6),0,1e-9); items[12]='B'
# 13
reg(13,[math.log(2),math.log(4),.25,math.log(3)],0,Q(lambda x:math.exp(x)/(1+math.exp(x)),0,math.log(3)),1e-6)
chk('13C',3/4-1/2,.25)
# 14
f14=lambda u:u**0  # placeholder shape: check with sample f whose integral 1..5 is 12 : f(u)=3
reg(14,[12,24,4,6],3,Q(lambda x:3.0,0,2)*1,1e-9)  # f=3 => int_1^5 f = 12, int_0^2 f(2x+1)=6
f14b=lambda u:u*u*12/ (Q(lambda z:z*z,1,5)); chk('14b',Q(lambda x:f14b(2*x+1),0,2),6,1e-6)
# ---- Part B
reg(15,[math.exp(-4),1-math.exp(-2),Q(lambda x:math.exp(-x*x),0,2),2*Q(lambda x:math.exp(-x*x),0,2)],2,Q(lambda x:math.exp(-x*x),0,2),1e-3)
reg(15,[0.018,0.865,0.882,1.764],2,Q(lambda x:math.exp(-x*x),0,2),1e-3); chk('15A',math.exp(-4),0.018,5e-2);chk('15B',1-math.exp(-2),.865,1e-3)
tt=[0,3,5,8,12];rr=[10.2,14.6,13.1,9.4,6.3];w=np.diff(tt)
T16=sum((rr[i]+rr[i+1])/2*w[i] for i in range(4));L16=sum(rr[i]*w[i] for i in range(4));R16=sum(rr[i+1]*w[i] for i in range(4))
reg(16,[130.05,136.7,123.4,260.1],0,T16,1e-9); chk('16B',L16,136.7);chk('16C',R16,123.4);chk('16D',2*T16,260.1)
V1=lambda t:math.exp(-.2*t)-.4; tt_=np.linspace(0,10,100001); Vv=np.cumsum([V1(t) for t in tt_])*1e-4; assert abs(tt_[Vv.argmax()]-4.581)<1e-3; ok+=1
reg(17,[0.916,2.291,3.0,4.581],3,5*math.log(2.5),1e-3); chk('17A',math.log(2.5),.916,1e-3);chk('17B',math.log(2.5)/.4,2.291,1e-3)
f18=lambda x:sq(x**3+1); M3=sum(f18(x) for x in [.5,1.5,2.5]); L3=sum(f18(x) for x in [0,1,2]);R3=sum(f18(x) for x in [1,2,3])
reg(18,[5.414,7.230,9.706,7.560],1,M3); chk('18A',L3,5.414,1e-3);chk('18C',R3,9.706,1e-3);chk('18D',(L3+R3)/2,7.560,1e-3)
I19=Q(lambda x:math.exp(math.sin(x)),0,2)
reg(19,[4.237,2.483,9.237,7.483],2,5+I19); chk('19A',I19,4.237,1e-3);chk('19B',math.exp(math.sin(2)),2.483,1e-3);chk('19D',5+math.exp(math.sin(2)),7.483,1e-3)
H=lambda x:Q(lambda t:math.exp(-t*t),0,x*x); Hp=d(H,1.2,1e-4)
reg(20,[.302,.126,.569,.251],0,Hp,2e-3); chk('20B',math.exp(-1.2**4),.126,3e-3);chk('20C',2.4*math.exp(-1.44),.569,2e-3);chk('20D',2*math.exp(-1.2**4),.251,2e-3)
V21=40+Q(lambda t:8+3*math.sin(.5*t),0,8)
reg(21,[73.92,45.73,104.01,113.92],3,V21,1e-4); chk('21A',V21-40,73.92,1e-4);chk('21B',40+8+3*math.sin(4),45.73,1e-4)
deg=40+64+6*(1-math.cos(math.radians(4))); chk('21C',deg,104.01,1e-4)
# ---- FRQ 22
E=lambda t:4+3*math.sin(t/2); tl=[0,2,5,7,8]; Ll=[3.0,5.0,6.4,5.6,4.8]; w=np.diff(tl)
Ta=sum((Ll[i]+Ll[i+1])/2*w[i] for i in range(4)); chk('22a',Ta,42.3)
IE=Q(E,0,8); chk('22b IE',IE,41.922,1e-4); chk('22b',25+IE-Ta,24.622,1e-4)
chk('22c',E(5)-6.4,-.605,2e-3); chk('22d2',E(2)-5.0,1.524,1e-3)
# ---- FRQ 23
f23=lambda x:(x+... if False else 0)
def f23(x):
    if x<=-2: return x+2 if False else (x+2)  # slope 1 from (-4,-2) to (-2,0)
    if x<=2: return sq(max(0,4-x*x))
    if x<=4: return -(x-2)
    return -2+2*(x-4)
assert f23(-4)==-2 and f23(-2)==0 and f23(4)==-2 and f23(6)==2
g23=lambda x:Q(f23,0,x,)
chk('23a1',g23(-2),-math.pi,1e-6); chk('23a2',g23(4),math.pi-2,1e-6)
chk('23b',f23(4),-2)
# inflection: sign changes of f'
xs=np.linspace(-3.999,5.999,100001); fx=np.array([f23(x) for x in xs]); dfx=np.gradient(fx,xs)
sg=np.sign(dfx); ch=xs[1:][np.where(sg[1:]*sg[:-1]<0)[0]]
ch=[c for c in ch if True]; print('f\' sign changes at',ch)
assert len(ch)==2 and abs(ch[0]-0)<2e-3 and abs(ch[1]-4)<2e-3; ok+=1
# critical points and abs min
zs=xs[1:][np.where(fx[1:]*fx[:-1]<0)[0]]; print('zeros of f',zs); assert np.allclose(zs,[-2,2,5],atol=2e-3) or len(zs)==3; ok+=1
cand={x:g23(x) for x in [-4,-2,2,5,6]}
chk('23 g(-4)',cand[-4],2-math.pi,1e-6);chk('g(2)',cand[2],math.pi,1e-6);chk('g(5)',cand[5],math.pi-3,1e-6);chk('g(6)',cand[6],math.pi-2,1e-6)
gr=np.array([g23(x) for x in np.linspace(-4,6,2001)]); chk('23d',gr.min(),-math.pi,1e-5)
items[22]=items[23]=None
# ---- letter balance and compare with solutions file
sol=open('units/u6_sol.tex').read()
found=dict((int(a),b) for a,b in re.findall(r"\\textbf\{Item (\d+)\.\}\s*\\ans\{\(([A-D])\)\}",sol))
exp={k:v for k,v in items.items() if v}
assert found==exp,(found,exp); ok+=1
from collections import Counter
print('Part A letters',Counter(exp[k] for k in range(1,15)),'Part B',Counter(exp[k] for k in range(15,22)))
print('ALL OK, assertions:',ok)
