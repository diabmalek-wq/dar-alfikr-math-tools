import numpy as np
from scipy import optimize, integrate
ok = 0
def chk(name, got, want, tol=1e-6):
    global ok
    assert abs(got-want) <= tol*max(1,abs(want)), f"FAIL {name}: got {got}, want {want}"
    ok += 1
def chk3(name, got, want):
    global ok
    assert abs(got-want) <= 5.0e-4+1e-12, f'FAIL {name}: got {got}, want {want}'
    ok += 1
def D(f, x, h=1e-6): return (f(x+h)-f(x-h))/(2*h)
def D2(f, x, h=1e-4): return (f(x+h)-2*f(x)+f(x-h))/h**2

# ---------- 4.1
chk('4.1 ex2a', (64-78)/6, -7/3); chk('4.1 ex2b', (58-64)/5, -1.2); chk('4.1 ex2c', (58-90)/15, -32/15)
C = lambda x: 50+3*x+0.02*x**2
chk('C1', D(C,100), 7, 1e-6); chk('C101-C100', C(101)-C(100), 7.02)
chk('F6', 84-3.2, 80.8)
chk('chk1.2', (170-55)/(3-1), 57.5)
P = lambda x: -0.5*x**2+40*x-150
chk('P1', D(P,20), 20, 1e-6); chk('P21-P20', P(21)-P(20), 19.5)
# ---------- 4.2
x = lambda t: t**3-6*t**2+9*t
v = lambda t: D(x,t); a = lambda t: D2(x,t)
chk('x1',x(1),4); chk('x3',x(3),0); chk('x4',x(4),4); chk('x0',x(0),0)
assert abs(v(1))<1e-5 and abs(v(3))<1e-5
ts = np.linspace(0,4,40001)
sp = np.sign(v(ts)*(6*ts-12))
# speed increasing on (1,2),(3,4)
for t0,inc in [(0.5,False),(1.5,True),(2.5,False),(3.5,True)]:
    assert (v(t0)*(6*t0-12)>0)==inc
ok+=4
chk('dist', abs(x(1)-x(0))+abs(x(3)-x(1))+abs(x(4)-x(3)), 12)
# Ex2 velocity graph
vv = lambda t: np.interp(t,[0,2,4,7,9],[0,4,4,-2,-2])
chk('v zero 6', optimize.brentq(lambda t: 12-2*t,4,7), 6)
# Ex3
v3 = lambda t: 4*t-t**2
chk('v3(3)',v3(3),3); chk('a3',D(v3,3),-2,1e-6); chk('v3(5)',v3(5),-5); chk('a3(5)',D(v3,5),-6,1e-6)
# check yourself 4.2
x1 = lambda t: t**2-6*t+5
chk('c1 v1',D(x1,1),-4,1e-6); chk('c1 a1',D2(x1,1),2,1e-3)
v2 = lambda t: t**3-3*t**2
for t0,inc in [(1,True),(2.5,False),(4,True)]:
    assert (v2(t0)*D(v2,t0)>0)==inc
ok+=3
x3 = lambda t: t**2-4*t
chk('disp',x3(5)-x3(0),5); chk('dist3',abs(x3(2)-x3(0))+abs(x3(5)-x3(2)),13)
# ---------- 4.3
chk('P10', D(lambda t:50000*np.exp(0.02*t),10), 1000*np.exp(0.2), 1e-6); chk3('P10v',1000*np.exp(.2),1221.403)
V = lambda t: 400*(1-t/20)**2
chk('V5',D(V,5),-30,1e-6); chk('V2',D2(V,5),2,1e-3); chk('V0',D(V,0),-40,1e-6); chk('V20',D(V,20),0,1e-5)
r = lambda t: (t-2)*(8-t)/2
tt=np.linspace(0,9,90001); assert abs(tt[np.argmax(r(tt))]-5)<1e-3; chk('rmax',r(5),4.5)
chk('r9',r(9),-3.5); chk('P2 9',D(r,9),-4,1e-6); chk('P2 5',D(r,5),0,1e-5)
assert r(1)<0 and r(9)<0 and r(3)>0; ok+=1
H = lambda t: 20+70*np.exp(-0.1*t)
for t0 in [0,3,10,30]: assert D(H,t0)<0 and D2(H,t0,1e-3)>0
ok+=1
R = lambda x: 60*x-0.1*x**2
chk('R100',D(R,100),40,1e-6); chk('R101-R100',R(101)-R(100),39.9); chk('R zero',optimize.brentq(lambda x:D(R,x),1,1000),300,1e-5)
# ---------- 4.4
chk('ripple',2*np.pi*10*3,60*np.pi); chk3('ripple v',60*np.pi,188.496)
chk('balloon',100/(4*np.pi*25),1/np.pi); chk3('bal v',1/np.pi,0.318)
chk('cone',10/(np.pi*16/4),5/(2*np.pi)); chk3('cone v',5/(2*np.pi),0.796)
chk('chk4.1',3*16*0.5,24); chk('chk4.3',8*np.pi*3*2,48*np.pi)
# ---------- 4.5
chk('ladder',-5/12*2,-5/6); chk('y',np.sqrt(169-25),12)
z=np.hypot(120,90); chk('z',z,150); chk('cars',(120*60+90*45)/z,75)
chk3('shadow',(9/16)*1.2,0.675); chk3('tip',(25/16)*1.2,1.875)
# solve similar triangles numerically
xs=3.2; s=optimize.brentq(lambda s: s/1.8-(xs+s)/5,0,10); chk('s=9/16x', s, 9/16*xs)
th = lambda h: np.arctan(h/40)
# d(theta)/dt with h = 30+3t
chk3('balloon angle',D(lambda t: th(30+3*t),0),0.048)
chk('c5.1',2*8*3,48); chk('c5.2',-12/(4*np.pi*4),-3/(4*np.pi)); chk('c5.2v',-3/(4*np.pi),-0.239,2e-3)
# ladder 10, y=8, y'=-1, x=6 : x x' + y y'=0
chk('c5.3', -(8*(-1))/6, 4/3)
# ---------- 4.6
f = np.sqrt
L = lambda x: 1+0.5*(x-1)
chk('L1.1',L(1.1),1.05); chk('L2',L(2),1.5)
assert L(1.1)>f(1.1) and L(2)>f(2); ok+=1
chk('err1.1', L(1.1)-f(1.1), 0.0012, 0.02); chk3('err2',L(2)-f(2),0.086)
chk('g3.4', 8-1.5*0.4, 7.4)
chk('dV', 400*np.pi*0.2, 80*np.pi); chk3('dVv',80*np.pi,251.327)
V10 = 4/3*np.pi*1000; chk3('V10',V10,4188.790); chk('rel', 80*np.pi/V10, 0.06, 1e-9)
chk('c6.1', 1+2*0.03, 1.06); assert 1.06 < np.exp(0.06); ok+=1
chk('c6.2', 10+0.4*(-0.5), 9.8)
f3=np.cbrt; chk('f3',D(f3,27),1/27,1e-6); assert 3+1/27 > f3(28); chk('c6.3',3+1/27,3.037037,1e-6)
# ---------- 4.7
def lim(f,a,side=(1,-1)):
    return [f(a+s*h) for s in side for h in (1e-4,)]
chk('4.7a', (3.0001**2-9)/(0.0001), 6, 1e-4)
chk('4.7b', np.sin(1e-5)/1e-5, 1, 1e-6)
chk('4.7c', (np.exp(3e-3)-1-3e-3)/1e-6, 4.5, 2e-3)
for xx in (50,100): assert xx**3/np.exp(xx)<1e-10
ok+=1
chk('lnx/sqrtx', np.log(1e12)/np.sqrt(1e12), 2.76e-5, 0.01)  # -> 0
assert np.exp(40)/(40**2+1)>1e12; ok+=1
# crossing e^x = x^3 
r1 = optimize.brentq(lambda x: np.exp(x)-x**3,1,3); r2 = optimize.brentq(lambda x: np.exp(x)-x**3,3,6)
chk3('cross1',r1,1.857); chk3('cross2',r2,4.536); chk('cross y',np.exp(r2),93.34,1e-3)
assert np.exp(1)<1 or True
chk('c7.1',(1-np.cos(1e-3))/1e-6,0.5,1e-4); chk('c7.2',(8.0001**0 and ((2+1e-5)**3-8)/((2+1e-5)**2-4)),3,1e-4)
chk('sx/x lim', np.sin(1e-4)/1e-4, 1, 1e-6)
chk('x^2+1', (1+1e-8)**2+1, 2, 1e-6)  # (x^2+1)/(x+1)->1, with x->1: 2/2
chk('x2+1 lim', ((1+1e-7)**2+1)/((1+1e-7)+1), 1, 1e-6)

# ================= PRACTICE
# A1,A2
chk('A2 ', (66-38)/(7-3), 7); chk('A2 d1',(74-20)/10,5.4); chk('A2 d2',28/10,2.8)
# A3
X3 = lambda t: t**3/3-2*t**2+3*t
for t0,left in [(0.5,False),(2,True),(4,False)]: assert (D(X3,t0)<0)==left
ok+=3
# A4
V4 = lambda t: t**2-6*t
chk('A4 v',V4(2),-8); chk('A4 a',D(V4,2),-2,1e-6)
# A5 graph
vg = lambda t: np.interp(t,[0,2,4,6],[2,-2,-2,2])
ag = lambda t: D(vg,t,1e-4)
for t0,inc in [(0.5,False),(1.5,True),(3,False),(4.5,False),(5.5,True)]:
    assert (vg(t0)*ag(t0)>1e-6)==inc, t0
    ok+=1
chk('A5 zero', optimize.brentq(vg,0,2), 1)
# A6 n/a ; A7
chk('A7',72*np.pi/(4*np.pi*9),2); chk('A7 d1',4*np.pi*9/(72*np.pi),0.5); chk('A7 d2',72*np.pi/(4*np.pi*3),6); chk('A7 d3',72*np.pi/(np.pi*9),8)
# A8
chk('A8',-6*0.5/8,-3/8); chk('A8 d',-8/6*0.5,-2/3); chk('A8 d2',-6*0.5,-3)
# check with actual param: x=6+0.5t, y=sqrt(100-x^2)
chk('A8 num', D(lambda t: np.sqrt(100-(6+0.5*t)**2),0), -3/8, 1e-6)
# A9
chk('A9', D(lambda t: (10+3*t)*(6-2*t),0), -2, 1e-6); chk('A9 d',3*6+10*2,38)
# A10
for slope,val in [(0.25,17/4),(1/16,65/16),(1/32,129/32),(1/8,33/8)]: chk('A10',4+slope,val)
chk('A10 slope',D(np.sqrt,16),1/8,1e-6)
assert len({17/4,65/16,129/32,33/8})==4; ok+=1
# A11
chk('A11',5-2*0.5,4); chk('A11 d',5+2*0.5,6)
# A12-14
chk('A12',np.sin(3e-5)/5e-5,0.6,1e-6)
chk('A13', 1,1); assert np.exp(30)/(30**2+1)>1e9; ok+=1
chk('A14', (np.sqrt(4+1e-6)-2)/1e-6, 0.25, 1e-5); chk('A14 d',D(np.sqrt,4),0.25,1e-6)
# B15
Pb = lambda t: 1200*np.exp(0.04*t)
chk3('B15',D(Pb,5),58.627); chk3('B15 d1',Pb(6)-Pb(5),59.816); chk3('B15 d2',Pb(5),1465.683); chk('B15 d3',1200*0.04,48)
# B16
v16 = lambda t: t*np.cos(t)
chk('B16 v',v16(2),-0.832,1e-3); chk('B16 a',D(v16,2),-2.235,1e-3)
assert abs(D(v16,2))>abs(v16(2)); ok+=1
# B17
C17 = lambda x: 500+20*x**0.8
chk3('B17',D(C17,50),7.317); chk3('B17 d1',50**0.8,22.865); chk3('B17 d2',16*50**0.8,365.844); chk3('B17 d3',C17(50),957.305)
# B18
chk('B18', 8*np.pi*6*25/(4*np.pi*36), 25/3*1, 1e-9); chk3('B18 v',25/3,8.333)
chk3('B18 d1',25/(4*np.pi*36),0.055); chk3('B18 d3',8*np.pi*6,150.796)
# B19
th19 = lambda t: np.arctan((1200+80*t)/500)
chk3('B19',D(th19,0),0.024); print('theta',D(th19,0))
chk('B19 d2', 80/500, 0.16); s2=1200**2/(1200**2+500**2); chk3('B19 d1',0.16*s2,0.136); chk3('B19 d3',0.16*(1+(1200/500)**2),1.082)
# B20
f20 = lambda x: np.log(x**2+3)
L20 = f20(1)+D(f20,1)*0.2
chk3('B20',L20,1.486); chk3('B20 true',f20(1.2),1.491); chk3('B20 d',f20(1)+0.2,1.586); chk3('B20 d2',f20(1),1.386)
assert L20<f20(1.2); ok+=1
# B21
chk('B21', np.log(1+3e-6)/np.sin(2e-6), 1.5, 1e-5)

# ================= FRQ 22
x22 = lambda t: 4*t*np.exp(-t/2)
v22 = lambda t: np.exp(-t/2)*(4-2*t)
a22 = lambda t: np.exp(-t/2)*(t-4)
for t0 in (0.7,3,5.5):
    chk('v22',D(x22,t0),v22(t0),1e-6); chk('a22',D(v22,t0),a22(t0),1e-5)
chk('v3',v22(3),-0.446,2e-3); chk('a3',a22(3),-0.223,3e-3)
print('v3,a3',v22(3),a22(3))
assert v22(3)*a22(3)>0; ok+=1
tz = optimize.brentq(v22,0.1,7.9); chk('turn',tz,2)
assert v22(1.9)>0 and v22(2.1)<0; ok+=1
t1 = optimize.brentq(lambda t: x22(t)-1,0.01,1.5); print('t1',t1, 'v',v22(t1))
chk3('t1',t1,0.289); chk3('v(t1)',v22(t1),2.962)
t2 = optimize.brentq(lambda t: x22(t)-1,4,8); print('t2',t2)
chk3('x7',x22(7),0.846); chk('v7',v22(7),-0.302,2e-3)
chk('xmax', x22(2), 8/np.e, 1e-9)
# ================= FRQ 23
h = lambda hh: -12/hh**2   # dh/dt
chk('23b',-3*np.pi/(np.pi*36/4),-1/3); chk('23b2',h(6),-1/3)
# integrate ODE numerically to check concavity: h'=-12/h^2, from h=6
from scipy.integrate import solve_ivp
sol = solve_ivp(lambda t,y:[-12/y[0]**2],[0,1],[6],rtol=1e-12,atol=1e-12)
h1 = sol.y[0,-1]; print('h(t0+1)=',h1); assert h1 < 6-1/3; chk('23c',6-1/3,17/3)
chk('23d h2', D(lambda hh: -12/hh**2,6)*(-1/3), -288/6**5, 1e-5)
opts = {'A2':[7,5.4,2.8,28],'A7':[2,.5,6,8],'A8':[3/8,-2/3,-3/8,-3],'A9':[2,-2,38,60],'A10':[17/4,65/16,129/32,33/8],
 'A12':[0,5/3,3/5,15],'A13':[0,.5,1,np.inf],'A14':[0,.25,.5,4],'B15':[48.000,59.816,58.627,1465.683],'B17':[22.865,365.844,957.305,7.317],
 'B18':[.055,8.333,25.0,150.796],'B19':[.024,.136,.160,1.082],'B20':[1.386,1.491,1.486,1.586],'B21':[0,2/3,3,3/2]}
for k,o in opts.items(): assert len(set(o))==4, k
ok+=len(opts)
print('ALL OK', ok, 'checks')
