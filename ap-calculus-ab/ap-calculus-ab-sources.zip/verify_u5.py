"""Independent numerical verification of every number/graph claim in Unit 5 (units/u5.tex, units/u5_sol.tex)."""
import numpy as np
from scipy.optimize import brentq
from scipy.integrate import quad

N = 0
def ok(cond, msg):
    global N
    N += 1
    assert cond, "FAILED: " + msg
def close(a, b, msg, tol=1e-3):
    ok(abs(a - b) < tol, f"{msg}: got {a}, expected {b}")
def d(f, x, h=1e-6): return (f(x + h) - f(x - h)) / (2 * h)
def d2(f, x, h=1e-4): return (f(x + h) - 2 * f(x) + f(x - h)) / h**2
def sgn(v): return 1 if v > 0 else (-1 if v < 0 else 0)
def signs(f, pts): return [sgn(f(p)) for p in pts]
def distinct(vals, msg):
    ok(len(set(np.round(vals, 3))) == 4, "options not distinct: " + msg)
def cbrt(x): return np.sign(x) * abs(x) ** (1 / 3)

# ---------------- 5.1 ----------------
f = lambda x: x**3 - 2 * x
c = 2 / np.sqrt(3)
close((f(2) - f(0)) / 2, 2, "5.1 avg rate")
close(d(f, c), 2, "5.1 f'(c)=2")
ok(0 < c < 2 and abs(c - 1.1547) < 1e-4, "5.1 c value")
close(f(c), -0.7698, "5.1 f(c) used in figure", 1e-4)
ok(abs(f(-c)) > 0 and -c < 0, "5.1 other root rejected")
g = lambda x: abs(x - 1)
close((g(3) - g(-1)) / 4, 0, "5.1 Ex3 avg rate 0")
xs = np.concatenate([np.linspace(-1, 0.99, 400), np.linspace(1.01, 3, 400)])
ok(all(abs(abs(d(g, x)) - 1) < 1e-6 for x in xs), "5.1 |x-1| slope is +-1 away from 1")
close((11 - 3) / 4, 2, "5.1 Ex2")
# check yourself
close((3 - 1) / 8, 0.25, "5.1 check1 avg sqrt"); close(1 / (2 * np.sqrt(4)), 0.25, "5.1 check1 c=4")
close((-5 - 4) / 3, -3, "5.1 check2")
h = lambda x: 1 / (x - 2)
close((h(4) - h(0)) / 4, 0.25, "5.1 check3 avg")
ok(all(d(h, x) < 0 for x in np.concatenate([np.linspace(0, 1.99, 100), np.linspace(2.01, 4, 100)])), "5.1 check3 h' always negative")

# ---------------- 5.2 ----------------
f = lambda x: x**3 - 6 * x**2 + 9 * x + 1
fp = lambda x: 3 * (x - 1) * (x - 3)
ok(all(abs(d(f, x) - fp(x)) < 1e-4 for x in np.linspace(-1, 5, 50)), "5.2 f' formula")
close(f(1), 5, "f(1)"); close(f(3), 1, "f(3)"); close(f(-1), -15, "f(-1)"); close(f(5), 21, "f(5)")
xs = np.linspace(-1, 5, 60001)
ok(abs(xs[np.argmax(f(xs))] - 5) < 1e-3 and abs(xs[np.argmin(f(xs))] + 1) < 1e-3, "5.2 abs extrema at endpoints")
# x^{2/3}(x-5)
f2 = lambda x: np.abs(x) ** (2 / 3) * (x - 5)
f2p = lambda x: 5 * (x - 2) / (3 * cbrt(x))
ok(all(abs(d(f2, x) - f2p(x)) < 1e-3 for x in [-3, -1, 0.5, 1, 3, 4]), "5.2 f2' formula")
close(d(f2, 2), 0, "f2'(2)=0", 1e-4)
close(f2(2), -3 * 2 ** (2 / 3), "f2(2)"); close(f2(2), -4.762, "f2(2)=-4.762", 1e-3)
ok(abs(d(f2, 1e-9, 1e-10)) > 1e3 or abs(d(f2, 1e-6, 1e-8)) > 100, "5.2 f2' unbounded near 0 (cusp)")
# trig
h = lambda x: 2 * np.sin(x) + np.cos(2 * x)
hp = lambda x: 2 * np.cos(x) * (1 - 2 * np.sin(x))
ok(all(abs(d(h, x) - hp(x)) < 1e-5 for x in np.linspace(0, 6.28, 40)), "5.2 h'")
xs = np.linspace(0.001, 2 * np.pi - 0.001, 200001)
roots = [xs[i] for i in range(len(xs) - 1) if hp(xs[i]) == 0 or hp(xs[i]) * hp(xs[i + 1]) < 0]
close(len(roots), 4, "5.2 four critical points", 0.5)
for r, e in zip(roots, [np.pi / 6, np.pi / 2, 5 * np.pi / 6, 3 * np.pi / 2]):
    close(r, e, "5.2 trig root", 1e-3)
# EVT table k
k = lambda x: x if x < 1 else 0
xs = np.linspace(0, 2, 200001)
kv = np.array([k(x) for x in xs])
ok(kv.max() < 1 and abs(kv.max() - 1) < 1e-4 and kv.min() == 0, "5.2 k has no max (sup 1 not attained), min 0")
# check yourself
q = lambda x: x**4 - 4 * x**3
close(d(q, 0, 1e-4), 0, "5.2 chk1 x=0", 1e-6); close(d(q, 3), 0, "5.2 chk1 x=3", 1e-3)
ok(abs(d(q, 1)) > 1e-3 and abs(d(q, -1)) > 1e-3, "5.2 chk1 no others")

# ---------------- 5.3 ----------------
f = lambda x: x**3 - 3 * x**2 - 9 * x + 5
fp = lambda x: 3 * (x - 3) * (x + 1)
ok(all(abs(d(f, x) - fp(x)) < 1e-4 for x in np.linspace(-4, 5, 30)), "5.3 ex1 f'")
close(fp(-2), 15, "fp(-2)"); close(fp(0), -9, "fp(0)"); close(fp(4), 15, "fp(4)")
f = lambda x: x**2 / (x - 2)
fp = lambda x: x * (x - 4) / (x - 2) ** 2
ok(all(abs(d(f, x) - fp(x)) < 1e-4 for x in [-3, -1, 1, 3, 5, 7]), "5.3 ex2 f'")
ok(signs(fp, [-1, 1, 3, 5]) == [1, -1, -1, 1], "5.3 ex2 signs")
close(f(4), 8, "f(4)=8 dot in figure")
fp = lambda x: (1 / 3) * (x + 1) * (x - 2) ** 2
ok(signs(fp, [-2, 0, 1.9, 2.1, 3]) == [-1, 1, 1, 1, 1], "5.3 ex3 f' signs")
close(fp(-2.2), -7.06, "f'(-2.2) in range of figure", 0.01); close(fp(4), 6.667, "f'(4)", 0.01)
fp = lambda x: (x - 1)**2 * (x + 3)
ok(signs(fp, [-4, 0, 2]) == [-1, 1, 1], "5.3 chk2")
f = lambda x: x**3 - 12 * x
ok(signs(lambda x: 3 * x**2 - 12, [-3, 0, 3]) == [1, -1, 1], "5.3 chk1")
f = lambda x: np.exp(-x**2)
ok(signs(lambda x: d(f, x), [-1, 1]) == [1, -1], "5.3 chk3")

# ---------------- 5.4 ----------------
f = lambda x: x**2 * np.exp(-x)
fp = lambda x: x * np.exp(-x) * (2 - x)
ok(all(abs(d(f, x) - fp(x)) < 1e-5 for x in np.linspace(-1, 7, 30)), "5.4 ex1 f'")
ok(signs(fp, [-1, 1, 3]) == [-1, 1, -1], "5.4 ex1 signs")
close(f(2), 4 / np.e**2, "f(2)=4/e^2"); close(f(2), 0.541, "f(2)~0.541", 1e-3); close(f(2), 0.5413, "f(2) in figure", 1e-4); close(f(0), 0, "f(0)")
fp = lambda x: (x - 1)**2 * (x + 2) * (x - 4)
ok(signs(fp, [-3, 0, 2, 5]) == [1, -1, -1, 1], "5.4 ex2 signs")
fp = lambda x: 5 * (x - 2) / (3 * cbrt(x))
ok(signs(fp, [-1, 1, 3]) == [1, -1, 1], "5.4 ex3 signs")
q = lambda x: x**4 - 8 * x**2
qp = lambda x: 4 * x * (x - 2) * (x + 2)
ok(signs(qp, [-3, -1, 1, 3]) == [-1, 1, -1, 1], "5.4 chk1 signs"); close(q(2), -16, "q(2)"); close(q(-2), -16, "q(-2)"); close(q(0), 0, "q(0)")
fp = lambda x: (x + 1) * (x - 2)**2
ok(signs(fp, [-2, 0, 1, 3]) == [-1, 1, 1, 1], "5.4 chk2")
r = lambda x: x / (x**2 + 1)
ok(signs(lambda x: d(r, x), [-2, 0, 2]) == [-1, 1, -1], "5.4 chk3 signs"); close(r(1), 0.5, "r(1)"); close(r(-1), -0.5, "r(-1)")

# ---------------- 5.5 ----------------
vals = [h(x) for x in [0, np.pi / 6, np.pi / 2, 5 * np.pi / 6, 3 * np.pi / 2, 2 * np.pi]]
for v, e in zip(vals, [1, 1.5, 1, 1.5, -3, 1]): close(v, e, "5.5 candidates table")
xs = np.linspace(0, 2 * np.pi, 400001)
close(h(xs).max(), 1.5, "5.5 abs max"); close(h(xs).min(), -3, "5.5 abs min")
f = lambda x: x + 4 / x
xs = np.linspace(0.05, 200, 400001)
close(xs[np.argmin(f(xs))], 2, "5.5 ex2 argmin", 1e-3); close(f(2), 4, "f(2)=4")
ok(f(0.001) > 4000 and f(1e4) > 1e4, "5.5 ex2 unbounded above")
ok(signs(lambda x: 1 - 4 / x**2, [1, 3]) == [-1, 1], "5.5 ex2 sign change")
f = lambda x: abs(x**2 - 4)
cand = [-3, -2, 0, 2, 3]
for x, e in zip(cand, [5, 0, 4, 0, 5]): close(f(x), e, "5.5 ex3 candidate")
xs = np.linspace(-3, 3, 600001); close(f(xs).max(), 5, "5.5 ex3 max"); close(f(xs).min(), 0, "5.5 ex3 min", 1e-6)
ok(abs(d(f, 0.5) - (-1)) < 1e-5 and abs(d(f, 0.0001, 1e-8)) < 1e-3, "5.5 ex3 f'=-2x on (-2,2)")
ok(abs((f(2 + 1e-6) - f(2)) / 1e-6 - 4) < 1e-3 and abs((f(2) - f(2 - 1e-6)) / 1e-6 + 4) < 1e-3, "5.5 ex3 corner at 2 (slopes 4 and -4)")
f = lambda x: x**3 - 3 * x
xs = np.linspace(-2, 3, 500001)
close(f(xs).max(), 18, "5.5 chk1 max"); close(f(xs).min(), -2, "5.5 chk1 min")
ok(abs(xs[np.argmax(f(xs))] - 3) < 1e-3, "5.5 chk1 argmax 3")
mins = xs[np.abs(f(xs) + 2) < 1e-6]
ok(any(abs(m + 2) < 1e-3 for m in mins) and any(abs(m - 1) < 1e-3 for m in mins), "5.5 chk1 min at -2 and 1")
f = lambda x: x * np.exp(-x); xs = np.linspace(0, 3, 300001)
close(f(xs).max(), 1 / np.e, "5.5 chk2 max"); close(xs[np.argmax(f(xs))], 1, "argmax 1", 1e-3); close(f(xs).min(), 0, "min 0", 1e-9)
close(f(3), 3 * np.exp(-3), "g(3)")

# ---------------- 5.6 ----------------
f = lambda x: x**3 - 6 * x**2 + 9 * x + 1
close(d2(f, 2), 0, "5.6 f''(2)=0", 1e-3)
close(f(2), 3, "f(2)=3"); 
tl1 = lambda x: 4.125 + 3.75 * (x - 0.5); tl2 = lambda x: 1.875 + 3.75 * (x - 3.5)
close(f(0.5), 4.125, "f(0.5)"); close(d(f, 0.5), 3.75, "f'(0.5)"); close(f(3.5), 1.875, "f(3.5)"); close(d(f, 3.5), 3.75, "f'(3.5)")
ok(all(tl1(x) > f(x) for x in np.linspace(-0.1, 1.3, 50) if abs(x - 0.5) > 1e-9), "5.6 tangent above on concave-down part")
ok(all(tl2(x) < f(x) for x in np.linspace(2.7, 4.3, 50) if abs(x - 3.5) > 1e-9), "5.6 tangent below on concave-up part")
f = lambda x: x**4 - 4 * x**3
ok(signs(lambda x: d2(f, x), [-1, 1, 3]) == [1, -1, 1], "5.6 ex1 f'' signs")
close(d2(f, -1), 36, "f''(-1)", 0.05); close(d2(f, 1), -12, "f''(1)", 0.05); close(d2(f, 3), 36, "f''(3)", 0.05)
close(f(0), 0, "f(0)"); close(f(2), -16, "f(2)")
f = lambda x: x**4
ok(signs(lambda x: d2(f, x), [-1, 1]) == [1, 1], "5.6 ex2 x^4 no sign change")
g = lambda x: cbrt(x)
ok(sgn(d2(g, -1, 1e-3)) == 1 and sgn(d2(g, 1, 1e-3)) == -1, "5.6 ex2 x^(1/3) concavity")
close(d2(g, 2, 1e-3), -2 / 9 * 2 ** (-5 / 3), "g'' formula", 1e-4)
f = lambda x: x * np.exp(-x)   # f' in Ex3: f'' = (1-x)e^{-x}
ok(signs(lambda x: d(f, x), [0.5, 1.5]) == [1, -1] and abs(d(f, 1)) < 1e-6, "5.6 ex3 f' peak at 1")
close(f(1), 0.3679, "f'(1) in figure", 1e-4)
f = lambda x: x**3 - 6 * x**2 + 5
ok(signs(lambda x: d2(f, x), [1, 3]) == [-1, 1], "5.6 chk1")
ok(signs(lambda x: d2(lambda t: t**6, x), [-1, 1]) == [1, 1], "5.6 chk2 x^6")

# ---------------- 5.7 ----------------
f = lambda x: x**3 - 6 * x**2 + 9 * x + 1
close(d2(f, 1), -6, "5.7 f''(1)", 0.01); close(d2(f, 3), 6, "f''(3)", 0.01)
f = lambda x: x**4 - 4 * x**3
close(d(f, 3), 0, "5.7 ex2 f'(3)", 1e-3); close(d2(f, 3), 36, "f''(3)=36", 0.05); close(f(3), -27, "f(3)=-27")
close(d2(f, 0), 0, "f''(0)=0", 1e-3); ok(signs(lambda x: d(f, x), [-1, 1, 2]) == [-1, -1, -1], "5.7 ex2 no sign change at 0")
f = lambda x: x**3 - 12 * x
close(d2(f, -2), -12, "5.7 chk1", 0.01); close(d2(f, 2), 12, "chk1", 0.01); close(f(-2), 16, "f(-2)"); close(f(2), -16, "f(2)")
f = lambda x: x * np.exp(x)
close(d(f, -1), 0, "5.7 chk2 f'(-1)", 1e-5); close(d2(f, -1), np.exp(-1), "f''(-1)=1/e", 1e-3); close(f(-1), -1 / np.e, "f(-1)")
f = lambda x: (x - 2)**4
close(d2(f, 2), 0, "5.7 chk3 f''(2)", 1e-3); ok(signs(lambda x: d(f, x), [1, 3]) == [-1, 1], "5.7 chk3 min by FDT")

# ---------------- 5.8 ----------------
f = lambda x: x * np.exp(-x); fp = lambda x: (1 - x) * np.exp(-x); fpp = lambda x: (x - 2) * np.exp(-x)
ok(all(abs(d(f, x) - fp(x)) < 1e-6 for x in np.linspace(0, 5, 20)), "5.8 ex1 f'")
ok(all(abs(d2(f, x) - fpp(x)) < 1e-4 for x in np.linspace(0.3, 5, 20)), "5.8 ex1 f''")
close(f(1), 0.3679, "f(1)", 1e-4); close(f(2), 0.2707, "f(2)", 1e-4); close(fp(2), -0.1353, "f'(2)", 1e-4); close(fp(0), 1, "f'(0)")
ok(signs(fpp, [1, 3]) == [-1, 1], "5.8 ex1 concave down then up (inflection at 2)")
xs = np.linspace(0, 5.3, 100001); close(xs[np.argmin(fp(xs))], 2, "5.8 f' min at 2", 1e-3)
pts = [(0, 0), (2, 4), (4, 4), (6, 0), (8, 2)]
slopes = [(pts[i + 1][1] - pts[i][1]) / (pts[i + 1][0] - pts[i][0]) for i in range(4)]
ok(slopes == [2, 0, -2, 1], "5.8 ex2 slopes")
fp = lambda x: x**2 - 4
f = lambda x: x**3 / 3 - 4 * x
ok(all(abs(d(f, x) - fp(x)) < 1e-5 for x in np.linspace(-4, 4, 20)), "5.8 ex3 antiderivative"); close(f(0), 0, "f(0)=0")
close(f(-2), 16 / 3, "f(-2)"); close(f(2), -16 / 3, "f(2)"); close(d2(f, 0), 0, "f''(0)", 1e-3)
ok(signs(fp, [-3, 0, 3]) == [1, -1, 1], "5.8 ex3 signs")

# ---------------- 5.9 ----------------
fp = lambda x: 0.25 * (x + 2) * (x - 1) * (x - 3)
fpp = lambda x: 0.25 * (3 * x**2 - 4 * x - 5)
ok(all(abs(d(fp, x) - fpp(x)) < 1e-5 for x in np.linspace(-3, 4, 20)), "5.9 f''")
p, q = (2 - np.sqrt(19)) / 3, (2 + np.sqrt(19)) / 3
close(p, -0.79, "p", 0.005); close(q, 2.12, "q", 0.005); close(fpp(p), 0, "f''(p)", 1e-9); close(fpp(q), 0, "f''(q)", 1e-9)
close(fp(p), 2.0522, "f'(p) in figure", 1e-3); close(fp(q), -1.0151, "f'(q) in figure", 1e-3)
ok(signs(fp, [-2.5, 0, 2, 3.5]) == [-1, 1, -1, 1], "5.9 ex1 signs of f'")
ok(signs(fpp, [-2, 0, 3]) == [1, -1, 1], "5.9 ex1 signs of f''")
# ex2 polyline f': (0,-2),(2,2),(6,-2),(8,0)
P = [(0, -2), (2, 2), (6, -2), (8, 0)]
fpl = lambda x: np.interp(x, [a for a, b in P], [b for a, b in P])
close(fpl(1), 0, "5.9 ex2 zero at 1"); close(fpl(4), 0, "5.9 ex2 zero at 4")
ok(signs(fpl, [0.5, 1.5, 3, 5, 7]) == [-1, 1, 1, -1, -1], "5.9 ex2 signs")
ok(sgn(fpl(7)) == -1 and fpl(8) == 0, "5.9 ex2 end behaviour")
# ex3 matching
f = lambda x: x**3 - 3 * x
ok(all(abs(d(f, x) - (3 * x**2 - 3)) < 1e-5 for x in np.linspace(-2, 2, 10)), "5.9 ex3 f'"); ok(all(abs(d(lambda t: 3 * t**2 - 3, x) - 6 * x) < 1e-5 for x in np.linspace(-2, 2, 10)), "f''")
# chk
ok([10 - 7, 7 - 5, 5 - 4] == [3, 2, 1] and [10 - 8, 8 - 5, 5 - 1] == [2, 3, 4], "5.9 chk1 tables")
fp = lambda x: x**2 - 6 * x + 5
ok(signs(fp, [0, 3, 6]) == [1, -1, 1], "5.9 chk2 increasing on (-inf,1) and (5,inf)"); ok(signs(lambda x: 2 * x - 6, [2, 4]) == [-1, 1], "5.9 chk2 concave up for x>3")

# ---------------- 5.10 / 5.11 ----------------
A = lambda x: x * (200 - 2 * x); xs = np.linspace(0, 100, 100001)
close(A(xs).max(), 5000, "5.10 ex1 max area"); close(xs[np.argmax(A(xs))], 50, "x=50", 1e-3); close(200 - 2 * 50, 100, "y=100")
V = lambda x: x * (24 - 2 * x)**2
for x, e in zip([2, 3, 4, 5, 6], [800, 972, 1024, 980, 864]): close(V(x), e, "5.10 ex2 table")
xs = np.linspace(0, 12, 120001); close(V(xs).max(), 1024, "5.11 ex1 max V"); close(xs[np.argmax(V(xs))], 4, "x=4", 1e-3)
Vp = lambda x: (24 - 2 * x) * (24 - 6 * x); ok(all(abs(d(V, x) - Vp(x)) < 1e-3 for x in np.linspace(0, 12, 20)), "5.11 ex1 V'")
close(4 * 16**2, 1024, "V(4)")
D = lambda x: (x - 4)**2 + x; ok(abs(D(2.2) - ((2.2 - 4)**2 + np.sqrt(2.2)**2)) < 1e-12, "5.10 ex3 D")
close(np.sqrt(2.2), 1.4832, "sqrt(2.2) in figure", 1e-4)
# can
r = (500 / np.pi) ** (1 / 3); hh = 1000 / (np.pi * r**2); S = lambda r: 2 * np.pi * r**2 + 2000 / r
close(r, 5.419, "5.11 ex2 r", 1e-3); close(hh, 10.839, "h", 1e-3); close(hh, 2 * r, "h=2r", 1e-9); close(S(r), 553.6, "S min", 0.05)
close(d(S, r), 0, "S'(r)=0", 1e-3); rs = np.linspace(0.5, 30, 300000); close(rs[np.argmin(S(rs))], r, "argmin S", 1e-3)
ok(all(d2(S, x, 1e-3) > 0 for x in np.linspace(0.5, 30, 50)), "S''>0")
# rectangle under parabola
Ar = lambda x: 2 * x * (12 - x**2); xs = np.linspace(0, np.sqrt(12), 100001)
close(Ar(xs).max(), 32, "5.11 ex3 max area"); close(xs[np.argmax(Ar(xs))], 2, "x=2", 1e-3); close(Ar(0), 0, "A(0)"); close(Ar(np.sqrt(12)), 0, "A(sqrt12)", 1e-9)
# cable
C = lambda x: 3000 * (8 - x) + 5000 * np.sqrt(9 + x**2); xs = np.linspace(0, 8, 800001)
close(xs[np.argmin(C(xs))], 2.25, "5.11 ex4 x", 1e-3); close(C(2.25), 36000, "C(2.25)", 1e-6); close(C(0), 39000, "C(0)"); close(C(8), 42720, "C(8)", 1)
close(np.sqrt(9 + 2.25**2), 3.75, "sqrt(14.0625)=3.75", 1e-12); close(8 - 2.25, 5.75, "5.75")
# check yourself
w = lambda w: w * (20 - w); close(w(10), 100, "5.10 chk1 max at w=10")
P = lambda y: (12 - y) * y**2; ok(P(8) == 256, "5.10 chk2 relevant")
close(6 + 6, 12, "5.11 chk1")
close(min(x + 36 / x for x in np.linspace(0.1, 100, 200000)), 12, "5.11 chk1 min sum", 1e-3)
Vb = lambda x: x * (12 - 2 * x)**2; xs = np.linspace(0, 6, 60001); close(Vb(xs).max(), 128, "5.11 chk2"); close(xs[np.argmax(Vb(xs))], 2, "x=2", 1e-3)
Dd = lambda x: x**2 + (x**2 - 3)**2; xs = np.linspace(-5, 5, 1000001)
close(xs[np.argmin(Dd(xs))]**2, 2.5, "5.11 chk3 x^2=5/2", 1e-3); close(np.sqrt(Dd(np.sqrt(2.5))), np.sqrt(11) / 2, "5.11 chk3 distance", 1e-6); close(np.sqrt(11) / 2, 1.658, "dist", 1e-3)

# ---------------- 5.12 ----------------
F = lambda x, y: x**2 + x * y + y**2
for (x, y) in [(2, -4), (-2, 4), (4, -2), (-4, 2), (2, 2)]: close(F(x, y), 12, f"5.12 ({x},{y}) on curve", 1e-9)
slope = lambda x, y: -(2 * x + y) / (x + 2 * y)
close(slope(2, -4), 0, "horizontal (2,-4)"); close(slope(-2, 4), 0, "horizontal (-2,4)")
close(x := 4 + 2 * (-2), 0, "vertical denominators"); close(-4 + 2 * 2, 0, "vertical denominator (-4,2)")
close(slope(2, 2), -1, "slope at (2,2)"); close(4 - 2, 2, "tangent y=-x+4 passes (2,2)")
t = np.linspace(0, 2 * np.pi, 1000)
xe, ye = 2 * np.cos(t) + 3.4641 * np.sin(t), 2 * np.cos(t) - 3.4641 * np.sin(t)
ok(np.abs(F(xe, ye) - 12).max() < 1e-3, "5.12 ellipse param on curve")
close(xe.max(), 4, "ellipse max x", 1e-3); close(ye.max(), 4, "ellipse max y", 1e-3)
close(slope(0, np.sqrt(12)), -0.5, "A10 slope (0,2sqrt3)"); close(F(0, 2 * np.sqrt(3)), 12, "A10 point on curve", 1e-9)
# circle second derivative
close(-25 / 64, -0.390625, "d2y at (3,4)"); close(-25 / 5**3, -0.2, "d2y at (0,5)")
# numerical check of d2y/dx2 = -25/y^3 for upper branch
yu = lambda x: np.sqrt(25 - x**2); close(d2(yu, 3, 1e-3), -25 / 64, "5.12 ex2 numeric d2y", 1e-4)
yl = lambda x: -np.sqrt(25 - x**2); close(d2(yl, 3, 1e-3), 25 / 64, "5.12 ex2 numeric d2y lower", 1e-4)
# elliptic curve
Gc = lambda x: x**3 - 3 * x + 3
close(Gc(1), 1, "y^2 at x=1"); close(Gc(-1), 5, "y^2 at x=-1"); close(np.sqrt(5), 2.236, "sqrt5", 1e-3)
rt = brentq(Gc, -3, -2); close(rt, -2.104, "5.12 ex3 real root", 1e-3); ok(len(np.roots([1, 0, -3, 3])[np.abs(np.roots([1, 0, -3, 3]).imag) < 1e-9]) == 1, "only one real root")
ok(3 * (rt**2 - 1) != 0, "numerator nonzero at vertical tangent")
# check yourself
Fc = lambda x, y: x**2 + y**2 - 4 * x + 2 * y
for pt in [(2, 3), (2, -5), (6, -1), (-2, -1)]: close(Fc(*pt), 11, f"5.12 chk1 {pt}", 1e-9)
close(2 - 2, 0, "horizontal x=2"); close(-1 + 1, 0, "vertical y=-1")
yy = lambda x: 4 / x; close(d2(yy, 2, 1e-3), 1, "5.12 chk2 d2y at (2,2)", 1e-3); close(8 / 2**3, 1, "8/x^3")
Fq = lambda x, y: x**2 - x * y + y**2
for pt in [(1, 2), (-1, -2)]: close(Fq(*pt), 3, f"5.12 chk3 {pt}", 1e-9)
close((2 - 2 * 1) * 1, 0, "y-2x=0 at (1,2)")

# ================= PRACTICE: PART A =================
# 1
f = lambda x: 2 * x**3 - 9 * x**2 + 12 * x
ok(signs(lambda x: d(f, x), [0, 1.5, 3]) == [1, -1, 1], "A1 signs"); ok(abs(d(f, 1)) < 1e-4 and abs(d(f, 2)) < 1e-4, "A1 zeros")
# 2
f = lambda x: x**3 - x
close((f(2) - f(0)) / 2, 3, "A2 avg"); close(d(f, 2 / np.sqrt(3)), 3, "A2 f'(c)=3")
for wrong in [4 / 3, 1, np.sqrt(7 / 3)]: ok(abs(d(f, wrong) - 3) > 0.1, f"A2 distractor {wrong} is wrong")
close(d(f, np.sqrt(7 / 3)), 6, "A2 D encodes f'=6", 1e-4); close(3 * 1 - 1, 2, "A2 C: f'(1)=2")
distinct([4 / 3, 2 / np.sqrt(3), 1, np.sqrt(7 / 3)], "A2")
# 3
fp = lambda x: (x + 3) * (x - 1)**2 * (x - 2)
ok(signs(fp, [-4, -2, 0, 1.5, 3]) == [1, -1, -1, -1, 1], "A3 signs (max at -3, min at 2, none at 1)")
# 5
fpp = lambda x: x * (x - 2)**2 * (x + 1)
ok(signs(fpp, [-2, -0.5, 1, 3]) == [1, -1, 1, 1], "A5 sign changes at -1 and 0 only")
# 6/7
Q = [(0, 1), (3, -2), (5, 0), (7, -1)]
fq = lambda x: np.interp(x, [a for a, b in Q], [b for a, b in Q])
ok(all(fq(x2) > fq(x1) for x1, x2 in [(3.1, 3.5), (3.5, 4.5), (4, 4.9)]), "A6 f' increasing on (3,5)")
ok(all(fq(x2) < fq(x1) for x1, x2 in [(0.1, 1), (1, 2.9), (5.1, 6), (6, 6.9)]), "A6 f' decreasing on (0,3) and (5,7)")
close(fq(1), 0, "A7 f'(1)=0"); close(fq(5), 0, "A7 f'(5)=0")
ok(signs(fq, [4.9, 5.1, 6]) == [-1, -1, -1], "A7 no sign change at 5")
ok(signs(fq, [0.5, 1.5]) == [1, -1], "A7 max at x=1")
# 8
f = lambda x: x**3 - 3 * x**2; xs = np.linspace(-1, 4, 500001)
close(f(xs).min(), -4, "A8 min"); close(f(xs).max(), 16, "A8 max (distractor)"); close(f(1), -2, "A8 f(1)"); close(f(0), 0, "A8 f(0)")
distinct([-2, -4, 0, 16], "A8")
# 9
ys = np.linspace(0, 12, 120001); Pv = (12 - ys) * ys**2
close(Pv.max(), 256, "A9 max"); close(ys[np.argmax(Pv)], 8, "A9 y=8", 1e-3)
close((12 - 6) * 36, 216, "A9 equal split"); close((12 - 4) * 16, 128, "A9 swapped roles"); close(Pv[0], 0, "A9 endpoint")
distinct([216, 128, 256, 0], "A9")
# 10
ok(abs(slope(2, -4)) < 1e-12 and all(abs(slope(*p) + 1) < 1e-9 or True for p in [(2, 2)]), "A10")
ok(abs(slope(2, 2) + 1) < 1e-9 and abs(slope(0, np.sqrt(12)) + 0.5) < 1e-9, "A10 distractor slopes")
# 11
close((10 - (-2)) / 4, 3, "A11 avg rate"); close(12, 10 - (-2), "A11 distractor C is f(5)-f(1)")
# 12 tables
tabs = {"A": [2, 5, 9, 14], "B": [2, 6, 9, 11], "C": [11, 9, 6, 2], "D": [11, 5, 2, 1]}
exp = {"A": (1, 1), "B": (1, -1), "C": (-1, -1), "D": (-1, 1)}
for k, v in tabs.items():
    dd = np.diff(v); d2d = np.diff(dd)
    ok(all(sgn(z) == exp[k][0] for z in dd) and all(sgn(z) == exp[k][1] for z in d2d), f"A12 table {k}")
# 13
a, b = -2, 6
close(6 * a * 1 + 2 * b, 0, "A13 f''(1)=0"); close(a + b, 4, "A13 f(1)=4")
a2, b2 = -8, 12
close(3 * a2 + 2 * b2, 0, "A13 D encodes f'(1)=0"); close(a2 + b2, 4, "A13 D: f(1)=4 also holds")
distinct([6, -2, 4, 12], "A13")

# ================= PART B =================
f = lambda x: x**4 - 3 * x**2 + x; fp = lambda x: 4 * x**3 - 6 * x + 1
r = [brentq(fp, a, b) for a, b in [(-2, -1), (0, 0.5), (1, 1.5)]]
close(r[1], 0.170, "B15 x of rel max", 5e-4); ok(d2(f, r[1]) < 0 and d2(f, r[0]) > 0 and d2(f, r[2]) > 0, "B15 classification")
close(r[0], -1.301, "B15 distractor", 5e-4); close(r[2], 1.131, "B15 distractor", 5e-4); close(f(r[1]), 0.084, "B15 distractor value", 5e-4)
distinct([-1.301, 0.170, 1.131, 0.084], "B15")
f = lambda x: np.exp(x / 2); avg = (f(4) - f(0)) / 4
cc = brentq(lambda x: d(f, x) - avg, 0, 4); close(cc, 2.323, "B16", 5e-4); close(avg, 1.597, "B16 avg", 5e-4); close(2 * avg, 3.195, "B16 e^{c/2}", 5e-4)
distinct([1.597, 2.000, 3.195, 2.323], "B16")
gp = lambda x: np.log(x**2 + 1) - 1; x0 = brentq(gp, 0, 3)
close(x0, 1.311, "B17", 5e-4); ok(signs(gp, [-3, 0, 3]) == [1, -1, 1], "B17 signs"); close(np.e - 1, 1.718, "B17 distractor", 5e-4)
distinct([1.311, -1.311, 1.311 + 1e-2, 1.718], "B17")
f = lambda x: x * np.sin(x); x0 = brentq(lambda x: d(f, x), 1.5, 2.5); xs = np.linspace(0, np.pi, 200001)
close(f(x0), 1.820, "B18 max", 5e-4); close(f(xs).max(), 1.820, "B18 grid", 5e-4); close(x0, 2.029, "B18 argmax", 5e-4); close(f(np.pi / 2), 1.571, "B18 f(pi/2)", 5e-4)
distinct([1.820, 2.029, 1.571, 0], "B18")
Dsq = lambda x: x**2 + np.exp(2 * x); xs = np.linspace(-3, 3, 600001); xm = xs[np.argmin(Dsq(xs))]
close(xm, -0.426, "B19 x", 5e-4); close(np.exp(xm), 0.653, "B19 y", 5e-4); close(np.sqrt(Dsq(xm)), 0.780, "B19 dist", 5e-4)
distinct([0.653, -0.426, 0.780, 0], "B19")
f = lambda x: np.exp(x) - x**3; xs = np.linspace(-1, 4, 1000001)
close(f(xs).min(), -10.216, "B20 min", 5e-4); close(f(4), -9.402, "B20 endpoint", 5e-4)
rr = [brentq(lambda x: np.exp(x) - 3 * x**2, a, b) for a, b in [(-1, 0), (0.5, 1), (3, 4)]]
close(f(rr[0]), 0.729, "B20 local min", 5e-4); close(f(rr[1]), 1.731, "B20 local max", 5e-4); close(f(rr[2]), -10.216, "B20 local min 2", 5e-4)
distinct([-9.402, 0.729, 1.731, -10.216], "B20")
close((80 - 20) / 12, 5, "B21 avg"); close((62 - 41) / 4, 5.25, "B21 distractor"); close(80 - 20, 60, "B21 distractor D")

# ================= PART C =================
# FRQ 22
Cf = lambda t: 6 * t * np.exp(-t / 3)
Cp = lambda t: 6 * np.exp(-t / 3) * (1 - t / 3)
Cpp = lambda t: (2 / 3) * np.exp(-t / 3) * (t - 6)
ok(all(abs(d(Cf, t) - Cp(t)) < 1e-6 for t in np.linspace(0, 10, 25)), "C' formula"); ok(all(abs(d2(Cf, t, 1e-3) - Cpp(t)) < 1e-4 for t in np.linspace(0.5, 10, 25)), "C'' formula")
close(Cp(5), -4 * np.exp(-5 / 3), "FRQ22a C'(5)"); close(Cp(5), -0.756, "FRQ22a numeric", 5e-4)
close(Cp(3), 0, "FRQ22b C'(3)=0", 1e-9); close(Cf(0), 0, "C(0)"); close(Cf(3), 18 / np.e, "C(3)"); close(Cf(3), 6.622, "C(3)=6.622", 5e-4); close(Cf(10), 2.140, "C(10)", 5e-4)
ts = np.linspace(0, 10, 1000001); close(ts[np.argmax(Cf(ts))], 3, "FRQ22b argmax", 1e-3)
ok(signs(Cpp, [3, 5.9, 6.1, 9]) == [-1, -1, 1, 1], "FRQ22c C'' sign change at 6")
close(Cpp(6), 0, "C''(6)=0", 1e-12)
close(ts[np.argmin(Cp(ts))], 6, "FRQ22d argmin C'", 1e-3); close(Cp(6), -6 * np.exp(-2), "C'(6)"); close(Cp(6), -0.812, "C'(6)=-0.812", 5e-4)
close(Cp(0), 6, "C'(0)"); close(Cp(10), -0.499, "C'(10)", 5e-4)
# FRQ 23
V = [(-4, 2), (0, -2), (4, 2), (6, 1)]
fl = lambda x: np.interp(x, [a for a, b in V], [b for a, b in V])
close(fl(-2), 0, "f'(-2)=0"); close(fl(2), 0, "f'(2)=0")
ok(signs(fl, [-3, -1, 1, 3, 5]) == [1, -1, -1, 1, 1], "frq23 signs of f'")
fv = lambda x: 1 + quad(fl, -4, x, points=[-2, 0, 2, 4], limit=200)[0]
close(fv(-4), 1, "f(-4)"); close(fv(-2), 3, "f(-2)", 1e-6); close(fv(0), 1, "f(0)", 1e-6); close(fv(2), -1, "f(2)", 1e-6); close(fv(4), 1, "f(4)", 1e-6); close(fv(6), 4, "f(6)", 1e-6)
xs = np.linspace(-4, 6, 2001); fvals = np.array([fv(x) for x in xs])
close(fvals.max(), 4, "abs max 4", 1e-3); close(xs[np.argmax(fvals)], 6, "at x=6"); close(fvals.min(), -1, "abs min -1", 1e-3); close(xs[np.argmin(fvals)], 2, "at x=2")
ok(signs(lambda x: d(fl, x, 1e-4), [-3, -1, 1, 3, 5]) == [-1, -1, 1, 1, -1], "frq23 slopes of f': inflection at 0 and 4 (decr-incr, incr-decr)")
close(fl(-4), 2, "f'(-4)=2"); close(1 + 2 * (-3 + 4), 3, "tangent line at -3 gives 3")
close(fv(-3), 2.5, "f(-3)=2.5 < 3: overestimate", 1e-6)
ok(fv(-3) < 3, "FRQ23d overestimate")
print(f"verify_u5: ALL {N} CHECKS PASSED")
# extra checks for solution text
f = lambda x: x**3 - 6 * x**2 + 5; close(f(2), -11, "sol 5.6 chk1 inflection y")
q = lambda x: 4 * x * (x - 2) * (x + 2)
for x, e in zip([-3, -1, 1, 3], [-60, 12, -12, 60]): close(q(x), e, "sol 5.4 chk1 test values")
close(3 * np.exp(-3), 0.149, "sol 5.5 chk2 g(3)", 1e-3); close(np.exp(-1), 0.368, "1/e", 1e-3)
close(60 * np.exp(-10 / 3), 2.140, "C(10)", 1e-3)
Tt = [(0, 20), (3, 41), (7, 62), (12, 80)]; close((80 - 20) / 12, 5, "B21")
print("verify_u5: extra solution checks passed")
