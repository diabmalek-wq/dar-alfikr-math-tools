"""Independent numeric verification for Unit 2 (numpy/scipy only)."""
import numpy as np
from math import *
from scipy.integrate import quad
from scipy.optimize import brentq

fails = []
def chk(name, got, want, tol=1e-6):
    ok = abs(got - want) <= tol * max(1, abs(want))
    if not ok:
        fails.append((name, got, want))
    print(("ok   " if ok else "FAIL ") + name, got, want)

def D(f, x, h=1e-4):          # 5-point central difference
    return (-f(x+2*h) + 8*f(x+h) - 8*f(x-h) + f(x-2*h)) / (12*h)
def Dl(f, x, h=1e-6):         # left/right one-sided slopes
    return (f(x)-f(x-h))/h
def Dr(f, x, h=1e-6):
    return (f(x+h)-f(x))/h

# ---------------- topic text examples ----------------
f = lambda x: x**2
chk('2.1 ex1 avg', (f(3)-f(1))/2, 4); chk('2.1 ex1 inst', Dr(f,1), 2, 1e-5)
D_tab = {0:0,10:35,25:110,40:215,60:400}
chk('2.1 ex2 a', (215-35)/30, 6); chk('2.1 ex2 b', (400-215)/20, 9.25)
chk('2.1 ex3 sqrt', D(sqrt,4), .25, 1e-6)
F = lambda x: x**3/3 - x
for x0 in (-2,-1,0,1.7): chk('2.2 ex1 f\'=x^2-1 at %s'%x0, D(F,x0), x0**2-1, 1e-6)
chk('2.2 ex2 sqrt 9', D(sqrt,9), 1/6); 
chk('2.2 ex3 cos', D(cos,pi/3), -sqrt(3)/2)
chk('2.3 ex1 est', (215-110)/15, 7)
for h,v in ((0.1,.4879),(0.01,.4988),(0.001,.4999)):
    chk('2.3 ex2 h=%s'%h, round((log(2+h)-log(2))/h,4), v, 1e-9)
chk('2.3 ex2 sym', (log(2.01)-log(1.99))/0.02, 0.5, 1e-5)
chk('2.3 fig chord slope', (sqrt(6)-sqrt(2))/4, 0.2588, 1e-3)
gg = lambda x: 7-x+0.15*(x-4)**2
chk('2.3 ex3 g(4)', gg(4), 3); chk("2.3 ex3 g'(4)", D(gg,4), -1); chk('2.3 ex3 pt(2,5) on tangent', 7-2, 5); chk('2.3 ex3 pt(6,1)', 7-6, 1)
# 2.4 piecewise
f1l=lambda x:x**2; f1r=lambda x:2*x-1; g1r=lambda x:x
chk('2.4 ex1 f cont', f1l(1), f1r(1)); chk('2.4 ex1 f slopes', D(f1l,1), D(f1r,1)); chk('2.4 ex1 g slopes', D(f1l,1)-D(g1r,1), 1)
chk('2.4 ex2 k', 4*1, 4); chk('2.4 ex2 slopes', D(lambda x:x**2,2), 4); chk('2.4 ex2 right', D(lambda x:3*x-2,2), 3)
xx = lambda x: x*abs(x)
chk('2.4 ex4 f\'(0) via (f(h)-f(0))/h, h=+-1e-9', max(abs(xx(1e-9)/1e-9), abs(xx(-1e-9)/-1e-9)), 0, 1e-6)
for x0 in (-1.5,0.7,2): chk('2.4 ex4 f\'=2|x| at %s'%x0, D(xx,x0), 2*abs(x0), 1e-5)
# vertical tangent: quotient grows
assert (1e-6)**(-2/3) > 1e3 and (-1e-6)**2 >0
# 2.5-2.6
p32 = lambda x: x**1.5
chk('2.5 ex2 y(4)', p32(4), 8); chk('2.5 ex2 slope', D(p32,4), 3)
chk('2.5 ex3 slope 12 at 2', D(lambda x:x**3,2), 12); chk('2.5 ex3 at -2', D(lambda x:x**3,-2), 12)
cub = lambda x: x**3-6*x**2+9*x+1
chk('2.6 ex2 hz 1', D(cub,1), 0); chk('2.6 ex2 hz 3', D(cub,3), 0); chk('2.6 ex2 f(1)', cub(1), 5); chk('2.6 ex2 f(3)', cub(3), 1)
s = lambda t: 2*t**3-9*t**2+12*t
chk('2.6 ex3 v(1)', D(s,1), 0); chk('2.6 ex3 v(2)', D(s,2), 0)
f6 = lambda x: 4*x**3-6*sqrt(x)+5/x**2+7
chk('2.6 ex1 formula', D(f6,2.3), 12*2.3**2-3/sqrt(2.3)-10/2.3**3)
chk('2.6 ex3b', 2*5-3*(-1)+2*2, 17)
# 2.7
chk('2.7 ex1', D(lambda x:5*sin(x)-2*cos(x)+3*exp(x)-4*log(x),pi), -5+3*exp(pi)-4/pi)
y27 = lambda x: exp(x)-2*x
chk('2.7 ex2 hz', D(y27,log(2)), 0); chk('2.7 ex2 y', y27(log(2)), 2-2*log(2)); chk('2.7 ex2 approx', round(2-2*log(2),3), 0.614)
chk('2.7 ex3 slope', D(log,e), 1/e); chk('2.7 ex3 tangent through origin', 1-(1/e)*e, 0)
# 2.8
chk('2.8 ex1a', D(lambda x:x**3*sin(x),1.1), 3*1.1**2*sin(1.1)+1.1**3*cos(1.1))
chk('2.8 ex1b', D(lambda x:sqrt(x)*exp(x),1.3), exp(1.3)*(1/(2*sqrt(1.3))+sqrt(1.3)))
chk('2.8 ex2', (-1)*4+3*5, 11); chk('2.8 ex2b', 6*1+(-2)*(-3), 12)
ye = lambda x:(x+2)*exp(x)
chk('2.8 ex3 y(0)', ye(0), 2); chk('2.8 ex3 slope', D(ye,0), 3)
# 2.9
q1=lambda x:(x**2-1)/(x**2+1); chk('2.9 ex1', D(q1,1.7), 4*1.7/(1.7**2+1)**2)
q2=lambda x:x/(x**2+1); chk('2.9 ex2 +1', D(q2,1),0); chk('2.9 ex2 -1', D(q2,-1),0); chk('2.9 ex2 f(1)',q2(1),.5)
chk('2.9 ex3 q', ((-3)*2-10*4)/4, -11.5); chk('2.9 ex3 r', (4*10-2*(-3))/100, 0.46)
# 2.10
sec=lambda x:1/cos(x); cot=lambda x:1/tan(x); csc=lambda x:1/sin(x)
x0=0.9
chk('2.10 tan', D(tan,x0), sec(x0)**2); chk('2.10 cot', D(cot,x0), -csc(x0)**2)
chk('2.10 sec', D(sec,x0), sec(x0)*tan(x0)); chk('2.10 csc', D(csc,x0), -csc(x0)*cot(x0))
chk('2.10 ex2 slope', D(tan,pi/4), 2)
chk('2.10 ex3 b', D(lambda x:exp(x)*cot(x),x0), exp(x0)*(cot(x0)-csc(x0)**2))
chk('2.10 ex3 a', D(lambda x:x*sec(x),x0), sec(x0)*(1+x0*tan(x0)))
# 2.4 fig: tan tangent
# ---------------- check yourself answers ----------------
f=lambda x:x**2-3*x
chk('c2.1.1',(f(4)-f(1))/3,2); chk('c2.1.2',D(f,2),1)
s=lambda t:t**3-6*t; chk('c2.1.3 avg',(s(3)-s(1))/2,7); chk('c2.1.3 inst',D(s,2),6)
chk('c2.2.1',D(lambda x:3*x**2-x,1.3),6*1.3-1); chk('c2.2.2',D(lambda x:1/x,2),-.25); chk('c2.2.3',D(lambda x:x**4,2),32,1e-5)
tx=[0,2,3,6,10]; fx=[5,9,10,4,-6]
chk('c2.3.1',(4-10)/(6-3),-2); chk('c2.3.2',(-6-4)/(10-6),-2.5); chk('c2.3.3',((2.1**3)-(1.9**3))/0.2,12.01)
chk('c2.4.1 L',Dl(lambda x:abs(x-3),3),-1); chk('c2.4.1 R',Dr(lambda x:abs(x-3),3),1)
a,b=2,-1; chk('c2.4.2 cont',a+b,1); chk('c2.4.2 slope',a,2)
assert 1e-9**(-1/3) > 1e2
chk('c2.5.2',D(lambda x:x**-1.5,4),-3/64); chk('c2.5.3',D(lambda x:x**4,2),32,1e-5)
chk('c2.6.1',D(lambda x:4*x**3-5*x**2+7*x-9,1),9); chk('c2.6.2',D(lambda x:3*sqrt(x)-6/x**2+pi**2,4),15/16)
for r in (3,-1): chk('c2.6.3 root %s'%r,D(lambda x:x**3-3*x**2-9*x+2,r),0,1e-6)
chk('c2.7.1',D(lambda x:3*sin(x)-2*cos(x)+5*exp(x),0),8); chk('c2.7.2',D(lambda x:4*log(x)-exp(x),1),4-e)
chk('c2.7.3',D(cos,pi/2),-1)
chk('c2.8.1',D(lambda x:x**2*exp(x),1),3*e); chk('c2.8.2',D(lambda x:x*log(x),e),2); chk('c2.8.3',(-1)*4+3*5,11)
chk('c2.9.1',D(lambda x:(2*x-1)/(x+3),1.2),7/(4.2)**2); chk('c2.9.2',D(lambda x:exp(x)/x**2,2),0); chk('c2.9.3',(2*3-6*(-1))/9,4/3)
chk('c2.10.1',D(lambda x:tan(x)-2*sec(x),pi/4),2-2*sqrt(2)); chk('c2.10.2',D(lambda x:x*cot(x),0.8),cot(.8)-.8*csc(.8)**2)
chk('c2.10.3',D(sec,pi/3),2*sqrt(3))

# ---------------- Part A ----------------
def mcq(n, opts, key, correct):
    L='ABCD'
    vals=list(opts)
    assert len(set(round(v,6) for v in vals))==4, 'options not distinct in item %d'%n
    chk('A/B item %d key %s'%(n,key), vals[L.index(key)], correct, 1e-5)
    # also guard: no other option equals the correct value
    for i,v in enumerate(vals):
        if i!=L.index(key): assert abs(v-correct)>1e-6*max(1,abs(correct)), 'duplicate correct value item %d'%n
h=1e-4
mcq(1,[0,12,6,8],'B',D(lambda x:x**3,2))
f2=lambda x:x**3-x
mcq(2,[2,6,3,11],'C',(f2(2)-f2(0))/2)
assert abs(D(f2,1)-2)<1e-6 and abs(D(f2,2)-11)<1e-6          # distractors A, D
f3=lambda x:x**3-8*sqrt(x)
mcq(3,[46,40,50,44],'A',D(f3,4)); chk('3 B',48-8*.5*sqrt(4),40); chk('3 C',48+2,50); chk('3 D',48-8*4**-.5,44)
f4=lambda x:x**3*log(x)
mcq(4,[3*e,e**2,3*e**2,4*e**2],'D',D(f4,e))
f5=lambda x:(x+1)/(x-1)
mcq(5,[1,-1,-.5,.5],'C',D(f5,3))
mcq(6,[1.7,6,13/6,3],'D',(16-10)/(6-4)); chk('6 A',(20-3)/10,1.7)
# 7: piecewise
def right(a,b,x): return a*x**2+b*x
def ok7(a,b): return abs(1-right(a,b,1))<1e-9 and abs(3-(2*a+b))<1e-9
res=[ok7(2,-1),ok7(3,-2),ok7(1,0),ok7(0,3)]
assert res==[True,False,False,False], res
print('ok   item 7 only (a,b)=(2,-1)')
# 8: graph with segments
def f8(x):
    if x<4: return 1+x if x<=2 else 3-(x-2)
    if x<=5: return 2
    return 2+2*(x-5)
# classify
cnt=0
for x0 in (1,2,3,4,5):
    jump=abs(f8(x0-1e-9)-f8(x0))>1e-6 if x0>0 else False
    # f8 at x0 uses the right-piece definition; left limit via x0-1e-9
    L=(f8(x0-1e-6)-f8(x0-2e-6))/1e-6; R=(f8(x0+2e-6)-f8(x0+1e-6))/1e-6
    nd = jump or abs(L-R)>1e-3
    cnt+=nd; print('   x=%s left slope %.3f right slope %.3f jump %s -> nondiff %s'%(x0,L,R,jump,nd))
chk('8 count',cnt,3)
assert abs(f8(4)-2)<1e-12 and abs(f8(4-1e-9)-1)<1e-6
sec3=1/cos(pi/3); t3=tan(pi/3)
f9=lambda x:2*sec(x)-tan(x)
mcq(9,[4*sqrt(3)+4,4,4*sqrt(3)-4,2*sqrt(3)-4],'C',D(f9,pi/3))
f10=lambda x:exp(x)/x
mcq(10,[e**2/4,3*e**2/4,e**2/2,e**2],'A',D(f10,2))
f11=lambda x:x**2*log(x)
mcq(11,[1,exp(-.5),exp(.5),exp(-2)],'B',exp(-.5)); chk('11 deriv zero',D(f11,exp(-.5)),0,1e-6)
# grid check that this is the only zero
xs=np.linspace(0.01,5,200001); d=np.array([2*x*log(x)+x for x in xs]); assert (np.sign(d[:-1])!=np.sign(d[1:])).sum()==1
mcq(12,[30,45,33,57],'C',2*3*(-2)+9*5)
chk('12 A',6*5,30); chk('12 D',12+45,57)
mcq(13,[0,.5,-sqrt(3)/2,sqrt(3)/2],'D',D(sin,pi/6)); 
for hh in (1e-3,1e-5): chk('13 numeric limit',(sin(pi/6+hh)-.5)/hh,sqrt(3)/2,1e-3)
# 14: counterexample f(x)=x^2 sin(1/x): differentiable at 0, f' not continuous
f14=lambda x:x**2*sin(1/x) if x!=0 else 0.0
chk('14 f\'(0)',(f14(1e-7)-0)/1e-7,0,1e-6)
vals=[2*x*sin(1/x)-cos(1/x) for x in (1/(2*pi*1000), 1/(2*pi*1000+pi))]
assert abs(vals[0]-vals[1])>1.5; print('ok   item 14: f\' oscillates near 0', vals)

# ---------------- Part B ----------------
f15=lambda x:exp(x)*log(x)
mcq(15,[exp(2)*log(2)-exp(2)/2,exp(2)/2,D(f15,2),exp(2)*log(2)],'C',D(f15,2))
chk('15 value 3dp',round(D(f15,2),3),8.816,1e-9)
chk('16 A',(57-71)/(9-5),-3.5); chk('16 B',(57-88)/7,-4.428571,1e-5); chk('16 C',(71-88)/3,-5.666667,1e-5)
mcq(16,[-3.5,-4.43,-5.67,3.5],'A',(57-71)/4)
g17=lambda x:2*x+exp(x)-5
r17=brentq(g17,0,3); chk('17 root 3dp',round(r17,3),1.059,1e-9)
r17b=brentq(lambda x:x**2+exp(x)-5,0,3); chk('17 A',round(r17b,3),1.241,1e-9); chk('17 B',round(log(5),3),1.609,1e-9)
mcq(17,[1.241,1.609,2.5,1.059],'D',round(r17,3))
f18=lambda x:x*tan(x)
mcq(18,[2.037,9.364,3.589,5.774],'B',round(D(f18,2),3))
chk('18 A deg',round(tan(radians(2))+2/cos(radians(2))**2,3),2.037,1e-9); chk('18 C',round(tan(2)+1/cos(2)**2,3),3.589,1e-9); chk('18 D',round(1/cos(2)**2,3),5.774,1e-9)
g19=lambda x:x**2/log(x)
mcq(19,[-2.976,3.269,2.976,18.0],'C',round(D(g19,3),3))
chk('19 B',round(3*(2*log(3)-1)/log(3),3),3.269,1e-9)
f20=lambda x:x**3*log(x)
yint=f20(2)-2*D(f20,2)
mcq(20,[-19.090,-24.636,5.545,12.318],'A',round(yint,3)); chk('20 B',round(-2*D(f20,2),3),-24.636,1e-9); chk('20 D',round(D(f20,2),3),12.318,1e-9)
f21=lambda x:x+2*sin(x)
xs=np.linspace(1e-6,10-1e-6,2000001); d=np.array(1+2*np.cos(xs)); n21=int((np.sign(d[:-1])!=np.sign(d[1:])).sum())
chk('21 count',n21,3); mcq(21,[2,4,6,3],'D',n21)
d2=1+2*np.cos(xs)  # cos=+-1/2 count
n6=int((np.sign(np.abs(np.cos(xs))-.5)[:-1]!=np.sign(np.abs(np.cos(xs))-.5)[1:]).sum()); chk('21 C (cos=+-1/2)',n6,6)

# ---------------- Part C ----------------
W=lambda t:3*t+t**2*log(t)
chk('22a',round((W(4)-W(1))/3,3),10.394,1e-9)
Wp=lambda t:3+2*t*log(t)+t
chk('22b formula',D(W,2.7),Wp(2.7)); chk('22b W\'(2)',round(Wp(2),3),7.773,1e-9)
chk('22c W(2)',round(W(2),3),8.773,1e-9); chk('22c slope',round(D(W,2),3),7.773,1e-9)
chk('22d',round((25-21)/1.5,3),2.667,1e-9)
# FRQ 23
fT={1:(4,-2),2:(5,6),3:(1,2)}; gT={1:(3,1),2:(2,3),3:(4,-1)}
chk('23a',fT[2][1]*gT[2][0]+fT[2][0]*gT[2][1],27)
pp=(fT[3][1]*gT[3][0]-fT[3][0]*gT[3][1])/gT[3][0]**2; chk('23b slope',pp,9/16); chk('23b point',fT[3][0]/gT[3][0],.25)
# 23c: solve a,b
a=fT[2][1]/gT[2][1]; b=fT[2][0]-a*gT[2][0]; chk('23c a',a,2); chk('23c b',b,1)
chk('23d w\'(3)',fT[3][1]-2,0); chk('23d w(3)',fT[3][0]-6,-5)

print()
print('FAILURES:', fails if fails else 'none')
assert not fails
