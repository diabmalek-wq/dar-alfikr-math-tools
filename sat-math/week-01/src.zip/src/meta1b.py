meta = dict(short="Lines \& Linear Functions",
 code="SAT-M \\textperiodcentered\\ W1-B", week="1", session="B",
 title="Lines, Slope \\& Linear Functions",
 topics="slope from points/graphs/tables \\textperiodcentered\\ forms of a line \\textperiodcentered\\ intercepts \\textperiodcentered\\ parallel \\& perpendicular \\textperiodcentered\\ translations \\textperiodcentered\\ meaning of slope/intercept \\textperiodcentered\\ linear function notation",
 skills=r"""
\begin{enumerate}[leftmargin=1.6em,itemsep=0pt,label=\textbf{S\arabic*.}]
\item Find slope from two points, a graph, a table, a standard-form equation, or a verbal rate.
\item Write and convert between slope-intercept, point-slope, standard and intercept forms.
\item Find $x$- and $y$-intercepts and use them (areas, conditions, context meaning).
\item Parallel and perpendicular lines, including directly from $Ax+By=C$.
\item Translate a line (up/down/left/right) and track slope and intercepts.
\item Interpret slope and intercept in context; build $f(x)=mx+b$ from data and solve for inputs.
\item Coordinate reasoning: collinearity, midpoint, perpendicular bisector, triangles cut by axes.
\item Parameter conditions on lines (a constant fixes slope, intercept, perpendicularity or area).
\end{enumerate}""",
 facts=r"""
\begin{itemize}[leftmargin=1.4em,itemsep=0pt]
\item Slope $=\dfrac{\text{rise}}{\text{run}}=$ constant rate of change; the $y$-intercept is the value at $x=0$; the $x$-intercept is where $y=0$.
\item Horizontal line $y=c$: slope $0$. Vertical line $x=c$: slope undefined.
\item Parallel $\iff$ equal slopes (different intercepts). Perpendicular $\iff$ slopes are negative reciprocals (product $-1$).
\item A function is linear if equal steps in $x$ give equal steps in $y$ (check every gap in a table).
\item Shifting a graph up $k$ adds $k$ to $y$; slope never changes under a translation.
\item Two points determine a line; on a graph read only points that sit exactly on grid intersections.
\end{itemize}""",
 formulas=r"""
\vspace{-4pt}\[
m=\dfrac{y_2-y_1}{x_2-x_1},\qquad y=mx+b,\qquad y-y_1=m(x-x_1),\qquad \dfrac xa+\dfrac yb=1
\]
\vspace{-8pt}\[
Ax+By=C:\ \ m=-\dfrac AB,\ \ \text{$x$-int }\dfrac CA,\ \ \text{$y$-int }\dfrac CB,\qquad \text{area with axes}=\dfrac12\left|\dfrac CA\cdot\dfrac CB\right|
\]
\vspace{-8pt}\[
\parallel:\ A_1B_2=A_2B_1,\qquad \perp:\ A_1A_2+B_1B_2=0,\qquad \text{midpoint}=\left(\dfrac{x_1+x_2}2,\dfrac{y_1+y_2}2\right),\qquad f(a+d)-f(a)=md
\]""",
 theory=r"""
\textbf{Choose the form by the data.}
\begin{center}\begin{tabular}{@{}ll@{}}\toprule
Given & Fastest route\\\midrule
two points & $m=\frac{\Delta y}{\Delta x}$, then point-slope with either point\\
slope and $y$-intercept & $y=mx+b$ directly\\
both intercepts $(a,0),(0,b)$ & $\frac xa+\frac yb=1$, or $m=-\frac ba$\\
$Ax+By=C$ & read $m=-\frac AB$; set $x=0$ or $y=0$ for intercepts\\
a table & $m$ from any two rows; confirm the rest have the same $m$\\\bottomrule\end{tabular}\end{center}
\textbf{Perpendicular in standard form.} Swap the coefficients and negate one: $\perp$ to $Ax+By=C$ is $Bx-Ay=C'$; find $C'$ from the given point.
\textbf{Parallel in standard form.} Keep $A,B$ (or scale both), change only $C$.
\textbf{Translation.} Down $k$: $b\to b-k$, and the $x$-intercept moves by $\frac km$. Same slope, always.
\textbf{Meaning.} In $y=mx+b$: $m$ = change in $y$ per $1$ unit of $x$; $b$ = starting value. Units of $m$ are (units of $y$)/(units of $x$).
\textbf{Constant conditions.} Turn the condition (slope, perpendicular, area, collinear) into one equation in the constant, then solve.
\textbf{Whole-number contexts.} Solve $f(x)=\text{target}$; if $x$ must be a whole day/trip/session, round to the first value that \emph{reaches} the target.""")
