from lib import *
S=Fraction
exec(open('meta1b.py').read())
guided=r"""
\begin{cbox}[title={Example 1 \textemdash\ Two points $\to$ equation $\to$ intercepts}]{TEAL}
A line passes through $(-1,7)$ and $(3,-1)$. Find its equation and both intercepts.\\[2pt]
$m=\dfrac{-1-7}{3-(-1)}=\dfrac{-8}{4}=-2$. Point-slope: $y-7=-2(x+1)\Rightarrow y=-2x+5$.\\
$y$-intercept $5$; $x$-intercept: $0=-2x+5\Rightarrow x=\frac52$.
\end{cbox}
\begin{cbox}[title={Example 2 \textemdash\ Perpendicular through a point (standard form)}]{TEAL}
Line $\ell$: $4x-3y=12$. Write the line through $(2,-1)$ perpendicular to $\ell$.\\[2pt]
Swap and negate: $3x+4y=C'$. Plug in $(2,-1)$: $C'=3(2)+4(-1)=2$. Answer: $3x+4y=2$.
\end{cbox}
\begin{cbox}[title={Example 3 \textemdash\ Meaning of slope and intercept}]{TEAL}
A gym plan costs $\$340$ after $2$ months and $\$640$ after $5$ months (linear). Write $C(m)$ and interpret its parts.\\[2pt]
$\text{slope}=\dfrac{640-340}{5-2}=100$. $C(m)=100m+b$; $340=200+b\Rightarrow b=140$. So $C(m)=100m+140$.\\
$100$ = dollars per month; $140$ = joining fee (cost at $m=0$).
\end{cbox}"""
P=[]
def add(lv,q,steps,ans=None,val=None,chk=None,opts=None,correct=None,tool='N',fig=None,src=''):
    d=dict(lv=lv,q=q,steps=steps,chk=chk,tool=tool,src=src)
    if opts is not None: d['opts']=opts;d['correct']=correct
    else: d['ans']=ans;d['val']=val
    if fig:d['fig']=fig
    P.append(d)
sl=lambda p1,p2:S(p2[1]-p1[1])/(p2[0]-p1[0])
# ---------- EASY
add('E',r"The function $f$ is defined by $f(x)=15x+10$. What is the value of $f(x)$ when $x=2$?",
 [r"Substitute $x=2$: $f(2)=15(2)+10$.",r"$f(2)=30+10=40$."],
 opts=[r"$27$",r"$30$",r"$40$",r"$50$"],correct=2,chk=lambda:('idx',[27,30,40,50].index(15*2+10)),src='new S1M1-2')
def e2():
    lines={'21x+4':(21,4),'4x+21':(4,21),'4x-21':(4,-21),'-4x+21':(-4,21)}
    ok=[i for i,(m,b) in enumerate(lines.values()) if b==21 and m==4]
    return ('idx',ok[0])
add('E',r"In the $xy$-plane, the graph of $y=f(x)$ is a line that passes through $(0,21)$ and has a slope of $4$. Which equation defines $f$?",
 [r"The line crosses the $y$-axis at $(0,21)$, so $b=21$.",r"The slope is $m=4$.",r"$f(x)=4x+21$."],
 opts=[r"$f(x)=21x+4$",r"$f(x)=4x+21$",r"$f(x)=4x-21$",r"$f(x)=-4x+21$"],correct=1,chk=e2,src='new S1M1-3')
add('E',r"A line has a slope of $-3$ and passes through the point $(5,-2)$. What is the $y$-intercept of the line?",
 [r"Use $y=mx+b$ with $m=-3$ and the point $(5,-2)$: $-2=-3(5)+b$.",r"$-2=-15+b$.",r"$b=13$."],
 ans="13",val=13,chk=lambda:-2-(-3*5),src='old A-094')
add('E',r"What is the $x$-intercept of the line given by $3x+4y=24$?",
 [r"At an $x$-intercept, $y=0$.",r"$3x=24$, so $x=8$.",r"The $x$-intercept is the point $(8,0)$."],
 opts=[r"$(0,6)$",r"$(0,8)$",r"$(6,0)$",r"$(8,0)$"],correct=3,chk=lambda:('idx',[(0,6),(0,8),(6,0),(8,0)].index((S(24,3),0))),src='old A-083')
add('E',r"The function $g$ is defined by $g(x)=\dfrac{x+1}{5}$. What is the $y$-intercept of the graph of $y=g(x)$ in the $xy$-plane?",
 [r"The $y$-intercept occurs at $x=0$.",r"$g(0)=\dfrac{0+1}{5}=\dfrac15$.",r"The $y$-intercept is $\left(0,\dfrac15\right)$."],
 opts=[r"$(0,5)$",r"$\left(0,\dfrac15\right)$",r"$(0,1)$",r"$(-1,0)$"],correct=1,chk=lambda:('idx',1 if (S(0)+1)/5==S(1,5) else -1),src='new S1M2-6')
add('E',r"A line passes through the points $(0,2)$ and $(3,3)$. What is the slope of the line?",
 [r"$m=\dfrac{y_2-y_1}{x_2-x_1}=\dfrac{3-2}{3-0}$.",r"$m=\dfrac13$."],
 ans=r"\dfrac{1}{3}",val=1/3,chk=lambda:float(sl((0,2),(3,3))),src='new S5M1-10')
# ---------- MEDIUM
add('M',r"The function $f$ is linear. Selected values of $x$ and $f(x)$ are shown in the table. What is the value of $f(0)$?\par\begin{center}\begin{tabular}{|c|c|}\hline $x$&$f(x)$\\\hline $2$&$11$\\\hline $5$&$20$\\\hline\end{tabular}\end{center}",
 [r"Slope: $\dfrac{20-11}{5-2}=3$.",r"From $x=2$ back to $x=0$ is a step of $-2$ in $x$, so $f$ drops by $3\cdot2=6$.",r"$f(0)=11-6=5$."],
 opts=[r"$2$",r"$5$",r"$8$",r"$11$"],correct=1,chk=lambda:('idx',[2,5,8,11].index(11-sl((2,11),(5,20))*2)),src='old A-001')
add('M',r"The graph of $\dfrac x4+\dfrac y6=1$ in the $xy$-plane is a line. What is the slope of this line?",
 [r"This is intercept form: intercepts $(4,0)$ and $(0,6)$.",r"$m=\dfrac{6-0}{0-4}=-\dfrac32$."],
 opts=[r"$-\dfrac23$",r"$-\dfrac32$",r"$\dfrac23$",r"$\dfrac32$"],correct=1,chk=lambda:('idx',[S(-2,3),S(-3,2),S(2,3),S(3,2)].index(sl((4,0),(0,6)))),src='old A-036')
add('M',r"Line $k$ is parallel to the line $y=-2x+7$ and passes through the point $(4,5)$. Which of the following is an equation of line $k$?",
 [r"Parallel lines have equal slopes, so $m=-2$.",r"$5=-2(4)+b\Rightarrow b=13$.",r"$y=-2x+13$."],
 opts=[r"$y=-2x+7$",r"$y=-2x+13$",r"$y=-2x+5$",r"$y=\dfrac12x+3$"],correct=1,chk=lambda:('idx',[(-2,7),(-2,13),(-2,5),(S(1,2),3)].index((-2,5-(-2)*4))),src='old A-084')
add('M',r"Line $t$ is defined by $y=4x+15$. Line $s$ is perpendicular to line $t$. What is the slope of line $s$?",
 [r"Perpendicular slopes are negative reciprocals.",r"$m_s=-\dfrac{1}{4}$."],
 opts=[r"$-4$",r"$-\dfrac14$",r"$\dfrac14$",r"$4$"],correct=1,chk=lambda:('idx',[-4,S(-1,4),S(1,4),4].index(S(-1,4))),src='new S3M1-8')
add('M',r"A line passes through the points $(2,11)$ and $(6,27)$. What is an equation of the line?",
 [r"$m=\dfrac{27-11}{6-2}=4$.",r"Use $(2,11)$: $11=4(2)+b\Rightarrow b=3$.",r"$y=4x+3$. Check $(6,27)$: $4(6)+3=27$."],
 opts=[r"$y=4x+3$",r"$y=4x-3$",r"$y=3x+5$",r"$y=4x+11$"],correct=0,chk=lambda:('idx',[(4,3),(4,-3),(3,5),(4,11)].index((sl((2,11),(6,27)),11-sl((2,11),(6,27))*2))),src='old A-080')
add('M',r"A book club charges $\$13$ for the first book and $\$11$ for each additional book. Which equation gives the total cost $y$, in dollars, for $x$ books, where $x\ge1$?",
 [r"Total $=13+11(x-1)$ (the first book costs $13$; the other $x-1$ cost $11$ each).",r"$13+11x-11=11x+2$."],
 opts=[r"$y=11x+13$",r"$y=11x+2$",r"$y=13x+11$",r"$y=11x-2$"],correct=1,chk=lambda:('idx',[ (11,13),(11,2),(13,11),(11,-2)].index((11,13-11))),src='new S1M2-12')
add('M',r"A linear function models the total cost, in dollars, of a field trip as $C(n)=25n+400$, where $n$ is the number of students attending. What does the number $25$ represent in this context?",
 [r"In $y=mx+b$, $m$ is the change in $y$ per $1$ unit of $x$.",r"Here each additional student adds $\$25$ to the total cost."],
 opts=[r"Fixed cost of the trip",r"Cost for $25$ students",r"Cost of each additional student",r"Students needed to cover the fixed cost"],correct=2,chk=lambda:('idx',2),src='old A-079')
add('M',r"For the linear function $g$, $g(9)=11$ and $g(x+1)-g(x)=2$ for all $x$. Which equation defines $g$?",
 [r"$g(x+1)-g(x)=2$ means the slope is $2$.",r"$11=2(9)+b\Rightarrow b=-7$.",r"$g(x)=2x-7$."],
 opts=[r"$g(x)=9x+2$",r"$g(x)=2x+11$",r"$g(x)=2x-7$",r"$g(x)=2x+9$"],correct=2,chk=lambda:('idx',[(9,2),(2,11),(2,11-2*9),(2,9)].index((2,11-2*9))),src='new S4M1-14')
def gline():
    return ('idx',[(-2,S(3,2)),(S(-1,2),3),(2,S(3,2)),(S(-1,2),S(3,2))].index((sl((0,S(3,2)),(3,0)),S(3,2))))
add('M',r"The graph of a linear relationship is shown. Which equation represents the line?",
 [r"Read two lattice-friendly points: $(0,1.5)$ and $(3,0)$.",r"$m=\dfrac{0-1.5}{3-0}=-\dfrac12$; the $y$-intercept is $1.5$.",r"$y=-\dfrac12x+\dfrac32$."],
 opts=[r"$y=-2x+\dfrac32$",r"$y=-\dfrac12x+3$",r"$y=2x+\dfrac32$",r"$y=-\dfrac12x+\dfrac32$"],correct=3,chk=gline,src='new S3M2-12',
 fig=fig(axes(-2,5,-2,4,1,1)+r"""
\draw[ln] (-1.5,2.25)--(4.5,-0.75);
\node[pt] at (0,1.5) {};\node[pt] at (3,0) {};
\node[font=\scriptsize,above right] at (0,1.5) {$(0,1.5)$};\node[font=\scriptsize,above right] at (3,0) {$(3,0)$};""",xu=0.85,yu=0.85))
# ---------- HARD
add('H',r"For the linear function $h$, $h(k)=c$ and $h(k+5)=c+15$, where $c$ and $k$ are constants. What is the value of $h(k+2)-h(k)$?",
 [r"A change of $5$ in the input changes the output by $15$, so the slope is $\dfrac{15}{5}=3$.",r"$h(k+2)-h(k)=3\cdot2=6$."],
 ans="6",val=6,chk=lambda:S(15,5)*2,src='old A-004')
add('H',r"The function $g$ is linear, and $g(a+3)=g(a)+15$ for all values of $a$. If $g(0)=-4$, what is the value of $g(6)$?",
 [r"A step of $3$ in the input adds $15$: slope $=5$.",r"$g(6)=g(0)+5\cdot6=-4+30=26$."],
 ans="26",val=26,chk=lambda:-4+S(15,3)*6,src='old A-025')
add('H',r"If $f(x)=4x-3$ and $f(2a)=3f(a)+7$, what is the value of $a$?",
 [r"$f(2a)=4(2a)-3=8a-3$.",r"$3f(a)+7=3(4a-3)+7=12a-2$.",r"$8a-3=12a-2\Rightarrow-4a=1\Rightarrow a=-\dfrac14$."],
 ans=r"-\dfrac{1}{4}",val=-0.25,chk=lambda:float(S(-2+3,8-12)),src='old A-034')
add('H',r"For the linear function $h$, $h(3)=20$ and $h(7)=44$. What is the value of $x$ for which $h(x)=62$?",
 [r"Slope: $\dfrac{44-20}{7-3}=6$.",r"$h(x)=44+6(x-7)$.",r"Set equal to $62$: $6(x-7)=18\Rightarrow x-7=3\Rightarrow x=10$."],
 ans="10",val=10,chk=lambda:7+S(62-44)/sl((3,20),(7,44)),src='old A-081')
add('H',r"For linear function $p$, $p(c)=-6$, $p(5)=42$, and the slope of the graph of $p$ is $8$. For linear function $t$, $t(c)=-7$ and $t(6)=56$. What is the slope of the graph of $t$?",
 [r"For $p$: $\dfrac{42-(-6)}{5-c}=8\Rightarrow5-c=6\Rightarrow c=-1$.",r"For $t$: the points are $(-1,-7)$ and $(6,56)$.",r"Slope of $t$: $\dfrac{56-(-7)}{6-(-1)}=\dfrac{63}{7}=9$."],
 ans="9",val=9,chk=lambda:(lambda c:sl((c,-7),(6,56)))(5-S(42+6,8)),src='new S2M2-10')
add('H',r"Line $\ell$ passes through the point $(-2,5)$ and is perpendicular to the line $3x-4y=12$. What is the $y$-intercept of line $\ell$?",
 [r"The given line has slope $\dfrac34$, so $\ell$ has slope $-\dfrac43$.",r"$5=-\dfrac43(-2)+b=\dfrac83+b$.",r"$b=5-\dfrac83=\dfrac73$."],
 ans=r"\dfrac{7}{3}",val=7/3,chk=lambda:float(5-(S(-4,3))*(-2)),src='old A-134')
add('H',r"$$4x-6y=10y+2$$ $$ty=\dfrac12+2x$$ In the system above, $t$ is a constant. If the system has no solution, what is the value of $t$?",
 [r"First equation: $4x-16y=2\Rightarrow y=\dfrac14x-\dfrac18$.",r"Second equation: $y=\dfrac2tx+\dfrac1{2t}$.",r"No solution means parallel, distinct lines: $\dfrac2t=\dfrac14\Rightarrow t=8$.",r"Intercepts: $\dfrac1{16}\ne-\dfrac18$, so the lines are distinct. $t=8$."],
 ans="8",val=8,chk=lambda:S(2)/S(1,4),src='old A-076')
add('H',r"In an arithmetic sequence, the $3^{\text{rd}}$ term is $17$ and the $10^{\text{th}}$ term is $52$. What is the $20^{\text{th}}$ term?",
 [r"Common difference: $d=\dfrac{52-17}{10-3}=5$.",r"$a_{20}=a_{10}+10d=52+50=102$."],
 ans="102",val=102,chk=lambda:52+10*S(52-17,7),src='old A-135')
# ---------- CHALLENGE
add('C',r"In the $xy$-plane, line $k$ has slope $\dfrac23$ and passes through $(6,-1)$. Line $m$ is perpendicular to line $k$ and has the same $y$-intercept as line $k$. What is the $x$-coordinate of the $x$-intercept of line $m$?",
 [r"Line $k$: $-1=\dfrac23(6)+b\Rightarrow b=-5$.",r"Line $m$ has slope $-\dfrac32$ and $y$-intercept $-5$: $y=-\dfrac32x-5$.",r"Set $y=0$: $-\dfrac32x=5\Rightarrow x=-\dfrac{10}{3}$."],
 ans=r"-\dfrac{10}{3}",val=-10/3,chk=lambda:float(-(-1-S(2,3)*6)/(S(-3,2))*-1*-1) if False else float((lambda b:-b/S(-3,2))(-1-S(2,3)*6)),src='original')
add('C',r"For a positive constant $K$, the line $3x+4y=K$ and the two coordinate axes bound a triangle of area $54$. What is the value of $K$?",
 [r"Intercepts: $x=\dfrac K3$ and $y=\dfrac K4$.",r"Area $=\dfrac12\cdot\dfrac K3\cdot\dfrac K4=\dfrac{K^2}{24}$.",r"$\dfrac{K^2}{24}=54\Rightarrow K^2=1296\Rightarrow K=36$."],
 ans="36",val=36,chk=lambda:[K for K in range(1,200) if S(K,3)*S(K,4)/2==54][0],src='original')
P=prep(P)
if __name__=="__main__":
    print(len(P),[(p['lv'],p.get('correct')) for p in P])
    build(meta,guided,P,'ws','W1B_ws.tex');build(meta,guided,P,'key','W1B_key.tex')
