from lib import *
S=Fraction
def sol(f):
    f0=f(S(0));f1=f(S(1));return -f0/(f1-f0)
meta=dict(short="Linear Equations",code="SAT-M \\textperiodcentered\\ W1-A",week="1",session="A",
 title="Linear Equations: Structure, Rearranging \\& Translating",
 topics="one-variable equations \\textperiodcentered\\ solution-count structure \\textperiodcentered\\ identities \\& coefficient matching \\textperiodcentered\\ literal equations \\textperiodcentered\\ word translation \\textperiodcentered\\ inequalities",
 skills=r"""
\begin{enumerate}[leftmargin=1.6em,itemsep=0pt,label=\textbf{S\arabic*.}]
\item Solve any linear equation (distribute, LCD for fractions/decimals, collect, divide).
\item Spot a repeated \emph{block} and solve for the block instead of the variable.
\item Decide \emph{one / none / infinitely many} solutions by comparing coefficients, before solving.
\item Match coefficients when an equation is true for every $x$; solve for constants.
\item Rearrange literal equations (make any letter the subject).
\item Translate words: ``less than'', consecutive integers, ratios, fixed-plus-rate, ages.
\item Linear inequalities: sign flip, compound statements, integer counts, rounding to a feasible whole number.
\item Absolute-value equations: split into two cases and test each answer.
\end{enumerate}""",
 facts=r"""
\begin{itemize}[leftmargin=1.4em,itemsep=0pt]
\item Equal operations on both sides keep an equation true; multiplying or dividing an inequality by a negative number reverses it.
\item ``$n$ less than $m$'' $=m-n$; ``at least'' $\ge$; ``at most'' / ``no more than'' $\le$; ``more than'' $>$.
\item Consecutive integers differ by $1$; consecutive \emph{even or odd} integers differ by $2$.
\item A ratio $a:b=m:n$ means $a=mt,\ b=nt$; the whole is $(m+n)t$.
\item $|u|=v$ means $u=v$ or $u=-v$, and requires $v\ge0$.
\item A sequence with a constant difference $d$ has $n$th term $a_1+(n-1)d$.
\end{itemize}""",
 formulas=r"""
\vspace{-4pt}\[
ax+b=cx+d\ \Longrightarrow\ (a-c)x=d-b,\qquad x=\dfrac{d-b}{a-c}\ \ (a\neq c)
\]
\vspace{-8pt}\[
P_{\text{rect}}=2(\ell+w),\qquad \text{total}=\text{fixed fee}+\text{rate}\times\text{quantity}
\]
\vspace{-8pt}\[
n,\ n+2,\ n+4,\ n+6\ \ (\text{consecutive odd}),\qquad \text{sum of }k\text{ terms}=k\cdot\text{(mean)}
\]""",
 theory=r"""
\textbf{Master reduction.} Every linear equation collapses to $mx=n$. Then:
\begin{center}\begin{tabular}{@{}lll@{}}\toprule
$m\ne0$ & one solution & $x=\dfrac nm$\\
$m=0,\ n\ne0$ & no solution & $0=n$ is false\\
$m=0,\ n=0$ & infinitely many & $0=0$ is true for all $x$\\\bottomrule\end{tabular}\end{center}
\textbf{Identity in $x$.} If two expressions are equal for every $x$, the coefficients of $x$ match \emph{and} the constants match.
\textbf{Block rule.} If an expression $E$ occurs, $cE=k\Rightarrow E=\frac kc$; scale or shift the block, never expand it.
\textbf{Inequalities.} Same steps as equations; reverse only on $\times/\div$ by a negative. Compound: operate on all three parts.
\textbf{Contexts.} Fixed + rate: $y=\text{fee}+\text{rate}\cdot n$. For ``at most'' counts solve, then round down; for ``at least'' counts round up.
\textbf{Absolute value.} Solve $u=v$ and $u=-v$, then substitute each answer into the original equation.""")
guided=r"""
\begin{cbox}[title={Example 1 \textemdash\ Structure first (parameter)}]{TEAL}
For what value of $k$ does $4(x-2)+k=4x-3$ have infinitely many solutions?\\[2pt]
Expand: $4x-8+k=4x-3$. The $x$-coefficients agree, so the constants must agree: $k-8=-3$, so $k=5$.
\end{cbox}
\begin{cbox}[title={Example 2 \textemdash\ Fractions: clear with the LCD}]{TEAL}
Solve $\dfrac{x+1}{2}-\dfrac{x-3}{5}=2$.\\[2pt]
LCD $=10$: $5(x+1)-2(x-3)=20\ \Rightarrow\ 3x+11=20\ \Rightarrow\ x=3$.
\end{cbox}
\begin{cbox}[title={Example 3 \textemdash\ Words $\to$ equation (consecutive integers)}]{TEAL}
The sum of three consecutive even integers is $54$. What is the largest?\\[2pt]
Let them be $n,\ n+2,\ n+4$: $3n+6=54\Rightarrow n=16$. The integers are $16,\,18,\,20$; the largest is $20$.
\end{cbox}"""
P=[]
def add(lv,q,steps,ans=None,val=None,chk=None,opts=None,correct=None,tool='N',fig=None,src=''):
    d=dict(lv=lv,q=q,steps=steps,chk=chk,tool=tool,src=src)
    if opts is not None: d['opts']=opts;d['correct']=correct
    else: d['ans']=ans;d['val']=val
    if fig:d['fig']=fig
    P.append(d)
# ---- EASY
add('E',r"If $f(x)=6(2x+4)$, for what value of $x$ is $f(x)=48$?",
 [r"Set $6(2x+4)=48$ and divide by $6$: $2x+4=8$.",r"Subtract $4$: $2x=4$.",r"Divide by $2$: $x=2$."],
 opts=[r"$2$",r"$4$",r"$6$",r"$8$"],correct=0,chk=lambda:('idx',[2,4,6,8].index(sol(lambda x:6*(2*x+4)-48))),src='new S5M1-4')
add('E',r"What value of $x$ satisfies the equation $\dfrac{2x+5}{3}=x-4$?",
 [r"Multiply both sides by $3$: $2x+5=3x-12$.",r"Subtract $2x$ and add $12$: $17=x$."],
 opts=[r"$-7$",r"$7$",r"$17$",r"$27$"],correct=2,chk=lambda:('idx',[-7,7,17,27].index(sol(lambda x:(2*x+5)/3-(x-4)))),src='old A-016')
def e3():
    f=lambda v:-5*(v-1)<=3*(v+3)
    opt=[lambda v:v<=S(-1,2),lambda v:v>=S(-1,2),lambda v:v>=S(1,2),lambda v:v<=S(1,2)]
    g=[S(i,4) for i in range(-12,13)]
    return ('idx',[i for i,o in enumerate(opt) if all(o(v)==f(v) for v in g)][0])
add('E',r"The inequality $-5(x-1)\le3(x+3)$ is equivalent to which of the following?",
 [r"Distribute: $-5x+5\le3x+9$.",r"Subtract $3x$ and $5$: $-8x\le4$.",r"Divide by $-8$ and reverse the inequality: $x\ge-\tfrac12$."],
 opts=[r"$x\le-\dfrac12$",r"$x\ge-\dfrac12$",r"$x\ge\dfrac12$",r"$x\le\dfrac12$"],correct=1,chk=e3,src='old A-126')
def e4():
    P_=[S(v) for v in (2,3,7,11)]
    cands=[lambda p:(6*p-3)/5,lambda p:(5*p+3)/6,lambda p:(6*p+3)/5,lambda p:p/5+3]
    return ('idx',[i for i,cd in enumerate(cands) if all(p_==(5*cd(p_)-3)/6 for p_ in P_)][0])
add('E',r"If $p=\dfrac{5q-3}{6}$, which expression is equal to $q$?",
 [r"Multiply by $6$: $6p=5q-3$.",r"Add $3$: $6p+3=5q$.",r"Divide by $5$: $q=\dfrac{6p+3}{5}$."],
 opts=[r"$\dfrac{6p-3}{5}$",r"$\dfrac{5p+3}{6}$",r"$\dfrac{6p+3}{5}$",r"$\dfrac p5+3$"],correct=2,chk=e4,src='old A-127')
add('E',r"$7x+28=7x+k$. The equation has infinitely many solutions. What is the value of $k$?",
 [r"The $x$-coefficients already match ($7=7$).",r"Infinitely many solutions requires the constants to match: $k=28$."],
 ans="28",val=28,chk=None,src='new S2M1-5')
# above chk: for k=28 identity -> solve returns [] ... fix: use dsimplify
P[-1]['chk']=lambda:[kk for kk in range(-50,60) if all(7*xx+28==7*xx+kk for xx in (0,1,5))][0]
add('E',r"If $58=22+3(x-5)$, what is the value of $3(x-5)$?",
 [r"Treat $3(x-5)$ as one block.",r"Subtract $22$ from both sides: $3(x-5)=58-22=36$."],
 ans="36",val=36,chk=lambda:58-22,src='old A-060')
# ---- MEDIUM
add('M',r"$m$, $n$, and $p$ are three consecutive positive odd integers with $m<n<p$. Their sum is $63$. What is the value of $mp$?",
 [r"Let the integers be $n-2,\ n,\ n+2$. Their sum is $3n=63$, so $n=21$.",r"Then $m=19$ and $p=23$.",r"$mp=19\cdot23=437$."],
 ans="437",val=437,chk=lambda:(sol(lambda x:3*x-63)-2)*(sol(lambda x:3*x-63)+2),src='old A-118')
add('M',r"What is the solution to $\dfrac{3x+5}{4}=\dfrac{4x-1}{5}$?",
 [r"Cross-multiply: $5(3x+5)=4(4x-1)$.",r"Expand: $15x+25=16x-4$.",r"Subtract $15x$ and add $4$: $29=x$."],
 ans="29",val=29,chk=lambda:sol(lambda x:(3*x+5)/S(4)-(4*x-1)/S(5)),src='old A-129')
add('M',r"If $\dfrac{3m}{4}+2=8$, what is the value of $\dfrac{5}{2m}$?",
 [r"Subtract $2$: $\dfrac{3m}{4}=6$.",r"Multiply by $\dfrac43$: $m=8$.",r"$\dfrac{5}{2m}=\dfrac{5}{16}$."],
 ans=r"\dfrac{5}{16}",val=0.3125,chk=lambda:float(5/(2*sol(lambda x:3*x/S(4)+2-8))),src='old A-128')
add('M',r"A woodworker charges a one-time fee of $\$45$ plus $\$17$ for each hour of work. The total charge for one job was $\$164$. For how many hours did the woodworker work?",
 [r"Write $45+17h=164$.",r"Subtract $45$: $17h=119$.",r"Divide by $17$: $h=7$."],
 opts=[r"$5$",r"$7$",r"$9$",r"$119$"],correct=1,chk=lambda:('idx',[5,7,9,119].index(sol(lambda x:45+17*x-164))),src='new S5M1-2')
add('M',r"A van can carry at most $3{,}600$ kg. It is already loaded with $40$ boxes of $25$ kg each. Each additional crate weighs $18$ kg. What is the greatest number of additional crates that can be loaded?",
 [r"Current load: $40\cdot25=1000$ kg, leaving $2600$ kg of capacity.",r"Inequality: $18c\le2600$, so $c\le144.4\ldots$",r"Only whole crates can be added, so round down: $144$."],
 ans="144",val=144,tool='C',chk=lambda:int((3600-40*25)//18),src='old A-021')
def m7():
    lo,hi=20-60,30-45
    opts=[(-15,40),(-40,-15),(15,40),(-40,15)]
    return ('idx',opts.index((lo,hi)))
add('M',r"Let $a$ and $b$ be numbers such that $20<a<30$ and $45<b<60$. Which of the following represents all possible values of $a-b$?",
 [r"Smallest $a-b$: use the smallest $a$ and the largest $b$: $20-60=-40$.",r"Largest $a-b$: use the largest $a$ and the smallest $b$: $30-45=-15$.",r"So $-40<a-b<-15$."],
 opts=[r"$-15<a-b<40$",r"$-40<a-b<-15$",r"$15<a-b<40$",r"$-40<a-b<15$"],correct=1,chk=m7,src='old A-123/A-037')
add('M',r"The solution to $3x-k=87$ is $x=174$, where $k$ is a constant. What is the value of $k$?",
 [r"Substitute $x=174$: $3(174)-k=87$.",r"$522-k=87$.",r"$k=522-87=435$."],
 ans="435",val=435,chk=lambda:sol(lambda k:3*174-k-87),src='new S5M2-15')
def m9():
    vals=[(S(3),S(5),S(7)),(S(2),S(9),S(4))]
    cands=[lambda N,Sv,pv:Sv*pv/N-1,lambda N,Sv,pv:N/(Sv*pv)+1,lambda N,Sv,pv:Sv*pv/N+1,lambda N,Sv,pv:(Sv*pv+1)/N]
    return ('idx',[i for i,cd in enumerate(cands) if all(N==Sv*pv/(cd(N,Sv,pv)-1) for N,Sv,pv in vals)][0])
add('M',r"$N=\dfrac{Sp}{q-1}$, where $N$, $S$, and $p$ are nonzero. Which expression is equal to $q$?",
 [r"Multiply by $(q-1)$: $N(q-1)=Sp$.",r"Divide by $N$: $q-1=\dfrac{Sp}{N}$.",r"Add $1$: $q=\dfrac{Sp}{N}+1$."],
 opts=[r"$\dfrac{Sp}{N}-1$",r"$\dfrac{N}{Sp}+1$",r"$\dfrac{Sp}{N}+1$",r"$\dfrac{Sp+1}{N}$"],correct=2,chk=m9,src='old A-033')
add('M',r"Daniel is now five times as old as his sister Emma. In $4$ years, Daniel will be three times as old as Emma will be then. How old is Daniel now?",
 [r"Let Emma's age be $e$; Daniel's is $5e$.",r"In $4$ years: $5e+4=3(e+4)$.",r"$5e+4=3e+12\Rightarrow2e=8\Rightarrow e=4$.",r"Daniel is $5e=20$."],
 ans="20",val=20,chk=lambda:5*sol(lambda x:5*x+4-3*(x+4)),src='old A-119 (reworked)')
# ---- HARD
add('H',r"$a(7x-14)+5a=7(ax-2a)-35$. For what value of $a$ does the equation have infinitely many solutions?",
 [r"Left side: $7ax-14a+5a=7ax-9a$.",r"Right side: $7ax-14a-35$.",r"The $x$-terms match. Constants must match: $-9a=-14a-35$.",r"$5a=-35$, so $a=-7$."],
 ans="-7",val=-7,chk=lambda:[v for v in range(-30,30) if all(v*(7*xx-14)+5*v==7*(v*xx-2*v)-35 for xx in (0,1,4))][0],src='new S1M2-9')
add('H',r"If $a(x-3)+5=bx-2a+11$ is true for all values of $x$, where $a$ and $b$ are constants, what is the value of $a$?",
 [r"Expand the left side: $ax-3a+5$.",r"Match $x$-coefficients: $a=b$.",r"Match constants: $-3a+5=-2a+11$.",r"$-6=a$."],
 ans="-6",val=-6,chk=lambda:sol(lambda a:-3*a+5-(-2*a+11)),src='old A-017')
add('H',r"$$\dfrac{18x+24}{6}-\dfrac{s}{11}=r(x-9)$$ In the equation above, $s$ and $r$ are constants and $s>0$. If the equation has infinitely many solutions, what is the value of $s$?",
 [r"Simplify the left side: $3x+4-\dfrac s{11}$. Right side: $rx-9r$.",r"Match $x$-coefficients: $r=3$.",r"Match constants: $4-\dfrac s{11}=-27$.",r"$\dfrac s{11}=31$, so $s=341$."],
 ans="341",val=341,chk=lambda:sol(lambda s:4-s/S(11)+27),src='old A-059')
def h4():
    ok=[m_ for m_ in (8,10,12,16) if m_%6==0 and S(m_,2)-S(m_,3)==m_//6]
    return ('idx',[8,10,12,16].index(ok[0]))
add('H',r"Let $m$ and $n$ be positive integers such that one-third of $m$ is $n$ less than one-half of $m$. Which of the following could be the value of $m$?",
 [r"Translate: $\dfrac m3=\dfrac m2-n$, so $n=\dfrac m2-\dfrac m3=\dfrac m6$.",r"Since $n$ is an integer, $m$ must be a multiple of $6$.",r"Only $12$ is a multiple of $6$ (then $n=2$)."],
 opts=[r"$8$",r"$10$",r"$12$",r"$16$"],correct=2,chk=h4,src='old A-122')
add('H',r"For a certain number $c$, a sequence begins $c,\ 2c+3,\ 3c+6,\ 4c+9,\ \ldots$ and the pattern continues. If the fifth term is $52$, what is the tenth term?",
 [r"The $k$th term is $kc+3(k-1)$.",r"Fifth term: $5c+12=52\Rightarrow c=8$.",r"Tenth term: $10c+27=80+27=107$."],
 ans="107",val=107,chk=lambda:10*sol(lambda c:5*c+12-52)+27,src='old A-120 (completed)')
add('H',r"The smallest integer in a set of consecutive integers is $-11$. The sum of the integers in the set is $12$. How many integers are in the set?",
 [r"The integers from $-11$ to $11$ cancel in pairs and sum to $0$.",r"The sum needs to be $12$ more, so the next integer, $12$, is included.",r"The set is $-11,-10,\ldots,12$: $12-(-11)+1=24$ integers."],
 ans="24",val=24,chk=lambda:[N for N in range(1,80) if sum(range(-11,-11+N))==12][0],src='old A-115')
add('H',r"Maya is $4$ years older than Noah. The square of Maya's age, in years, is $64$ greater than the square of Noah's age. What is the sum, in years, of their ages?",
 [r"Let Noah be $N$ and Maya be $N+4$.",r"$(N+4)^2-N^2=64\Rightarrow8N+16=64$, so $N=6$.",r"Maya is $10$; the sum is $16$."],
 ans="16",val=16,chk=lambda:(lambda N:N+N+4)(sol(lambda x:(x+4)**2-x**2-64)),src='old A-124')
def h8():
    sols=[v for v in [S(1,2),4] if abs(3*v+2)==5*v-6]
    return sols[0]
add('H',r"What is the value of $x$ that satisfies $|3x+2|=5x-6$?",
 [r"Case 1: $3x+2=5x-6\Rightarrow x=4$. Check: $|14|=14$. \checkmark",r"Case 2: $3x+2=-(5x-6)\Rightarrow8x=4\Rightarrow x=\tfrac12$. Check: $|3.5|=3.5$ but $5(\tfrac12)-6=-3.5$. Rejected.",r"The only solution is $x=4$."],
 ans="4",val=4,tool='D',chk=h8,src='old A-039')
# ---- CHALLENGE
add('C',r"For each integer $k\neq1$, the equation $(k+1)x+3=2x+k$ has exactly one solution $x$. What is the sum of all integer values of $k$ for which $x$ is also an integer?",
 [r"Collect: $(k-1)x=k-3$, so $x=\dfrac{k-3}{k-1}=1-\dfrac2{k-1}$.",r"$x$ is an integer exactly when $(k-1)$ divides $2$: $k-1\in\{\pm1,\pm2\}$.",r"So $k\in\{2,0,3,-1\}$, giving $x=-1,\,3,\,0,\,2$.",r"Sum: $2+0+3-1=4$. ($k=1$ gives $0=-2$, no solution, so it is excluded.)"],
 ans="4",val=4,chk=lambda:sum(kk for kk in range(-60,60) if kk!=1 and (kk-3)%(kk-1)==0),src='original')
def c2():
    tot=0
    for xv in (S(2),S(9,2),S(7)):
        sides=[xv+2,3*xv-2,5*xv-16]
        if min(sides)<=0:continue
        if len(set(sides))<3 or True:
            sd=sorted(sides)
            if len(set(sides))==3:continue
            if sd[0]+sd[1]>sd[2]: tot+=sum(sides)
    return tot
add('C',r"In the triangle shown (not drawn to scale), the side lengths are $x+2$, $3x-2$, and $5x-16$. The triangle is isosceles. What is the sum of all possible perimeters?",
 [r"Three possible pairings of equal sides.",r"$x+2=3x-2$: $x=2$, sides $4,4,-6$. Invalid (negative side).",r"$x+2=5x-16$: $x=\tfrac92$, sides $6.5,\,11.5,\,6.5$. Valid since $13>11.5$; perimeter $24.5$.",r"$3x-2=5x-16$: $x=7$, sides $9,\,19,\,19$. Valid; perimeter $47$.",r"Sum of possible perimeters: $24.5+47=71.5$."],
 ans="71.5",val=71.5,chk=c2,src='original',
 fig=fig(r"""\draw[very thick,NAVY,fill=BLUE!8] (0,0)--(8,0)--(3,5)--cycle;
\node[below] at (4,0) {$3x-2$};\node[above left] at (1.5,2.5) {$x+2$};\node[above right] at (5.5,2.5) {$5x-16$};""",xu=0.5,yu=0.5))
P=prep(P)
if __name__=="__main__":
    print(len(P),[ (p['lv'],p.get('correct')) for p in P])
    build(meta,guided,P,'ws','W1A_ws.tex');build(meta,guided,P,'key','W1A_key.tex')
