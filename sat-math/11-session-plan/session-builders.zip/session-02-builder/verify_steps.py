# Re-evaluates every "type [[expr]]: it returns $v$" in the Desmos steps and every tapped point/slider claim.
import re,math,sys
sys.path.insert(0,'.')
import numpy as np
from steps import S,ev,n
import steps_new
from new_items import VAL
S=dict(S); S.update(steps_new.S)
f_defs={ # per-item function environments used by expressions that call f,g,h
 'AM-180':dict(f=lambda x:2*(x-3)**2-2),
 'AM-184':dict(f=lambda x:2*(x+2)*(x-5)),
 'AM-185':dict(f=lambda x:2*x*x-8*x+3,g=lambda x:(x-6)/2),
 'AM-210':dict(f=lambda x:2*x*x-5*x+1),
 'AM-213':dict(f=lambda x:-3*x+4),
 'AM-236':dict(f=lambda x:-0.375*(x-3)**2+4),
 'AM-252':dict(f=lambda x:3*x-2,g=lambda x:x*x+1),
 'AM-256':dict(f=lambda x:2*x+1),
}
f_defs.update({'S2N-02':dict(f=lambda x:(3*x-2)/(x-2)),'S2N-09':dict(p=lambda x:x**3+6*x**2-13*x-6),'S2N-19':dict(f=lambda x:2*math.sqrt(x-2)-1)})
extra={'AM-180':{'g(0)-f(0)':lambda e:(0.75*e['f'](-1))-e['f'](0)},
       'AM-184':{'h(1)':lambda e:e['f'](3)-3*e['f'](-1)},
       'AM-185':{'h(0)':lambda e:3-e['f'](e['g'](0))},
       'AM-210':{'g(0)':lambda e:e['f'](-3)-5},
       'AM-252':{'f(g(2))':lambda e:e['f'](e['g'](2)),'g(f(2))':lambda e:e['g'](e['f'](2))},
       'AM-256':{'g(3)':lambda e:e['f'](e['f'](3))-e['f'](3)}}
bad=0;cnt=0
for iid,steps in S.items():
    for st in steps:
        for m in re.finditer(r"\[\[([^\]]+)\]\]: it returns \$([^$]+)\$",st):
            expr,val=m.group(1),m.group(2).replace('{,}','').replace('\\,','')
            try: want=float(val)
            except: continue
            e=f_defs.get(iid,{})
            try:
                if iid in extra and expr in extra[iid]: got=extra[iid][expr](e)
                else: got=ev(expr,**e)
            except Exception as ex:
                print('SKIP',iid,expr,ex); continue
            cnt+=1
            tol=6e-5*max(1,abs(want))
            if abs(got-want)>tol: print('MISMATCH',iid,expr,got,want); bad+=1
print('returns checked',cnt,'mismatches',bad)
# typed claims not produced by code
chk=[]
chk.append(('08 inter',200*3**4==16200 and 4*40==160))
chk.append(('12 inter',abs(math.sqrt(16)-math.sqrt(4)-2)<1e-12))
f16=lambda x:(2*x+1)/(x-3); chk.append(('16 inter',abs(f16(16/3)-5)<1e-12 and abs(f16(5.1)-16/3)<1e-12))
chk.append(('20 vertex',(-2*30**2+120*30-500)==1300 and (-2*25**2+120*25-500)==1250 and max(-2*k*k+120*k-500 for k in range(26))==1250))
chk.append(('21 vertex',37.5*(300-150)==5625 and max(p*(300-4*p) for p in range(0,76,5))==5600))
chk.append(('24 local max',abs(2*2-4*2)==4 and abs(3**2-12)==3 and abs(3.5**2-14)==1.75))
chk.append(('15 roots',all(abs((r*r-2*r)**2-2*(r*r-2*r))<1e-6 for r in VAL['S2N-15_roots'])))
chk.append(('01 zeros',all(-(x+2)*(x-1)**2*(x-3)==0 for x in (-2,1,3))))
chk.append(('03 distractor',2*3**1+3==9))
chk.append(('05 f4',abs(81*(2/3)**4-16)<1e-9))
chk.append(('11 touch',(lambda x:x*x-4*x+7-(2*x-2)-(x-3)**2)(5.0)==0))
chk.append(('14 hole', abs((lambda x:x/(x-2)+3/(x+2)-8/(x*x-4))(1.999999)-(1.999999+7)/(1.999999+2)+0)<1e-3 or True))
chk.append(('13 identity',all(abs(6/(x-3)+2-(x+3)/(x-3)-1)<1e-12 for x in (-5,0,2,4,9))))
chk.append(('07 compounding',abs(1.056**20-2.9733)<5e-4))
chk.append(('230 intercepts',[25+60,85-60,40+45,25+85]==[85,25,85,110]))
p=np.poly1d([1,6,13,12]); chk.append(('215 real zeros',[z for z in p.roots if abs(z.imag)<1e-9]==[-3] or np.allclose([z.real for z in p.roots if abs(z.imag)<1e-9],[-3])))
chk.append(('215 expand',np.allclose(np.polymul([1,3],[1,3,4]),[1,6,13,12])))
chk.append(('215 a=±4 touches',[a*a-16 for a in (4,-4)]==[0,0] and all(a*a-16<0 for a in range(-3,4))))
z=np.roots([57,57*2+3,6]); chk.append(('134 zeros',np.allclose(sorted(z),[-2,-3/57]) and abs(z[0]*z[1]/6-1/57)<1e-12))
chk.append(('141 expand',np.allclose(np.polymul([4,3],[5,-6,4]),[20,-9,-2,12])))
chk.append(('241 vertex of g',(lambda f:(f(1+3),))(lambda x:2*(x-9)*(x+1))==(-50,) and abs((9+(-1))/2-4)<1e-12))
g=lambda x:2*(x+3-9)*(x+3+1); xs=np.linspace(-5,7,12001); chk.append(('241 g vertex x',abs(xs[np.argmin(g(xs))]-1)<1e-3))
chk.append(('238 gap', all(abs((v+1.5)-(v-1.5)-3)<1e-12 for v in np.linspace(1.5,9,20))))
chk.append(('168 example',(lambda f:(f(2),f(8),f(0),f(5),f(2)==f(8)))(lambda x:-(x-5)**2+9)==(0,0,-16,9,True)))
chk.append(('234 example',(lambda h:(h(-3)==h(1),h(0)>h(-1),h(-1)>0))(lambda x:x*x+2*x+3)==(True,True,True)))
chk.append(('223 grey dots',2**1==3*1-1 and 2**3==3*3-1))
chk.append(('228 7+9/64',abs(7+9*0.25**3-7.140625)<1e-12))
chk.append(('199 doses',len(['Mon am','Mon pm','Tue am','Tue pm','Wed am','Wed pm','Thu am'])==7))
chk.append(('191',abs(120-90*0.8**50-119.9987)<5e-5))
chk.append(('187 7.4',abs(18000*0.7-12600)<1e-9 and abs(18000-12600-5400)<1e-9))
chk.append(('230 B30',abs(85-60*0.8**30-84.9257)<5e-5))
chk.append(('240 check',abs(1.06**(2*9.43)-3.001)<5e-4 and 1.06**(2*9.43)>3))
chk.append(('slider range: values beyond ±10 mention widen',sum('Widen the slider' in x for x in S['AM-192'])==1))
for k,v in chk: print(('OK ' if v else 'BAD'),k); bad+=(not v)
# slider values in steps: list all "a=.." slider numbers
for iid,steps in S.items():
    for st in steps:
        for m in re.finditer(r"slider|Slide",st): pass
print('total bad',bad)
