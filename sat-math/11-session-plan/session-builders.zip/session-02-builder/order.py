import json,os
HERE=os.path.dirname(os.path.abspath(__file__))
def interleave(old,new):
    out=[];m=len(new);pos=[int((j+1)*len(old)/(m+1)) for j in range(m)]
    j=0
    for i,o in enumerate(old,1):
        out.append(o)
        while j<m and pos[j]==i: out.append(new[j]); j+=1
    out+=new[j:]
    return out
def final_order(items):
    A=[o for o in items if o['part']=='In class']; B=[o for o in items if o['part']!='In class']
    isn=lambda o:o['id'].startswith('S2N')
    oa=interleave([o for o in A if not isn(o)],[o for o in A if isn(o)])
    ob=interleave([o for o in B if not isn(o)],[o for o in B if isn(o)])
    return oa+ob,len(oa)
