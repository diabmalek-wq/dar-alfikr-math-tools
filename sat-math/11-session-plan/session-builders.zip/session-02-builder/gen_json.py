# regenerates s2_items.json: the 49 original items (kept as is) + the 24 new items from new_items.py
import json,re,os,sys
HERE=os.path.dirname(os.path.abspath(__file__)); os.chdir(HERE); sys.path.insert(0,HERE)
from new_items import make
old=[o for o in json.load(open('s2_items.json')) if not o['id'].startswith('S2N')]
new=make()
for o in new:
    if o['id'] in ('S2N-12','S2N-13','S2N-14'):
        o['q']=re.sub(r'^\$(.+?)\$ (?=[A-Z])',lambda m:'$$'+m.group(1)+'$$\n\n',o['q'],count=1)
json.dump(old+new,open('s2_items.json','w'),indent=1)
print(len(old),len(new))
