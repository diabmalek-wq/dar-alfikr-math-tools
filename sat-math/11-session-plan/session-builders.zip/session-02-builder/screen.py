import re,json,difflib,csv
from new_items import make
t=open('/home/claude/repo-check2/sat-bank/verified-item-bank/SAT_Bank_Verified_Item_Bank.md').read()
blocks=re.split(r'^### (?=[A-Z]{1,3}-\d+\s*$)',t,flags=re.M)[1:]
B={}
for b in blocks:
    i=b.split('\n',1)[0].strip()
    m=re.search(r'\*\*Question:\*\* (.*?)\n\n\*\*Correct Answer',b,re.S)
    if m: B[i]=m.group(1)
print('bank items',len(B))
plan={r['id'] for r in csv.DictReader(open('/home/claude/repo-check2/sat-math/11-session-plan/session_plan_11.csv'))}
print('plan ids',len(plan),'all in bank',all(p in B for p in plan))
def nums(s):
    s=re.sub(r'\\(?:dfrac|frac|left|right|cdot|sqrt|le|ge|neq|par|medskip|begin|end)\w*','',s)
    return set(re.findall(r'(?<![A-Za-z])-?\d+(?:\.\d+)?',s))
def norm(s):
    s=re.sub(r'\d+(?:\.\d+)?','#',s); s=re.sub(r'\\[a-zA-Z]+','',s); return re.sub(r'[^a-z# ]','',s.lower())
# also screen against existing 49 (in bank) -> covered
flag=0
for it in make():
    q=it['q']+' '+' '.join(it['opts'] or [])
    ns=nums(q); nt=norm(it['q'])
    best=[]
    for k,v in B.items():
        nv=nums(v); j=len(ns&nv)/max(1,len(ns|nv))
        r=difflib.SequenceMatcher(None,nt,norm(v)).quick_ratio()
        sim=difflib.SequenceMatcher(None,nt,norm(v)).ratio() if r>0.55 else 0
        best.append((j,sim,k))
    bj=max(best); bs=max(best,key=lambda x:x[1])
    st='REVIEW' if (bj[0]>=0.5 and len(ns)>=3) or bs[1]>=0.6 else 'ok'
    if st!='ok': flag+=1
    print(it['id'],st,'numJ %.2f %s'%(bj[0],bj[2]),'textsim %.2f %s'%(bs[1],bs[2]))
print('flagged',flag)
