# Parses the Answers PDF and compares the checked option and "Answer:" with independently computed values.
import re,subprocess,sys,json
pdf=sys.argv[1] if len(sys.argv)>1 else 'S2_key.pdf'
subprocess.run(['pdftotext','-bbox',pdf,'bb.html'],check=True)
t=open('bb.html').read()
W=[]
for pi,p in enumerate(t.split('<page ')[1:]):
    for m in re.finditer(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">(.*?)</word>',p):
        x0,y0,x1,y1=map(float,m.groups()[:4]); W.append(dict(p=pi,x0=x0,y0=y0,x1=x1,y1=y1,s=m.group(5).replace('&lt;','<').replace('&gt;','>').replace('&amp;','&')))
from order import final_order
items=json.load(open('s2_items.json')); order=[o['id'] for o in final_order(items)[0]]
KEY=dict((i,v) for i,v in json.load(open('keyed.json')))
# headers
tags=[w for w in W if w['s'] in('Hard','Medium','Challenge')]
H=[]
for w in W:
    if re.fullmatch(r'\d+\.',w['s']) and w['x0']<60 and any(t_['p']==w['p'] and abs(t_['y0']-w['y0'])<3 for t_ in tags): H.append(w)
assert [int(h['s'][:-1]) for h in H]==list(range(1,len(order)+1)),[h['s'] for h in H]
# independent expectations (from solve.py, before reading the bank)
SPR={'S2N-02':13/3,'S2N-05':182.25,'S2N-08':8/3,'S2N-09':-7,'S2N-11':-2,'S2N-12':9,'S2N-14':-7,'S2N-16':5.1,'S2N-19':5,'S2N-20':1250,'S2N-23':6,'AM-162':32,'AM-165':82,'AM-181':2,'AM-183':48,'AM-184':16,'AM-185':-42,'AM-186':25,'AM-188':-21,'AM-190':8,'AM-236':-105/8,'AM-238':3,'AM-240':9.43,'AM-241':-1,'AM-252':-4,'AM-254':11,'AM-256':8,'AM-258':-2,'AM-260':16,'AM-262':5,'AM-215':13,'AM-134':1/57}
NUM={'S2N-07':5.6,'S2N-10':4,'S2N-15':4,'S2N-18':3,'S2N-21':5600,'AM-164':25,'AM-192':32,'AM-199':198.4,'AM-201':72.8,'AM-209':-18,'AM-210':29,'AM-213':4,'AM-221':70,'AM-244':-84,'AM-246':839,'AM-249':45,'AM-141':24}
TXT={'S2N-04':'g(x)=x2+4','S2N-13':'Therearenorealsolutions','S2N-17':'(-3,-3)','S2N-22':'f(x)=(x-2)(x+2)(x-3)(x+3)','S2N-24':'IandIIonly','AM-163':'Theballreacheditsmaximumheightof148feet3secondsafteritwaslaunched.','AM-168':'IandIIIonly','AM-187':'Itdecreasesby30%eachyear.','AM-191':'Onlygattainsamaximum,125','AM-223':'x<1orx>3','AM-228':'IandIIIonly','AM-234':'IandIIonly','AM-251':'(−1,−3)','AM-253':'x=−1andx=3','AM-255':'(2,−2)','AM-259':'Norealnumbers','AM-261':'(−3,−2)'}
LET={'AM-168':'x','AM-180':'x'}
EXP06='m(w)=80127w/12'
def norm(s): return s.replace('−','-').replace('−','-')
def fl(s):
    s=norm(s).replace(',','').replace('$','')
    return float(s)
bad=0;lets=[]
def key(w): return (w['p'],w['y0'],w['x0'])
for i,h in enumerate(H):
    iid=order[i]
    nxt=H[i+1] if i+1<len(H) else None
    blk=[w for w in W if (w['p'],w['y0'])>=(h['p'],h['y0']-1) and (nxt is None or (w['p'],w['y0'])<(nxt['p'],nxt['y0']-1))]
    ticks=[w for w in blk if '✓' in w['s']]
    ans=[k for k,w in enumerate(blk) if w['s']=='Answer:']
    assert len(ans)==1,(iid,'Answer: count',len(ans))
    a=ans[0]; aw=blk[a]
    ss=[k for k,w in enumerate(blk) if k>0 and w['s']=='1.' and w['x0']<75]
    ss=min(ss,key=lambda k:(blk[k]['p'],blk[k]['y0']))
    labels=[w for w in blk if re.fullmatch(r'\([ABCD]\)',w['s']) and w['x0']<330 and (w['p'],w['y0'])<(blk[ss]['p'],blk[ss]['y0'])]
    if labels:   # multiple choice
        assert len(labels)==4,(iid,len(labels))
        # checkmark may be glued to text ("✓" own word or part of word)
        assert len(ticks)>=1,(iid,'no tick')
        tk=ticks[0] if len(ticks)==1 else None
        assert tk is not None,(iid,'ticks',len(ticks))
        # label = last label before tick in same column
        col=lambda x: 0 if x<285 else 1
        cand=[l for l in labels if col(l['x0'])==col(tk['x0']) and (l['p'],l['y0'])<=(tk['p'],tk['y0']+2)]
        lab=max(cand,key=lambda l:(l['p'],l['y0']))
        L=lab['s'][1]
        # cell text: words in same column from label until next label row in that column
        rows=sorted([l for l in labels if col(l['x0'])==col(lab['x0'])],key=lambda l:(l['p'],l['y0']))
        idx=rows.index(lab); end=rows[idx+1] if idx+1<len(rows) else None
        nxt_row=end
        step1=blk[ss]
        top=lab['y0']-17
        if nxt_row is not None and nxt_row['p']==lab['p']: bot=nxt_row['y0']-17
        else:
            bot=lab['y0']+45
            if step1['p']==lab['p']: bot=min(bot,step1['y0']-17)
        cell=[w for w in blk[:ss] if col(w['x0'])==col(lab['x0']) and w['p']==lab['p'] and top<=w['y0']<bot and w['x0']>=lab['x0']-3 and w is not lab]
        text=re.sub(r'[\x00-\x1f]','',norm(''.join(w['s'] for w in sorted(cell,key=lambda w:(w['x0'],w['y0'])))).replace('✓',''))
        # answer letter
        al=[w for w in blk[a+1:a+3] if re.fullmatch(r'\([ABCD]\)',w['s'])]
        assert al,(iid,'no answer letter')
        AL=al[0]['s'][1]
        ok=(AL==L) and ("ABCD"[KEY[iid]]==L)
        if iid in NUM:
            nums=re.findall(r'-?[\d.]+',text.replace(',',''))
            ok=ok and len(nums)==1 and abs(float(nums[0])-NUM[iid])<1e-9
        elif iid in TXT:
            ok=ok and sorted(norm(TXT[iid]))==sorted(text)
        elif iid=='S2N-01': pass
        elif iid=='S2N-03': ok=ok and sorted(text)==sorted('f(x)=3·2x+2')
        elif iid=='S2N-06': ok=ok and sorted(text)==sorted(EXP06)
        elif iid=='AM-180':
            ok=ok and sorted(text)==sorted('132')
        elif iid=='AM-216': ok=ok and sorted(text)==sorted('f(x)=12·2x')
        elif iid=='AM-230': ok=ok and sorted(text)==sorted('T=25+60(0.8)t')
        elif iid=='AM-247': ok=ok and sorted(text)==sorted('162·3-t2')
        else: ok=False; print('no expectation',iid)
        lets.append(L)
        print(('OK ' if ok else 'BAD'),i+1,iid,'tick',L,'answer',AL,'|',repr(text))
        bad+=(not ok)
    else:        # SPR
        assert not ticks,(iid,'tick on SPR')
        right=[w for w in blk if w['p']==aw['p'] and w['x0']>aw['x1']-1]
        main=[w for w in right if abs(w['y0']-aw['y0'])<4]
        low=[w for w in right if aw['y0']+3<w['y0']<aw['y0']+12]
        ov=lambda w,l: min(w['x1'],l['x1'])-max(w['x0'],l['x0'])>0
        up=[w for w in right if aw['y0']-11<w['y0']<aw['y0']-4 and any(ov(w,l) for l in low)]
        s=[norm(w['s']).replace('$','') for w in sorted(main,key=lambda w:w['x0'])]
        sign=-1 if any(x.startswith('-') for x in s) else 1
        if low:
            nu=''.join(w['s'] for w in sorted(up,key=lambda w:w['x0'])); de=''.join(w['s'] for w in sorted(low,key=lambda w:w['x0']))
            val=sign*float(nu)/float(de); s=s+['frac',nu,de]
        else:
            digits=''.join(x.lstrip('-') for x in s).replace(',','')
            val=sign*float(digits) if re.fullmatch(r'[\d.]+',digits) else None
        ok=val is not None and abs(val-SPR[iid])<1e-3*(1 if iid=='AM-240' else 0.001)+1e-9
        if iid=='AM-134': ok=val is not None and abs(val-1/57)<1e-12
        print(('OK ' if ok else 'BAD'),i+1,iid,'SPR',s,'->',val,'expect',SPR[iid]); bad+=(not ok)
from collections import Counter
print('letter counts',sorted(Counter(lets).items()),'mc',len(lets),'spr',len(order)-len(lets),'bad',bad)
