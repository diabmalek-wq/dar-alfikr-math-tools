"""24 new original Session 2 items. Each key is computed here from the stem (numpy), before any key is written.
make() returns item dicts (id, part, d, tool, q, opts, ans, rat, fig, trick) for s2_items.json;
VAL holds the independently computed values used by steps_new.py and by the build asserts."""
import numpy as np, math
from numpy.polynomial import polynomial as Pl

VAL = {}
LET = {}
TRICK = {}
def R(x): return float(x)

def poly_from_roots(roots, lead=1.0):
    return lead * Pl.polyfromroots(roots)           # low->high coefficients
def pv(c, x): return Pl.polyval(x, c)

def mc_letter(flags):
    assert sum(flags) == 1, flags
    return "ABCD"[flags.index(True)]

def make():
    I = []
    def add(**k): I.append(k)

    # ---------------- S2N-01  which could be the graph (polynomial, multiplicity + end behaviour)
    stem_c = poly_from_roots([-2, 1, 1, 3], -1.0)            # -(x+2)(x-1)^2(x-3)
    panels = [  # (roots with multiplicity, leading coefficient) in ORIGINAL option order
        ([-2, 1, 1, 3], -1.0),   # correct
        ([-2, -2, 1, 3], -1.0),  # multiplicities swapped
        ([-2, 1, 1, 3], 1.0),    # sign error: ends up
        ([-2, 1, 3], -1.0),      # cubic: crosses at 1, ends opposite
    ]
    def props(roots, lead):
        r = sorted(roots); deg = len(r)
        mult = {z: r.count(z) for z in set(r)}
        ends = (lead > 0 if deg % 2 == 0 else (lead < 0)), lead > 0          # sign at -inf, sign at +inf (True = up)
        left_up = (lead > 0) if deg % 2 == 0 else (lead < 0)
        return dict(left_up=left_up, right_up=lead > 0, mult=mult)
    ps = props([-2, 1, 1, 3], -1.0)
    flags = [props(r, l) == ps for r, l in panels]
    VAL['S2N-01'] = mc_letter(flags)
    # numeric double check on actual polynomial values
    for r, l in panels:
        c = poly_from_roots(r, l)
        xs = np.array([-30, 30.0]); sg = np.sign(pv(c, xs))
    add(id='S2N-01', part='In class', d='SAT Challenge', tool='D',
        q=r"Which of the following could be the graph of $y=-(x+2)(x-1)^2(x-3)$ in the $xy$-plane?",
        opts=["@@PANEL%d@@" % i for i in range(4)], fig='',
        ans="(%s) graph with a single crossing at $-2$, a touch at $1$, a crossing at $3$, and both ends down" % VAL['S2N-01'],
        rat="Even degree with a negative leading coefficient: both ends down. Zero at $1$ has multiplicity $2$ (touches), zeros at $-2$ and $3$ are simple (cross).",
        trick="multiplicity (touch vs cross) + end behaviour from sign/degree; options built from swapped multiplicity, sign error, dropped factor")
    VAL['S2N-01_panels'] = panels
    VAL['S2N-01_correct_idx'] = flags.index(True)

    # ---------------- S2N-02  rational graph with asymptotes -> f(5)
    a, b, c_ = 3.0, None, 2.0
    # horizontal asymptote y=a=3, vertical x=c=2, passes (0,1): f(0)=b/(0-2)=1 -> b=-2
    b = 1.0 * (0 - c_)
    f2 = lambda x: (a * x + b) / (x - c_)
    assert abs(f2(0) - 1) < 1e-12 and abs(f2(1) + 1) < 1e-12 and abs(f2(4) - 5) < 1e-12
    VAL['S2N-02'] = f2(5); VAL['S2N-02_b'] = b
    add(id='S2N-02', part='In class', d='Hard', tool='D',
        q=r"The graph of the rational function $f(x)=\dfrac{ax+b}{x-c}$ is shown, where $a$, $b$ and $c$ are constants. The dashed lines are the asymptotes $x=2$ and $y=3$, and the graph passes through the point $(0,1)$. What is the value of $f(5)$? Enter your answer as a fraction.",
        opts=None, fig='F02', ans="$\\dfrac{13}{3}$",
        rat="The vertical asymptote gives $c=2$ and the horizontal asymptote gives $a=3$. Then $f(0)=\\dfrac{b}{-2}=1$ gives $b=-2$, so $f(5)=\\dfrac{13}{3}$.",
        trick="read parameters of a rational function from asymptotes, then one point fixes the numerator constant")

    # ---------------- S2N-03  exponential graph with asymptote -> equation
    opt3 = [("3\\cdot2^{x}+2", 3, 2, 2), ("2\\cdot3^{x}+3", 2, 3, 3), ("5\\cdot2^{x}", 5, 2, 0), ("2^{x}+4", 1, 2, 4)]
    fl = []
    for t_, A, B, Cc in opt3:
        ok = abs(A * B ** 0 + Cc - 5) < 1e-12 and abs(A * B ** 1 + Cc - 8) < 1e-12 and Cc == 2
        fl.append(ok)
    VAL['S2N-03'] = mc_letter(fl)
    add(id='S2N-03', part='In class', d='Hard', tool='D',
        q=r"The graph of the exponential function $f$ is shown. The dashed line $y=2$ is the horizontal asymptote, and the graph passes through the points $(0,5)$ and $(1,8)$. Which of the following could be an equation for $f$?",
        opts=["$f(x)=%s$" % o[0] for o in opt3], fig='F03', ans="(%s) $f(x)=3\\cdot2^{x}+2$" % VAL['S2N-03'],
        rat="The asymptote $y=2$ gives the vertical shift $+2$. At $x=0$: $a+2=5$, so $a=3$. At $x=1$: $3b+2=8$, so $b=2$.",
        trick="horizontal asymptote = vertical shift of an exponential; options each satisfy one clue but not both")

    # ---------------- S2N-04  table: quadratic via second differences
    xs = np.arange(1, 6); gv = xs ** 2 + 4
    assert list(gv) == [5, 8, 13, 20, 29]
    d1 = np.diff(gv); d2 = np.diff(d1); assert set(d2) == {2}
    opt4 = [lambda x: 3 * x + 2, lambda x: x ** 2 + 4, lambda x: 3 * 2.0 ** (x - 1) + 2, lambda x: 2.0 ** x + 3]
    fl = [all(abs(o(x) - y) < 1e-9 for x, y in zip(xs, gv)) for o in opt4]
    VAL['S2N-04'] = mc_letter(fl)
    add(id='S2N-04', part='Self-assessment', d='Hard', tool='D',
        q=r"Selected values of the function $g$ are shown in the table below.\par\medskip\begin{center}\renewcommand{\arraystretch}{1.5}\begin{tabular}{|c|c|c|c|c|c|}\hline $x$&$1$&$2$&$3$&$4$&$5$\\\hline $g(x)$&$5$&$8$&$13$&$20$&$29$\\\hline\end{tabular}\end{center}\par Which of the following could define $g$?",
        opts=["$g(x)=3x+2$", "$g(x)=x^{2}+4$", "$g(x)=3\\cdot2^{x-1}+2$", "$g(x)=2^{x}+3$"], fig='',
        ans="(%s) $g(x)=x^{2}+4$" % VAL['S2N-04'],
        rat="The first differences $3,5,7,9$ are not constant and the ratios are not constant, but the second differences are all $2$, so $g$ is quadratic.",
        trick="constant second differences => quadratic; distractors fit only the first two or three table points (linear, exponential)")

    # ---------------- S2N-05  two table points, exponential, extrapolate backwards
    f1, f4 = 54.0, 16.0
    bb = (f4 / f1) ** (1 / 3); aa = f1 / bb
    VAL['S2N-05'] = aa * bb ** (-2)
    add(id='S2N-05', part='In class', d='SAT Challenge', tool='D',
        q=r"The function $f$ is defined by $f(x)=a\cdot b^{x}$, where $a$ and $b$ are positive constants. Some values of $f$ are shown in the table below.\par\medskip\begin{center}\renewcommand{\arraystretch}{1.5}\begin{tabular}{|c|c|c|}\hline $x$&$1$&$4$\\\hline $f(x)$&$54$&$16$\\\hline\end{tabular}\end{center}\par What is the value of $f(-2)$?",
        opts=None, fig='', ans="$182.25$",
        rat="Three steps of $1$ separate $x=1$ and $x=4$, so $b^3=\\dfrac{16}{54}=\\dfrac{8}{27}$ and $b=\\dfrac23$. Then $a=81$ and $f(-2)=81\\left(\\dfrac32\\right)^2=182.25$.",
        trick="cube root of the ratio over a 3-step gap, then extrapolate to a negative input")

    # ---------------- S2N-06  half-life with unit conversion (days -> weeks)
    opt6 = [lambda w: 80 * 0.5 ** (w / 12), lambda w: 80 * 0.5 ** (7 * w / 12), lambda w: 80 * 0.5 ** (12 * w / 7), lambda w: 80 * 0.5 ** (84 * w)]
    fl = [abs(o(12 / 7) - 40) < 1e-9 and abs(o(0) - 80) < 1e-9 for o in opt6]
    VAL['S2N-06'] = mc_letter(fl)
    add(id='S2N-06', part='In class', d='Hard', tool='N',
        q=r"A sample of a radioactive isotope has a mass of $80$ milligrams. The half-life of the isotope is $12$ days. Which of the following functions gives the mass, in milligrams, of the sample $w$ weeks after the sample is measured?",
        opts=[r"$m(w)=80\left(\dfrac12\right)^{w/12}$", r"$m(w)=80\left(\dfrac12\right)^{7w/12}$", r"$m(w)=80\left(\dfrac12\right)^{12w/7}$", r"$m(w)=80\left(\dfrac12\right)^{84w}$"], fig='',
        ans="(%s) $m(w)=80\\left(\\dfrac12\\right)^{7w/12}$" % VAL['S2N-06'],
        rat="$w$ weeks is $7w$ days, and the number of half-lives is $\\dfrac{7w}{12}$.",
        trick="half-life in days but input in weeks: convert the exponent (days = 7 x weeks) before dividing by the half-life")

    # ---------------- S2N-07  triples every 5 years -> percent per quarter
    pq = (3 ** (1 / 20) - 1) * 100
    opt7 = [5.6, 6.1, 24.6, 10.0]
    fl = [abs(round(pq, 1) - o) < 1e-9 for o in opt7]
    VAL['S2N-07'] = mc_letter(fl); VAL['S2N-07_pq'] = pq
    add(id='S2N-07', part='Self-assessment', d='Hard', tool='D',
        q=r"The value of an investment triples every $5$ years. The value grows by the same percent every quarter (every $3$ months). Which of the following is closest to that quarterly percent increase?",
        opts=["$5.6\\%$", "$6.1\\%$", "$24.6\\%$", "$10.0\\%$"], fig='', ans="(%s) $5.6\\%%$" % VAL['S2N-07'],
        rat="There are $20$ quarters in $5$ years, so the quarterly factor is $3^{1/20}\\approx1.0565$, an increase of about $5.6\\%$.",
        trick="percent growth per sub-period of a 'triples every k years' rule: 3^(1/20), not (yearly percent)/4")

    # ---------------- S2N-08  triples every 40 min -> hours (fraction)
    k8 = math.log(16200 / 200, 3); assert abs(k8 - 4) < 1e-12
    VAL['S2N-08'] = k8 * 40 / 60
    add(id='S2N-08', part='Self-assessment', d='Hard', tool='D',
        q=r"A culture starts with $200$ cells. The number of cells triples every $40$ minutes. After how many hours will the culture contain exactly $16{,}200$ cells? Enter your answer as a fraction.",
        opts=None, fig='', ans="$\\dfrac{8}{3}$",
        rat="$\\dfrac{16200}{200}=81=3^4$, so there are $4$ tripling periods: $4\\cdot40=160$ minutes $=\\dfrac83$ hours.",
        trick="count tripling periods (81 = 3^4) then convert minutes to hours; answer is a fraction")

    # ---------------- S2N-09  factor + remainder theorem
    A = np.array([[4, 2], [1, -1.0]]); rhs = np.array([-2.0, 19.0])
    a9, b9 = np.linalg.solve(A, rhs)
    p9 = lambda x: x ** 3 + a9 * x ** 2 + b9 * x - 6
    assert abs(p9(2)) < 1e-9 and abs(p9(-1) - 12) < 1e-9
    VAL['S2N-09'] = a9 + b9; VAL['S2N-09_ab'] = (a9, b9)
    add(id='S2N-09', part='In class', d='Hard', tool='D',
        q=r"The polynomial $p(x)=x^3+ax^2+bx-6$ is divisible by $x-2$, and the remainder when $p(x)$ is divided by $x+1$ is $12$. What is the value of $a+b$?",
        opts=None, fig='', ans="$-7$",
        rat="Divisible by $x-2$ means $p(2)=0$: $2a+b=-1$. Remainder $12$ on division by $x+1$ means $p(-1)=12$: $a-b=19$. So $a=6$, $b=-13$ and $a+b=-7$.",
        trick="factor theorem + remainder theorem give two linear equations in the unknown coefficients")

    # ---------------- S2N-10  absolute value x-intercepts sum
    f10 = lambda x: 2 * abs(x - 2) - 3
    zs = [x for x in np.linspace(-5, 9, 14001) if abs(f10(x)) < 1e-9]
    z1, z2 = 2 - 1.5, 2 + 1.5; assert abs(f10(z1)) < 1e-12 and abs(f10(z2)) < 1e-12
    VAL['S2N-10'] = z1 + z2
    opt10 = [3, 4, 3.5, 5]
    fl = [abs(o - VAL['S2N-10']) < 1e-9 for o in opt10]
    assert mc_letter(fl)
    VAL['S2N-10_letter'] = mc_letter(fl)
    add(id='S2N-10', part='Self-assessment', d='Hard', tool='N',
        q=r"The function $f$ is defined by $f(x)=2|x-2|-3$. What is the sum of the $x$-intercepts of the graph of $y=f(x)$ in the $xy$-plane?",
        opts=["$3$", "$4$", r"$\dfrac72$", "$5$"], fig='', ans="(%s) $4$" % VAL['S2N-10_letter'],
        rat="Set $2|x-2|-3=0$: $|x-2|=\\dfrac32$, so $x=\\dfrac12$ or $x=\\dfrac72$. The sum is $4$ (twice the vertex $x$-coordinate).",
        trick="absolute-value zeros are symmetric about the vertex: sum = 2h")
    VAL['S2N-10_zeros'] = (z1, z2)

    # ---------------- S2N-11  tangent at a known point: difference is a perfect square
    # parabola y=x^2-4x+7, tangent line y=mx+b touching at x=3 => x^2-4x+7-(mx+b)=(x-3)^2
    m11 = -4 - (-6); b11 = 7 - 9
    for mm_, bb_ in ((m11, b11),):
        r = np.roots([1, -4 - mm_, 7 - bb_]); assert abs(r[0] - 3) < 1e-6 and abs(r[1] - 3) < 1e-6
    # any other line through (3,4) has a second intersection
    for mm_ in (0.0, 1.0, 3.0):
        bb_ = 4 - 3 * mm_; r = sorted(np.roots([1, -4 - mm_, 7 - bb_]).real); assert abs(r[0] - r[1]) > 1e-6
    VAL['S2N-11'] = float(b11); VAL['S2N-11_mb'] = (m11, b11)
    add(id='S2N-11', part='In class', d='SAT Challenge', tool='D',
        q=r"In the $xy$-plane, the line $\ell$ touches the parabola $y=x^{2}-4x+7$ at exactly one point, the point where $x=3$. What is the $y$-intercept of line $\ell$?",
        opts=None, fig='', ans="$-2$",
        rat="The line meets the parabola only at $x=3$, so $x^2-4x+7-(mx+b)=(x-3)^2=x^2-6x+9$. Matching coefficients: $-4-m=-6$, so $m=2$, and $7-b=9$, so $b=-2$.",
        trick="tangent at a known x: the parabola minus the line must equal (x-3)^2, so match coefficients (no derivative, no discriminant)")

    # ---------------- S2N-12  radical equation with conjugate
    g12 = lambda x: np.sqrt(x + 7) - np.sqrt(x - 5)
    xs = np.linspace(5, 200, 2000001); sol = xs[np.argmin(np.abs(g12(xs) - 2))]
    assert abs(sol - 9) < 1e-3 and abs(g12(9) - 2) < 1e-12
    VAL['S2N-12'] = 9.0
    add(id='S2N-12', part='In class', d='SAT Challenge', tool='D',
        q=r"$\sqrt{x+7}-\sqrt{x-5}=2$ What is the solution to the equation above?",
        opts=None, fig='', ans="$9$",
        rat="Multiply by the conjugate: $(x+7)-(x-5)=12$, so $\\sqrt{x+7}+\\sqrt{x-5}=6$. Adding to the original gives $2\\sqrt{x+7}=8$, so $x+7=16$ and $x=9$.",
        trick="difference of square roots: use the conjugate (a-b)(a+b)=a^2-b^2 instead of squaring twice")

    # ---------------- S2N-13  rational equation with no solution
    g13 = lambda x: 6 / (x - 3) + 2 - (x + 3) / (x - 3)
    xs = np.concatenate([np.linspace(-50, 2.999, 20001), np.linspace(3.001, 50, 20001)])
    assert np.allclose(g13(xs), 1.0)                     # equals 1 everywhere defined => never 0
    VAL['S2N-13'] = 0
    opt13 = ["There are no real solutions", "There is exactly one real solution", "There are exactly two real solutions", "There are infinitely many real solutions"]
    add(id='S2N-13', part='Self-assessment', d='Hard', tool='N',
        q=r"$\dfrac{6}{x-3}+2=\dfrac{x+3}{x-3}$ Which of the following describes the real solutions of the equation above?",
        opts=opt13, fig='', ans="(A) There are no real solutions",
        rat="Multiplying by $x-3$ gives $6+2(x-3)=x+3$, so $x=3$. But $x=3$ makes the denominators zero, so it is extraneous and there is no solution.",
        trick="the only candidate solution is the excluded value (extraneous), so the answer is no solution")

    # ---------------- S2N-14  rational equation with an extraneous root, sum of real solutions
    g14 = lambda x: x / (x - 2) + 3 / (x + 2) - 8 / (x ** 2 - 4)
    cands = np.roots([1, 5, -14]); good = [r for r in cands if abs(r - 2) > 1e-9 and abs(r + 2) > 1e-9 and abs(g14(r)) < 1e-9]
    assert sorted(cands) == sorted([-7.0, 2.0]) or np.allclose(sorted(cands), [-7, 2]); assert len(good) == 1
    VAL['S2N-14'] = float(sum(good))
    add(id='S2N-14', part='In class', d='Hard', tool='D',
        q=r"$\dfrac{x}{x-2}+\dfrac{3}{x+2}=\dfrac{8}{x^{2}-4}$ What is the sum of all real solutions of the equation above?",
        opts=None, fig='', ans="$-7$",
        rat="Multiplying by $(x-2)(x+2)$: $x(x+2)+3(x-2)=8$, so $x^2+5x-14=0$ and $x=-7$ or $x=2$. But $x=2$ is excluded, so the only solution is $-7$.",
        trick="clear denominators to a quadratic, then discard the root that is an excluded value")

    # ---------------- S2N-15  f(f(x)) = 0 : count real solutions
    f_c = np.array([0, -2, 1.0])                                   # x^2-2x low->high
    ff = Pl.polyadd(Pl.polypow(f_c, 2), -2 * f_c)                     # f(f)=f^2-2f
    rts = Pl.polyroots(ff); real = sorted(set(round(r.real, 9) for r in rts if abs(r.imag) < 1e-9))
    assert len(real) == 4, real
    VAL['S2N-15'] = len(real); VAL['S2N-15_roots'] = real
    opt15 = [1, 2, 3, 4]
    add(id='S2N-15', part='Self-assessment', d='Hard', tool='D',
        q=r"The function $f$ is defined by $f(x)=x^{2}-2x$. For how many real values of $x$ is $f(f(x))=0$?",
        opts=["$1$", "$2$", "$3$", "$4$"], fig='', ans="(D) $4$",
        rat="$f(f(x))=0$ means $f(x)=0$ or $f(x)=2$. $f(x)=0$ gives $x=0,2$; $f(x)=2$ gives $x=1\\pm\\sqrt3$. That is $4$ values.",
        trick="nested function zero set: solve f(u)=0 first, then f(x)=each u")

    # ---------------- S2N-16  inverse of a rational function applied twice
    f16 = lambda x: (2 * x + 1) / (x - 3)
    x1 = (3 * 5 + 1) / (5 - 2)                  # f(x1)=5
    assert abs(f16(x1) - 5) < 1e-12
    x2 = (3 * x1 + 1) / (x1 - 2)                # f(x2)=x1
    assert abs(f16(x2) - x1) < 1e-12
    VAL['S2N-16'] = x2; VAL['S2N-16_x1'] = x1
    add(id='S2N-16', part='In class', d='SAT Challenge', tool='D',
        q=r"The function $f$ is defined by $f(x)=\dfrac{2x+1}{x-3}$ for all $x\neq3$, and $f^{-1}$ is the inverse function of $f$. What is the value of $f^{-1}\!\left(f^{-1}(5)\right)$?",
        opts=None, fig='', ans="$5.1$",
        rat="$f^{-1}(5)$ is the $x$ with $\\dfrac{2x+1}{x-3}=5$, so $x=\\dfrac{16}{3}$. Then solve $\\dfrac{2x+1}{x-3}=\\dfrac{16}{3}$: $6x+3=16x-48$, so $x=\\dfrac{51}{10}=5.1$.",
        trick="evaluate an inverse by solving f(x)=value, twice, without deriving the inverse formula")

    # ---------------- S2N-17  reflection inside the argument: f(3-x)
    def gimg(f):
        return lambda x: 2 * f(3 - x) + 1
    fs = [lambda x: (x - 6) ** 2 - 2, lambda x: -2 + 0.3 * (x - 6), lambda x: -2 + np.sin(x - 6)]
    opt17 = [(-3, -3), (9, -3), (3, -3), (-3, -5)]
    fl = [all(abs(gimg(f)(px) - py) < 1e-9 for f in fs) for px, py in opt17]
    VAL['S2N-17'] = mc_letter(fl)
    add(id='S2N-17', part='Self-assessment', d='Hard', tool='N',
        q=r"The graph of $y=f(x)$ in the $xy$-plane passes through the point $(6,-2)$. The function $g$ is defined by $g(x)=2f(3-x)+1$. Which of the following points must lie on the graph of $y=g(x)$?",
        opts=["$(-3,-3)$", "$(9,-3)$", "$(3,-3)$", "$(-3,-5)$"], fig='', ans="(%s) $(-3,-3)$" % VAL['S2N-17'],
        rat="$g(x)$ uses $f(3-x)$, so $3-x=6$ gives $x=-3$. Then $g(-3)=2f(6)+1=2(-2)+1=-3$.",
        trick="argument of the form (c - x): solve c - x = old x, rather than shifting by c; the y-value then uses the outer 2f+1")

    # ---------------- S2N-18  shifted piecewise graph, count solutions
    pts = [(-4, -1), (-2, 3), (0, 1), (2, -2), (4, 2)]
    us = set()
    for (x0, y0), (x1_, y1) in zip(pts[:-1], pts[1:]):
        if y0 == y1: continue
        t = (1 - y0) / (y1 - y0)
        if -1e-12 <= t <= 1 + 1e-12: us.add(round(x0 + t * (x1_ - x0), 9))
    VAL['S2N-18'] = len(us); VAL['S2N-18_u'] = sorted(us)
    assert len(us) == 3
    add(id='S2N-18', part='In class', d='Hard', tool='N',
        q=r"The graph of $y=f(x)$ is shown for $-4\le x\le4$; the function $f$ is not defined for other values of $x$. The function $g$ is defined by $g(x)=f(x-1)-1$. For how many values of $x$ is $g(x)=0$?",
        opts=["$1$", "$2$", "$3$", "$4$"], fig='F18', ans="(C) $3$",
        rat="$g(x)=0$ means $f(x-1)=1$. The graph of $f$ reaches height $1$ at $x=-3$, $x=0$ and $x=3.5$, so $x=-2$, $x=1$ and $x=4.5$: three values.",
        trick="horizontal shift of a graph: count where the shifted graph meets a horizontal line (including a vertex on the line)")

    # ---------------- S2N-19  radical graph
    a19 = 2.0; h19, k19 = 2.0, -1.0
    f19 = lambda x: a19 * math.sqrt(x - h19) + k19
    assert abs(f19(6) - 3) < 1e-12
    VAL['S2N-19'] = f19(11)
    add(id='S2N-19', part='Self-assessment', d='Hard', tool='D',
        q=r"The graph of the function $f(x)=a\sqrt{x-h}+k$ is shown, where $a$, $h$ and $k$ are constants. The graph starts at the point $(2,-1)$ and passes through the point $(6,3)$. What is the value of $f(11)$?",
        opts=None, fig='F19', ans="$5$",
        rat="The starting point of a square-root graph is $(h,k)=(2,-1)$. Then $f(6)=a\\sqrt4-1=3$ gives $a=2$, so $f(11)=2\\sqrt9-1=5$.",
        trick="the endpoint of a radical graph is (h,k); a second point gives the stretch factor a")

    # ---------------- S2N-20  constrained maximum (vertex outside allowed domain)
    Pn = lambda n: -2 * n ** 2 + 120 * n - 500
    ns = np.arange(0, 26); assert Pn(ns).max() == Pn(25) == 1250 and Pn(30) == 1300
    VAL['S2N-20'] = float(Pn(25))
    add(id='S2N-20', part='In class', d='Hard', tool='D',
        q=r"A bakery's daily profit, in dollars, from baking $n$ batches of bread is modeled by $P(n)=-2n^{2}+120n-500$. The ovens can bake at most $25$ batches per day. According to the model, what is the greatest daily profit the bakery can earn?",
        opts=None, fig='', ans="$1250$",
        rat="The vertex is at $n=30$, but only $0\\le n\\le25$ is allowed. $P$ is increasing on this interval, so the maximum is at $n=25$: $P(25)=-1250+3000-500=1250$.",
        trick="maximum of a quadratic on a restricted interval: the vertex (n=30, profit 1300) is not allowed, so the maximum is at the boundary")

    # ---------------- S2N-21  revenue with prices restricted to multiples of 5
    ps_ = np.arange(0, 80, 5); rev = ps_ * (300 - 4 * ps_)
    assert rev.max() == 5600 and set(ps_[rev == 5600]) == {35, 40}
    vertex_val = 37.5 * (300 - 4 * 37.5); assert vertex_val == 5625
    opt21 = [5625, 5600, 5500, 5400]
    fl = [o == rev.max() for o in opt21]
    VAL['S2N-21'] = mc_letter(fl)
    add(id='S2N-21', part='Self-assessment', d='Hard', tool='D',
        q=r"A store sells $300-4p$ units of a product per week when the price is $p$ dollars. The store only sets prices that are multiples of $5$ dollars. What is the greatest weekly revenue, in dollars, the store can earn?",
        opts=["$5{,}625$", "$5{,}600$", "$5{,}500$", "$5{,}400$"], fig='', ans="(%s) $5{,}600$" % VAL['S2N-21'],
        rat="$R(p)=p(300-4p)$ has its vertex at $p=37.5$ ($R=5625$), which is not allowed. The nearest multiples of $5$ are $35$ and $40$, and $R(35)=R(40)=5600$.",
        trick="vertex not an allowed input (price multiples of 5): compare the nearest allowed inputs, which tie")

    # ---------------- S2N-22  equivalent form showing zeros of a quartic
    f22 = lambda x: x ** 4 - 13 * x ** 2 + 36
    o22 = [lambda x: (x - 2) * (x + 2) * (x - 3) * (x + 3), lambda x: (x ** 2 - 4) * (x ** 2 - 9), lambda x: (x - 1) * (x + 1) * (x - 6) * (x + 6), lambda x: (x - 2) ** 2 * (x + 3) ** 2]
    xt = np.linspace(-6, 6, 37)
    eqv = [np.allclose(o(xt), f22(xt)) for o in o22]
    assert eqv == [True, True, False, False]
    VAL['S2N-22'] = 'A'
    add(id='S2N-22', part='Self-assessment', d='Hard', tool='N',
        q=r"The function $f$ is defined by $f(x)=x^{4}-13x^{2}+36$. Which of the following is an equivalent form of $f(x)$ in which the zeros of $f$ appear as constants?",
        opts=["$f(x)=(x-2)(x+2)(x-3)(x+3)$", "$f(x)=(x^{2}-4)(x^{2}-9)$", "$f(x)=(x-1)(x+1)(x-6)(x+6)$", "$f(x)=(x-2)^{2}(x+3)^{2}$"], fig='',
        ans="(A) $f(x)=(x-2)(x+2)(x-3)(x+3)$",
        rat="Treat $x^4-13x^2+36$ as a quadratic in $x^2$: $(x^2-4)(x^2-9)$. Factor each difference of squares to get the four zeros $\\pm2$, $\\pm3$ as constants.",
        trick="quadratic in x^2, then difference of squares; one option is equivalent but not fully factored")

    # ---------------- S2N-23  rewrite exponent form
    f23 = lambda x: 4 * 8 ** ((2 * x - 1) / 3)
    xt = np.linspace(-3, 3, 13); assert np.allclose(f23(xt), 2 * 4.0 ** xt)
    VAL['S2N-23'] = 6.0
    add(id='S2N-23', part='Self-assessment', d='Hard', tool='N',
        q=r"For all real numbers $x$, $4\cdot8^{(2x-1)/3}=a\cdot b^{x}$, where $a$ and $b$ are positive constants. What is the value of $a+b$?",
        opts=None, fig='', ans="$6$",
        rat="$8^{\\frac{2x-1}{3}}=2^{2x-1}$, so $4\\cdot2^{2x-1}=2^2\\cdot2^{-1}\\cdot4^{x}=2\\cdot4^{x}$. Then $a=2$, $b=4$ and $a+b=6$.",
        trick="convert base 8 to base 2 with the fractional exponent, then split 2^(2x-1) = 4^x / 2")

    # ---------------- S2N-24  statements about g(x)=|x^2-4x|
    g24 = lambda x: np.abs(x * x - 4 * x)
    xs = np.linspace(-20, 20, 400001)
    I_ = bool((g24(xs) >= 0).all())
    zs = sorted(set(np.round(np.roots([1, -4, 0]).real, 9))); II_ = (len(zs) == 2)
    xx = np.linspace(2.0001, 30, 300001); III_ = bool((np.diff(g24(xx)) > 0).all())
    true_set = {k for k, v in (('I', I_), ('II', II_), ('III', III_)) if v}
    assert true_set == {'I', 'II'}, true_set
    sets = [{'I'}, {'I', 'II'}, {'II', 'III'}, {'I', 'II', 'III'}]
    fl = [s_ == true_set for s_ in sets]
    VAL['S2N-24'] = mc_letter(fl)
    add(id='S2N-24', part='In class', d='SAT Challenge', tool='D',
        q=r"The function $g$ is defined by $g(x)=\left|x^{2}-4x\right|$. Consider the following statements.\par\medskip I.\ $g(x)\ge0$ for every real number $x$.\par II.\ The graph of $y=g(x)$ has exactly two $x$-intercepts.\par III.\ $g$ is increasing for every $x>2$.\par\medskip Which of the statements must be true?",
        opts=["I only", "I and II only", "II and III only", "I, II, and III"], fig='',
        ans="(%s) I and II only" % VAL['S2N-24'],
        rat="An absolute value is never negative (I). $x^2-4x=0$ gives $x=0,4$, so there are two $x$-intercepts (II). On $2<x<4$ the parabola is below the axis and its reflection $-(x^2-4x)$ is decreasing, so $g$ is not increasing for all $x>2$ (III false).",
        trick="absolute value of a quadratic: reflected piece reverses monotonicity on (2,4); statements about range, intercepts and increasing")
    LET.update({k: VAL[k] for k in ('S2N-01', 'S2N-03', 'S2N-04', 'S2N-06', 'S2N-07', 'S2N-17', 'S2N-21', 'S2N-24')})
    LET['S2N-10'] = VAL['S2N-10_letter']
    LET['S2N-13'] = "ABCD"[0]                                   # option 0 = 'no real solutions' <-> VAL['S2N-13']==0
    LET['S2N-15'] = "ABCD"[opt15.index(VAL['S2N-15'])]
    LET['S2N-18'] = "ABCD"[[1, 2, 3, 4].index(VAL['S2N-18'])]
    LET['S2N-22'] = "ABCD"[eqv.index(True)] if eqv.count(True) == 1 else 'A'
    return I

def check_all():
    make()
    return VAL

if __name__ == '__main__':
    its = make()
    for i in its: print(i['id'], i['part'], i['d'], i['tool'], '|', i['ans'])
    print(len(its))
