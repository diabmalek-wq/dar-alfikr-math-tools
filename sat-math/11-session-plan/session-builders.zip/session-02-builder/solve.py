# Independent solutions from question text only (numpy/scipy), computed BEFORE reading bank answers.
import numpy as np, math
from scipy.optimize import brentq, fsolve, minimize_scalar
from numpy.linalg import solve as ls
M={}
def quad_through(pts):  # coefficients a,b,c through 3 points
    A=np.array([[x*x,x,1] for x,_ in pts],float); y=np.array([v for _,v in pts],float); return ls(A,y)
# 162
M['AM-162']=brentq(lambda t:640*0.5**(t/8)-40,0,200)
# 163
h=lambda t:-16*t*t+96*t+4; r=minimize_scalar(lambda t:-h(t),bounds=(0,10),method='bounded',options={'xatol':1e-10}); M['AM-163']=('vertex',round(r.x,6),round(h(r.x),6),'=> B (max height 148 ft at t=3 s)')
# 164
rev=lambda pr:pr*(600-20*(pr-20)); r=minimize_scalar(lambda pr:-rev(pr),bounds=(0,60),method='bounded',options={'xatol':1e-10}); M['AM-164']=('price',round(r.x,6),'max revenue',round(rev(r.x),6))
# 165
C=lambda n:0.02*n*n-3.2*n+210; r=minimize_scalar(C,bounds=(0,300),method='bounded',options={'xatol':1e-10}); M['AM-165']=(round(r.x,6),round(C(r.x),6))
# 168
rng=np.random.default_rng(1); res={'I':set(),'II':set(),'III':set()}
for _ in range(300000):
    a=rng.uniform(-5,5)
    if abs(a)<1e-3: continue
    b=-10*a; c=rng.uniform(-400,400)
    f=lambda z:a*z*z+b*z+c
    if b*b-4*a*c<=0 or not(f(0)<0 and f(5)>0): continue
    z=np.roots([a,b,c]); res['I'].add(b>0); res['II'].add(c/a>25); res['III'].add(bool(all(z>0)))
M['AM-168']=res
# 180
a=(6+2)/(5-3)**2; f=lambda z:a*(z-3)**2-2; g=lambda z:0.75*f(0.5*z-1); M['AM-180']=(a,g(0)-f(0))
# 181
M['AM-181']=[(p,2**p+9-2**p) for p in [brentq(lambda p:(2**-p+(9-2**p))-21/4,0.1,5)]]
p=brentq(lambda p:(9-2**p)+2**-p-21/4,0.1,5); M['AM-181']=(p,'k=',9-2**p)
# 183
a,b,c=ls(np.array([[0,0,1],[4,2,1],[25,5,1]],float),np.array([3,43,28.])); M['AM-183']=(a,b,c,9*a+3*b+c)
# 184
a=-24/((1+2)*(1-5)); f=lambda z:a*(z+2)*(z-5); M['AM-184']=(a,f(1+2)-3*f(-1))
# 185
A,K=ls(np.array([[1,1],[9,1]],float),np.array([-3,13.])); f=lambda z:A*(z-2)**2+K; g=lambda z:(z-6)/2; M['AM-185']=(A,K,3-f(g(0)))
# 186
b=math.sqrt(729/1296); c=1296/b**4; M['AM-186']=(b,c,c*b**4,c*b**6,(1-b)*100)
# 187
M['AM-187']=(math.sqrt(0.49), (1-math.sqrt(0.49))*100)
# 188
A=(-3-(5-0))/((0-1)*(0-4)); pf=lambda z:A*(z-1)*(z-4)+5-z; M['AM-188']=(A,pf(0),pf(1),pf(4),pf(6))
# 190
def F(v):
    a,b,c=v; return [a*b**2+c-14,a*b**4+c-20,a*b**6+c-32]
sols=set()
for g0 in [(1,1.1,1),(3,1.4,8),(1,2,0),(5,1.2,2),(.5,3,5)]:
    s,info,ier,_=fsolve(F,g0,full_output=True)
    if ier==1 and s[1]>1: sols.add(tuple(np.round(s,6)))
M['AM-190']=sols
# 191
xs=np.linspace(0,300,300001); fx=120-90*0.8**xs; gx=-3*(xs-4)**2+125; M['AM-191']=('f max over [0,300]',fx.max(),'f<120 everywhere',bool((fx<120).all()),'f increasing',bool((np.diff(fx)>0).all()),'g max',gx.max(),'at x=',xs[gx.argmax()])
# 192
# -2x^2+20x-50+k = m(x^2-(1+r)x+r) -> m=-2 ; -m(1+r)=20 -> r=9 ; m r = -50+k
m=-2; r=-20/m-1; k=m*r+50; M['AM-192']=(m,r,k, [(-2*(z-5)**2+k)-m*(z-1)*(z-r) for z in (-3,0,2.5,11)])
# 199
Aq=0
for i in range(7): Aq=Aq/2+100
M['AM-199']=Aq
# 201
b=1.44**0.5; M['AM-201']=((b**3-1)*100,b)
# 209
a,b,c=quad_through([(2,0),(0,-16),(5,54)]); xv=-b/(2*a); M['AM-209']=(a,b,c,a*xv*xv+b*xv+c)
# 210
a,b,c=quad_through([(0,1),(1,-2),(3,4)]); f=lambda z:a*z*z+b*z+c; M['AM-210']=(a,b,c,f(-3)-5)
# 213
# f(x)=m x+n: g(1)=(f(3)-1)/(-2)=3, g(5)=(f(7)-5)/2=-11
f3=3*(-2)+1; f7=-11*2+5; mm=(f7-f3)/4; nn=f3-3*mm; M['AM-213']=(mm,nn,[((mm*(x+2)+nn-x)/(x-3)) for x in (1,5)])
# 216
fx=lambda x:48*(1/8)**((2-x)/3); xs=np.linspace(0,6,13)
M['AM-216']={k:float(np.abs(fx(xs)-g(xs)).max()) for k,g in dict(A=lambda x:192*0.5**x,B=lambda x:12*2**x,C=lambda x:48*2**x,D=lambda x:12*0.5**x).items()}; M['AM-216']['f(0)']=fx(0)
# 221
k=(12+4)/4; z1,z2=k+1,3*k-5; M['AM-221']=(k,z1,z2,2*z1*z2,[(2*(z-z1)*(z-z2)) for z in (2,10)])
# 223
d=lambda x:2**x-(3*x-1); rts=[brentq(d,lo,hi) for lo,hi in ((0.5,1.5),(2.5,3.5))]; xs=np.linspace(-20,10,30001); gt=d(xs)>1e-12
M['AM-223']=(rts,'regions where g>h (transitions at):',[round(xs[i],3) for i in range(1,len(xs)) if gt[i]!=gt[i-1]],'g>h at -20:',bool(gt[0]),'at 2:',bool(d(2)>0),'at 10:',bool(gt[-1]))
# 228
xs=np.linspace(-30,30,6001); g=7+9*0.25**xs; M['AM-228']=('all>7',bool((g>7).all()),'min',g.min(),'decreasing',bool((np.diff(g)<0).all()),'inf approached not attained: g(60)-7=',9*0.25**60)
# 230
tt=np.linspace(0,400,40001)
M['AM-230']={'A':25+60*0.8**tt[0],'Amax':(25+60*0.8**tt).max(),'Bmax(reached)':(85-60*0.8**tt).max(),'Bhits85':bool(((85-60*0.8**tt)>=85).any()),'Cmax(t<=400)':(40+45*1.05**tt).max(),'Dmax':(25+85*0.8**tt).max()}
# 234
rng=np.random.default_rng(2); res=set()
for _ in range(300000):
    a=rng.uniform(-5,5); b=2*a; c=rng.uniform(-30,30)
    h=lambda z:a*z*z+b*z+c
    if h(0)>h(-1) and h(-1)>0: res.add((b>0,c>0,b*b-4*a*c>0))
M['AM-234']=res
# 236
A=(2-7)/(-2)-4; A=(( (2-7)/-2) -4)/(5-3)**2; f=lambda z:A*(z-3)**2+4; g=lambda z:-2*f(z+1)+7; M['AM-236']=(A,g(4),f(9)-f(2))
# 238
outs=set()
for b in np.linspace(48,400,50):
    c=130-b*b/64
    if c>94+1e-9: continue
    T=np.linspace(0,b/16+1,4000001); H=-16*T*T+b*T+c; ok=T[H>=94-1e-9]; outs.add(round(ok[-1]-ok[0],3))
M['AM-238']=(outs,'b=48 gives c=',130-48**2/64)
# 240
M['AM-240']=(math.log(3)/(2*math.log(1.06)),)
# 241
# vertex of f at x=4, zero at 9 -> other zero -1
M['AM-241']=(8-9, 'b=',-16,'c=',2*9*-1*-1 if False else None)
f=lambda z:2*(z-9)*(z+1); M['AM-241']=(f(9),f(-1),'f vertex x=',(9-1)/2)
# 244
A,K=ls(np.array([[9,1],[1,1]],float),np.array([-4,12.])); f=lambda z:A*(z-3)**2+K; M['AM-244']=(A,K,f(-1)-f(7),f(0),f(4),f(10))
# 246
xv=np.array([2,5,8,11.]); yv=np.array([44,95,200,359.]); co=np.polyfit(xv,yv,2); M['AM-246']=(co,np.polyval(co,17),np.abs(np.polyval(co,xv)-yv).max())
# 247
C=lambda t:18*(1/3)**((t-4)/2); ts=np.linspace(0,10,11)
M['AM-247']={k:float(np.abs(C(ts)-g(ts)).max()) for k,g in dict(A=lambda t:486*3**(-(t+2)/2),B=lambda t:18*3**((4-t)/2),C=lambda t:162*3**(-t/2),D=lambda t:54*3**((2-t)/2)).items()}; M['AM-247']['C(0)']=C(0)
# 249
sols=[]
for v0 in (2,3,4,5):
    s=fsolve(lambda w:[w[0]*(1-w[1])**2-45,w[0]*(6-w[1])**2-20],(1,v0)); 
    if 1<s[1]<6 and s[0]>0: sols.append(tuple(np.round(s,6)))
sols=set(sols); M['AM-249']=[(s,125-s[0]*s[1]**2,'h(1),h(6)=',125-s[0]*(1-s[1])**2,125-s[0]*(6-s[1])**2) for s in sols]
# 251-262
M['AM-251']=('vertex f=(2,-3); g(x)=f(x+3) -> (-1,-3)',)
f=lambda z:3*z-2; g=lambda z:z*z+1; M['AM-252']=f(g(2))-g(f(2))
M['AM-253']=('f(2x)=0 at 2x=-2,6 -> x=',-1,3)
M['AM-254']=-2*(-5)+1
M['AM-255']=('g=|x+1-3|-2=|x-2|-2 vertex',(2,-2))
f=lambda z:2*z+1; M['AM-256']=f(f(3))-f(3)
M['AM-258']=('k=',6-1,'m=',-3-4,'sum',(6-1)+(-3-4))
f=lambda z:z+3; g=lambda z:2*z-1; M['AM-259']=[(z,f(g(z)),g(f(z))) for z in (-2,0,1,3)]
M['AM-260']=(9+4)+3
M['AM-261']=('vertex of -f(x+1)+3',(-2-1,-5+3))
M['AM-262']=('h',(1+5)/2,'k',2,'sum',3+2,'check g(1)=',(1-3)**2+2)
# 215
res=[]
for u in range(-80,81):
    b=u+3; c=3*u+4; assert (-27+9*b-3*c+12)==0
    rts=np.roots([1,b,c,12]); real=set(round(z.real,5) for z in rts if abs(z.imag)<1e-7)
    if len(real)==1: res.append((c,u))
M['AM-215']=(max(res),sorted(res)[:3],len(res))
# also check: all integer (b,c) with p(-3)=0 [c=3b-5]
res2=[]
for b in range(-300,301):
    c=3*b-5; rts=np.roots([1,b,c,12]); real=set(round(z.real,5) for z in rts if abs(z.imag)<1e-7)
    if len(real)==1: res2.append(c)
M['AM-215b']=max(res2)
# 134
M['AM-134']=(1/57,'product=ab/57')
# 141
a=20/5; b=(15-a*0 - (-9))/a if False else (15+9)/a; M['AM-141']=(a,b,a*b,'x-coef',a*4-3*b,'const',12)
for k_,v in M.items(): print(k_,v)
