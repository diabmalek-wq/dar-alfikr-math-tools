"""Desmos-style solution steps for Session 2.
Every number quoted in a step is computed here (not typed by hand) from the item data,
and every typed Desmos expression that 'returns' a value is evaluated by ev()."""
import math, re
import numpy as np
from scipy.optimize import brentq

def n(v, d=4):
    s = ('%.*f' % (d, v)).rstrip('0').rstrip('.')
    return '0' if s in ('-0', '') else s
def ev(expr, **kw):
    e = expr.replace('^', '**')
    e = re.sub(r'(\d|\))\s*(\(|[a-zA-Z])', r'\1*\2', e)
    env = dict(sqrt=math.sqrt, abs=abs, ln=math.log, **kw)
    return eval(e, {'__builtins__': {}}, env)
def c(e): return '[[%s]]' % e
def v(x, d=4): return '$%s$' % n(x, d)
def ret(e, d=4, **kw): return "Type %s: it returns %s" % (c(e), v(ev(e, **kw), d))
def pt(x, y, d=4): return "$(%s,\\,%s)$" % (n(x, d), n(y, d))
def reg(xs, ys):
    a, b, cc = np.polyfit(xs, ys, 2)
    assert np.abs(np.polyval([a, b, cc], xs) - np.array(ys)).max() < 1e-9
    return a, b, cc
def table(xs, ys):
    return ("Open a table and enter $x_1=%s$ and $y_1=%s$. Type %s: Desmos returns $a=%s$, $b=%s$, $c=%s$."
            % (",".join(map(str, xs)), ",".join(map(str, ys)), c('y_1~a*x_1^2+b*x_1+c'), '%s', '%s', '%s'))
def tab_reg(xs, ys):
    a, b, cc = reg(xs, ys)
    return table(xs, ys) % (n(a), n(b), n(cc)), (a, b, cc)

S = {}
V = {}  # recorded numbers for verification

# 162
t32 = brentq(lambda x: 640 * 0.5 ** (x / 8) - 40, 0, 400)
S['AM-162'] = ["Type %s and %s (letting $x$ stand for $t$; zoom out to see both)." % (c('y=640*(1/2)^(x/8)'), c('y=40')),
               "Tap the intersection: %s. Its $x$-value is the time." % pt(t32, 40),
               ret('640*(1/2)^(32/8)') + ", so the dose is at $40$ milligrams after $32$ hours."]
V['AM-162'] = t32

# 163
S['AM-163'] = ["Type %s (letting $x$ stand for $t$) and tap the top of the curve (zoom out if needed)." % c('y=-16x^2+96x+4'),
               "The vertex is %s, the highest point because the parabola opens downward." % pt(3, ev('-16*3^2+96*3+4')),
               "The first coordinate is time and the second is height, so $3$ seconds after launch the ball is at its maximum height of $148$ feet."]

# 164
vx = 5
S['AM-164'] = ["Let $x$ be the number of \\$1 increases. The price is $20+x$ and the tickets sold are $600-20x$. Type %s." % c('y=(20+x)(600-20x)'),
               "Tap the vertex (zoom out if needed): %s." % pt(vx, ev('(20+x)*(600-20*x)', x=5)),
               "That is $x=5$ increases of \\$1. " + ret('20+5') + ", the price in dollars. The value $12{,}500$ is the greatest revenue, not the price."]

V['AM-164'] = 25

# 165
S['AM-165'] = ["Type %s (letting $x$ stand for $n$) and zoom out." % c('y=0.02x^2-3.2x+210'),
               "Tap the vertex (lowest point): %s." % pt(80, ev('0.02*80^2-3.2*80+210')),
               ret('0.02*80^2-3.2*80+210') + ", so the minimum cost per unit is $82$ dollars."]

_vx=3.2/(2*0.02); V['AM-165'] = 0.02*_vx**2-3.2*_vx+210

# 168
f168 = lambda x: -(x - 5) ** 2 + 9
S['AM-168'] = ["$f(2)=f(8)$ puts the axis at $x=5$. With two zeros and $f(5)>0$ the parabola opens downward. Try an example that fits: type %s." % c('y=-(x-5)^2+9'),
               "Tap the points: zeros %s and %s (both positive), $y$-intercept %s (so $f(0)<0$), vertex %s (so $f(5)>0$). Statement III holds." % (pt(2, 0), pt(8, 0), pt(0, f168(0)), pt(5, f168(5))),
               "Type %s: the same graph, so $b=%s>0$ and statement I holds." % (c('y=-x^2+10x-16'), n(10)),
               "The zeros multiply to $2\\cdot8=16$, not more than $25$ (in general they are $5\\pm d$ with $d<5$, product $25-d^2<25$), so II fails. Statements I and III only."]
assert f168(2) == 0 and f168(8) == 0 and f168(0) == -16 and -1 * 1 == -1 and (10 == 10)
assert all(abs(f168(x) - (-x * x + 10 * x - 16)) < 1e-12 for x in range(-3, 9)) and 2 * 8 == 16

# 180
a180 = 2
f180 = lambda x: a180 * (x - 3) ** 2 - 2
g180 = lambda x: 0.75 * f180(0.5 * x - 1)
assert f180(5) == 6
S['AM-180'] = ["Type %s (accept the slider for $a$) and plot the point %s." % (c('f(x)=a(x-3)^2-2'), c('(5,6)')),
               "Slide $a$ until the curve passes through the point: $a=2$. Then $p=f(0)=%s$." % n(f180(0)),
               "Type %s and then %s: it returns $%s$, which is $\\dfrac{13}{2}$." % (c('g(x)=3/4*f(x/2-1)'), c('g(0)-f(0)'), n(g180(0) - f180(0)))]
V['AM-180'] = g180(0) - f180(0)

# 181
p181 = brentq(lambda x: 2 ** x - 2 ** (-x) - 3.75, 0.1, 6)
k181 = 9 - 2 ** p181
S['AM-181'] = ["Subtract the two equations: $2^p-2^{-p}=9-\\dfrac{21}{4}=\\dfrac{15}{4}$. Type %s and %s." % (c('y=2^x-2^(-x)'), c('y=15/4')),
               "Tap the intersection: %s, so $p=%s$." % (pt(p181, 3.75), n(p181)),
               "Then $k=9-2^2=%s$. Check: %s, which is $\\dfrac{21}{4}$." % (n(k181), ret('2^(-2)+5'))]
V['AM-181'] = p181

# 183
t183, (a183, b183, c183) = tab_reg([0, 2, 5], [3, 43, 28])
S['AM-183'] = [t183.replace('Open a table', 'The altitude points are $(0,3)$, $(2,43)$, $(5,28)$. Open a table'),
               "So $h(t)=%s t^2+%s t+%s$." % (n(a183), n(b183), n(c183)),
               ret('-5*3^2+30*3+3') + ", the altitude $3$ seconds after launch in meters."]
V['AM-183'] = a183 * 9 + b183 * 3 + c183

# 184
a184 = -24 / ((1 + 2) * (1 - 5))
f184 = lambda x: a184 * (x + 2) * (x - 5)
h184 = lambda x: f184(x + 2) - 3 * f184(-x)
S['AM-184'] = ["The zeros are $-2$ and $5$: type %s (slider $a$) and plot %s." % (c('f(x)=a(x+2)(x-5)'), c('(1,-24)')),
               "Slide $a$ until the curve passes through the point: $a=%s$." % n(a184),
               "Type %s and then %s: it returns $%s$." % (c('h(x)=f(x+2)-3f(-x)'), c('h(1)'), n(h184(1)))]
V['AM-184'] = h184(1)

# 185
t185, (a185, b185, c185) = tab_reg([1, 3, 5], [-3, -3, 13])
f185 = lambda x: a185 * x * x + b185 * x + c185
g185 = lambda x: (x - 6) / 2
h185 = lambda x: 3 - f185(g185(x))
S['AM-185'] = ["The axis is $x=2$, so $f(1)=f(3)=-3$. " + t185,
               "Type %s, %s and %s." % (c('f(x)=2x^2-8x+3'), c('g(x)=(x-6)/2'), c('h(x)=3-f(g(x))')),
               "Type %s: it returns $%s$, the $y$-intercept's $y$-coordinate." % (c('h(0)'), n(h185(0)))]
assert (n(a185), n(b185), n(c185)) == ('2', '-8', '3')
V['AM-185'] = h185(0)

# 186
b186 = math.sqrt(729 / 1296)
c186 = 1296 / b186 ** 4
S['AM-186'] = ["$f(3)$ and $f(1)$ are two steps apart, so $b^2=\\dfrac{729}{1296}$. " + ret('sqrt(729/1296)') + ", so $b=%s$." % n(b186),
               "Each increase of $1$ multiplies $f$ by $0.75$: " + ret('(1-0.75)*100') + ", a decrease of $25\\%$.",
               "Check: " + ret('1296/0.75^4') + ", so $c=4096$. Then " + ret('4096*0.75^6')[0].lower() + ret('4096*0.75^6')[1:] + ", which is $f(3)$."]
assert abs(c186 - 4096) < 1e-6
V['AM-186'] = (1 - b186) * 100

# 187
S['AM-187'] = ["One year multiplies the value by $0.49^{1/2}$. " + ret('0.49^(1/2)') + ".",
               "The yearly factor is $0.7$, so the loss is $(1-0.7)\\cdot100$ percent. " + ret('(1-0.7)*100') + ".",
               "Check: " + ret('18000*0.49^(1/2)') + ", which is $0.7\\cdot18{,}000$, a drop of $5{,}400$ from $18{,}000$."]

# 188
t188, (a188, b188, c188) = tab_reg([0, 1, 4], [-3, 4, 1])
p188 = lambda x: a188 * x * x + b188 * x + c188
S['AM-188'] = ["On the line $y=5-x$: at $x=1$, $y=%s$; at $x=4$, $y=%s$. So $p$ passes through $(1,4)$, $(4,1)$ and $(0,-3)$." % (n(ev('5-1')), n(ev('5-4'))),
               t188.replace('Open a table and enter', 'Open a table and enter'),
               ret('-2*6^2+9*6-3') + ", so $p(6)=%s$." % n(p188(6))]
assert (n(a188), n(b188), n(c188)) == ('-2', '9', '-3')
V['AM-188'] = p188(6)

# 190
b190 = math.sqrt(12 / 6)
a190 = 6 / (b190 ** 2 * (b190 ** 2 - 1))
c190 = 14 - a190 * b190 ** 2
S['AM-190'] = ["The differences are $20-14=6$ and $32-20=12$, and the second is $b^2$ times the first. " + ret('12/6') + ", so $b^2=2$ and $b=\\sqrt2$.",
               "Then $ab^2(b^2-1)=6$ becomes $2a(2-1)=6$. " + ret('6/(2*(2-1))') + ", so $a=3$.",
               "Then $c=14-ab^2$: " + ret('14-3*2') + ", so $c=8$.",
               "Check: type %s and plot %s, %s and %s; the curve passes through all three." % (c('y=3*sqrt(2)^x+8'), c('(2,14)'), c('(4,20)'), c('(6,32)'))]
assert abs(3 * math.sqrt(2) ** 2 + 8 - 14) < 1e-9 and abs(3 * math.sqrt(2) ** 4 + 8 - 20) < 1e-9 and abs(3 * math.sqrt(2) ** 6 + 8 - 32) < 1e-9
V['AM-190'] = c190

# 191
S['AM-191'] = ["Type %s and %s." % (c('y=120-90*0.8^x\\{x>=0\\}'), c('y=-3(x-4)^2+125\\{x>=0\\}')),
               "Tap the top of the parabola: %s, so $g$ attains a maximum of $125$." % pt(4, 125),
               "Type %s to draw the line $120$: $f$ rises toward it but never touches it (no grey dot appears). For example, %s, still below $120$." % (c('y=120'), ret('120-90*0.8^50')[0].lower() + ret('120-90*0.8^50')[1:]),
               "So only $g$ attains a maximum, $125$."]

# 192
k192 = 32
S['AM-192'] = ["Comparing the $x^2$ terms gives $m=-2$. At $x=1$ the right side is $0$, so the left side must be $0$ there. Type %s (accept the slider for $k$) and plot %s." % (c('y=-2(x-5)^2+k'), c('(1,0)')),
               "Widen the slider range (set its maximum to $40$) and slide $k$ until the curve passes through the point: $k=32$.",
               "Check: " + ret('-2*(1-5)^2+32') + ".",
               "Also $r=9$: type %s; it lies exactly on top of %s." % (c('y=-2(x-1)(x-9)'), c('y=-2(x-5)^2+32'))]
assert all(abs((-2 * (x - 5) ** 2 + 32) - (-2 * (x - 1) * (x - 9))) < 1e-9 for x in (-3, 0, 2, 7, 11))
V['AM-192'] = k192

# 199
A7 = 100 * (1 - 0.5 ** 7) / (1 - 0.5)
S['AM-199'] = ["The doses are Mon 8 a.m., Mon 8 p.m., Tue 8 a.m., Tue 8 p.m., Wed 8 a.m., Wed 8 p.m., Thu 8 a.m.: $7$ doses. Each dose is $100$ and each earlier dose has been halved once for every dose since.",
               "The amount is $100\\left(1+\\tfrac12+\\tfrac14+\\cdots+\\tfrac1{64}\\right)=100\\cdot\\dfrac{1-0.5^7}{1-0.5}$.",
               ret('100*(1-0.5^7)/(1-0.5)') + ", which is $198.4$ to the nearest tenth."]
V['AM-199'] = A7

# 201
S['AM-201'] = ["$f(x+2)=b^2f(x)$ and it is $44\\%$ greater, so $b^2=1.44$. " + ret('sqrt(1.44)') + ", so $b=1.2$.",
               "Now $f(x+3)=b^3f(x)$: " + ret('1.2^3') + ".",
               "A factor of $1.728$ is an increase of $(1.728-1)\\cdot100$ percent. " + ret('(1.728-1)*100') + ", so $p=72.8$."]
V['AM-201'] = (1.2 ** 3 - 1) * 100

# 209
t209, (a209, b209, c209) = tab_reg([0, 2, 5], [-16, 0, 54])
S['AM-209'] = [t209.replace('Open a table', 'The points are $(0,-16)$, $(2,0)$ and $(5,54)$. Open a table'),
               "Type %s and tap the vertex (lowest point): %s." % (c('y=2x^2+4x-16'), pt(-1, 2 - 4 - 16)),
               "The minimum value of $f$ is $-18$."]
assert (n(a209), n(b209), n(c209)) == ('2', '4', '-16')
V['AM-209'] = -18

# 210
t210, (a210, b210, c210) = tab_reg([0, 1, 3], [1, -2, 4])
f210 = lambda x: a210 * x * x + b210 * x + c210
g210 = lambda x: f210(x - 3) - 5
S['AM-210'] = [t210,
               "Type %s and %s: right $3$, down $5$." % (c('f(x)=2x^2-5x+1'), c('g(x)=f(x-3)-5')),
               "Tap the $y$-intercept of $g$: %s. Check: type %s; it returns $%s$." % (pt(0, g210(0)), c('g(0)'), n(g210(0)))]
assert (n(a210), n(b210), n(c210)) == ('2', '-5', '1')
V['AM-210'] = g210(0)

# 213
S['AM-213'] = ["$g(1)=3$ gives $\\dfrac{f(3)-1}{1-3}=3$: " + ret('3*(-2)+1') + ", so $f(3)=-5$. $g(5)=-11$ gives $\\dfrac{f(7)-5}{5-3}=-11$: " + ret('-11*2+5') + ", so $f(7)=-17$.",
               "Open a table with $x_1=3,7$ and $y_1=-5,-17$ and type %s: Desmos returns $m=%s$, $n=%s$." % (c('y_1~m*x_1+n'), n(-3), n(4)),
               "The $y$-intercept is $%s$. Check with %s: " % (n(4), c('f(x)=-3x+4')) + "type %s; it returns $%s$, and type %s; it returns $%s$." % (c('(f(1+2)-1)/(1-3)'), n(((-3 * 3 + 4) - 1) / (1 - 3)), c('(f(5+2)-5)/(5-3)'), n(((-3 * 7 + 4) - 5) / (5 - 3)))]
assert np.allclose(np.polyfit([3, 7], [-5, -17], 1), [-3, 4])

V['AM-213'] = 4

# 216
S['AM-216'] = ["Type %s and tap the $y$-intercept: %s, so the constant factor must be $12$." % (c('y=48*(1/8)^((2-x)/3)'), pt(0, 48 * (1 / 8) ** (2 / 3))),
               "Type %s: it lies exactly on top of the first graph." % c('y=12*2^x'),
               "The others fail: %s starts at $192$, %s starts at $48$, and %s starts at $12$ but falls instead of rises. Only (@@L@@) matches and shows $12$." % (c('y=192*(1/2)^x'), c('y=48*2^x'), c('y=12*(1/2)^x'))]
assert abs(48 * (1 / 8) ** (2 / 3) - 12) < 1e-9

# 221
k221 = 4
S['AM-221'] = ["$g(2)=g(10)$ puts the axis at $x=6$, so the zeros add to $12$: $(k+1)+(3k-5)=12$. Type %s and %s (letting $x$ stand for $k$)." % (c('y=4x-4'), c('y=12')),
               "Tap the intersection: %s, so $k=4$ and the zeros are $5$ and $7$." % pt(4, 12),
               "Type %s and tap the $y$-intercept: %s, so $c=70$." % (c('y=2(x-5)(x-7)'), pt(0, 2 * 5 * 7)),
               "Check $g(2)=g(10)$: type %s and %s; both return $%s$." % (c('2(2-5)(2-7)'), c('2(10-5)(10-7)'), n(ev('2*(2-5)*(2-7)')))]
assert ev('2*(2-5)*(2-7)') == ev('2*(10-5)*(10-7)') == 30
V['AM-221'] = 70

# 223
S['AM-223'] = ["Type %s and %s." % (c('y=2^x'), c('y=3x-1')),
               "Tap the two intersections: %s and %s." % (pt(1, 2), pt(3, 8)),
               "The exponential curve is above the line to the left of $x=1$ and to the right of $x=3$, and below it in between. So $g(x)>h(x)$ for $x<1$ or $x>3$."]
assert 2 ** 1 == 3 * 1 - 1 and 2 ** 3 == 3 * 3 - 1 and 2 ** 2 < 3 * 2 - 1

# 228
S['AM-228'] = ["Type %s and %s." % (c('y=7+9*(1/4)^x'), c('y=7')),
               "The curve falls toward the line but never touches it: " + ret('7+9*(1/4)^3') + ", still above $7$. So $g(x)>7$ for every $x$ (I true), and there is no minimum value (II false).",
               "The curve always goes down as $x$ increases, so $g$ is decreasing (III true). I and III only."]

# 230
S['AM-230'] = ["Type the four models with $x$ standing for $t$: %s, %s, %s, %s, and the line %s." % (c('y=25+60*0.8^x'), c('y=85-60*0.8^x'), c('y=40+45*1.05^x'), c('y=25+85*0.8^x'), c('y=85')),
               "Tap the $y$-intercepts: (@@M4@@) %s, (@@M1@@) %s, (@@M3@@) %s, (@@M2@@) %s." % (pt(0, ev('25+85')), pt(0, ev('25+60')), pt(0, ev('40+45')), pt(0, ev('85-60'))),
               "(@@M4@@) and (@@M1@@) have factor $0.8$, so they fall and their greatest values are the $y$-intercepts, $110$ and $85$. (@@M3@@) has factor $1.05$ and rises without limit past $85$. (@@M2@@) rises toward $85$ but never reaches it: " + ret('85-60*0.8^30') + ".",
               "Only model (@@M1@@) has $85$ as the greatest temperature actually reached."]

# 234
S['AM-234'] = ["$h(-3)=h(1)$ puts the axis at $x=-1$. Since $h(0)>h(-1)$, the vertex is the lowest point (opens upward) and $h(-1)>0$ says it is above the axis. Try %s." % c('y=(x+1)^2+2'),
               "Tap the vertex: %s. The curve never meets the $x$-axis, so III is false. Check: %s and %s are both $%s$." % (pt(-1, 2), c('h(-3)'), c('h(1)'), n(6)),
               "Type %s: the same graph, so $b=2>0$ (I) and $c=3>0$ (II). In general $b=2a>0$ and $c=h(0)>h(-1)>0$. I and II only." % c('y=x^2+2x+3')]
assert ((-3 + 1) ** 2 + 2, (1 + 1) ** 2 + 2) == (6, 6)
S['AM-234'][1] = "Tap the vertex: %s. The curve never meets the $x$-axis, so III is false. Check $h(-3)=h(1)$: type %s; it returns $6$ and type %s; it returns $6$." % (pt(-1, 2), c('(-3+1)^2+2'), c('(1+1)^2+2'))

# 236
a236 = (2.5 - 4) / (5 - 3) ** 2
f236 = lambda x: a236 * (x - 3) ** 2 + 4
g236 = lambda x: -2 * f236(x + 1) + 7
assert abs(g236(4) - 2) < 1e-12
S['AM-236'] = ["$g(4)=-2f(5)+7=2$, so $f(5)=\\dfrac{2-7}{-2}$. " + ret('(2-7)/(-2)') + ".",
               "With the vertex $(3,4)$, $f(x)=a(x-3)^2+4$ and $f(5)=2.5$. " + ret('(2.5-4)/(5-3)^2') + ", so $a=-0.375$.",
               "Type %s, then %s: it returns $%s$, which is $-\\dfrac{105}{8}$." % (c('f(x)=-0.375(x-3)^2+4'), c('f(9)-f(2)'), n(f236(9) - f236(2))),
               "Check: type %s; it returns $%s$." % (c('-2f(5)+7'), n(g236(4)))]
V['AM-236'] = f236(9) - f236(2)

# 238
S['AM-238'] = ["The maximum is $130$ at some time $v$, so $h(t)=-16(t-v)^2+130$. Type %s (accept the slider for $v$) and %s." % (c('y=-16(x-v)^2+130'), c('y=94')),
               "Set $v=3$ and tap the two intersections: %s and %s. Change $v$: the gap between them stays the same." % (pt(1.5, 94), pt(4.5, 94)),
               "A launch height of at most $94$ means $130-16v^2\\le94$, so $v\\ge1.5$ and both crossings come after launch. " + ret('4.5-1.5') + ", the seconds spent at or above $94$ feet."]
assert abs(-16 * (1.5 - 3) ** 2 + 130 - 94) < 1e-12 and abs(-16 * (4.5 - 3) ** 2 + 130 - 94) < 1e-12
V['AM-238'] = 3

# 240
t240 = math.log(3) / (2 * math.log(1.06))
S['AM-240'] = ["Every half-year multiplies by $1.06$, so after $t$ years the factor is $1.06^{2t}$. Type %s and %s (letting $x$ stand for $t$)." % (c('y=1.06^(2x)'), c('y=3')),
               "Tap the intersection: %s." % pt(t240, 3),
               ret('ln(3)/(2*ln(1.06))') + ", which is $9.43$ to the nearest hundredth.",
               "Check: " + ret('1.06^(2*9.43)') + ", just above $3$."]
V['AM-240'] = t240

# 241
S['AM-241'] = ["$g(x)=f(x+3)$ has its vertex at $x=1$, so the vertex of $f$ is at $x=4$. The zeros $9$ and $r$ are centred on $4$: $\\dfrac{9+r}{2}=4$. Type %s and %s (letting $x$ stand for $r$)." % (c('y=(9+x)/2'), c('y=4')),
               "Tap the intersection: %s, so $r=-1$." % pt(-1, 4),
               "Check: type %s and %s, and tap the vertex of $g$: %s. Its $x$-value is $1$." % (c('f(x)=2(x-9)(x+1)'), c('g(x)=f(x+3)'), pt(1, 2 * (1 - 6) * (1 + 4)))]
assert 2 * (1 - 6) * (1 + 4) == -50
V['AM-241'] = -1

# 244
t244, (a244, b244, c244) = tab_reg([0, 6, 4], [-4, -4, 12])
f244 = lambda x: a244 * x * x + b244 * x + c244
S['AM-244'] = ["$f(-1)=f(7)$ puts the axis at $x=3$, so $f(6)=f(0)=-4$. The points are $(0,-4)$, $(6,-4)$, $(4,12)$.",
               t244,
               ret('-2*10^2+12*10-4') + ", so $f(10)=%s$." % n(f244(10))]
assert (n(a244), n(b244), n(c244)) == ('-2', '12', '-4')
V['AM-244'] = f244(10)

# 246
t246, (a246, b246, c246) = tab_reg([2, 5, 8, 11], [44, 95, 200, 359])
S['AM-246'] = [t246,
               "Check: type %s; the curve passes through all four table points." % c('y=3x^2-4x+40'),
               ret('3*17^2-4*17+40') + ", so $g(17)=%s$." % n(a246 * 289 + b246 * 17 + c246)]
assert (n(a246), n(b246), n(c246)) == ('3', '-4', '40')
V['AM-246'] = a246 * 289 + b246 * 17 + c246

# 247
S['AM-247'] = ["Type %s and tap the $y$-intercept: %s. The curve falls, so its maximum is $162$ at $t=0$." % (c('y=18*(1/3)^((x-4)/2)'), pt(0, 18 * (1 / 3) ** (-2))),
               "Type each option: %s, %s, %s, %s. All four lie exactly on that curve." % (c('y=486*3^(-(x+2)/2)'), c('y=18*3^((4-x)/2)'), c('y=162*3^(-x/2)'), c('y=54*3^((2-x)/2)')),
               "Only (@@L@@) has the maximum value $162$ as its coefficient (the others show $486$, $18$ and $54$). Check: " + ret('18*3^2') + "."]
assert all(abs(18 * (1 / 3) ** ((t - 4) / 2) - g(t)) < 1e-9 for t in (0, 1, 2.5, 7) for g in (lambda t: 486 * 3 ** (-(t + 2) / 2), lambda t: 18 * 3 ** ((4 - t) / 2), lambda t: 162 * 3 ** (-t / 2), lambda t: 54 * 3 ** ((2 - t) / 2)))

# 249
v249 = (6 + 2 / 3) / (1 + 2 / 3)
a249 = 45 / (1 - v249) ** 2
S['AM-249'] = ["Write $h(t)=125-a(t-v)^2$. Then $a(1-v)^2=45$ and $a(6-v)^2=20$. Dividing, $\\dfrac{6-v}{v-1}=\\sqrt{\\dfrac{20}{45}}$. " + ret('sqrt(20/45)') + ", which is $\\dfrac23$.",
               "Solve $6-v=\\tfrac23(v-1)$: " + ret('(6+2/3)/(1+2/3)') + ", so $v=4$. Then " + ret('45/(1-4)^2') + ", so $a=5$.",
               "Type %s and plot %s and %s: it passes through both. Tap the $y$-intercept: %s." % (c('y=125-5(x-4)^2'), c('(1,80)'), c('(6,105)'), pt(0, 125 - 5 * 16))]
assert abs(v249 - 4) < 1e-9 and abs(a249 - 5) < 1e-9 and 125 - 5 * 9 == 80 and 125 - 5 * 4 == 105
V['AM-249'] = 125 - 5 * 16

# 251
S['AM-251'] = ["Type %s and tap the vertex: %s." % (c('f(x)=x^2-4x+1'), pt(2, 2 * 2 * 0 + (2 ** 2 - 8 + 1))),
               "Type %s and tap the vertex: %s." % (c('g(x)=f(x+3)'), pt(-1, -3)),
               "$f(x+3)$ moves the graph $3$ units left, so the vertex $(2,-3)$ becomes $(-1,-3)$."]
assert 2 ** 2 - 4 * 2 + 1 == -3

# 252
S['AM-252'] = ["Type %s and %s." % (c('f(x)=3x-2'), c('g(x)=x^2+1')),
               "Type %s: it returns $%s$. Type %s: it returns $%s$." % (c('f(g(2))'), n(3 * (2 ** 2 + 1) - 2), c('g(f(2))'), n((3 * 2 - 2) ** 2 + 1)),
               ret('13-17') + "."]
V['AM-252'] = (3 * (2 ** 2 + 1) - 2) - ((3 * 2 - 2) ** 2 + 1)

# 253
S['AM-253'] = ["The graph of $y=f(2x)$ has an $x$-intercept wherever $2x$ is an $x$-intercept of $f$, so $2x=-2$ or $2x=6$.",
               "Solve each: $x=\\dfrac{-2}{2}=-1$ and $x=\\dfrac62=3$.",
               "Replacing $x$ by $2x$ squeezes the graph horizontally by a factor of $2$, so each $x$-intercept is halved: $x=-1$ and $x=3$."]

# 254
S['AM-254'] = ["Shifting the graph $3$ units right does not change its lowest value, so $f(x-3)$ still has a minimum of $-5$.",
               "Multiplying by $-2$ flips the graph over, so the minimum becomes a maximum: $-2\\cdot(-5)=10$.",
               "Adding $1$ raises the graph by $1$: $10+1=11$, the maximum value of $g$."]

# 255
S['AM-255'] = ["The vertex of $f(x)=|x-3|$ is $(3,0)$.",
               "$f(x+1)$ moves the graph $1$ unit left, to $(2,0)$, and the $-2$ moves it $2$ units down, to $(2,-2)$.",
               "Check by rewriting: $g(x)=|(x+1)-3|-2=|x-2|-2$, whose vertex is $(2,-2)$."]

# 256
f256 = lambda x: 2 * x + 1
g256 = lambda x: f256(f256(x)) - f256(x)
S['AM-256'] = ["Type %s and %s." % (c('f(x)=2x+1'), c('g(x)=f(f(x))-f(x)')),
               "Type %s: it returns $%s$." % (c('g(3)'), n(g256(3))),
               "Check by hand: $f(3)=7$ and $f(f(3))=f(7)=15$, and $15-7=8$."]
V['AM-256'] = g256(3)

# 258
S['AM-258'] = ["Type %s and tap its vertex: %s." % (c('f(x)=(x-1)^2+4'), pt(1, 4)),
               "The vertex moves from $(1,4)$ to $(6,-3)$. Horizontally: " + ret('6-1') + ", so $k=5$. Vertically: " + ret('-3-4') + ", so $m=-7$.",
               "Type %s and tap the vertex: %s." % (c('g(x)=f(x-5)-7'), pt(6, -3)),
               ret('5+(-7)') + ", so $k+m=-2$."]
V['AM-258'] = 5 + (-7)

# 259
S['AM-259'] = ["Type %s and %s." % (c('f(x)=x+3'), c('g(x)=2x-1')),
               "Type %s and %s: two lines, $y=2x+2$ and $y=2x+5$." % (c('y=f(g(x))'), c('y=g(f(x))')),
               "They are parallel, so there is no intersection and no $x$ with $f(g(x))=g(f(x))$."]
assert all(2 * x + 2 != 2 * (x + 3) - 1 for x in range(-10, 10)) and all((2 * x - 1 + 3) == 2 * x + 2 and 2 * (x + 3) - 1 == 2 * x + 5 for x in range(-5, 5))

# 260
S['AM-260'] = ["$g(3)=f(3)+4=9+4=%d$." % (9 + 4),
               "$h(3)=f(3-2)=f(1)=3$.",
               "$g(3)+h(3)=%d+3=%d$." % (9 + 4, 9 + 4 + 3)]

# 261
S['AM-261'] = ["$f(x+1)$ moves the vertex $1$ unit left: $(-2,5)\\to(-3,5)$.",
               "The minus sign reflects the graph over the $x$-axis, so $(-3,5)\\to(-3,-5)$.",
               "The $+3$ moves it up $3$: $(-3,-5)\\to(-3,-2)$."]

# 262
S['AM-262'] = ["The minimum value is $2$, so $k=2$. The points $(1,6)$ and $(5,6)$ are at the same height, so the axis is halfway: " + ret('(1+5)/2') + ", so $h=3$.",
               "Type %s and plot %s and %s: the curve passes through both. Tap the vertex: %s." % (c('y=(x-3)^2+2'), c('(1,6)'), c('(5,6)'), pt(3, 2)),
               ret('3+2') + ", so $h+k=5$."]
assert (1 - 3) ** 2 + 2 == 6 and (5 - 3) ** 2 + 2 == 6
V['AM-262'] = 5

# 215
S['AM-215'] = ["$p(-3)=0$ and the constant term is $12$, so $p(x)=(x+3)(x^2+ux+4)$ with $u$ an integer. For one real zero the quadratic factor must have none. Type %s (accept the slider for $a$, in the place of $u$)." % c('y=x^2+a*x+4'),
               "Slide $a$: the parabola stays above the $x$-axis for $a=-3,\\dots,3$ and touches it at $a=\\pm4$ (a new zero). So the largest allowed $a$ is $3$.",
               "Expanding, $c=3a+4$: " + ret('3*3+4') + ".",
               "Check: type %s; it crosses the $x$-axis only at $(-3,\\,0)$." % c('y=x^3+6x^2+13x+12')]
V['AM-215'] = 13

# 134
S['AM-134'] = ["Try $a=3$ and $b=2$: type %s." % c('y=57x^2+(57*2+3)x+3*2'),
               "Tap the zeros: %s and %s." % (pt(-2, 0), pt(-3 / 57, 0)),
               "Their product over $ab$: " + ret('(-2)*(-3/57)/6') + ".",
               ret('1/57') + ", so $k=\\dfrac1{57}$."]
V['AM-134'] = 1 / 57

# 141
S['AM-141'] = ["The $x^3$ terms: $5a=20$. " + ret('20/5') + ", so $a=4$.",
               "The $x^2$ terms: $-ab+15=-9$. " + ret('15-(-9)') + ", so $ab=24$.",
               "Check with $b=6$: " + ret('24/4') + ". Type %s and %s; the two curves coincide." % (c('y=(4x+3)(5x^2-6x+4)'), c('y=20x^3-9x^2-2x+12'))]
V['AM-141'] = 24

N = set(['AM-253', 'AM-254', 'AM-255', 'AM-260', 'AM-261'])

# lower-case "Type" in mid-sentence
def _fix(st):
    parts=re.split(r'(?<=\. )|(?<=^)',st)
    out=[];first=True
    segs=re.split(r'(\. )',st)
    res='';
    for i,sg in enumerate(segs):
        if i>0 and segs[i-1]!='. ' and sg!='. ':
            sg=sg.replace('Type [[','type [[')
        res+=sg
    return res
def _fix2(st):
    # sentence-level: split at '. ' ; inside a sentence, anything after the first word becomes lower-case type
    segs=re.split(r'(?<=\. )',st);out=[]
    for sg in segs:
        head,sep,tail=sg.partition(' ')
        tail=tail.replace('Type [[','type [[')
        out.append(head+sep+tail)
    return ''.join(out)
for _k in S: S[_k]=[_fix2(x) for x in S[_k]]

V['AM-254'] = -2 * (-5) + 1
V['AM-260'] = 9 + 4 + 3
