"""TikZ figures for the new Session 2 items. Every curve is drawn from the same numbers used in the stem and in new_items.py."""
from figlib import axes, FIGSTYLE, fig
from new_items import make, VAL
make()

def _fac(r):
    return "(\\x-(%g))" % r if r < 0 else "(\\x-%g)" % r
def poly_expr(roots, lead):
    return "{%g*%s}" % (lead, "*".join(_fac(r) for r in roots))

def F02():
    # f(x) = (3x-2)/(x-2), asymptotes x=2, y=3, point (0,1)
    b = "\\begin{scope}\\clip (-4,-6) rectangle (8,10);\n"
    b += "\\draw[ln,domain=-4:1.75,samples=80] plot (\\x,{(3*\\x-2)/(\\x-2)});\n"
    b += "\\draw[ln,domain=2.25:8,samples=120] plot (\\x,{(3*\\x-2)/(\\x-2)});\n\\end{scope}\n"
    b += "\\draw[dashed,GREY] (2,-6)--(2,10); \\draw[dashed,GREY] (-4,3)--(8,3);\n"
    b += "\\node[GREY,font=\\scriptsize,right] at (2,-5.2){$x=2$}; \\node[GREY,font=\\scriptsize,above] at (-3.2,3){$y=3$};\n"
    b += "\\node[pt] at (0,1){}; \\node[font=\\scriptsize,below left] at (0,1){$(0,1)$};"
    return fig(axes(-4, 8, -6, 10, 2, 2, lab_x=2, lab_y=2) + "\n" + b, xu=0.62, yu=0.33)

def F03():
    b = "\\begin{scope}\\clip (-3,0) rectangle (3,14);\n\\draw[ln,domain=-3:3,samples=80] plot (\\x,{3*2^\\x+2});\n\\end{scope}\n"
    b += "\\draw[dashed,GREY] (-3,2)--(3,2); \\node[GREY,font=\\scriptsize,below right] at (1.6,2){$y=2$};\n"
    b += "\\node[pt] at (0,5){}; \\node[font=\\scriptsize,left] at (-0.1,5.3){$(0,5)$};\n\\node[pt] at (1,8){}; \\node[font=\\scriptsize,right] at (1.1,8){$(1,8)$};"
    return fig(axes(-3, 3, 0, 14, 1, 2, lab_x=1, lab_y=2) + "\n" + b, xu=0.9, yu=0.3)

def F18():
    pts = [(-4, -1), (-2, 3), (0, 1), (2, -2), (4, 2)]
    b = "\\draw[ln] " + " -- ".join("(%g,%g)" % p for p in pts) + ";\n"
    b += "".join("\\node[pt] at (%g,%g){};\n" % p for p in pts)
    return fig(axes(-4, 4, -3, 4, 1, 1) + "\n" + b, xu=0.85, yu=0.75)

def F19():
    b = "\\draw[ln,domain=2:12,samples=80] plot (\\x,{2*sqrt(\\x-2)-1});\n"
    b += "\\node[pt] at (2,-1){}; \\node[font=\\scriptsize,below right] at (2,-1){$(2,-1)$};\n\\node[pt] at (6,3){}; \\node[font=\\scriptsize,above left] at (6,3){$(6,3)$};"
    return fig(axes(0, 12, -2, 6, 1, 1, lab_x=2, lab_y=1, skipx=(2,)) + "\n" + b, xu=0.55, yu=0.5)

def panel(i):
    roots, lead = VAL['S2N-01_panels'][i]
    xmin, xmax, ymin, ymax = -3.5, 4.5, -14, 18
    s = "\\begin{tikzpicture}[x=0.62cm,y=0.095cm]" + FIGSTYLE
    s += "\\begin{scope}\\clip (%g,%g) rectangle (%g,%g);\\draw[ln,domain=%g:%g,samples=140] plot (\\x,%s);\\end{scope}" % (xmin, ymin, xmax, ymax, xmin, xmax, poly_expr(roots, lead))
    s += "\\draw[axisline] (%g,0)--(%g,0) node[right]{\\scriptsize$x$}; \\draw[axisline] (0,%g)--(0,%g) node[above]{\\scriptsize$y$};" % (xmin, xmax + 0.3, ymin, ymax + 3)
    def yv(x):
        v = lead
        for r in roots: v *= (x - r)
        return v
    for t in range(-3, 5):
        if not t: continue
        best = 'below'
        for anc, dx, dy in (('below', 0, -1), ('below right', 0.45, -1), ('below left', -0.45, -1), ('above', 0, 1), ('above right', 0.45, 1), ('above left', -0.45, 1)):
            cx = t + dx
            xs = [cx - 0.4 + 0.8 * k / 16 for k in range(17)]
            if all(not (-6 <= yv(x) <= 0 and dy < 0 or 0 <= yv(x) <= 6 and dy > 0) for x in xs):
                best = anc; break
        e = -2 if best.startswith('below') else 2
        s += "\\draw (%d,%d)--(%d,%d) node[%s,font=\\tiny,inner sep=1pt]{$%d$};" % (t, -e, t, e, best, t)
    s += "\\end{tikzpicture}"
    return s

FIG = {'F02': F02, 'F03': F03, 'F18': F18, 'F19': F19}
