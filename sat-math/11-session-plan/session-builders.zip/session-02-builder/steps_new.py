"""Solution steps for the 24 new items. All numbers come from new_items.VAL or from ev(); letters come from placeholders filled in at build time."""
import math, numpy as np
from steps import n, ev, c, v, ret, pt, tab_reg, _fix2
from new_items import VAL, make
make()
S = {}; V = {}; N = set(); T = {}

# 01
S['S2N-01'] = ["A factor with an even power (the square $(x-1)^2$) makes the graph touch the $x$-axis and turn at $x=1$. The factors $(x+2)$ and $(x-3)$ appear once, so the graph crosses there. Degree $4$ with leading coefficient $-1$ means both ends point down.",
               "Type %s: the zeros are %s, %s and %s, and the curve touches at $x=1$ without crossing." % (c('y=-(x+2)(x-1)^2(x-3)'), pt(-2, 0), pt(1, 0), pt(3, 0)),
               "Only graph (@@P0@@) touches at $1$, crosses at $-2$ and $3$, and has both ends down. Graph (@@P1@@) touches at $-2$ instead, graph (@@P2@@) has both ends up, and graph (@@P3@@) crosses at $1$ with ends in opposite directions."]
V['S2N-01'] = None

# 02
bb = VAL['S2N-02_b']; f2 = lambda x: (3 * x + bb) / (x - 2)
S['S2N-02'] = ["The horizontal asymptote $y=3$ gives $a=3$ and the vertical asymptote $x=2$ gives $c=2$. Type %s (accept the slider for $b$) and plot %s." % (c('f(x)=(3x+b)/(x-2)'), c('(0,1)')),
               "Slide $b$ until the curve passes through the point: $b=%s$." % n(bb),
               "Type %s: it returns $%s$, which is $\\dfrac{13}{3}$." % (c('f(5)'), n(f2(5)))]
assert abs(f2(0) - 1) < 1e-12
V['S2N-02'] = f2(5)

# 03
S['S2N-03'] = ["The asymptote $y=2$ is the vertical shift. Type %s (accept the sliders for $a$ and $b$) and plot %s and %s." % (c('f(x)=a*b^x+2'), c('(0,5)'), c('(1,8)')),
               "At $x=0$: " + ret('5-2') + ", so $a=3$. At $x=1$: " + ret('(8-2)/3') + ", so $b=2$.",
               "Type each option as its own line: only %s passes through both points (the others miss $(1,8)$ or have a different asymptote)." % c('y=3*2^x+2')]
S['S2N-03'][2] = "Type each option as its own line: only (@@L@@) passes through both points. For example the second option %s reaches $%s$ at $x=1$, not $8$." % (c('y=2*3^x+3'), n(2 * 3 + 3))

# 04
xs = [1, 2, 3, 4, 5]; ys = [5, 8, 13, 20, 29]
a4, b4, c4 = np.polyfit(xs, ys, 2); assert (round(a4, 9), round(b4, 9), round(c4, 9)) == (1, 0, 4)
S['S2N-04'] = ["Open a table and enter $x_1=1,2,3,4,5$ and $y_1=5,8,13,20,29$. Type %s: Desmos returns $a=1$, $b=0$, $c=4$ with $r^2=1$." % c('y_1~a*x_1^2+b*x_1+c'),
               "So $g(x)=x^2+4$. Type %s: the curve passes through all five table points." % c('y=x^2+4'),
               "Check the others: " + ret('3*3+2')[0].lower() + ret('3*3+2')[1:] + " (not $13$), and " + ret('2^2+3')[0].lower() + ret('2^2+3')[1:] + " (not $8$), and " + ret('3*2^(3-1)+2')[0].lower() + ret('3*2^(3-1)+2')[1:] + " (not $13$)."]
V['S2N-04'] = None

# 05
b5 = (16 / 54) ** (1 / 3); a5 = 54 / b5
S['S2N-05'] = ["From $x=1$ to $x=4$ is $3$ steps, so $b^3=\\dfrac{16}{54}$. " + ret('(16/54)^(1/3)') + ", so $b=\\dfrac23$.",
               "Then $a\\cdot\\dfrac23=54$. " + ret('54/(2/3)') + ", so $a=81$.",
               ret('81*(2/3)^(-2)') + ", so $f(-2)=182.25$.",
               "Check: " + ret('81*(2/3)^4') + ", which matches $f(4)=16$."]
V['S2N-05'] = a5 * b5 ** (-2)

# 06
S['S2N-06'] = ["$w$ weeks is $7w$ days.",
               "The number of half-lives that pass is the number of days divided by $12$: $\\dfrac{7w}{12}$.",
               "So the mass is $80\\left(\\dfrac12\\right)^{\\frac{7w}{12}}$. Check: after $12$ days, which is $w=\\dfrac{12}{7}$, the exponent is $\\dfrac{7\\cdot12/7}{12}=1$ and the mass is $40$, half of $80$. That is option (@@L@@)."]

# 07
pq = VAL['S2N-07_pq']
S['S2N-07'] = ["$5$ years is $20$ quarters, and the value triples over those $20$ quarters, so each quarter multiplies the value by $3^{1/20}$.",
               ret('3^(1/20)') + ".",
               ret('(3^(1/20)-1)*100') + ", so about $5.6\\%$ per quarter.",
               "Check: " + ret('1.056^20') + ", close to $3$. (Dividing the yearly rate by $4$ would give $6.1\\%$, which compounds to too much.)"]
T['S2N-07'] = 'D'
V['S2N-07'] = pq

# 08
S['S2N-08'] = ["Let $x$ be the number of tripling periods: type %s and %s." % (c('y=200*3^x'), c('y=16200')),
               "Tap the intersection: %s, so there are $4$ periods." % pt(4, 16200),
               ret('4*40') + " minutes, and " + ret('160/60') + ", which is $\\dfrac83$ hours."]
V['S2N-08'] = 160 / 60

# 09
a9, b9 = VAL['S2N-09_ab']
S['S2N-09'] = ["$p(2)=0$ gives $8+4a+2b-6=0$, so $b=-1-2a$. $p(-1)=12$ gives $-1+a-b-6=12$, so $b=a-19$. Type %s and %s (letting $x$ stand for $a$ and $y$ for $b$)." % (c('y=-1-2x'), c('y=x-19')),
               "Tap the intersection: %s, so $a=6$ and $b=-13$." % pt(a9, b9),
               "Check: type %s, then %s: it returns $0$, and %s: it returns $12$." % (c('p(x)=x^3+6x^2-13x-6'), c('p(2)'), c('p(-1)')),
               ret('6+(-13)') + ", so $a+b=-7$."]
p9 = lambda x: x ** 3 + 6 * x ** 2 - 13 * x - 6
assert p9(2) == 0 and p9(-1) == 12 and abs(-1 - 2 * a9 - b9) < 1e-12 and abs(a9 - 19 - b9) < 1e-12
V['S2N-09'] = a9 + b9

# 10
N.add('S2N-10')
S['S2N-10'] = ["Set $2|x-2|-3=0$, so $|x-2|=\\dfrac32$.",
               "Then $x-2=\\dfrac32$ or $x-2=-\\dfrac32$, so $x=\\dfrac72$ or $x=\\dfrac12$.",
               "The sum is $\\dfrac72+\\dfrac12=4$, which is twice the vertex $x$-coordinate $2$. That is option (@@L@@)."]
V['S2N-10'] = 4.0

# 11
m11, b11 = VAL['S2N-11_mb']
S['S2N-11'] = ["The line meets the parabola only at $x=3$, so $x^2-4x+7-(mx+b)$ must equal $(x-3)^2=x^2-6x+9$.",
               "The $x$-terms: $-4-m=-6$. " + ret('-4-(-6)') + ", so $m=2$.",
               "The constants: $7-b=9$. " + ret('7-9') + ", so $b=-2$.",
               "Check: type %s and %s; they touch only at %s." % (c('y=x^2-4x+7'), c('y=2x-2'), pt(3, 3 ** 2 - 12 + 7))]
assert (m11, b11) == (2, -2) and 2 * 3 - 2 == 3 ** 2 - 12 + 7 == 4
V['S2N-11'] = float(b11)

# 12
S['S2N-12'] = ["Type %s and %s (the left side needs $x\\ge5$)." % (c('y=sqrt(x+7)-sqrt(x-5)'), c('y=2')),
               "Tap the intersection: %s, so $x=9$." % pt(9, ev('sqrt(9+7)-sqrt(9-5)')),
               "Check: " + ret('sqrt(9+7)-sqrt(9-5)') + "."]
V['S2N-12'] = 9.0

# 13
N.add('S2N-13')
S['S2N-13'] = ["The expressions are undefined at $x=3$. Multiply both sides by $x-3$: $6+2(x-3)=x+3$.",
               "Simplify: $2x=x+3$, so $x=3$.",
               "But $x=3$ makes the denominators zero, so it is extraneous. The equation has no real solutions, option (@@L@@)."]
V['S2N-13'] = None

# 14
g14 = lambda x: x / (x - 2) + 3 / (x + 2) - 8 / (x ** 2 - 4)
S['S2N-14'] = ["Multiply by $(x-2)(x+2)$: $x(x+2)+3(x-2)=8$, so $x^2+5x-14=0$. Type %s and tap the zeros: %s and %s." % (c('y=x^2+5x-14'), pt(-7, 0), pt(2, 0)),
               "Type %s: its graph has a hole at $x=2$ (the expression is undefined there), and its only $x$-intercept is %s." % (c('y=x/(x-2)+3/(x+2)-8/(x^2-4)'), pt(-7, 0)),
               "Check: " + ret('(-7)/(-7-2)+3/(-7+2)-8/((-7)^2-4)') + ".",
               "Only $x=-7$ works, so the sum of all real solutions is $-7$."]
assert abs(g14(-7)) < 1e-12
V['S2N-14'] = -7.0

# 15
r15 = VAL['S2N-15_roots']
S['S2N-15'] = ["Type %s and %s." % (c('f(x)=x^2-2x'), c('y=f(f(x))')),
               "Tap the $x$-intercepts: %s, %s, %s and %s: four of them." % tuple(pt(r, 0) for r in r15),
               "Check by hand: $f(x)=0$ gives $x=0,2$; $f(x)=2$ gives $x=1\\pm\\sqrt3$. " + ret('1-sqrt(3)') + " and " + ret('1+sqrt(3)')[0].lower() + ret('1+sqrt(3)')[1:] + ".",
               "So there are $4$ values, option (@@L@@)."]
assert [round(x, 4) for x in r15] == [round(1 - math.sqrt(3), 4), 0.0, 2.0, round(1 + math.sqrt(3), 4)]
V['S2N-15'] = 4

# 16
f16 = lambda x: (2 * x + 1) / (x - 3)
x1 = VAL['S2N-16_x1']; x2 = VAL['S2N-16']
S['S2N-16'] = ["$f^{-1}(5)$ is the input where $f(x)=5$. Type %s and %s and tap the intersection: %s, so $f^{-1}(5)=\\dfrac{16}{3}$." % (c('y=(2x+1)/(x-3)'), c('y=5'), pt(x1, 5)),
               "Now find the input where $f(x)=\\dfrac{16}{3}$. Type %s and tap the intersection: %s." % (c('y=16/3'), pt(x2, x1)),
               "So $f^{-1}(f^{-1}(5))=5.1$. Check: " + ret('(2*5.1+1)/(5.1-3)') + ", which is $\\dfrac{16}{3}$."]
V['S2N-16'] = x2

# 17
N.add('S2N-17')
S['S2N-17'] = ["$g(x)=2f(3-x)+1$ uses $f$ at the input $3-x$. The known point has $f(6)=-2$, so we need $3-x=6$.",
               "That gives $x=-3$. Then $g(-3)=2f(6)+1=2(-2)+1=-3$.",
               "So $(-3,-3)$ must lie on the graph of $g$, option (@@L@@). The $x$-value is not $6+3$ or $6-3$ because $x$ is subtracted inside."]
V['S2N-17'] = None

# 18
N.add('S2N-18')
us = VAL['S2N-18_u']
S['S2N-18'] = ["$g(x)=0$ means $f(x-1)=1$, so find where the graph of $f$ is at height $1$.",
               "From the graph, $f(u)=1$ at $u=%s$, $u=%s$ (the point $(0,1)$) and $u=%s$." % tuple(n(u) for u in us),
               "Since $u=x-1$, $x=u+1$: $x=%s$, $x=%s$ and $x=%s$. All lie in the domain $-3\\le x\\le5$ of $g$, so there are $3$ values, option (@@L@@)." % tuple(n(u + 1) for u in us)]
V['S2N-18'] = 3

# 19
S['S2N-19'] = ["The graph starts at $(h,k)=(2,-1)$. Type %s (accept the slider for $a$) and plot %s." % (c('f(x)=a*sqrt(x-2)-1'), c('(6,3)')),
               "Slide $a$ until the curve passes through the point: $a=2$.",
               "Type %s: it returns $%s$." % (c('f(11)'), n(2 * math.sqrt(11 - 2) - 1))]
assert 2 * math.sqrt(4) - 1 == 3
V['S2N-19'] = 2 * math.sqrt(9) - 1

# 20
Pn = lambda k: -2 * k ** 2 + 120 * k - 500
S['S2N-20'] = ["Type %s (letting $x$ stand for $n$)." % c('y=-2x^2+120x-500\\{0<=x<=25\\}'),
               "The vertex of the full parabola is %s, but $n=30$ is not allowed. On $0\\le n\\le25$ the curve is still rising at its right end." % pt(30, Pn(30)),
               ret('-2*25^2+120*25-500') + ", so the greatest allowed profit is $1250$ dollars."]
V['S2N-20'] = float(Pn(25))

# 21
R21 = lambda p_: p_ * (300 - 4 * p_)
S['S2N-21'] = ["Type %s (letting $x$ stand for $p$). The vertex is %s, but $37.5$ is not a multiple of $5$." % (c('y=x(300-4x)'), pt(37.5, R21(37.5))),
               "Try the nearest multiples of $5$: " + ret('35*(300-4*35)') + " and " + ret('40*(300-4*40)')[0].lower() + ret('40*(300-4*40)')[1:] + ".",
               "Farther prices give less: " + ret('30*(300-4*30)') + ", and " + ret('45*(300-4*45)')[0].lower() + ret('45*(300-4*45)')[1:] + ". The greatest allowed revenue is $5{,}600$ dollars, option (@@L@@)."]
V['S2N-21'] = 5600.0

# 22
N.add('S2N-22')
S['S2N-22'] = ["Treat $x^4-13x^2+36$ as a quadratic in $x^2$: $(x^2-4)(x^2-9)$.",
               "Factor each difference of squares: $(x-2)(x+2)(x-3)(x+3)$.",
               "The zeros $-2,\\,2,\\,-3,\\,3$ now appear as constants, option (@@L@@). The form $(x^2-4)(x^2-9)$ is equivalent but still has $x^2$ in each factor."]

# 23
N.add('S2N-23')
S['S2N-23'] = ["Write $8=2^3$: $8^{\\frac{2x-1}{3}}=2^{2x-1}$.",
               "Then $4\\cdot2^{2x-1}=2^2\\cdot2^{-1}\\cdot2^{2x}=2\\cdot4^x$.",
               "So $a=2$ and $b=4$, and $a+b=6$."]
V['S2N-23'] = 6.0

# 24
g24 = lambda x: abs(x * x - 4 * x)
S['S2N-24'] = ["Type %s." % c('y=abs(x^2-4x)'),
               "The whole graph is on or above the $x$-axis (I true), and the $x$-intercepts are %s and %s, exactly two (II true)." % (pt(0, 0), pt(4, 0)),
               "Tap the local maximum %s: after $x=2$ the graph falls to $(4,0)$, so $g$ is not increasing for all $x>2$ (III false). Check: " % pt(2, g24(2)) + ret('abs(3^2-4*3)') + " and " + ret('abs(3.5^2-4*3.5)')[0].lower() + ret('abs(3.5^2-4*3.5)')[1:] + ".",
               "Only I and II must be true, option (@@L@@)."]
assert g24(3) == 3 and g24(3.5) == 1.75
for k in S: S[k] = [_fix2(x) for x in S[k]]
N.add('S2N-06')
