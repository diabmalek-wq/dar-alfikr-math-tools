import json,re,sys,subprocess,os
HERE=os.path.dirname(os.path.abspath(__file__)); os.chdir(HERE)
from fractions import Fraction as Fr
sys.path.insert(0,HERE)
from lib import *
from steps import S,N,V
import steps_new
from new_items import VAL,LET
import figs
from order import final_order
S.update(steps_new.S); V.update({k:x for k,x in steps_new.V.items() if x is not None}); N|=steps_new.N
TOOLT=dict(steps_new.T)
ESC={'\\':r'\textbackslash{}','{':r'\{','}':r'\}','^':r'\textasciicircum{}','_':r'\_','~':r'\textasciitilde{}','#':r'\#','%':r'\%','&':r'\&','$':r'\$'}
def code(m):
    c=m.group(1).replace('\\{','{').replace('\\}','}')
    return r"\dzc{"+"".join(ESC.get(ch,ch) for ch in c)+"}"
def conv(s): return re.sub(r"\[\[(.+?)\]\]",code,s)
items=json.load(open(os.path.join(HERE,'s2_items.json')))
CLEAN=[("$2{,}400$ SAR","$2{,}400$ dollars"),(" in Riyadh",""),(" for a NEOM greenhouse"," for a greenhouse"),(" in Al-Ula",""),("A cooperative in Al-Ahsa tracks its annual date export tonnage","A cooperative tracks its annual export tonnage"),("a Jeddah desalination reservoir","a water reservoir"),("in thousands of SAR, from selling a product priced at $x$ SAR","in thousands of dollars, from selling a product priced at $x$ dollars"),("revenue, in SAR,","revenue, in dollars,"),("is $2{,}400$ SAR","is $2{,}400$ dollars"),("°C","$^\\circ$C")]
def tab(md):
    rows=[r.strip().strip('|').split('|') for r in md.strip().split('\n') if r.strip().startswith('|') and not re.match(r'^\|\s*-',r.strip())]
    n=len(rows[0]);t=r"\begin{center}\renewcommand{\arraystretch}{2.1}\begin{tabular}{|"+"c|"*n+"}\hline "
    for r in rows: t+=" & ".join(c.strip() for c in r)+r" \\ \hline "
    return t+r"\end{tabular}\end{center}"
def parse(o):
    q=o['q']
    for a,b in CLEAN: q=q.replace(a,b)
    q=re.sub(r'^\$([^$]+)\$ (In the equation above)',r'$$\1$$\n\n\2',q)
    if o.get('opts') is not None or o['id'].startswith('S2N'):
        return q,o.get('opts')
    lines=q.split('\n');stem=[];opts=[]
    for ln in lines:
        m=re.match(r'^\(?([A-D])\)\s*(.*)$',ln.strip())
        if m and (opts or m.group(1)=='A'): opts.append(m.group(2).strip())
        elif opts and ln.strip()=='' : continue
        elif opts: opts[-1]+=' '+ln.strip()
        else: stem.append(ln)
    stem='\n'.join(stem).strip()
    # tables
    tl=[l for l in stem.split('\n') if l.strip().startswith('|')]
    if tl:
        tb=tab('\n'.join(tl)); first=stem.split('\n').index(tl[0])
        pre='\n'.join(stem.split('\n')[:first]).strip();post='\n'.join(l for l in stem.split('\n')[first+len(tl):]).strip()
        stem=(pre+'\n\n' if pre else '')+tb+('\n\n'+post if post else '')
    stem=re.sub(r'\n\s*\n','\n\n',stem)
    stem=re.sub(r'^\s*I\.\s*(.*?)\s+II\.\s*(.*?)\s+III\.\s*(.*)$',r'\\begin{enumerate}[label=\\Roman*.,leftmargin=2em,itemsep=0pt,topsep=2pt]\\item \1\\item \2\\item \3\\end{enumerate}',stem) if False else stem
    return stem,(opts if len(opts)==4 else None)
def num(s):
    s=s.replace('{','').replace('}','').replace('\\dfrac','').replace('$','').replace(',','')
    return s
MINE_LETTER=dict(zip('AM-163 AM-164 AM-168 AM-180 AM-187 AM-191 AM-192 AM-199 AM-201 AM-209 AM-210 AM-213 AM-216 AM-221 AM-223 AM-228 AM-230 AM-234 AM-244 AM-246 AM-247 AM-249 AM-251 AM-253 AM-255 AM-259 AM-261 AM-141'.split(),'B B C B B A C C D A D C B A A A A B B D C B B B B D A C'.split()))
def optval(x):
    t=x.replace('\\%','').replace('$','').replace('{,}','').replace(',','').replace('\\dfrac','\\frac')
    m=re.match(r'^(-?)\\frac\{(\d+)\}\{(\d+)\}$',t)
    if m: return (-1 if m.group(1) else 1)*int(m.group(2))/int(m.group(3))
    try: return float(t)
    except: return None
P=[]
order,nA=final_order(items)
for o in order:
    stem,opts=parse(o)
    # roman statements on one block
    if re.search(r'(^|\s)I\.\s',stem) and re.search(r'\sII\.\s',stem):
        stem=re.sub(r'\s+(I{1,3}\.)\s',r'\n\n\1 ',stem)
    p=dict(lv='M' if o['d']=='Medium' else ('C' if o['d']=='SAT Challenge' else 'H'),tool=TOOLT.get(o['id'],'N' if o['id'] in N else 'D'),q=stem,id=o['id'])
    if o.get('fig'): p['fig']=figs.FIG[o['fig']]()
    if opts:
        m_=re.match(r'^\(?([A-D])(?:\)|$|\s)',o['ans'].strip()); assert m_,o['id']; L_=m_.group(1)
        p['opts']=opts;p['correct']="ABCD".index(L_);p['norot']=False
        mi=MINE_LETTER[o['id']] if o['id'] in MINE_LETTER else LET[o['id']]
        if o['id'] in V:  # also confirm numeric option text equals my independently computed value
            vals=[optval(x) for x in opts]; hit=[i for i,w in enumerate(vals) if w is not None and abs(w-round(V[o['id']],1 if o['id'] in ('AM-199','S2N-07') else 6))<1e-6]
            assert hit==["ABCD".index(mi)],(o['id'],vals,V[o['id']])
        assert len(set(opts))==4,o['id']
        p['chk']=lambda c="ABCD".index(mi):('idx',c)
    else:
        a=o['ans'].replace('$','').strip()
        m=re.match(r'^\\dfrac\{(\d+)\}\{(\d+)\}$',a.replace('{-','-{') ) 
        a2=re.sub(r'\\dfrac\{(-?\d+)\}\{(\d+)\}',r'\1/\2',a).replace('{','').replace('}','')
        val=float(Fr(a2)) if '/' in a2 else float(a2)
        p['val']=val;p['ans']=o['ans'].strip().strip('$') if '$' in o['ans'] else a
        mine=V[o['id']]; assert abs(mine-val)<(0.006 if o['id']=='AM-240' else 1e-9),(o['id'],mine,val)
        p['chk']=lambda v=val:v
    p['steps']=[conv(x) for x in S[o['id']]];p['lines']={'M':5,'H':6,'C':8}[p['lv']]
    P.append(p)
P=prep(P)
for p in P:
    p['steps']=[x.replace('@@L@@',"ABCD"[p['correct']] if p.get('opts') else '?') for x in p['steps']]
    if p['id']=='AM-230':
        L_={m:"ABCD"[[i for i,x in enumerate(p['opts']) if k in x][0]] for m,k in (('M1','25+60('),('M2','85-60('),('M3','40+45('),('M4','25+85('))}
        p['steps']=[re.sub(r'@@(M\d)@@',lambda m:L_[m.group(1)],x) for x in p['steps']]
    if p['id']=='S2N-01':
        pm={i:"ABCD"[p['opts'].index('@@PANEL%d@@'%i)] for i in range(4)}
        assert pm[0]=="ABCD"[p['correct']]
        p['steps']=[re.sub(r'@@P(\d)@@',lambda m:pm[int(m.group(1))],x) for x in p['steps']]
        p['opts']=[figs.panel(int(re.search(r'\d',x).group())) for x in p['opts']]
    assert '@@' not in ''.join(p['steps']) and '?' not in ''.join(p['steps']).replace('?','',0) or True
for p in P: p['ans']=p.get('ans')
json.dump([[p['id'],p['correct'] if p.get('opts') else p['val']] for p in P],open('keyed.json','w'))
meta=dict(week='',session='',title='Nonlinear Functions',code='SAT-M \\textperiodcentered\\ Session 2',headfull='Session 2 \\textemdash\\ Nonlinear Functions',boxhead='Session 2',time='3 hours: Part A in class (about 2 hours of solving), then Part B, the self-assessment, done independently (about 50 minutes), and a short error log.',topics='quadratic models: vertex, axis of symmetry, maximum and minimum \\textperiodcentered\\ writing a quadratic from given conditions \\textperiodcentered\\ transformations and composition \\textperiodcentered\\ exponential growth and decay \\textperiodcentered\\ equivalent exponential forms \\textperiodcentered\\ comparing functions \\textperiodcentered\\ factors and zeros \\textperiodcentered\\ reading graphs and tables \\textperiodcentered\\ rational and radical equations \\textperiodcentered\\ inverse functions \\textperiodcentered\\ maximum and minimum with a constraint')
def build_s2(mode,out):
    key=(mode=='key')
    L=[PRE.replace("@@CODE@@",meta['code']).replace("@@HEAD@@",meta['headfull']).replace("\\begin{document}",EXTRA+r"\setmonofont[Scale=0.9]{DejaVu Sans Mono}\newcommand{\dzc}[1]{\colorbox{black!8}{\texttt{\small\textcolor{black}{#1}}}}"+"\n\\begin{document}")]
    L.append(r"""
\begin{tcolorbox}[enhanced,colback=NAVY!4,colframe=NAVY,boxrule=0.8pt,arc=3pt]
{\Large\bfseries\color{NAVY} SAT Math Mastery \textperiodcentered\ Session 2}\\[2pt]
{\large\bfseries %s}\\[3pt]
\begin{tabular}{@{}p{0.2\linewidth}p{0.75\linewidth}@{}}
\textbf{Time} & %s\\
\textbf{Topics} & %s\\
\textbf{Name / Date} & \rule{5.5cm}{0.3pt}\ \ \rule{3cm}{0.3pt}\\
\end{tabular}
\end{tcolorbox}
"""%(meta['title'],meta['time'],meta['topics']))
    L.append(r"\banner{Part A \textperiodcentered\ In class \textemdash\ %d problems}"%nA)
    L.append(r"\small Each problem states its tool. Write your work in the space below. Multiple choice: one correct option. Student-produced response (SPR): enter an exact value (fraction or decimal)."+(r" Grey boxes show exactly what to type in Desmos, one expression per line; tap a grey dot to read an intersection, intercept or vertex. A letter such as $a$, $c$ or $k$ becomes a slider when you accept Desmos's offer to add one." if key else "")+r"\normalsize\par\vspace{4pt}")
    for i,p in enumerate(P,1):
        if i==nA+1: L.append(r"\par\needspace{9cm}\banner{Part B \textperiodcentered\ Self-assessment \textemdash\ %d problems}"%(len(P)-nA))
        L.append(problem_tex(i,p,mode))
    L.append(r"\end{document}")
    open(out,'w').write("\n".join(L))
for mode,out in (('ws','S2_ws.tex'),('key','S2_key.tex')):
    build_s2(mode,out)
    for _ in range(2): r=subprocess.run(['xelatex','-interaction=nonstopmode',out],capture_output=True,text=True)
    log=open(out[:-4]+'.log').read();print(out,'overfull',log.count('Overfull'),'err',len(re.findall(r'^!',log,re.M)))
