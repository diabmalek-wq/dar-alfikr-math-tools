"""Independent solutions for the 45 Extra Practice items. Each answer is computed from the stem (sympy / fractions / numpy /
brute force); the bank's answer is read ONLY in the comparison loop at the end."""
import json,re,math,itertools
from fractions import Fraction as Fr
import numpy as np
D=json.load(open('items.json')); items={o['id']:o for o in D['items']}
def num(t):
    t=t.replace('\\%','').replace('$','').replace('{,}','').replace(',','')
    t=re.sub(r'\\dfrac\{(-?\d+)\}\{(\d+)\}',r'(\1/\2)',t); t=re.sub(r'\\dfrac(\d)(\d)',r'(\1/\2)',t)
    try: return float(eval(t,{},{}))
    except Exception: return None
def numeric_pick(o,val,tol=1e-9):
    vs=[num(x) for x in o['opts']]; assert all(v is not None for v in vs),o['id']
    hit=[i for i,v in enumerate(vs) if abs(v-val)<tol]; assert len(hit)==1,(o['id'],vs,val); return hit[0]
def text_pick(o,pred):
    hit=[i for i,x in enumerate(o['opts']) if pred(x)]; assert len(hit)==1,(o['id'],hit); return hit[0]
M={}
def O(i): return items[i]
# ---------- evaluating claims: design facts from the stem -> the one supported conclusion
# 133: random assignment (yes), random sample from all students (no: volunteers)
M['PS-133']=('opt',text_pick(O('PS-133'),lambda t:'caused' in t and 'volunteers like those' in t))
# 134: random sample of city adults (generalises to the city), nobody assigned (no causation)
M['PS-134']=('opt',text_pick(O('PS-134'),lambda t:'adults in the city' in t and 'positively associated' in t and 'not been shown' in t))
# 135: voluntary response by a club site -> self-selection bias
M['PS-135']=('opt',text_pick(O('PS-135'),lambda t:'selected themselves' in t))
# 136: only random assignment supports a causal claim
M['PS-136']=('opt',text_pick(O('PS-136'),lambda t:'Randomly assign' in t))
# ---------- margin of error
lo,hi=51-2.5,51+2.5; assert lo<50<hi            # 50 inside the interval: majority plausible, not established
M['PS-137']=('opt',text_pick(O('PS-137'),lambda t:t.startswith('It is plausible that a majority') and 'less than half' in t))
M['PS-138']=('val',float(Fr(32,10)*18000+Fr(4,10)*18000))
me2=6/math.sqrt(1600/400); M['PS-139']=('opt',numeric_pick(O('PS-139'),me2))
P=(30-4,30+4); Q=(38-4,38+4); overlap=max(P[0],Q[0])<=min(P[1],Q[1]); assert overlap
M['PS-140']=('opt',text_pick(O('PS-140'),lambda t:('plausible' in t and 'same' in t)==overlap and 'exactly' not in t and 'definitely' not in t and 'not possible' not in t))
M['PS-141']=('opt',text_pick(O('PS-141'),lambda t:'plausible' in t and 'seniors at the school' in t and '$57\\%$ and $67\\%$' in t))
Ns=[n for n in range(1,100000) if Fr(9,60)==Fr(150,n)]; assert len(Ns)==1; M['PS-142']=('val',Ns[0])
# ---------- probability
M['PS-143']=('val',float(Fr(35,36+35)))
ps=[Fr(i,1000) for i in range(0,1001) if Fr(4,10)+Fr(i,1000)-Fr(4,10)*Fr(i,1000)==Fr(7,10)]; assert len(ps)==1; M['PS-144']=('val',float(ps[0]))
marb=['R']*5+['B']*3; pairs=list(itertools.permutations(range(8),2))
pr=Fr(sum(marb[a]==marb[b] for a,b in pairs),len(pairs)); M['PS-145']=('opt',numeric_pick(O('PS-145'),float(pr)))
rolls=[(a,b) for a in range(1,7) for b in range(1,7)]; cond=[r for r in rolls if r[0]%2==0 or r[1]%2==0]
M['PS-146']=('val',float(Fr(sum(sum(r)==8 for r in cond),len(cond))))
M['PS-147']=('val',(500-(240+180-70))/500)
vote=Fr(3,10)*Fr(8,10)+Fr(7,10)*Fr(5,10); M['PS-148']=('val',float(Fr(3,10)*Fr(8,10)/vote))
M['PS-149']=('val',float(Fr(90,120)/Fr(60,100)))
# ---------- two-variable data
M['PS-150']=('opt',text_pick(O('PS-150'),lambda t:'no absences' in t and ('$%d$'%(82-1.6*0)) in t and 'decreases' not in t))
pts=[(0,8),(1,12),(2,18),(3,27),(4,40.5)]
cands={'$y=8(1.5)^x$':lambda x:8*1.5**x,'$y=4x+8$':lambda x:4*x+8,'$y=2x^2+2x+8$':lambda x:2*x*x+2*x+8,'$y=8(1.2)^x$':lambda x:8*1.2**x}
M['PS-151']=('opt',text_pick(O('PS-151'),lambda t:all(abs(cands[t](x)-y)<1e-9 for x,y in pts)))
M['PS-152']=('val',51-(3.2*10+14))
xs=list(range(1,11))+[11]; ys=[2*x+1 for x in range(1,11)]+[40]; sl,ic=np.polyfit(xs,ys,1); assert sl>2 and ic<1
M['PS-153']=('opt',text_pick(O('PS-153'),lambda t:(('Greater slope' in t)==(sl>2)) and (('Smaller slope' in t)==(sl<2)) and (('smaller $y$-intercept' in t)==(ic<1)) and (('greater $y$-intercept' in t)==(ic>1)) and 'same' not in t))
assert not (20<=150<=80); M['PS-154']=('opt',text_pick(O('PS-154'),lambda t:'less reliable' in t and 'outside' in t))
M['PS-155']=('val',1.5*10+4)
M['PS-156']=('val',-(-2+3+1-4))
# ---------- functions
def vals(t):
    t=re.sub(r'\\dfrac(\d)(\d)',r'\1/\2',t); return sorted(float(eval(s)) for s in re.findall(r'x=\s*(-?[\d/]+)',t))
zf=[-2,5]; zg=sorted(z/2 for z in zf)   # f(2x)=0 when 2x is a zero of f
M['AM-288']=('opt',text_pick(O('AM-288'),lambda t:vals(t)==zg))
f={1:3,2:4,3:1,4:2}; g={1:4,2:1,3:2,4:3}; finv={v:k for k,v in f.items()}; M['AM-289']=('val',g[finv[g[3]]])
odds=[lambda x:x,lambda x:x**3,lambda x:x**3-2*x,lambda x:x*abs(x),lambda x:math.atan(x),lambda x:x**5+x**3]
tests={'[f(x)]^2':lambda f,x:f(x)**2,'f(f(x))':lambda f,x:f(f(x)),'f(x)+1':lambda f,x:f(x)+1,'f(x)+x':lambda f,x:f(x)+x}
def even_all(h): return all(abs(h(f_,x)-h(f_,-x))<1e-9 for f_ in odds for x in (0.3,1.7,2.9))
M['AM-290']=('opt',text_pick(O('AM-290'),lambda t:even_all(tests[re.sub(r'[\$\\ ]|left|right','',t).replace('[','[').strip() if False else t.replace('$','').strip()])))
fx=lambda x:(x-1)*(x-5); gx=lambda x:fx(-x)+4; M['AM-291']=('val',gx(2))
def defined(x): return x*x-5-1>=-1e-12 if True else None
sets={'$x\\ge1$':lambda x:x>=1,'$-\\sqrt6\\le x\\le\\sqrt6$':lambda x:-math.sqrt(6)<=x<=math.sqrt(6),'all real numbers':lambda x:True,'$x\\le-\\sqrt6$ or $x\\ge\\sqrt6$':lambda x:x<=-math.sqrt(6) or x>=math.sqrt(6)}
grid=[k/20 for k in range(-100,101)]+[math.sqrt(6),-math.sqrt(6)]
truth=lambda x:(x*x-5-1)>=-1e-12
M['AM-292']=('opt',text_pick(O('AM-292'),lambda t:all(sets[t](x)==truth(x) for x in grid)))
sol=[Fr(i,3) for i in range(-300,300) if Fr(i,3)!=3 and (2*Fr(i,3)+1)/(Fr(i,3)-3)==5]; assert len(sol)==1; M['AM-293']=('val',float(sol[0]))
pt=(4,-2); new=(pt[0]+1,3*pt[1]+5)
M['AM-294']=('opt',text_pick(O('AM-294'),lambda t:tuple(int(s) for s in re.findall(r'-?\d+',t))==new))
ks=[Fr(n,4) for n in range(-400,400) if 49-8*Fr(n,4)>0 and abs(((7+math.sqrt(49-8*Fr(n,4)))/4)**2+((7-math.sqrt(49-8*Fr(n,4)))/4)**2-9)<1e-9]; assert len(ks)==1
M['AM-295']=('val',float(ks[0]))
rr=[r.real for r in np.roots([1,0,-5,0,4]) if abs(r.imag)<1e-9]; assert len(rr)==4; M['AM-296']=('val',float(np.prod(rr)))
us=np.roots([1,-6,8]); xr=[math.log2(v.real) for v in us if v.real>0]; assert len(xr)==2; M['AM-297']=('val',float(sum(xr)))
# ---------- similar triangles
M['GT-226']=('val',24*math.sqrt(100/36))
ratio=Fr(2,5); abc=Fr(20)/ratio**2; M['GT-227']=('val',float(abc-20))
M['GT-228']=('opt',numeric_pick(O('GT-228'),15*math.sqrt(18/50),tol=1e-6))
ad=20*math.sqrt(1/2); M['GT-229']=('val',round(ad,1))
M['GT-230']=('val',math.hypot(6,8)*math.sqrt(150/(6*8/2)))
M['GT-231']=('val',144*(1/3)**2)
aa=Fr(8+8,(0-4)**2); M['AM-298']=('val',float(aa*(2-4)**2-8))   # g(1)=f(2)
M['AM-299']=('val',max(3-1,3-6))
fe={3:7,5:2}     # f(5)=f(-5)=2 because f is even
g3=fe[3]+fe[3]; g5=fe[5]+fe[5]; M['AM-300']=('val',g3+g5)
rs=np.roots([1,-5,2]); M['AM-301']=('val',float((rs[0]/rs[1]+rs[1]/rs[0]).real))
zs=np.roots([1,-7,14,-8]); assert all(abs(z.imag)<1e-9 for z in zs) and len(zs)==3; M['AM-302']=('val',float(sum(z.real**2 for z in zs)))
# ---------- comparison with the bank (read only here)
def bankval(a):
    a=a.split('(or')[0]; return num(a.replace('\\dfrac{','(').replace('}{',')/(').replace('$',''),) if False else None
def parse_bank(a):
    a=a.split('(or')[0].strip()
    m=re.search(r'\\dfrac\{(\d+)\}\{(\d+)\}',a)
    if m: return int(m.group(1))/int(m.group(2))
    return num(a)
bad=0
for iid,o in items.items():
    kind,v=M[iid]
    if o['opts']:
        assert kind=='opt' and len(set(o['opts']))==4,iid
        got="ABCD"[v]; ok=got==o['letter']; print('OK ' if ok else 'BAD',iid,got,o['letter'],o['opts'][v][:55])
    else:
        want=parse_bank(o['sans']); ok=abs(float(v)-want)<(5e-4 if iid in('PS-143','PS-146','PS-148','AM-293') else 1e-9)
        print('OK ' if ok else 'BAD',iid,'computed',round(float(v),6),'bank',want)
    bad+=(not ok)
print('total',len(M),'bad',bad); assert set(M)==set(items) and bad==0
json.dump({k:(a,b) for k,(a,b) in M.items()},open('solved.json','w'))
