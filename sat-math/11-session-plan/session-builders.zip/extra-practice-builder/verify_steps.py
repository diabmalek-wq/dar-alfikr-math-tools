import re,math,json
import numpy as np
from steps import S,V,TAPS,T,ev,DList,VERBAL
items={o['id']:o for o in json.load(open('items.json'))['items']}; solved=json.load(open('solved.json'))
ENV=dict(g_1=DList([4,1,2,3]),f_1=DList([3,4,1,2]))
bad=0;boxes=0;ret_n=0;withbox=set()
def fail(*a):
    global bad; bad+=1; print('FAIL',*a)
def num(t):
    t=t.replace('\\%','').replace('$','').replace('{,}','').replace(',','')
    t=re.sub(r'\\dfrac\{(-?\d+)\}\{(\d+)\}',r'(\1/\2)',t)
    try: return float(eval(t))
    except Exception: return None
for iid,steps in S.items():
    assert 3<=len(steps)<=4,(iid,len(steps))
    for st in steps:
        for m in re.finditer(r"\[\[(.+?)\]\]",st):
            expr=m.group(1); boxes+=1; withbox.add(iid)
            tail=st[m.end():]
            mm=re.match(r": it returns \$([^$]+)\$",tail)
            if mm:
                ret_n+=1; want=float(mm.group(1).replace('{,}',''))
                try: got=ev(expr,**ENV)
                except Exception as e: fail(iid,expr,'eval error',e); continue
                if abs(got-want)>6e-5*max(1,abs(want)): fail(iid,expr,got,want)
            elif expr.startswith('y='):
                ok=False
                for x in (3.7,-3.7,0.9,5.3,-1.3,2.6):
                    try: ev(expr[2:],x=x); ok=True; break
                    except Exception: pass
                if not ok: fail(iid,'typed curve does not evaluate',expr)
            elif '~' in expr: pass
            else: fail(iid,'unclassified box',expr)
for t in TAPS:
    y=ev(t['f'],x=t['x'])
    if abs(y-t['y'])>1e-9: fail('tap y',t)
    if t['g'] is not None and abs(y-ev(t['g'],x=t['x']))>1e-6: fail('tap not on both curves',t)
def zs(coefs): return sorted(r.real for r in np.roots(coefs) if abs(r.imag)<1e-9)
def taps(i): return sorted(t['x'] for t in TAPS if t['id']==i)
def close(a,b,tol=1e-6): return len(a)==len(b) and all(abs(x-y)<tol for x,y in zip(a,b))
chk=lambda name,ok: (print('OK ',name) if ok else fail(name))
chk('AM-288 taps -1,2.5',close(taps('AM-288'),[-1,2.5]))
chk('AM-292 taps +-sqrt6',close(taps('AM-292'),[-math.sqrt(6),math.sqrt(6)]))
chk('AM-293 tap 16/3',close(taps('AM-293'),[16/3]))
chk('AM-296 taps',close(taps('AM-296'),zs([1,0,-5,0,4])))
chk('AM-297 taps 1,2',close(taps('AM-297'),[1,2]))
chk('AM-299 taps -3,2',close(taps('AM-299'),[-3,2]))
chk('AM-301 taps',close(taps('AM-301'),zs([1,-5,2])))
chk('AM-302 taps',close(taps('AM-302'),zs([1,-7,14,-8])))
chk('PS-144 tap 0.5',close(taps('PS-144'),[0.5]))
chk('PS-142 tap 1000',close(taps('PS-142'),[1000],1e-3))
xs=[0,1,2,3,4];ys=[8,12,18,27,40.5]; a,b=np.polyfit(xs,np.log(ys),1); chk('PS-151 fit a=8 b=1.5',abs(math.exp(b)-8)<1e-9 and abs(math.exp(a)-1.5)<1e-9)
x=np.arange(1,12.0); y=np.append(2*np.arange(1,11)+1,40.0); m,c=np.polyfit(x,y,1)
chk('PS-153 regression',m>2 and c<1 and any('%.3f'%m in s for s in S['PS-153']) and any('%.3f'%c in s for s in S['PS-153']))
# final answers vs the independent solve.py
nchk=0
for iid,o in items.items():
    kind,val=solved[iid]
    if kind=='val':
        if iid not in V: fail(iid,'SPR without recorded final value'); continue
        if abs(V[iid]-val)>1e-9: fail(iid,'final',V[iid],val)
        nchk+=1
    elif iid in V:
        want=num(o['opts'][val]); 
        if want is None or abs(V[iid]-want)>1e-6: fail(iid,'option value',V[iid],want)
        nchk+=1
print('problems',len(S),'with >=1 box',len(withbox),'boxes',boxes,'returns-checked',ret_n,'taps',len(TAPS),'final answers checked',nchk)
print('without box:',sorted(set(S)-withbox),'verbal list',VERBAL)
print('total bad',bad); assert bad==0
