"""TikZ figures for GT-227 and GT-229, drawn from the numbers in the stems (AD:DB = 2:3 and equal areas)."""
import math
from figlib import fig
A=(3.2,4.4); B=(0.0,0.0); C=(7.0,0.0)
def pt(P,Q,t): return (P[0]+t*(Q[0]-P[0]),P[1]+t*(Q[1]-P[1]))
def tri(t,labels_extra=""):
    D=pt(A,B,t); E=pt(A,C,t)
    s=[r"\draw[thick,BLUE] (%g,%g)--(%g,%g)--(%g,%g)--cycle;"%(A+B+C),
       r"\draw[thick,ORANGE] (%g,%g)--(%g,%g);"%(D+E)]
    mid=lambda P,Q:((P[0]+Q[0])/2,(P[1]+Q[1])/2)
    for (P,Q) in ((D,E),(B,C)):
        m=mid(P,Q); s.append(r"\draw[-{Stealth[length=1.6mm]},thick,INK] (%g,%g)--(%g,%g);"%(m[0]-0.15,m[1],m[0]+0.1,m[1]))
    s.append(r"\node[above,font=\small] at (%g,%g){$A$};"%A); s.append(r"\node[below left,font=\small] at (%g,%g){$B$};"%B)
    s.append(r"\node[below right,font=\small] at (%g,%g){$C$};"%C)
    s.append(r"\node[left,font=\small] at (%g,%g){$D$};"%D); s.append(r"\node[right,font=\small] at (%g,%g){$E$};"%E)
    return s,D,E
def F227():
    s,D,E=tri(2/5)
    s.append(r"\node[font=\small] at (%g,%g){$20$};"%(A[0],(A[1]+D[1])/2-0.1))
    s.append(r"\node[font=\small] at (%g,%g){$?$};"%(A[0],D[1]/2-0.1))
    s.append(r"\node[font=\scriptsize,GREY,left] at (%g,%g){$2$};"%(pt(A,D,0.5)[0]-0.1,pt(A,D,0.5)[1]))
    s.append(r"\node[font=\scriptsize,GREY,left] at (%g,%g){$3$};"%(pt(D,B,0.5)[0]-0.1,pt(D,B,0.5)[1]))
    return fig("\n".join(s),xu=0.62,yu=0.62)
def F229():
    t=1/math.sqrt(2); s,D,E=tri(t)
    s=[r"\fill[BLUE!10] (%g,%g)--(%g,%g)--(%g,%g)--cycle;"%(A+D+E)]+s
    s.append(r"\node[font=\small] at (%g,%g){area $S$};"%(A[0],(A[1]+D[1])/2-0.35))
    s.append(r"\node[font=\small] at (%g,%g){area $S$};"%(A[0],D[1]/2))
    m=pt(A,B,0.5); s.append(r"\node[font=\small,left] at (%g,%g){$20$};"%(m[0]-0.35,m[1]+0.1))
    s.append(r"\draw[GREY] (%g,%g)--(%g,%g);"%(m[0]-0.2,m[1]+0.1,m[0]+0.02,m[1]+0.02))
    return fig("\n".join(s),xu=0.62,yu=0.62)
FIG={'GT-227':F227,'GT-229':F229}
