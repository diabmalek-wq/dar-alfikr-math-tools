"""Extract the 45 items of section 2.39 from the bank into raw.json (no editing here)."""
import re,json
B=open('/home/claude/cb/bank_new3.md').read()
s=B.index('### 2.39'); e=B.index('## 3. Bank Index',s)
blocks=re.split(r'\n(?=### [A-Z]{2}-\d+)',B[s:e])[1:]
out=[]
for b in blocks:
    g=lambda k:re.search(r'\*\*%s:\*\*[ \t]*(.*?)(?=\n\n\*\*|\n\*\*|\n---|\Z)'%(k),b,re.S).group(1).strip() if k in('Question','Correct Answer') else re.search(r'\*\*%s:\*\*[ \t]*([^\n]*)'%k,b).group(1).strip()
    out.append(dict(id=re.match(r'### (\S+)',b).group(1),d=g('Difficulty'),fmt=g('Format'),skill=g('Skill'),q=g('Question'),ans=g('Correct Answer')))
assert len(out)==45
json.dump(out,open('raw.json','w'),indent=1); print(len(out))
