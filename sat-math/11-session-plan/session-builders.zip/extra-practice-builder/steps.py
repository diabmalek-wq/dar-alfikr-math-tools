"""Desmos-style worked solutions for the Extra Practice set. Every number quoted is computed here from the typed expressions;
every [[expr]] is re-evaluated in verify_steps.py with the same Desmos-syntax evaluator (ev)."""
import math, re, statistics as _st
import numpy as np
from math import comb

class DList(list):
    """Desmos list: 1-indexed"""
    def __getitem__(self,i): return list.__getitem__(self,i-1) if isinstance(i,int) else list.__getitem__(self,i)
def n(v, d=4):
    s = ('%.*f' % (d, v)).rstrip('0').rstrip('.')
    if s in ('-0', ''): s = '0'
    if re.fullmatch(r'-?\d{4,}', s):
        neg = s.startswith('-'); r = s.lstrip('-'); out = ''
        while len(r) > 3: out = '{,}' + r[-3:] + out; r = r[:-3]
        s = ('-' if neg else '') + r + out
    return s
def ev(expr, **kw):
    e = expr.replace('^', '**')
    e = re.sub(r'(\d|\))\s*(\(|[a-zA-Z])', r'\1*\2', e)
    env = dict(sqrt=lambda v: math.sqrt(v) if v>=0 else (0.0 if v>-1e-12 else math.sqrt(v)), abs=abs, ln=math.log, log=math.log10, pi=math.pi, nCr=comb, mean=lambda l:sum(l)/len(l),
               median=lambda l:_st.median(l), stdev=lambda l:_st.stdev(l), total=sum, **kw)
    return eval(e, {'__builtins__': {}}, env)
def c(e): return '[[%s]]' % e
def v(x, d=4): return '$%s$' % n(x, d)
def ret(e, d=4, **kw): return "Type %s: it returns %s" % (c(e), v(ev(e, **kw), d))
def pt(x, y, d=4): return "$(%s,\\,%s)$" % (n(x, d), n(y, d))
def L(_t, **kw): return re.sub(r"@(\w+)@", lambda m: str(kw[m.group(1)]), _t)
S = {}; T = {}; V = {}; TAPS = []
def roots(f, g, lo, hi, N=20000):
    h = lambda x: ev(f, x=x) - ev(g, x=x); xs = np.linspace(lo, hi, N); out = []
    from scipy.optimize import brentq
    prev = None
    for x in xs:
        try: y = h(x)
        except Exception: prev = None; continue
        if prev is not None and prev[1] * y < 0: out.append(brentq(h, prev[0], x, xtol=1e-13))
        elif y == 0: out.append(x)
        prev = (x, y)
    return out
def tap(iid, f, g, lo, hi, k=None):
    """Desmos intersection of y=f and y=g in [lo,hi]: returns list of point strings (all roots) and registers each claim"""
    rs = roots(f, g, lo, hi)
    assert rs, (iid, f, g)
    pts = []
    for x in rs:
        y = ev(f, x=x); TAPS.append(dict(id=iid, f=f, g=g, x=x, y=y)); pts.append(pt(x, y))
    return rs, pts
def at(iid, f, x):
    y = ev(f, x=x); TAPS.append(dict(id=iid, f=f, g=None, x=x, y=y)); return pt(x, y)

# ================= evaluating claims (verbal: Desmos evaluates the numbers, then reasoning decides)
S['PS-133'] = [
 "Count the people who were randomly assigned: " + ret('60+60') + " volunteers, so every participant was assigned at random.",
 "Check the group sizes: " + ret('60/120') + " went to each method. Random assignment supports a cause-and-effect conclusion.",
 "But the $120$ were volunteers who answered an advertisement, not a random sample of all students, so the conclusion applies only to volunteers like them.",
 "Best supported: method $X$ caused higher scores for volunteers like those in the study."]
S['PS-134'] = [
 "Random selection: the $500$ adults were chosen at random from the city, so the result generalizes to adults in the city (no calculation is needed here).",
 "Nobody was assigned to exercise more or less, so the study is observational and can show association only.",
 "Reading the data: those who exercise more tend to sleep more, a positive association. Choices A and B claim a cause; C refuses to generalize.",
 "Best supported: a positive association among adults in the city, with no cause shown."]
S['PS-135'] = [
 "How many said yes? " + ret('0.91*1850') + " people (about $1684$) voted yes.",
 "That is a lot of people, but they chose to respond on a cycling club's site, so they are a voluntary-response sample of people who like bike lanes.",
 "A large count does not fix self-selection bias, so the sample-size choice is wrong.",
 "Main reason: respondents selected themselves and are likely to hold similar views."]
S['PS-136'] = [
 "Compare the sample sizes: " + ret('5000/500') + " times as many adults would still be an observational study.",
 "People chose whether to drink coffee, so other differences (age, lifestyle) could explain the lower rate.",
 "Only random assignment balances those other factors between the groups, so only it allows a cause-and-effect conclusion.",
 "The change needed: randomly assign the participants to drink coffee daily or not."]
S['PS-137'] = [
 "Lower end of the plausible values: " + ret('51-2.5') + ".",
 "Upper end: " + ret('51+2.5') + ".",
 "The interval $48.5$ to $53.5$ contains $50$, so both more than half and less than half are plausible.",
 "Best supported: it is plausible that a majority support the tax, but less than half is also plausible."]
S['PS-138'] = [
 "Greatest plausible mean: " + ret('3.2+0.4') + " hours per day.",
 "Multiply by the number of students: " + ret('3.6*18000') + ".",
 "Check the sample-mean total for comparison: " + ret('3.2*18000') + " (this ignores the margin of error, the trap).",
 "The greatest plausible total is $64{,}800$ hours per day."]
V['PS-138'] = ev('3.6*18000')
S['PS-139'] = [
 "The margin of error shrinks with $\\sqrt n$. The sample factor is " + ret('1600/400') + ".",
 "Its square root: " + ret('sqrt(1600/400)') + ".",
 "Divide the old margin by it: " + ret('6/sqrt(1600/400)') + " percent.",
 "Dividing by $4$ instead gives " + ret('6/4') + ", the trap."]
V['PS-139'] = ev('6/sqrt(1600/400)')
S['PS-140'] = [
 "Town $P$: " + ret('30-4') + " to " + ret('30+4') + " percent.",
 "Town $Q$: " + ret('38-4') + " to " + ret('38+4') + " percent.",
 "The intervals share the value $34$, so the same percent in both towns is plausible.",
 "Best supported: it is plausible that the percent in favor is the same in both towns."]
S['PS-141'] = [
 "Interval for the surveyed group: " + ret('62-5') + " to " + ret('62+5') + " percent.",
 "Seniors are what share of the school? " + ret('1200/(1200+2800)') + ", and the sample came only from them.",
 "So the interval describes seniors at the school, not all students, and it is a range of plausible values, not an exact value.",
 "Best supported: it is plausible that between $57\\%$ and $67\\%$ of the seniors at the school plan to attend college."]
S['PS-142'] = [
 "Tagged fraction in the sample: " + ret('9/60') + ".",
 "That fraction should equal $\\dfrac{150}{N}$. Type " + c('y=150/x') + " and " + c('y=9/60') + ", tap the intersection: " + "%s." % pt(*(lambda r:(r,0.15))(roots('150/x','9/60',1,5000)[0])),
 "Check: " + ret('150/(9/60)') + " fish.",
 "Estimated number of fish: $1000$."]
TAPS.append(dict(id='PS-142', f='150/x', g='9/60', x=roots('150/x','9/60',1,5000)[0], y=0.15))
V['PS-142'] = ev('150/(9/60)')
S['PS-143'] = [
 "Customers who did not renew: " + ret('36+35') + ".",
 "Those on Plan $B$: $35$, so type " + ret('35/71') + ".",
 "Compare the trap (all $200$ customers): " + ret('35/200') + ", which is wrong.",
 "Probability $\\dfrac{35}{71}\\approx0.493$ (enter $35/71$)."]
V['PS-143'] = ev('35/71')
r144, p144 = tap('PS-144', '0.4+x-0.4*x', '0.7', 0, 1)
S['PS-144'] = [
 "For independent events $P(A\\text{ or }B)=P(A)+P(B)-P(A)P(B)$. Type " + c('y=0.4+x-0.4x') + " and " + c('y=0.7') + " ($x$ stands for $P(B)$).",
 "Tap the intersection: " + p144[0] + ". Its $x$-value is $P(B)$.",
 "Check: " + ret('0.4+0.5-0.4*0.5') + ".",
 "$P(B)=0.5$."]
V['PS-144'] = r144[0]
S['PS-145'] = [
 "Both red: " + ret('(5/8)(4/7)') + ".",
 "Both blue: " + ret('(3/8)(2/7)') + ".",
 "Add: " + ret('(5/8)(4/7)+(3/8)(2/7)') + ".",
 "Match with the options: " + ret('13/28') + ", so the answer is $\\dfrac{13}{28}$."]
V['PS-145'] = ev('13/28')
S['PS-146'] = [
 "Outcomes with at least one even die: " + ret('36-3*3') + " (remove the $3\\times3$ all-odd pairs).",
 "Sum $8$ with an even die: $(2,6),(6,2),(4,4)$, so $3$ outcomes. ($(3,5)$ and $(5,3)$ are all-odd.)",
 "Probability: " + ret('3/27') + ".",
 "Answer: $\\dfrac19$ (enter $1/9$)."]
V['PS-146'] = ev('3/27')
S['PS-147'] = [
 "Own a car or a bicycle: " + ret('240+180-70') + ".",
 "Own neither: " + ret('500-350') + ".",
 "Probability: " + ret('150/500') + ".",
 "Answer: $0.3$."]
V['PS-147'] = ev('150/500')
S['PS-148'] = [
 "Voters over $60$: " + ret('0.3*0.8') + ".",
 "Voters not over $60$: " + ret('0.7*0.5') + ".",
 "Share of voters who are over $60$: " + ret('0.24/(0.24+0.35)') + ".",
 "Answer: $\\dfrac{24}{59}$ (enter $24/59$)."]
V['PS-148'] = ev('0.24/(0.24+0.35)')
S['PS-149'] = [
 "Drug $X$: " + ret('90/120') + ".",
 "Drug $Y$: " + ret('60/100') + ".",
 "Ratio: " + ret('(90/120)/(60/100)') + ".",
 "Answer: $1.25$."]
V['PS-149'] = ev('(90/120)/(60/100)')
# ================= two-variable data
r150, _ = [0], 0
S['PS-150'] = [
 "Type " + c('y=82-1.6x') + " and tap where the line crosses the $y$-axis: " + at('PS-150', '82-1.6*x', 0) + ".",
 "Check by typing " + ret('82-1.6*0') + ", the predicted score when $x=0$.",
 "$x$ is days absent, so $x=0$ means no absences. For comparison, " + ret('82-1.6*5') + " is the prediction after $5$ absences.",
 "The number $82$ is the predicted score of a student with no absences."]
xs151=[0,1,2,3,4]; ys151=[8,12,18,27,40.5]
a151=np.polyfit(xs151,np.log(ys151),1); b151=math.exp(a151[0]); A151=math.exp(a151[1])
S['PS-151'] = [
 "Open a table with $x_1=0,1,2,3,4$ and $y_1=8,12,18,27,40.5$. Type " + c('y_1~a*b^{x_1}') + ": Desmos returns $a=%s$ and $b=%s$ (an exponential fit)." % (n(A151,3), n(b151,3)),
 "Test (A) at $x=4$: " + ret('8*1.5^4') + ", matching $40.5$.",
 "Test (C) at $x=2$: " + ret('2*2^2+2*2+8') + ", not $18$; test (D) at $x=1$: " + ret('8*1.2^1') + ", not $12$; test (B) at $x=2$: " + ret('4*2+8') + ", not $18$.",
 "Only $y=8(1.5)^x$ fits all five pairs: (A)."]
S['PS-152'] = [
 "Type " + c('y=3.2x+14') + " and read the predicted value at $x=10$: " + at('PS-152','3.2*x+14',10) + ".",
 "Check: " + ret('3.2*10+14') + ".",
 "Residual = actual $-$ predicted: " + ret('51-46') + ".",
 "Answer: $5$."]
V['PS-152'] = ev('51-46')
x153=list(range(1,12)); y153=[2*t+1 for t in range(1,11)]+[40]; m153,b153=np.polyfit(x153,y153,1)
S['PS-153'] = [
 "The old line predicts " + ret('2*11+1') + " at $x=11$, so the new point is " + ret('40-23') + " above the line.",
 "Open a table with $x_1=1,2,\\ldots,11$ and $y_1=3,5,\\ldots,21,40$. Type " + c('y_1~mx_1+b') + ": Desmos returns $m=%s$ and $b=%s$." % (n(m153,3),n(b153,3)),
 "Compare with $y=2x+1$: the slope $%s$ is greater than $2$ and the intercept $%s$ is smaller than $1$." % (n(m153,3),n(b153,3)),
 "Answer: (C) greater slope and smaller $y$-intercept."]
S['PS-154'] = [
 "Range of the data: " + ret('0.85*20+12') + " to " + ret('0.85*80+12') + " for $x$ from $20$ to $80$.",
 "The prediction at $x=150$: " + ret('0.85*150+12') + ".",
 "Desmos can compute it, so (C) is false. But $150$ lies far outside $20$ to $80$, so the straight-line pattern may not continue.",
 "Answer: it is less reliable because $150$ is outside the range of the data."]
S['PS-155'] = [
 "Type " + c('y=1.5x+4') + ". The least-squares line passes through the point of means $(\\bar x,\\bar y)$.",
 "Read the line at $x=10$: " + at('PS-155','1.5*x+4',10) + ".",
 "Check: " + ret('1.5*10+4') + ".",
 "Answer: $\\bar y=19$."]
V['PS-155'] = ev('1.5*10+4')
S['PS-156'] = [
 "Residuals add to zero for a least-squares line. Add the four known ones: " + ret('-2+3+1-4') + ".",
 "The fifth residual cancels that: " + ret('0-(-2)') + ".",
 "Check: " + ret('-2+3+1-4+2') + ".",
 "Answer: $2$."]
V['PS-156'] = ev('0-(-2)')
# ================= functions
z288,p288 = tap('AM-288','(2*x+2)*(2*x-5)','0',-5,5)
S['AM-288'] = [
 "Pick a sample $f$ with zeros $-2$ and $5$: $f(x)=(x+2)(x-5)$. Then $g(x)=f(2x)=(2x+2)(2x-5)$. Type " + c('y=(2x+2)(2x-5)') + ".",
 "Tap the two $x$-intercepts: " + p288[0] + " and " + p288[1] + ".",
 "Check: " + ret('-2/2') + " and " + ret('5/2') + ", the old zeros divided by $2$.",
 "Answer: (C) $x=-1$ and $x=\\dfrac52$."]
S['AM-289'] = [
 "Open a table with $x_1=1,2,3,4$, $f_1=3,4,1,2$, $g_1=4,1,2,3$. First $g(3)$: type " + c('(g_1[3])') + ": it returns $2$.",
 "Now find $x$ with $f(x)=2$: look down the $f$ column, $f(4)=2$, so type " + c('(f_1[4])') + ": it returns $2$, and $f^{-1}(2)=4$.",
 "Finally $g(4)$: type " + c('(g_1[4])') + ": it returns $3$.",
 "Answer: $3$."]
V['AM-289'] = 3
S['AM-290'] = [
 "Pick an odd function to test, $f(x)=x^3$, and compare $x=2$ with $x=-2$. (A): " + ret('(2^3)^2') + " and " + ret('((-2)^3)^2') + ": equal, so even.",
 "(B) $f(f(x))$: " + ret('(2^3)^3') + " and " + ret('((-2)^3)^3') + ": opposites, so odd.",
 "(C) $f(x)+1$: " + ret('2^3+1') + " and " + ret('(-2)^3+1') + ": not equal. (D) $f(x)+x$: " + ret('2^3+2') + " and " + ret('(-2)^3-2') + ": opposites.",
 "Only (A) $[f(x)]^2$ must be even."]
S['AM-291'] = [
 "Reflect across the $y$-axis and shift up $4$: $g(x)=f(-x)+4$. Type " + c('y=(-x-1)(-x-5)+4') + ".",
 "Read the graph at $x=2$: " + at('AM-291','(-x-1)*(-x-5)+4',2) + ".",
 "Check: " + ret('(-2-1)(-2-5)+4') + ".",
 "Answer: $25$."]
V['AM-291'] = ev('(-2-1)*(-2-5)+4')
z292=[-math.sqrt(6),math.sqrt(6)]; p292=[at('AM-292','sqrt(x^2-6)',x) for x in z292]
S['AM-292'] = [
 "$f(g(x))=\\sqrt{(x^2-5)-1}=\\sqrt{x^2-6}$. Type " + c('y=sqrt(x^2-6)') + ".",
 "Desmos draws the curve only where it is defined. Tap the $x$-intercepts: " + p292[0] + " and " + p292[1] + ".",
 "Check: " + ret('sqrt(6)') + ", and the curve exists for $x\\le-\\sqrt6$ and $x\\ge\\sqrt6$ only (nothing between).",
 "Answer: (D) $x\\le-\\sqrt6$ or $x\\ge\\sqrt6$."]
r293,p293 = tap('AM-293','(2*x+1)/(x-3)','5',3.01,100)
S['AM-293'] = [
 "$f^{-1}(5)$ is the $x$ with $f(x)=5$. Type " + c('y=(2x+1)/(x-3)') + " and " + c('y=5') + ".",
 "Tap the intersection on the right branch: " + p293[0] + ". Its $x$-value is $f^{-1}(5)$.",
 "Check: " + ret('16/3') + ".",
 "Answer: $\\dfrac{16}{3}$ (enter $16/3$)."]
V['AM-293'] = r293[0]
S['AM-294'] = [
 "$f(x-1)$ moves the point right $1$: " + ret('4+1') + ".",
 "Then $y$ becomes $3(-2)+5$: " + ret('3(-2)+5') + ".",
 "The point is $(5,-1)$. Check with the other options: " + ret('3(-2)+5') + " is not $11$, so (A) and (D) fail; $x=3$ would need a left shift.",
 "Answer: (B) $(5,-1)$."]
S['AM-295'] = [
 "By Vieta $r+s=\\dfrac72$ and $rs=\\dfrac k2$, and $r^2+s^2=(r+s)^2-2rs$, so $k=(r+s)^2-9$: " + ret('(7/2)^2-9') + ".",
 "Check the roots for $k=3.25$: " + ret('(7+sqrt(49-8*3.25))/4') + " and " + ret('(7-sqrt(49-8*3.25))/4') + ".",
 "Their squares add to: " + ret('((7+sqrt(49-8*3.25))/4)^2+((7-sqrt(49-8*3.25))/4)^2') + ".",
 "Answer: $k=\\dfrac{13}{4}$ (enter $13/4$)."]
V['AM-295'] = ev('(7/2)^2-9')
z296,p296 = tap('AM-296','x^4-5*x^2+4','0',-4,4)
S['AM-296'] = [
 "Type " + c('y=x^4-5x^2+4') + ".",
 "Tap the four $x$-intercepts: " + ", ".join(p296) + ".",
 "Multiply them: " + ret('(-2)(-1)(1)(2)') + ".",
 "Answer: $4$."]
V['AM-296'] = ev('(-2)*(-1)*(1)*(2)')
z297,p297 = tap('AM-297','2^(2*x)-6*2^x+8','0',-3,5)
S['AM-297'] = [
 "Type " + c('y=2^(2x)-6*2^x+8') + ".",
 "Tap the $x$-intercepts: " + p297[0] + " and " + p297[1] + ".",
 "Add the solutions: " + ret('1+2') + ".",
 "Answer: $3$."]
V['AM-297'] = ev('1+2')
# ================= similar triangles
S['GT-226'] = [
 "Scale factor = square root of the area ratio: " + ret('sqrt(100/36)') + ".",
 "Perimeters scale by the scale factor itself: " + ret('24*sqrt(100/36)') + ".",
 "Check with the squares: " + ret('(24*sqrt(100/36)/24)^2') + " equals " + ret('100/36') + ".",
 "Answer: $40$."]
V['GT-226'] = ev('24*sqrt(100/36)')
S['GT-227'] = [
 "$AD:AB=2:5$, so the scale factor is " + ret('2/5') + ".",
 "Area of $ABC$: " + ret('20/(2/5)^2') + ".",
 "Quadrilateral $DBCE$: " + ret('125-20') + ".",
 "Answer: $105$."]
V['GT-227'] = ev('125-20')
S['GT-228'] = [
 "Length ratio = square root of the area ratio: " + ret('sqrt(18/50)') + ".",
 "Smaller altitude: " + ret('15*sqrt(18/50)') + ".",
 "Check the area ratio: " + ret('(9/15)^2') + " equals " + ret('18/50') + ".",
 "Answer: (D) $9$."]
V['GT-228'] = ev('15*sqrt(18/50)')
S['GT-229'] = [
 "$\\triangle ADE$ has half the area of $\\triangle ABC$, so $\\dfrac{AD}{AB}=\\sqrt{\\tfrac12}$: " + ret('sqrt(1/2)') + ".",
 "Multiply by $AB=20$: " + ret('20*sqrt(1/2)') + ".",
 "Check: " + ret('(20*sqrt(1/2)/20)^2') + " is the area ratio $\\dfrac12$.",
 "Answer: $14.1$."]
V['GT-229'] = round(ev('20*sqrt(1/2)'),1)
S['GT-230'] = [
 "Hypotenuse of the small triangle: " + ret('sqrt(6^2+8^2)') + ", and its area " + ret('6*8/2') + ".",
 "Scale factor: " + ret('sqrt(150/24)') + ".",
 "Hypotenuse of the large triangle: " + ret('10*sqrt(150/24)') + ".",
 "Answer: $25$."]
V['GT-230'] = ev('10*sqrt(150/24)')
S['GT-231'] = [
 "The scale factor from apex to the cut is $\\dfrac13$. Area factor: " + ret('(1/3)^2') + ".",
 "Cross-section area: " + ret('144*(1/3)^2') + ".",
 "Check with side lengths: base side " + ret('sqrt(144)') + ", cut side " + ret('sqrt(144)/3') + ", area " + ret('(sqrt(144)/3)^2') + ".",
 "Answer: $16$."]
V['GT-231'] = ev('144*(1/3)^2')
S['AM-298'] = [
 "Vertex form $f(x)=a(x-4)^2-8$. Use $(0,8)$: " + ret('(8+8)/(0-4)^2') + " for $a$.",
 "Type " + c('y=(x-4)^2-8') + " and check it passes through $(0,8)$: " + at('AM-298','(x-4)^2-8',0) + ".",
 "$g(1)=f(2)$: " + ret('(2-4)^2-8') + ".",
 "Answer: $-4$."]
V['AM-298'] = ev('(2-4)**2-8')
z299,p299 = tap('AM-299','(3-x-1)*(3-x-6)','0',-6,6)
S['AM-299'] = [
 "Take a sample $f$ with zeros $1$ and $6$, $f(x)=(x-1)(x-6)$, so $g(x)=f(3-x)=(3-x-1)(3-x-6)$. Type " + c('y=(3-x-1)(3-x-6)') + ".",
 "Tap the $x$-intercepts: " + p299[0] + " and " + p299[1] + ".",
 "Check: " + ret('3-1') + " and " + ret('3-6') + ".",
 "Greatest $x$-intercept: $2$."]
V['AM-299'] = max(z299)
S['AM-300'] = [
 "$f$ is even, so $g(x)=f(x)+f(-x)=2f(x)$. $g(3)$: " + ret('2*7') + ".",
 "$f(5)=f(-5)=2$, so $g(5)$: " + ret('2*2') + ".",
 "Total: " + ret('14+4') + ".",
 "Answer: $18$."]
V['AM-300'] = ev('14+4')
z301,p301 = tap('AM-301','x^2-5*x+2','0',-1,6)
S['AM-301'] = [
 "Type " + c('y=x^2-5x+2') + " and tap the $x$-intercepts: " + p301[0] + " and " + p301[1] + ". These are $s$ and $r$.",
 "Type " + ret('((5+sqrt(17))/2)/((5-sqrt(17))/2)+((5-sqrt(17))/2)/((5+sqrt(17))/2)') + ".",
 "Check with Vieta: " + ret('(5^2-2*2)/2') + ".",
 "Answer: $\\dfrac{21}{2}$ (enter $21/2$)."]
V['AM-301'] = ev('(5^2-2*2)/2')
z302,p302 = tap('AM-302','x^3-7*x^2+14*x-8','0',-1,6)
S['AM-302'] = [
 "Type " + c('y=x^3-7x^2+14x-8') + ".",
 "Tap the three $x$-intercepts: " + ", ".join(p302) + ".",
 "Sum of the squares: " + ret('1^2+2^2+4^2') + ".",
 "Answer: $21$."]
V['AM-302'] = ev('1^2+2^2+4^2')
# ---- tool tags: Desmos wherever Desmos does the solving; the claims/verbal items stay No calculator
T.update({i:'D' for i in S})
for i in ('PS-133','PS-134','PS-135','PS-136','PS-137','PS-140','PS-141'): T[i]='N'
VERBAL=['PS-134']
