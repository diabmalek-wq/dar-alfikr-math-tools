"""raw.json -> items.json: layout (Part A / Part B), tables, options, figures, repairs. Edits are recorded in FIXES."""
import json,re,sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import figs
raw=json.load(open('raw.json'))
def tab(md):
    rows=[r.strip().strip('|').split('|') for r in md.strip().split('\n') if r.strip().startswith('|') and not re.match(r'^\|\s*-',r.strip())]
    n=len(rows[0]);t=r"\begin{center}\renewcommand{\arraystretch}{1.7}\begin{tabular}{|"+"c|"*n+"}\hline "
    for r in rows: t+=" & ".join(c.strip() for c in r)+r" \\ \hline "
    return t+r"\end{tabular}\end{center}"
FIXES={}
REPAIR={'AM-293':("x\ne3$",r"x\neq3$","stem damaged in the bank (a '\\n' escape swallowed the backslash of \\neq, leaving a line break and the letter e: 'x<newline>e3'); restored x \\neq 3, math unchanged")}
# Part A = 25 Hard items (domain mix), Part B = 11 Hard + 9 Medium; Hard first inside each part, bank order otherwise
PARTB_HARD=['PS-138','PS-142','PS-143','PS-145','PS-152','PS-155','AM-293','AM-298','AM-300','AM-296','GT-230']
def split(q):
    stem=[];opts=[]
    for ln in q.split('\n'):
        m=re.match(r'^\(([A-D])\)\s*(.*)$',ln.strip())
        if m: opts.append(m.group(2).strip())
        elif opts and ln.strip(): opts[-1]+=' '+ln.strip()
        elif not opts: stem.append(ln)
    return '\n'.join(stem).strip(),opts
def render_stem(stem):
    lines=stem.split('\n'); out=[];i=0
    while i<len(lines):
        if lines[i].strip().startswith('|'):
            j=i
            while j<len(lines) and lines[j].strip().startswith('|'): j+=1
            out.append('\n\n'+tab('\n'.join(lines[i:j]))+'\n\n'); i=j
        else: out.append(lines[i]); i+=1
    return re.sub(r'\n{3,}','\n\n',"\n".join(out)).strip()
items=[]
for o in raw:
    q=o['q']
    if o['id'] in REPAIR:
        a,b,why=REPAIR[o['id']]; assert a in q; q=q.replace(a,b); FIXES[o['id']]=why
    stem,opts=split(q); mc=o['fmt'].startswith('Multiple')
    if mc:
        assert len(opts)==4 and len(set(opts))==4,o['id']; letter=re.match(r'^\(([A-D])\)',o['ans']).group(1)
    else: opts=None; letter=None
    fig=figs.FIG[o['id']]() if o['id'] in figs.FIG else ''
    items.append(dict(id=o['id'],d=o['d'],skill=o['skill'],q=render_stem(stem)+fig if False else render_stem(stem),fig=fig,opts=opts,letter=letter,
                      sans=None if mc else o['ans'],part='B' if (o['d']=='Medium' or o['id'] in PARTB_HARD) else 'A'))
A=[x for x in items if x['part']=='A']; B=[x for x in items if x['part']=='B']
B=[x for x in B if x['d']=='Hard']+[x for x in B if x['d']=='Medium']
assert len(A)==25 and len(B)==20 and all(x['d']=='Hard' for x in A)
json.dump(dict(items=A+B,fixes=FIXES),open('items.json','w'),indent=1); print(len(A),len(B))
