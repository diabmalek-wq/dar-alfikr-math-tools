import re,json,sys
sys.path.insert(0,'.')
from ids import IDS
t=open('/home/claude/repo-check2/sat-bank/verified-item-bank/SAT_Bank_Verified_Item_Bank.md').read()
blocks=re.split(r'\n(?=### )',t)
d={b.split('\n')[0][4:].strip():b for b in blocks if b.startswith('### ')}
out=[]
for i,p,df in IDS:
    b=d[i]
    q=re.search(r'\*\*Question:\*\*\s*(.*?)\n\s*\n?\s*\*\*Correct Answer:\*\*\s*(.*?)\n',b,re.S)
    body=q.group(1); ans=q.group(2).strip()
    body=re.sub(r'\*\*Figure \(TikZ.*?```latex.*?```','',body,flags=re.S)
    body=re.sub(r'^\[Figure:[^\]]*\]\s*','',body)
    body=re.sub(r'\n\*\*Figure.*','',body,flags=re.S)
    lines=body.strip().split('\n')
    stem=[];opts=[]
    for ln in lines:
        m=re.match(r'^\(?([A-D])\)\s*(.*)$',ln.strip())
        if m and (opts or m.group(1)=='A'): opts.append(m.group(2).strip())
        elif ln.strip()=='' : continue
        elif opts: raise Exception((i,ln))
        else: stem.append(ln.strip())
    hdr=b[:600]
    ismc=('Multiple Choice' in hdr.split('**Question')[0])
    assert (len(opts)==4)==ismc,(i,len(opts))
    out.append(dict(id=i,part='A' if p=='In class' else 'B',d=df,q='\n\n'.join(stem),opts=opts or None,bank_ans=ans))
json.dump(out,open('items_raw.json','w'),indent=1)
for o in out: print(o['id'],o['part'],o['d'],o['bank_ans'][:30],'|',o['q'][:70].replace('\n',' '))
