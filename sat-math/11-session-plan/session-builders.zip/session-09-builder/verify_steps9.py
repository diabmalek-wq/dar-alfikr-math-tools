"""Re-evaluates every typed [[expr]] in the Answers steps with the Desmos-syntax evaluator and checks every quoted value, tapped point
and final answer against the independent solve9/compare9 answers."""
import re,json,math
from dsteps import STEPS,R,A
from desmos_ev import ev,lst,solve_x
KEY=json.load(open('key9.json')); items={o['id']:o for o in json.load(open('items9.json'))}
bad=0
def fail(*a):
    global bad; bad+=1; print('FAIL',*a)
def close(a,b,tol=6e-5): return abs(a-b)<=tol*max(1,abs(b))
tot=0; per={}; covered={}
for i,steps in STEPS.items():
    text=' '.join(steps); boxes=re.findall(r'\[\[(.+?)\]\](?!\])',text); per[i]=len(boxes); tot+=len(boxes); cov=set()
    if not 3<=len(steps)<=4: fail(i,'step count',len(steps))
    if not boxes: fail(i,'no Desmos box')
    for ent in R[i]:
        k=ent[0]
        if k=='ret':
            _,e,kw,shown=ent; cov.add(e)
            m=re.search(r'\[\['+re.escape(e)+r'\]\]: it returns \$([^$]+)\$',text)
            if not m: fail(i,'ret not in text',e); continue
            got=ev(e,**kw)
            if not close(got,float(m.group(1))): fail(i,e,got,m.group(1))
        elif k=='inter':
            _,r1,r2,lo,hi,pick,sx,sy=ent; cov|={'y='+r1,'y='+r2}
            rs=solve_x(lambda x:ev(r1,x=x)-ev(r2,x=x),lo,hi); x=rs[pick]; y=ev(r1,x=x)
            if not(close(x,float(sx)) and close(y,float(sy)) and close(ev(r2,x=x),y)): fail(i,'inter',r1,r2,x,y,sx,sy)
            if '$(%s,\\,%s)$'%(sx,sy) not in text: fail(i,'tap text missing',sx,sy)
        elif k=='inter2':
            _,r1,r2,lo,hi,shown=ent; cov|={'y='+r1,'y='+r2}
            rs=solve_x(lambda x:ev(r1,x=x)-ev(r2,x=x),lo,hi)
            if [round(r,4) for r in rs]!=[round(float(s),4) for s in shown]: fail(i,'inter2',rs,shown)
        elif k=='imp':
            _,l,r,pts=ent; cov.add(l+'='+r)
            for px,py in pts:
                if abs(ev(l,x=px,y=py)-ev(r,x=px,y=py))>1e-9: fail(i,'curve point',l,r,px,py)
        elif k=='list':
            cov.add(ent[1]+'='+ent[2]); L=lst(ent[2])
            if len(L)!=8: fail(i,'list')
    covered[i]=cov
# special boxes handled by hand-written checks
if i:=None: pass
sp={'GT-040':['(x+4)^2+(y-b)^2=100','(4,13)','(-10,-1)'],'GT-005':['y=29-x','y=9'],'GT-168':[]}
if any(abs((x+4)**2+(y-7)**2-100)>1e-9 for x,y in [(4,13),(-10,-1)]): fail('GT-040 slider b=7')
if abs(ev('29-x',x=20)-9)>1e-12: fail('GT-005 k')
# every box must be covered
unc=0
for i,steps in STEPS.items():
    for b in re.findall(r'\[\[(.+?)\]\](?!\])',' '.join(steps)):
        if b not in covered[i] and b not in sp.get(i,[]): fail(i,'box not verified',b); unc+=1
# claimed tapped values typed in the prose
EXP={'GT-043':25,'GT-045':60,'GT-047':20,'GT-100':4,'GT-101':6,'GT-118':2,'GT-121':5,'GT-133':8,'GT-143':2,'GT-154':4,'GT-173':27,'GT-174':3,'GT-177':12,'GT-183':2,'GT-185':15,'GT-186':2,'GT-128':15}
for i,v in EXP.items():
    xs=[float(e[6]) for e in R[i] if e[0]=='inter']
    if not any(abs(x-v)<5e-4 for x in xs[:1]): fail(i,'claimed tap',v,xs)
# final answers vs independent solutions
for i,o in items.items():
    a=A[i]; k=KEY[i]
    if o['opts']:
        tol=0.06 if i in('GT-067','GT-068','GT-070','GT-071') else 1e-9
        if abs(a-k['val'])>tol: fail(i,'MC answer',a,k['val'])
    else:
        tv=k['val']
        if i=='GT-112': tv=5/3
        if abs(a-tv)>1e-6: fail(i,'SPR answer',a,tv)
print('items with >=1 Desmos box:',sum(1 for v in per.values() if v>=1),'of',len(STEPS)); print('total boxes:',tot,'unverified boxes:',unc)
print('step counts:',sorted(set(len(v) for v in STEPS.values())))
print('FAILURES',bad)
