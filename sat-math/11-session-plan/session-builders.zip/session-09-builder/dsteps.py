"""Desmos solutions for Session 9. Every typed [[expr]] value is computed by ev(); intersections are solved numerically;
registry R lets verify_steps9.py re-check everything. A[id] = the value the Desmos solution produces as the final answer."""
import math
from desmos_ev import ev,lst,solve_x
def n(v,d=4):
    s=('%.*f'%(d,v)).rstrip('0').rstrip('.'); return '0' if s in('-0','') else s
def c(e): return '[[%s]]'%e
R={}; A={}; STEPS={}; CUR=[None]
def reg(*t): R.setdefault(CUR[0],[]).append(t)
def ret(e,d=4,**kw):
    v=ev(e,**kw); s=n(v,d); reg('ret',e,kw,s); return "Type %s: it returns $%s$"%(c(e),s)
def val(e,**kw): return ev(e,**kw)
def pt(x,y,d=4): return "$(%s,\\,%s)$"%(n(x,d),n(y,d))
def inter(r1,r2,lo,hi,pick=0,d=4):
    f=lambda x:ev(r1,x=x)-ev(r2,x=x); rs=solve_x(f,lo,hi); x=rs[pick]; y=ev(r1,x=x)
    reg('inter',r1,r2,lo,hi,pick,n(x,d),n(y,d))
    return "Type %s and %s"%(c('y='+r1),c('y='+r2)),"%s"%pt(x,y,d),x,y
def imp(lhs,rhs,pts):
    for (px,py) in pts: assert abs(ev(lhs,x=px,y=py)-ev(rhs,x=px,y=py))<1e-9,(lhs,rhs,px,py)
    reg('imp',lhs,rhs,pts); return c(lhs+'='+rhs)
def pts_txt(pts): return ", ".join(pt(a,b) for a,b in pts)
def step(i):
    def deco(f): CUR[0]=i; STEPS[i],A[i]=f(); return f
    return deco
def N(v,d=4): return n(v,d)
# ======================================================= 043
@step('GT-043')
def _():
    t,tap,x,y=inter('sin(2x deg)','cos((x+15) deg)',0.001,44.999)
    return [t+" (set the window to $0<x<45$).","Tap the intersection: "+tap+". The $x$-value is the answer.",
      ret('sin(2*25 deg)')+" and "+ret('cos((25+15) deg)')[5:]+", so the two sides agree at $x=25$.",
      "The window excludes the other crossings such as $x=105$, so $x=%s$."%n(x,0)],x
@step('GT-044')
def _():
    v=val('30/16')
    return ["$\\tan A=\\dfrac{\\text{opposite}}{\\text{adjacent}}=\\dfrac{BC}{AC}$. "+ret('30/16')+".",
      ret('15/8')+", the same decimal, so option (@@L@@) matches.",
      "The other options: "+ret('8/15')+" (inverted) and "+ret('34/16')[5:]+" (hypotenuse used).",
      "So $\\tan A=\\dfrac{15}{8}$."],ev('15/8')
@step('GT-045')
def _():
    t,tap,x,y=inter('36/x','0.6',1,200)
    return ["$\\cos A=\\dfrac{AC}{AB}$, so $\\dfrac{36}{AB}=\\dfrac35=0.6$ with $x$ standing for $AB$.",
      t+".","Tap the intersection: "+tap+", so $AB=%s$."%n(x,0),
      "Check: "+ret('36/60')+", which is $\\dfrac35$."],x
@step('GT-046')
def _():
    return ["$AC$ is opposite the $30^\\circ$ angle, $BC=18$ is adjacent, so $AC=18\\tan30^\\circ$. "+ret('18tan(30 deg)')+".",
      "Compare with the options: "+ret('6sqrt(3)')+" matches, so option (@@L@@).",
      "The others: "+ret('9sqrt(3)')+" and "+ret('18sqrt(3)')[5:]+" are too big, and $9$ is just half of $18$.",
      "So $AC=6\\sqrt3$."],ev('18tan(30 deg)')
@step('GT-047')
def _():
    t,tap,x,y=inter('2x+x*sqrt(2)','40+20sqrt(2)',0.1,100)
    return ["Let each leg be $x$. The hypotenuse is $x\\sqrt2$, so the perimeter is $2x+x\\sqrt2$.",
      t+".","Tap the intersection: "+tap+", so each leg is $%s$."%n(x,0),
      "The hypotenuse is $x\\sqrt2$: "+ret('20sqrt(2)')+", that is $20\\sqrt2$."],ev('20sqrt(2)')
@step('GT-066')
def _():
    return ["Hypotenuse: "+ret('sqrt(9^2+12^2)')+".",
      "$\\sin A=\\dfrac{BC}{AB}$: "+ret('12/15')+".",
      ret('4/5')+", the same, so option (@@L@@).",
      "The option $\\dfrac35$ is "+ret('9/15')[5:]+", which is $\\cos A$."],ev('4/5')
@step('GT-067')
def _():
    return ["The legs are involved, so use tangent: $\\tan35^\\circ=\\dfrac{EF}{18}$.",
      ret('18tan(35 deg)')+".",
      "The closest option is $12.6$, option (@@L@@).",
      "Wrong-function answers differ: "+ret('18sin(35 deg)')+" (sine) and "+ret('18cos(35 deg)')[5:]+" (cosine)."],ev('18tan(35 deg)')
@step('GT-068')
def _():
    return ["Two sides and the included angle: Law of Cosines, $c^2=80^2+95^2-2(80)(95)\\cos62^\\circ$.",
      ret('80^2+95^2-2*80*95cos(62 deg)')+".",
      ret('sqrt(80^2+95^2-2*80*95cos(62 deg))')+".",
      "The closest option is $91.0$, option (@@L@@)."],ev('sqrt(80^2+95^2-2*80*95cos(62 deg))')
@step('GT-069')
def _():
    return ["Missing leg: "+ret('sqrt(13^2-5^2)')+".",
      "$\\cos A=\\dfrac{AC}{AB}$: "+ret('12/13')+".",
      "Compare: "+ret('5/13')+" is $\\sin A$, not the answer; option (@@L@@) has $\\dfrac{12}{13}$.",
      "So $\\cos A=\\dfrac{12}{13}$."],ev('12/13')
@step('GT-070')
def _():
    return ["The $40$ m is adjacent to the $58^\\circ$ angle and the height is opposite: $h=40\\tan58^\\circ$.",
      ret('40tan(58 deg)')+".","Closest option: $64.0$, option (@@L@@).",
      "A distractor comes from using sine instead of tangent: "+ret('40sin(58 deg)')+"."],ev('40tan(58 deg)')
@step('GT-071')
def _():
    return ["Third angle: "+ret('180-40-65')+" degrees.",
      "Law of Sines: $EF=22\\dfrac{\\sin40^\\circ}{\\sin75^\\circ}$. "+ret('22sin(40 deg)/sin(75 deg)')+".",
      "Closest option: $14.6$, option (@@L@@).",
      "Check using the other ratio: "+ret('22sin(65 deg)/sin(75 deg)')+" is side $DF$, not $EF$."],ev('22sin(40 deg)/sin(75 deg)')
@step('GT-072')
def _():
    return ["The acute angles are complementary, so $\\cos Q=\\sin P=\\dfrac7{25}$: "+ret('7/25')+".",
      "Check in Desmos: let $P=\\arcsin\\dfrac7{25}$ and type "+ret('cos(pi/2-arcsin(7/25))')+".",
      "Option (@@L@@) is $\\dfrac7{25}$. The option $\\dfrac{24}{25}$ is "+ret('24/25')[5:]+", the cosine of $P$ instead."],ev('cos(pi/2-arcsin(7/25))')
@step('GT-087')
def _():
    return ["Origin at Noah's house: Maya ends at $(3,4)$ and Noah at $(-5,-2)$.",
      "Distance: "+ret('sqrt((3-(-5))^2+(4-(-2))^2)')+" miles.",
      "Time: "+ret('10/5')+" hours."],ev('10/5')
@step('GT-088')
def _():
    return ["Area from two sides and the angle between them: $\\dfrac12(8)(10)\\sin60^\\circ$.",
      ret('1/2*8*10*sin(60 deg)')+".",
      ret('20sqrt(3)')+", the same, so option (@@L@@).",
      "The others: "+ret('20sqrt(2)')+" and "+ret('40sqrt(3)')[5:]+" do not match."],ev('20sqrt(3)')
@step('GT-097')
def _():
    return ["Differences: $9-(-3)=12$ and $-4-(-9)=5$.",ret('sqrt((9-(-3))^2+(-4-(-9))^2)')+".",
      "So the distance is $13$."],13.0
@step('GT-100')
def _():
    t,tap,x,y=inter('(x+1)^2+(x+8)^2','(x+9)^2',0.01,100)
    return ["Pythagorean theorem: $(x+1)^2+(x+8)^2=(x+9)^2$. "+t+".",
      "Tap the intersection with a positive $x$: "+tap+", so $x=%s$."%n(x,0),
      "The legs are "+ret('4+1')[5:]+" and "+ret('4+8')[5:]+" (hypotenuse $13$).",
      "Area: "+ret('1/2*(4+1)(4+8)')+"."],ev('1/2*(4+1)(4+8)')
@step('GT-101')
def _():
    t,tap,x,y=inter('3x+x*sqrt(3)','18+6sqrt(3)',0.1,100)
    return ["Sides are $s$, $s\\sqrt3$, $2s$, so the perimeter is $3s+s\\sqrt3$. "+t+".",
      "Tap the intersection: "+tap+", so $s=%s$."%n(x,0),
      "Hypotenuse $2s$: "+ret('2*6')+".","Option (@@L@@)."],ev('2*6')
@step('GT-102')
def _():
    t,tap,x,y=inter('arctan(x/5)','2arctan(5/x)',0.1,50)
    return ["With $x=BC$: angle $A=\\arctan\\dfrac x5$ and angle $C=\\arctan\\dfrac5x$. The condition is $A=2C$. "+t+".",
      "Tap the intersection: "+tap+", so $BC\\approx%s$."%n(x,4),
      "Compare with the options: "+ret('5sqrt(3)')+", the same, so option (@@L@@).",
      "Check: "+ret('arctan(5sqrt(3)/5)*180/pi')+" degrees for $A$ and "+ret('arctan(5/(5sqrt(3)))*180/pi')[5:]+" degrees for $C$."],x
@step('GT-107')
def _():
    return ["Altitude rule: $BD^2=AD\\cdot DC$. "+ret('3*12')+".",
      ret('sqrt(3*12)')+", so $BD=6$, option (@@L@@).",
      "Check: "+ret('(3^2+6^2)+(12^2+6^2)')+" equals "+ret('15^2')[5:]+", so the triangle is right-angled at $B$."],ev('sqrt(3*12)')
@step('GT-112')
def _():
    return ["$QR=$ "+ret('sqrt(30^2-18^2)')[5:]+".",
      "Area two ways: $QS=\\dfrac{18\\cdot24}{30}$. "+ret('18*24/30')+".",
      "Ratio: "+ret('24/14.4')+".",
      "That equals "+ret('5/3')+", so the answer is $\\dfrac53$."],ev('24/14.4')
@step('GT-118')
def _():
    t,tap,x,y=inter('12x^2','48',0.01,20)
    return ["Areas $48:108$ give $AD:DB=4:9$: "+ret('48/108')+" and "+ret('4/9')[5:]+".",
      "With $AD=4k$, $DB=9k$, $CD=6k$, area of $ACD$ is $12k^2$. "+t+" ($x$ stands for $k$).",
      "Tap the intersection: "+tap+", so $k=2$.",
      "$AB=13k$: "+ret('13*2')+"."],ev('13*2')
@step('GT-121')
def _():
    t,tap,x,y=inter('16x^2','80x',0.5,50)
    return ["Legs $PQ=4k$, $QR=3k$, $PR=5k$, and $PQ^2=PS\\cdot PR$ gives $16k^2=16\\cdot5k=80k$.",
      t+" ($x$ stands for $k$).","Tap the intersection with $x>0$: "+tap+", so $k=5$.",
      "$PR=$ "+ret('5*5')[5:]+" and $SR=$ "+ret('25-16')[5:]+", option (@@L@@)."],ev('25-16')
@step('GT-125')
def _():
    return ["Let the legs be $a$, $b$: $ab=2\\cdot96$ and $a^2+b^2=400$. "+ret('2*96')+".",
      "$a+b=\\sqrt{400+2ab}$: "+ret('sqrt(400+2*192)')+".",
      "Square side $s=\\dfrac{ab}{a+b}$: "+ret('192/28')+".",
      ret('48/7')+", the same, so option (@@L@@)."],ev('192/28')
@step('GT-128')
def _():
    t,tap,x,y=inter('sin(x deg)+cos(x deg)','sqrt(6)/2',0.1,89.9)
    return ["$\\sin Q=\\cos P$, so the condition is $\\sin P+\\cos P=\\dfrac{\\sqrt6}2$ with $x$ standing for $P$ in degrees. "+t+".",
      "Tap the first intersection: "+tap+", so $P=15^\\circ$ and $Q=75^\\circ$ (the other crossing swaps them).",
      ret('tan(15 deg)+tan(75 deg)')+"."],ev('tan(15 deg)+tan(75 deg)')
@step('GT-133')
def _():
    t,tap,x,y=inter('x(10-x)','16',0.01,9.99,pick=1)
    return ["With $AD=x$, $DB=10-x$ and $CD^2=AD\\cdot DB=16$. "+t+".",
      "Tap the intersection with the larger $x$ (because $AD>DB$): "+tap+", so $AD=8$.",
      "$AC=$ "+ret('sqrt(8^2+4^2)')[5:]+" and $\\cos A=\\dfrac{AD}{AC}$: "+ret('8/sqrt(80)')+".",
      ret('2sqrt(5)/5')+", the same, so option (@@L@@)."],ev('8/sqrt(80)')
@step('GT-136')
def _():
    t,tap,x,y=inter('x(sqrt(3)-1)/2','5',0.1,100)
    return ["With $BC=x$: $AC=x\\sqrt3$, $AB=2x$, and $r=\\dfrac{x+x\\sqrt3-2x}2=\\dfrac{x(\\sqrt3-1)}2$. "+t+".",
      "Tap the intersection: "+tap+", so $BC\\approx%s$."%n(x,4),
      "$AC=x\\sqrt3$: "+ret('10/(sqrt(3)-1)*sqrt(3)')+".",
      ret('15+5sqrt(3)')+", the same, so option (@@L@@)."],ev('10/(sqrt(3)-1)*sqrt(3)')
@step('GT-143')
def _():
    t,tap,x,y=inter('30x^2','120',0.01,20)
    return ["Sides $5k$, $12k$, $13k$, so the area is $30k^2$. "+t+" ($x$ stands for $k$).",
      "Tap the intersection: "+tap+", so $k=2$, $AC=24$ and $AB=26$.",
      "Leg rule $AD=\\dfrac{AC^2}{AB}$: "+ret('24^2/26')+".",
      ret('288/13')+", the same, so option (@@L@@)."],ev('24^2/26')
@step('GT-151')
def _():
    f=lambda x:ev('sin((5x-20) deg)',x=x)-ev('cos((x+14) deg)',x=x); rs=solve_x(f,0.001,44.999)
    reg('inter2','sin((5x-20) deg)','cos((x+14) deg)',0.001,44.999,[n(r,4) for r in rs])
    return ["Type %s and %s, with the window $0<x<45$."%(c('y=sin((5x-20) deg)'),c('y=cos((x+14) deg)')),
      "Tap both intersections: "+pt(rs[0],ev('sin((5x-20) deg)',x=rs[0]))+" and "+pt(rs[1],ev('sin((5x-20) deg)',x=rs[1]))+".",
      "The solutions are $x=%s$ and $x=%s$. Sum: "%(n(rs[0],0),n(rs[1],0))+ret('16+31')+"."],ev('16+31')
@step('GT-154')
def _():
    t,tap,x,y=inter('x(x+5)','36',0.01,50)
    return ["With $AD=x$ and $DB=x+5$: $CD^2=AD\\cdot DB=36$. "+t+".",
      "Tap the intersection with $x>0$: "+tap+", so $AD=4$, $DB=9$, $AB=13$.",
      "$AC=\\sqrt{4^2+6^2}$ and $\\sin B=\\dfrac{AC}{AB}$: "+ret('sqrt(4^2+6^2)/13')+".",
      ret('2sqrt(13)/13')+", the same, so option (@@L@@)."],ev('sqrt(4^2+6^2)/13')
@step('GT-168')
def _():
    L=lst('[7,14...20]')
    reg('list','L','[7,14...20]')
    return ["Height from $R$ to line $PQ$: "+ret('14sin(30 deg)')+". So $a<7$ gives no triangle, $a=7$ one, $7<a<14$ two, and $a\\ge14$ one.",
      "Type the values that give exactly one triangle as a list: "+c('L=[7,14...20]')+".",
      ret('L.length',L=L)+".","So the count is $8$."],float(len(L))
@step('GT-173')
def _():
    t,tap,x,y=inter('sin(x deg)','cos((2x+9) deg)',0.001,29.999)
    return [t+" (window $0<x<30$).","Tap the intersection: "+tap+".",
      "Check the angles are complementary: "+ret('27+(2*27+9)')+".","So $x=%s$."%n(x,0)],x
@step('GT-174')
def _():
    t,tap,x,y=inter('sqrt((8x)^2+(15x)^2)','51',0.1,50)
    return ["Sides $8k$, $15k$ and hypotenuse $\\sqrt{(8k)^2+(15k)^2}$ ($x$ stands for $k$). "+t+".",
      "Tap the intersection: "+tap+", so $k=3$.","Perimeter: "+ret('8*3+15*3+51')+"."],ev('8*3+15*3+51')
@step('GT-175')
def _():
    return ["Hypotenuse: "+ret('sqrt(7^2+24^2)')+".","Area two ways: $h=\\dfrac{7\\cdot24}{25}$. "+ret('7*24/25')+".",
      "Check: "+ret('1/2*25*6.72')+" equals "+ret('1/2*7*24')[5:]+", the area of the triangle."],ev('7*24/25')
@step('GT-176')
def _():
    return ["Each leg is $\\dfrac{14}{\\sqrt2}$: "+ret('14/sqrt(2)')+".","Perimeter: "+ret('14+2*14/sqrt(2)')+".",
      ret('14+14sqrt(2)')+", the same, so option (@@L@@)."],ev('14+2*14/sqrt(2)')
@step('GT-177')
def _():
    t,tap,x,y=inter('x*sqrt(3)/2','6sqrt(3)',0.1,100)
    return ["Height of an equilateral triangle with side $x$ is $\\dfrac{x\\sqrt3}2$. "+t+".","Tap the intersection: "+tap+", so $s=%s$."%n(x,0),
      "Perimeter: "+ret('3*12')+"."],ev('3*12')
@step('GT-178')
def _():
    return ["$\\cos(90^\\circ-\\theta)=\\sin\\theta=0.6$ and $\\tan\\theta$: "+ret('tan(arcsin(0.6))')+".",
      "Sum: "+ret('0.6+tan(arcsin(0.6))')+".","Check directly: "+ret('cos(pi/2-arcsin(0.6))+tan(arcsin(0.6))')+", option (@@L@@)."],ev('0.6+tan(arcsin(0.6))')
@step('GT-179')
def _():
    return ["Height $=\\sqrt{13^2-7^2}$: "+ret('sqrt(13^2-7^2)')+".","To the nearest tenth: "+ret('round(sqrt(13^2-7^2),1)',1)+" (that is $11.0$).",
      "Check how far the top slid down: "+ret('12-sqrt(13^2-7^2)')+" feet (the ladder started $12$ feet up)."],round(ev('sqrt(13^2-7^2)'),1)
@step('GT-180')
def _():
    return ["Hypotenuse: "+ret('sqrt(8^2+15^2)')+".","Area two ways: $QS=\\dfrac{8\\cdot15}{17}$: "+ret('8*15/17')+".",
      ret('120/17')+", the same fraction, $\\dfrac{120}{17}$."],ev('8*15/17')
@step('GT-181')
def _():
    return [ret('cos(5pi/3)')+" (Desmos is in radian mode, which is what we want here).",ret('1/2')+", the same, so option (@@L@@).",
      "The options with $\\dfrac{\\sqrt3}{2}$ are "+ret('sqrt(3)/2')[5:]+", which is $\\cos\\dfrac\\pi6$, so they are wrong."],ev('cos(5pi/3)')
@step('GT-182')
def _():
    return ["Height is opposite the $38^\\circ$ angle and the string is the hypotenuse: $h=80\\sin38^\\circ$.",ret('80sin(38 deg)')+".",
      "To the nearest meter: $49$.","Check the tangent mistake: "+ret('80tan(38 deg)')+" is too large."],round(ev('80sin(38 deg)'))
@step('GT-183')
def _():
    t,tap,x,y=inter('6x^2','24',0.01,20)
    return ["Sides $3k,4k,5k$ give area $6k^2$. "+t+" ($x$ stands for $k$).","Tap the intersection: "+tap+", so $k=2$.",
      "Hypotenuse $5k$: "+ret('5*2')+"."],ev('5*2')
@step('GT-184')
def _():
    return ["Adjacent leg: "+ret('50*7/25')+".","Other leg: "+ret('sqrt(50^2-14^2)')+".","Area: "+ret('1/2*14*48')+"."],ev('1/2*14*48')
@step('GT-185')
def _():
    t,tap,x,y=inter('x^2+(x+5)^2','625',0.1,50)
    return ["Pythagorean theorem: $x^2+(x+5)^2=25^2$. "+t+".",
      "Tap the intersection with a positive $x$: "+tap+", so $x=%s$ (the other intersection has $x=-20$)."%n(x,0),
      "Legs $15$ and $20$: area "+ret('1/2*15*20')+"."],ev('1/2*15*20')
@step('GT-186')
def _():
    t,tap,x,y=inter('sqrt((12x)^2+(35x)^2)','74',0.1,50)
    return ["Sides $12k$ and $35k$ ($x$ stands for $k$): the diagonal is $\\sqrt{(12k)^2+(35k)^2}$. "+t+".",
      "Tap the intersection: "+tap+", so $k=2$.","Area: "+ret('(12*2)(35*2)')+"."],ev('(12*2)(35*2)')
# ---------------- circles
@step('GT-004')
def _():
    pts=[(6,0),(0,-8),(0,0),(3,1)]
    a=imp('x^2+y^2-6x+8y','0',pts[:3]); b=imp('(x-3)^2+(y+4)^2','25',pts[:3])
    return ["Type the circle: %s. Tap its intercepts %s, %s and %s."%(a,pt(6,0),pt(0,-8),pt(0,0)),
      "Type the completed-square form %s: the same circle (it passes through the same three points)."%b,
      "Radius: "+ret('sqrt(25)')+". Option (@@L@@)."],ev('sqrt(25)')
@step('GT-005')
def _():
    k=20; pts=[(-2,8),(-2,2)]
    a=imp('x^2+y^2+4x-10y+20','0',pts)
    return ["Completing the square gives $(x+2)^2+(y-5)^2=29-k$. Set the radius squared to $9$: type "+c('y=29-x')+" and "+c('y=9')+" ($x$ stands for $k$).",
      "Tap the intersection: "+pt(20,9)+", so $k=20$.",
      "Check: type "+a+". Its top and bottom points "+pt(-2,8)+" and "+pt(-2,2)+" are $6$ apart, so the radius is "+ret('(8-2)/2')[5:]+"."],float(k)
@step('GT-006')
def _():
    return ["Arc length $s=r\\theta$ (radians): "+ret('45*5pi/6')+".",ret('75pi/2')+", the same, so option (@@L@@).",
      "The option $45\\pi$ is "+ret('45pi')[5:]+", which uses $\\theta=\\pi$."],ev('45*5pi/6')
@step('GT-015')
def _():
    pts=[(-1,2),(-9,2)]
    a=imp('x^2+y^2+10x-4y+13','0',pts)
    return ["Type the circle: "+a+". Tap its rightmost and leftmost points "+pt(-1,2)+" and "+pt(-9,2)+".",
      "Radius is half the width: "+ret('(-1-(-9))/2')+".","Option (@@L@@)."],ev('(-1-(-9))/2')
@step('GT-018')
def _():
    pts=[(10,-1),(-2,-1)]
    a=imp('x^2+y^2-8x+2y-19','0',pts)
    return ["Type the circle: "+a+". Tap its rightmost and leftmost points "+pt(10,-1)+" and "+pt(-2,-1)+".",
      "Diameter is the width: "+ret('10-(-2)')+".",
      "Check with the completed square $(x-4)^2+(y+1)^2=36$: "+ret('2sqrt(36)')+"."],ev('10-(-2)')
@step('GT-021')
def _():
    return ["The inscribed angle is half the central angle on the same arc: "+ret('100/2')+".",
      "Check the other direction: "+ret('2*50')+", the central angle.","So $\\angle ACB=50^\\circ$."],ev('100/2')
@step('GT-028')
def _():
    return ["Chord length $=2r\\sin\\dfrac{\\theta}2$: "+ret('2*10*sin(30 deg)')+".","Option (@@L@@) is $10$.",
      "Check an option: "+ret('10sqrt(3)')+" would need a $120^\\circ$ angle, since "+ret('2*10*sin(60 deg)')[5:]+"."],ev('2*10*sin(30 deg)')
@step('GT-029')
def _():
    return ["The tangent is perpendicular to the radius, so $PQ=\\sqrt{OQ^2-OP^2}$: "+ret('sqrt(15^2-9^2)')+".",
      "Option (@@L@@) is $12$.","The option $\\sqrt{306}$ is "+ret('sqrt(15^2+9^2)')[5:]+", which adds instead of subtracts."],ev('sqrt(15^2-9^2)')
@step('GT-038')
def _():
    return ["Fraction of the circle: "+ret('(10sqrt(3)/3*pi)/(2pi*20sqrt(3))')+".",
      "Central angle: "+ret('360*(10sqrt(3)/3*pi)/(2pi*20sqrt(3))')+" degrees.",
      "$CD=AD\\tan30^\\circ$: "+ret('20sqrt(3)*tan(30 deg)')+"."],ev('20sqrt(3)*tan(30 deg)')
@step('GT-039')
def _():
    return ["Central angle: "+ret('360-90-90-100')+" degrees.","Radius is $18$, arc length: "+ret('80/360*36pi')+".",
      ret('8pi')+", the same, so option (@@L@@)."],ev('80/360*36pi')
@step('GT-040')
def _():
    a=imp('(x+4)^2+(y-7)^2','100',[(4,13),(-10,-1)])
    return ["Type the circle with a slider: "+c('(x+4)^2+(y-b)^2=100')+" (accept the slider for $b$), and plot "+c('(4,13)')+" and "+c('(-10,-1)')+".",
      "Slide $b$ until both points sit on the circle: $b=7$ (the equation with $b=7$ is "+a+").",
      "Check: "+ret('(4+4)^2+(13-7)^2')+" and "+ret('(-10+4)^2+(-1-7)^2')[5:]+"."],7.0
@step('GT-052')
def _():
    return ["Multiply by $\\dfrac{180}{\\pi}$: "+ret('7pi/12*180/pi')+".","So the angle is $105^\\circ$.",
      "Check the reverse: "+ret('105*pi/180/pi*12')+" (that is $7$ twelfths of $\\pi$)."],ev('7pi/12*180/pi')
@step('GT-053')
def _():
    return ["Multiply by $\\dfrac{\\pi}{180}$ and divide by $\\pi$: "+ret('540*pi/180/pi')+".","So $540^\\circ=3\\pi$ and $a=3$.",
      "Check: "+ret('3pi*180/pi')+" degrees."],ev('540*pi/180/pi')
