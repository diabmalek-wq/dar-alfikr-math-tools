import json,re,math
from solve9 import solve_all
from mathutil import *
S=solve_all()
items=json.load(open('items9.json'))
ROUND={'GT-179':lambda v:round(v,1),'GT-182':lambda v:round(v),'GT-168':lambda v:v}
CHANGED={'GT-043','GT-173','GT-174','GT-175','GT-182','GT-185','GT-186','GT-018','GT-005'}   # bank answer intentionally differs from solution
EXPECT_NEW={'GT-173':27,'GT-174':120,'GT-175':6.72,'GT-182':49,'GT-185':150,'GT-186':1680,'GT-018':12,'GT-005':20}
def scalar(i):
    v=S[i]
    if isinstance(v,Fraction): return float(v)
    if isinstance(v,list):
        assert len(set(round(float(x),6) for x in v))==1 or i in ('GT-151',),(i,v)
        return float(v[0]) if i!='GT-151' else float(sum(v))
    return float(v)
KEY={}
bad=0
for o in items:
    i=o['id']; v=scalar(i)
    if i=='GT-043': assert [round(x,6) for x in S[i]]==[25.0] and any(abs(x-105)<1e-6 for x in S['GT-043_nodomain']); 
    if i=='GT-151': assert [round(x,6) for x in S[i]]==[16.0,31.0]
    if i in ROUND: v=ROUND[i](v)
    bank=o['bank_ans']
    if o['opts']:
        vals=[lx(x) for x in o['opts']]
        assert len(set(o['opts']))==4
        closeness=[abs(x-v) for x in vals]
        k=int(np.argmin(closeness))
        # exact options: require match to 1e-9; 'closest' decimal options: nearest within 0.06 and runner-up clearly farther
        srt=sorted(closeness)
        if i in ('GT-067','GT-068','GT-070','GT-071'): assert srt[0]<0.06 and srt[1]>1.0,(i,closeness)
        else: assert srt[0]<1e-9 and srt[1]>1e-3,(i,closeness,v)
        L=re.match(r'^\(?([A-D])',bank).group(1)
        ok=("ABCD"[k]==L)
        KEY[i]=dict(idx=k,val=vals[k])
        print(i,'MC mine=',"ABCD"[k],'bank=',L,'OK' if ok else '<<<< MISMATCH')
        bad+=not ok
    else:
        a=bank.split('(or')[0]
        bv=lx(a) if '\\' in a else float(a.replace('$','').strip())
        if i in EXPECT_NEW:
            ok=abs(v-EXPECT_NEW[i])<1e-6; tag='NEW'
        else:
            ok=abs(v-bv)<1e-6; tag='bank'
        KEY[i]=dict(val=v)
        print(i,'SPR mine=',round(v,6),tag,'bank=',bv,'OK' if ok else '<<<< MISMATCH')
        bad+=not ok
print('BAD',bad)
json.dump(KEY,open('key9.json','w'))
