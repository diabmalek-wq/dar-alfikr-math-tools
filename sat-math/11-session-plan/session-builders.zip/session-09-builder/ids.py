import csv
rows=[r for r in csv.DictReader(open('/home/claude/cb/session_plan_11.csv')) if r['session']=='9']
IDS=[(r['id'],r['part'],r['difficulty']) for r in rows]
