import figs9,sys,subprocess
from lib import PRE,EXTRA
ids=sorted(figs9.FIG)
body=[]
for i in ids:
    body.append(r"\begin{minipage}[t]{0.48\linewidth}\textbf{%s}\\ %s\end{minipage}\hfill"%(i,figs9.FIG[i]()))
tex=PRE.replace("@@CODE@@","g").replace("@@HEAD@@","g").replace("\\begin{document}",EXTRA+"\\begin{document}")+"\n".join(body)+"\\end{document}"
open('gal.tex','w').write(tex)
r=subprocess.run(['xelatex','-interaction=nonstopmode','gal.tex'],capture_output=True,text=True)
import re
print(re.findall(r'^!.*',open('gal.log').read(),re.M)[:10])
