"""Independent solutions (numpy/scipy/brute force) from the FINAL stem of each item.
Computed first; compared to the bank's answer only afterwards (compare() at the bottom)."""
import math,json,re,itertools
import numpy as np
from scipy.optimize import brentq,fsolve
from mathutil import *
SOL={}; PAR={}
def solve_all():
    S=SOL
    # 043 sin(2x)=cos(x+15), 0<x<45
    f=lambda x:sind(2*x)-cosd(x+15); r=roots_in(f,0.0001,44.9999); S['GT-043']=r
    S['GT-043_nodomain']=[x for x in roots_in(f,0.0001,359.9999)]
    # 044
    C,A,B=(0,0),(16,0),(0,30); S['GT-044']=Fraction(B[1]-C[1],A[0]-C[0])
    # 045: B=(0,t) with cos(angle A)=3/5
    A=(36,0); t=brentq(lambda t:math.cos(math.radians(ang(A,(0,0),(0,t))))-0.6,1,500); S['GT-045']=dist(A,(0,t))
    # 046: C right, angle B=30, BC=18
    Bp=(18,0); y=brentq(lambda y:ang(Bp,(0,0),(0,y))-30,0.1,100); S['GT-046']=y
    # 047: legs L, 2L+L*sqrt2 = 40+20 sqrt2
    L=brentq(lambda L:2*L+L*math.sqrt(2)-(40+20*math.sqrt(2)),1,100); S['GT-047']=dist((0,0),(L,L))*0+math.hypot(L,L)
    # 066
    C,A,B=(0,0),(9,0),(0,12); S['GT-066']=Fraction(dist(B,C)).limit_denominator(100)/Fraction(dist(A,B)).limit_denominator(100)
    # 067
    F,D=(0,0),(18,0); E_=(0,brentq(lambda y:ang(D,F,(0,y))-35,0.1,100)); S['GT-067']=dist(E_,F)
    # 068
    X,Y,Z=(0,0),(80,0),(95*cosd(62),95*sind(62)); S['GT-068']=dist(Y,Z)
    # 069
    C,B=(0,0),(0,5); a=brentq(lambda a:dist((a,0),B)-13,1,50); S['GT-069']=math.cos(math.radians(ang((a,0),C,B)))
    # 070
    S['GT-070']=40*math.tan(math.radians(58))
    # 071: D=(0,0), E=(22,0); F = intersection of ray from D at 40 deg and ray from E at 180-65
    Dp,Ep=np.array([0,0.]),np.array([22,0.]); u=np.array([cosd(40),sind(40)]); w=np.array([-cosd(65),sind(65)])
    ts=np.linalg.solve(np.array([u,-w]).T,Ep-Dp); Fp=Dp+ts[0]*u
    assert abs(ang(Dp,Ep,Fp)-40)<1e-9 and abs(ang(Ep,Dp,Fp)-65)<1e-9
    S['GT-071']=dist(Ep,Fp)
    # 072: sin P = 7/25, right angle at R
    R=(0,0); p=brentq(lambda p:7/math.hypot(p,7)-7/25,1,100); P_=(p,0); Q_=(0,7)
    S['GT-072']=math.cos(math.radians(ang(Q_,R,P_)))
    # 087
    lay=(3,4); noor=(-5,-2); S['GT-087']=dist(lay,noor)/5
    # 088
    Qp=(0,0);Rp=(10,0);Pp=(8*cosd(60),8*sind(60)); S['GT-088']=area(Pp,Qp,Rp)
    # 097
    S['GT-097']=dist((-3,-9),(9,-4))
    # 100
    xs=roots_in(lambda x:(x+1)**2+(x+8)**2-(x+9)**2,0.001,100); assert len(xs)==1; S['GT-100']=0.5*(xs[0]+1)*(xs[0]+8)
    # 101: 30-60-90, short leg s: sides s, s*tan60, hyp
    s=brentq(lambda s:s+s*math.tan(math.radians(60))+math.hypot(s,s*math.tan(math.radians(60)))-(18+6*math.sqrt(3)),0.1,100); S['GT-101']=math.hypot(s,s*math.tan(math.radians(60)))
    # 102
    A=(5,0);B=(0,0); y=brentq(lambda y:ang(A,B,(0,y))-2*ang((0,y),B,A),0.1,100); S['GT-102']=y
    # 107
    h=brentq(lambda h:np.dot(np.array([0,0])-np.array([3,h]),np.array([15,0])-np.array([3,h])),0.1,50); S['GT-107']=h
    # 112
    Q=(0,0);P=(0,18); r=brentq(lambda r:dist(P,(r,0))-30,1,100); Rr=(r,0); Sf=foot(Q,P,Rr); S['GT-112']=dist(Q,Rr)/dist(Q,Sf)
    # 118: A=(0,0),B=(c,0),D=(d,0),C=(d,h)
    def F118(v):
        c,d,h=v; return [0.5*d*h-48,0.5*(c-d)*h-108,-d*(c-d)+h*h]
    sol=fsolve(F118,[26,8,12]); assert max(abs(np.array(F118(sol))))<1e-9; S['GT-118']=sol[0]
    # 121: P=(0,0), R=(r,0), S=(16,0), Q=(16,h)
    def F121(v):
        r,h=v; return [-16*(r-16)+h*h,h/(r-16)-4/3]
    sol=fsolve(F121,[25,12]); assert max(abs(np.array(F121(sol))))<1e-9; S['GT-121']=sol[0]-16
    # 125: legs a,b: a^2+b^2=400, ab/2=96 ; square at the right-angle corner
    def F125(v): a,b=v; return [a*a+b*b-400,a*b/2-96]
    a,b=fsolve(F125,[16,12]); assert max(abs(np.array(F125([a,b]))))<1e-9
    # square corner (s,s) lies on line x/a+y/b=1  -> cross-product test
    g=lambda s:((0-a)*(s-0)-(b-0)*(s-a))*(-1)   # orientation of (s,s) w.r.t. segment (a,0)->(0,b)
    s=brentq(g,0.01,min(a,b)); S['GT-125']=s
    # 128: sinP+cosP = sqrt6/2, 0<P<90
    ps=roots_in(lambda P:sind(P)+cosd(P)-math.sqrt(6)/2,0.001,89.999); S['GT-128']=[tand(P)+tand(90-P) for P in ps]
    # 133: A=(0,0),B=(10,0),D=(p,0),C=(p,4)
    ps=roots_in(lambda p:np.dot(np.array([0,0])-np.array([p,4]),np.array([10,0])-np.array([p,4])),0.001,9.999); pp=[p for p in ps if p>5]; assert len(pp)==1
    p=pp[0]; S['GT-133']=math.cos(math.radians(ang((0,0),(10,0),(p,4))))
    # 136: C=(0,0), A=(a,0), B=(0,a tan30); inradius = area/semiperimeter =5
    def inr(a):
        b=a*tand(30);c=math.hypot(a,b); return (a*b/2)/((a+b+c)/2)-5
    a=brentq(inr,1,200); S['GT-136']=a
    # 143
    def F143(v): a,b=v; return [b/a-5/12,0.5*a*b-120]
    a,b=fsolve(F143,[24,10]); Cc=(0,0);Aa=(a,0);Bb=(0,b); Dd=foot(Cc,Aa,Bb); S['GT-143']=dist(Aa,Dd)
    # 151
    f=lambda x:sind(5*x-20)-cosd(x+14); r=roots_in(f,0.0001,44.9999); S['GT-151']=r
    # 154: A=(0,0),B=(L,0),D=(t,0),C=(t,6); DB = AD+5
    def F154(v): L,t=v; return [-t*(L-t)+36,(L-t)-(t+5)]
    L,t=fsolve(F154,[13,4]); assert max(abs(np.array(F154([L,t]))))<1e-9
    S['GT-154']=math.sin(math.radians(ang((L,0),(0,0),(t,6))))
    # 168: count integer a in 1..20 giving exactly one triangle (P=30, PR=14, QR=a)
    def ntri(a):
        # place P at origin, R=(14,0); Q on ray from P at angle 30 deg; |QR|=a. Solve |Q-R|=a for Q=t(cos30,sin30), t>0
        u=np.array([cosd(30),sind(30)]); Rr=np.array([14,0.])
        # t^2 -2 t u.R + |R|^2 - a^2 = 0
        bq=-2*np.dot(u,Rr); cq=196-a*a; disc=bq*bq-4*cq
        if disc<-1e-12: return 0
        if abs(disc)<1e-9: return 1 if -bq/2>1e-9 else 0
        ts=[(-bq-math.sqrt(disc))/2,(-bq+math.sqrt(disc))/2]; return sum(1 for t in ts if t>1e-9)
    S['GT-168']=sum(1 for a in range(1,21) if ntri(a)==1)
    # 173
    f=lambda x:sind(x)-cosd(2*x+9); S['GT-173']=roots_in(f,0.0001,29.9999)
    # 174: tan A = 8/15, AB=51
    def F174(k): return math.hypot(8*k,15*k)-51
    k=brentq(F174,0.1,10); S['GT-174']=8*k+15*k+51
    # 175: Q=(0,0), P=(7,0), R=(0,24)
    Sf=foot((0,0),(7,0),(0,24)); S['GT-175']=dist((0,0),Sf)
    # 176
    L=brentq(lambda L:math.hypot(L,L)-14,1,50); S['GT-176']=2*L+14
    # 177: equilateral side s, height = 6 sqrt3
    s=brentq(lambda s:dist((s/2,s*math.sqrt(3)/2),(s/2,0))-6*math.sqrt(3),1,100); S['GT-177']=3*s
    # 178
    th=math.asin(0.6); S['GT-178']=math.cos(math.pi/2-th)+math.tan(th)
    # 179
    S['GT-179']=math.sqrt(13**2-7**2)
    # 180
    Sf=foot((0,0),(8,0),(0,15)); S['GT-180']=dist((0,0),Sf)
    # 181
    S['GT-181']=math.cos(5*math.pi/3)
    # 182
    S['GT-182']=80*math.sin(math.radians(38))
    # 183: acute angle with sine 3/5; hypotenuse H: legs
    H=brentq(lambda H:0.5*(H*0.6)*(H*math.sqrt(1-0.36))-24,1,100); S['GT-183']=H
    # 184
    H=50;a=H*7/25;b=math.sqrt(H*H-a*a); S['GT-184']=a*b/2
    # 185
    x=roots_in(lambda x:x*x+(x+5)**2-625,0.001,100); assert len(x)==1; S['GT-185']=0.5*x[0]*(x[0]+5)
    # 186
    k=brentq(lambda k:math.hypot(12*k,35*k)-74,0.1,50); S['GT-186']=12*k*35*k
    # circles: extents of x^2+y^2+Dx+Ey+F=0 via discriminant in y
    def xext(D,E,F):
        # E^2-4(x^2+Dx+F)>=0
        g=lambda x:E*E-4*(x*x+D*x+F); lo=-D/2; r=[roots_in(g,lo-200,lo,400001),roots_in(g,lo,lo+200,400001)]; return r[0][0],r[1][0]
    x1,x2=xext(-6,8,0); S['GT-004']=(x2-x1)/2
    # 005: radius 3, find k with width 6
    k=brentq(lambda k:(lambda e:e[1]-e[0])(xext(4,-10,k))-6,-100,28.99); S['GT-005']=k
    x1,x2=xext(10,-4,13); S['GT-015']=(x2-x1)/2
    x1,x2=xext(-8,2,-19); S['GT-018']=(x2-x1)
    # 006
    S['GT-006']=45*5*math.pi/6
    # 021: O=(0,0), A at 40deg, B at 140 (100 deg central), C at 270
    Op=(0,0); Ap=(cosd(40),sind(40)); Bp=(cosd(140),sind(140)); Cp=(0,-1); assert abs(ang(Op,Ap,Bp)-100)<1e-9; S['GT-021']=ang(Cp,Ap,Bp)
    # 028
    S['GT-028']=dist((10*cosd(0),10*sind(0)),(10*cosd(60),10*sind(60)))
    # 029
    xq=brentq(lambda x:dist((0,0),(x,-9))-15,0,100); S['GT-029']=dist((0,-9),(xq,-9))
    # 038: r=20 sqrt3, minor arc BD length = (10 sqrt3 /3) pi
    r=20*math.sqrt(3); phi=(10*math.sqrt(3)/3*math.pi)/r; Dp=(r*math.cos(phi),r*math.sin(phi)); Cp=(r/math.cos(phi),0); assert abs(np.dot(np.array(Dp),np.array(Cp)-np.array(Dp)))<1e-9; S['GT-038']=dist(Cp,Dp)
    # 039: r from circumference, angle APB=100
    r=36*math.pi/(2*math.pi); d=brentq(lambda d:math.degrees(2*math.asin(r/d))-100,r*1.0001,100); al=math.acos(r/d); Aa=(r*math.cos(al),r*math.sin(al)); Bb=(r*math.cos(al),-r*math.sin(al)); cen=ang((0,0),Aa,Bb); S['GT-039']=cen/360*2*math.pi*r
    # 040
    bs=roots_in(lambda b:(4+4)**2+(13-b)**2-100,-100,100); cs=roots_in(lambda b:(-10+4)**2+(-1-b)**2-100,-100,100)
    S['GT-040']=[b for b in bs if any(abs(b-c)<1e-6 for c in cs)]
    # 052, 053
    S['GT-052']=math.degrees(7*math.pi/12); S['GT-053']=math.radians(540)/math.pi
    return S
if __name__=='__main__':
    S=solve_all()
    for k,v in S.items(): print(k,v)
