"""Desmos-syntax-aware evaluator: a^2, implicit multiplication, sqrt, pi, abs, ln, sin(x deg), arcsin/arccos/arctan (radians),
nCr, lists [a,b...c], L.length, mean(L), median(L), stdev(L), total(L)."""
import math,re,statistics
def lst(s):
    s=s.strip()[1:-1]; out=[]
    for part in re.split(r',(?![^\[]*\])',s):
        part=part.strip()
        m=re.match(r'^(-?[\d.]+)\s*\.\.\.\s*(-?[\d.]+)$',part)
        if m:
            a,b=float(m.group(1)),float(m.group(2)); k=int(round(b-a)); out+= [a+i for i in range(k+1)]
        elif re.match(r'^(-?[\d.]+),\s*(-?[\d.]+)\s*\.\.\.\s*(-?[\d.]+)$',part): raise ValueError
        else: out.append(float(part))
    return out
def ev(expr,**kw):
    e=expr.strip()
    e=re.sub(r'\bdeg\b','*(pi/180)',e)
    e=re.sub(r'(\w+)\.length',r'len(\1)',e)
    e=e.replace('^','**')
    e=re.sub(r'(?<![A-Za-z_])([xyktsabL])\(',r'\1*(',e)
    for _ in range(2):
        e=re.sub(r'(\d|\))\s*(\(|[a-zA-Z_])',lambda m:m.group(1)+'*'+m.group(2),e)
    e=re.sub(r'(\bx|\bk|\bt)\s*(sqrt|sin|cos|tan|arcsin|arccos|arctan|pi)',r'\1*\2',e)
    env=dict(sqrt=math.sqrt,abs=abs,ln=math.log,pi=math.pi,sin=math.sin,cos=math.cos,tan=math.tan,arcsin=math.asin,arccos=math.acos,arctan=math.atan,
             nCr=lambda n,r:math.comb(int(n),int(r)),mean=statistics.mean,median=statistics.median,stdev=statistics.stdev,total=sum,len=len,round=round)
    env.update(kw)
    return eval(e,{'__builtins__':{}},env)
def solve_x(f,lo,hi,n=20001):
    from scipy.optimize import brentq
    import numpy as np
    xs=np.linspace(lo,hi,n); ys=[f(x) for x in xs]; r=[]
    for i in range(n-1):
        if ys[i]==0: r.append(xs[i])
        elif ys[i]*ys[i+1]<0: r.append(brentq(f,xs[i],xs[i+1],xtol=1e-13))
    return r
