"""Builds items9.json from items_raw.json (bank) + explicit edits. Edits are listed in EDITS (report)."""
import json,re
raw=json.load(open('items_raw.json'))
R={o['id']:o for o in raw}
EDITS={}   # id -> (kind, note)
def rep(i,a,b,kind,note):
    o=R[i]; assert a in o['q'],(i,a)
    o['q']=o['q'].replace(a,b); EDITS[i]=(kind,note)
# ---- FIXES (bank item flawed) ----
rep('GT-043','what is the value of $x$?','and $0<x<45$, what is the value of $x$?','FIX','no domain given: x=105 (and 145, ...) also satisfy the equation, so answer 25 was not unique; added 0<x<45')
R['GT-043']['q']=R['GT-043']['q'].replace('$\\sin(2x)^{\\circ} = \\cos(x + 15)^{\\circ}$, and','$\\sin(2x)^{\\circ} = \\cos(x + 15)^{\\circ}$ and')
# ---- DUPLICATE / CONTEXT / NUMBER changes ----
rep('GT-087',"Layla walked from Noor's house","Maya walked from Noah's house",'CONTEXT','Arabic names -> neutral')
R['GT-087']['q']=(R['GT-087']['q'].replace("while Noor walked","while Noah walked").replace("If Noor were to walk directly to Layla's location","If Noah were to walk directly to Maya's location").replace("take her, if Noor walks","take him, if Noah walks"))
assert 'Noor' not in R['GT-087']['q'] and 'Layla' not in R['GT-087']['q']
rep('GT-006',"As part of a Vision 2030 public-space project in Riyadh, a circular plaza","A circular plaza",'CONTEXT','Saudi context removed (Vision 2030 / Riyadh)')
# 173: same cofunction answer (25) as 043 -> new numbers
rep('GT-173','\\cos\\left((3x-10)^\\circ\\right)','\\cos\\left((2x+9)^\\circ\\right)','DUP','near-duplicate of GT-043 (same trick, same answer 25): now sin(x)=cos(2x+9), x=27')
# 174: tan A = 5/12 also in GT-143
rep('GT-174','\\dfrac{5}{12}$, and $AB=39$','\\dfrac{8}{15}$, and $AB=51$','DUP','tan A=5/12 repeated GT-143 (and 5-12-13 family): now tan A=8/15, AB=51')
# 175: legs 9,12 repeated GT-066
rep('GT-175','$PQ=9$ and $QR=12$','$PQ=7$ and $QR=24$','DUP','legs 9,12 repeated GT-066 and same altitude trick as GT-180: now legs 7,24')
# 182: near-identical to GT-070 (tower, 40 m, tan)
R['GT-182']['q']="A kite is flying at the end of a straight string that is $80$ meters long. The string makes an angle of $38^\\circ$ with level ground. To the nearest meter, how high above the ground is the kite?"
EDITS['GT-182']=('DUP','near-duplicate of GT-070 (tower, 40 m, tan): now kite on 80 m string at 38 degrees (sine)')
# 185: same trick and same answer (30) as GT-100
R['GT-185']['q']="The legs of a right triangle have lengths $x$ and $x+5$, and the hypotenuse is $25$. What is the area of the triangle?"
EDITS['GT-185']=('DUP','same trick and same answer (area 30, 5-12-13) as GT-100: now legs x, x+5, hypotenuse 25, area 150')
# 186
R['GT-186']['q']="The diagonal of a rectangle is $74$ and the ratio of its two side lengths is $12:35$. What is the area of the rectangle?"
EDITS['GT-186']=('DUP','5:12 / 13 family repeated (GT-100, 174, 185, 143): now 12:35, diagonal 74')
# circles
rep('GT-018','- 8x + 2y - 8 = 0','- 8x + 2y - 19 = 0','DUP','radius 5 repeated GT-004: now r=6, diameter 12')
rep('GT-005','is a circle with radius $4$','is a circle with radius $3$','DUP','radius 4 repeated GT-015: now radius 3, k=20')
for o in raw:
    q=o['q']
    q=re.sub(r'\$\$(.+?)\$\$',lambda m:'$$'+m.group(1)+'$$',q)
    o['q']=q
# SPR 173 stem layout: equation first then sentence (display)
json.dump(raw,open('items9.json','w'),indent=1)
for k,v in EDITS.items(): print(k,v)
for o in raw:
    if o['id'] in EDITS: print('\n',o['id'],o['q'])
