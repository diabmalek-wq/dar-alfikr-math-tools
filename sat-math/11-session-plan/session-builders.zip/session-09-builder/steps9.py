"""Worked steps for Session 9. Every derived number is computed here (math/numpy), formatted by tex()/dec()."""
import math
from mathutil import *
from solve9 import solve_all
SOL=solve_all()
def c(e): return '[[%s]]'%e
def m(x): return '$%s$'%x
def T(v): return tex(v)
def D(v,d=1): return '$%s$'%dec(v,d)
hyp=math.hypot
STEPS={}; CHK=[]   # CHK: (id, quoted-string, value) registry for verify
def reg(i,s,v): CHK.append((i,s,v)); return s
S=STEPS
# ---- 043
x=SOL['GT-043'][0]
S['GT-043']=["Sine of one angle equals cosine of its complement, so the two angles must add to $90^\\circ$. Write $(2x)+(x+15)=90$.",
 "Combine like terms: $3x+15=90$, so $3x=%d$."%round(90-15),
 "Divide by $3$: $x=%d$."%round(x),
 "Check: $\\sin %d^\\circ=\\cos %d^\\circ$ since $%d+%d=90$. The domain $0<x<45$ rules out the other branches (such as $x=105$)."%(round(2*x),round(x+15),round(2*x),round(x+15))]
# ---- 044
S['GT-044']=["$\\tan A=\\dfrac{\\text{opposite}}{\\text{adjacent}}$. Opposite angle $A$ is $BC=30$; adjacent is $AC=16$.",
 "So $\\tan A=\\dfrac{30}{16}=%s$ after dividing top and bottom by $2$."%T(SOL['GT-044']),
 "That is option (@@L@@). The option with $\\dfrac{8}{15}$ flips the fraction, and the ones with $34$ use the hypotenuse $\\sqrt{16^2+30^2}=%d$."%round(hyp(16,30))]
# ---- 045
S['GT-045']=["$\\cos A=\\dfrac{\\text{adjacent}}{\\text{hypotenuse}}=\\dfrac{AC}{AB}$, so $\\dfrac{36}{AB}=\\dfrac35$.",
 "Cross-multiply: $3\\cdot AB=5\\cdot 36=%d$."%(5*36),
 "Divide by $3$: $AB=%d$. (Check: $36$-$%d$-$%d$ is the $3$-$4$-$5$ triangle times $12$.)"%(round(SOL['GT-045']),round(48),round(60))]
# ---- 046
ac=SOL['GT-046']
S['GT-046']=["$AC$ is opposite the $30^\\circ$ angle and $BC=18$ is adjacent to it, so use $\\tan 30^\\circ=\\dfrac{AC}{18}$.",
 "$\\tan 30^\\circ=\\dfrac{1}{\\sqrt3}$, so $AC=\\dfrac{18}{\\sqrt3}$.",
 "Rationalize: $\\dfrac{18}{\\sqrt3}\\cdot\\dfrac{\\sqrt3}{\\sqrt3}=\\dfrac{18\\sqrt3}{3}=%s$ (about $%s$). Option (@@L@@)."%(tex(ac),dec(ac,2))]
# ---- 047
L=SOL['GT-047']/math.sqrt(2)
S['GT-047']=["Let each leg be $L$. The hypotenuse is $L\\sqrt2$, so the perimeter is $2L+L\\sqrt2=L(2+\\sqrt2)$.",
 "The given perimeter factors the same way: $40+20\\sqrt2=20(2+\\sqrt2)$.",
 "So $L=%d$ and the hypotenuse is $L\\sqrt2=%s$."%(round(L),tex(SOL['GT-047']))]
# ---- 066
S['GT-066']=["Find the hypotenuse: $AB=\\sqrt{9^2+12^2}=\\sqrt{%d}=%d$."%(81+144,round(hyp(9,12))),
 "$\\sin A=\\dfrac{\\text{opposite}}{\\text{hypotenuse}}$, and the side opposite $A$ is $BC=12$.",
 "$\\sin A=\\dfrac{12}{%d}=%s$. Option (@@L@@). The option $\\dfrac35$ is $\\cos A$ (adjacent over hypotenuse)."%(round(hyp(9,12)),T(SOL['GT-066']))]
# ---- 067
v=SOL['GT-067']; t35=tand(35)
S['GT-067']=["The two legs are involved (opposite $EF$, adjacent $DF=18$), so use tangent: $\\tan 35^\\circ=\\dfrac{EF}{18}$.",
 "Make sure the calculator is in degree mode: $\\tan 35^\\circ\\approx %s$."%dec(t35,4),
 "$EF=18\\tan 35^\\circ\\approx 18(%s)\\approx %s$. Option (@@L@@)."%(dec(t35,4),dec(v,1))]
# ---- 068
v=SOL['GT-068']; cs=cosd(62)
S['GT-068']=["Two sides and the angle between them: use the Law of Cosines, $c^2=80^2+95^2-2(80)(95)\\cos 62^\\circ$.",
 "In degree mode $\\cos 62^\\circ\\approx %s$, so $c^2\\approx %d+%d-%d(%s)\\approx %s$."%(dec(cs,4),80**2,95**2,2*80*95,dec(cs,4),dec(v*v,0)),
 "$c\\approx\\sqrt{%s}\\approx %s$. Option (@@L@@)."%(dec(v*v,0),dec(v,1))]
# ---- 069
S['GT-069']=["Find the missing leg: $AC=\\sqrt{13^2-5^2}=\\sqrt{%d}=%d$."%(169-25,round(math.sqrt(144))),
 "$\\cos A=\\dfrac{\\text{adjacent}}{\\text{hypotenuse}}=\\dfrac{AC}{AB}$.",
 "$\\cos A=\\dfrac{%d}{13}$. Option (@@L@@). The option $\\dfrac{5}{13}$ is $\\sin A$."%round(math.sqrt(144))]
# ---- 070
v=SOL['GT-070']
S['GT-070']=["The tower, the ground and the line of sight make a right triangle. The $40$ meters is adjacent to the $58^\\circ$ angle and the height is opposite, so use $\\tan 58^\\circ=\\dfrac{h}{40}$.",
 "In degree mode $\\tan 58^\\circ\\approx %s$."%dec(tand(58),4),
 "$h=40\\tan 58^\\circ\\approx 40(%s)\\approx %s$ meters. Option (@@L@@)."%(dec(tand(58),4),dec(v,1))]
# ---- 071
v=SOL['GT-071']
S['GT-071']=["The angles add to $180^\\circ$, so $F=180^\\circ-40^\\circ-65^\\circ=%d^\\circ$."%(180-40-65),
 "Law of Sines: $\\dfrac{EF}{\\sin 40^\\circ}=\\dfrac{DE}{\\sin F}=\\dfrac{22}{\\sin 75^\\circ}$ (side $EF$ faces the $40^\\circ$ angle, side $DE$ faces $F$).",
 "$EF=22\\cdot\\dfrac{\\sin 40^\\circ}{\\sin 75^\\circ}\\approx 22\\cdot\\dfrac{%s}{%s}\\approx %s$. Option (@@L@@)."%(dec(sind(40),4),dec(sind(75),4),dec(v,1))]
# ---- 072
S['GT-072']=["Angle $R$ is the right angle, so $P+Q=90^\\circ$: the two acute angles are complementary.",
 "For complementary angles, the sine of one equals the cosine of the other: $\\cos Q=\\sin P$.",
 "So $\\cos Q=%s$. Option (@@L@@). (Check with sides: $QR=7$, $PQ=25$, $\\cos Q=\\dfrac{QR}{PQ}=\\dfrac{7}{25}$.)"%T(SOL['GT-072'])]
# ---- 087
S['GT-087']=["Put Noah's house at the origin. Maya ends at $(3,4)$ and Noah ends at $(-5,-2)$.",
 "Distance: $\\sqrt{(3-(-5))^2+(4-(-2))^2}=\\sqrt{8^2+6^2}=\\sqrt{%d}=%d$ miles."%(64+36,round(SOL['GT-087']*5)),
 "Time $=\\dfrac{\\text{distance}}{\\text{rate}}=\\dfrac{%d}{5}=%d$ hours."%(round(SOL['GT-087']*5),round(SOL['GT-087']))]
# ---- 088
S['GT-088']=["Area of a triangle from two sides and the angle between them: $\\dfrac12\\cdot PQ\\cdot QR\\cdot\\sin Q$.",
 "$\\dfrac12(8)(10)\\sin 60^\\circ=%d\\cdot\\dfrac{\\sqrt3}{2}$."%(40),
 "$=%s$. Option (@@L@@)."%tex(SOL['GT-088'])]
# ---- 097
S['GT-097']=["Subtract coordinates: $\\Delta x=9-(-3)=12$ and $\\Delta y=-4-(-9)=5$.",
 "Distance $=\\sqrt{12^2+5^2}=\\sqrt{%d}=%d$."%(144+25,round(SOL['GT-097']))]
# ---- 100
S['GT-100']=["Pythagorean theorem: $(x+1)^2+(x+8)^2=(x+9)^2$.",
 "Expand: $2x^2+18x+65=x^2+18x+81$, so $x^2=16$ and $x=4$ (lengths are positive).",
 "The legs are $x+1=5$ and $x+8=12$ (the hypotenuse is $13$).",
 "Area $=\\dfrac12(5)(12)=%d$."%round(SOL['GT-100'])]
# ---- 101
s=SOL['GT-101']/2
S['GT-101']=["In a $30^\\circ$-$60^\\circ$-$90^\\circ$ triangle the sides are $s$, $s\\sqrt3$ and $2s$.",
 "Perimeter: $s+s\\sqrt3+2s=3s+s\\sqrt3=s(3+\\sqrt3)$. Since $18+6\\sqrt3=6(3+\\sqrt3)$, we get $s=%d$."%round(s),
 "Hypotenuse $=2s=%d$. Option (@@L@@)."%round(SOL['GT-101'])]
# ---- 102
S['GT-102']=["The acute angles add to $90^\\circ$ and $A=2C$, so $3C=90^\\circ$, giving $C=30^\\circ$ and $A=60^\\circ$.",
 "$AB=5$ is opposite the $30^\\circ$ angle, so it is the short leg. $BC$ is opposite the $60^\\circ$ angle.",
 "Short leg times $\\sqrt3$: $BC=5\\sqrt3\\approx %s$. Option (@@L@@)."%dec(SOL['GT-102'],2)]
# ---- 107
S['GT-107']=["The altitude to the hypotenuse is the geometric mean of the two pieces: $BD^2=AD\\cdot DC$.",
 "$BD^2=3\\cdot12=%d$."%(36),
 "$BD=%d$. Option (@@L@@). (Check: $AB^2=3^2+6^2=%d$, $BC^2=12^2+6^2=%d$, and $%d+%d=%d=15^2$.)"%(round(SOL['GT-107']),45,180,45,180,225)]
# ---- 112
r=24; h=SOL['GT-112']
q=18*24/30
S['GT-112']=["First $QR=\\sqrt{30^2-18^2}=\\sqrt{%d}=%d$."%(900-324,r),
 "Area two ways: $\\dfrac12(PQ)(QR)=\\dfrac12(PR)(QS)$, so $18\\cdot24=30\\cdot QS$ and $QS=%s$."%dec(q,1),
 "$\\dfrac{QR}{QS}=\\dfrac{24}{%s}=%s$ (or about $%s$)."%(dec(q,1),T(SOL['GT-112']),dec(SOL['GT-112'],3))]
# ---- 118
S['GT-118']=["Triangles $ACD$ and $CDB$ share the height $CD$, so their areas are in the ratio of their bases: $\\dfrac{AD}{DB}=\\dfrac{48}{108}=\\dfrac{4}{9}$.",
 "Let $AD=4k$ and $DB=9k$. The altitude to the hypotenuse gives $CD^2=AD\\cdot DB=36k^2$, so $CD=6k$.",
 "Area of $ACD$: $\\dfrac12(4k)(6k)=12k^2=48$, so $k^2=4$ and $k=2$.",
 "$AB=AD+DB=13k=%d$. (Check: $[CDB]=\\dfrac12(18)(12)=108$.)"%round(SOL['GT-118'])]
# ---- 121
S['GT-121']=["$\\tan\\angle QRP=\\dfrac{PQ}{QR}=\\dfrac43$, so the legs are $PQ=4k$, $QR=3k$ and the hypotenuse is $PR=5k$.",
 "Leg rule: $PQ^2=PS\\cdot PR$, so $16k^2=16\\cdot5k$, giving $k=5$ and $PR=%d$."%25,
 "$SR=PR-PS=25-16=%d$. Option (@@L@@). (Check: $QR^2=SR\\cdot PR$ gives $15^2=9\\cdot25$.)"%round(SOL['GT-121'])]
# ---- 125
S['GT-125']=["Let the legs be $a$ and $b$. The area gives $ab=2\\cdot96=%d$ and Pythagoras gives $a^2+b^2=20^2=%d$."%(192,400),
 "$(a+b)^2=a^2+b^2+2ab=400+384=%d$, so $a+b=%d$."%(784,28),
 "The square's corner $E$ lies on the hypotenuse, so $s\\left(\\dfrac1a+\\dfrac1b\\right)=1$, which gives $s=\\dfrac{ab}{a+b}$.",
 "$s=\\dfrac{192}{28}=%s$. Option (@@L@@). (The legs are $12$ and $16$.)"%T(SOL['GT-125'])]
# ---- 128
S['GT-128']=["$Q=90^\\circ-P$, so $\\sin Q=\\cos P$ and $\\tan Q=\\dfrac{1}{\\tan P}$.",
 "Square the given sum: $\\sin^2P+2\\sin P\\cos P+\\cos^2P=\\dfrac64$, so $1+2\\sin P\\cos P=\\dfrac32$ and $\\sin P\\cos P=\\dfrac14$.",
 "$\\tan P+\\tan Q=\\dfrac{\\sin P}{\\cos P}+\\dfrac{\\cos P}{\\sin P}=\\dfrac{\\sin^2P+\\cos^2P}{\\sin P\\cos P}=\\dfrac{1}{1/4}=%d$."%round(SOL['GT-128'][0])]
# ---- 133
S['GT-133']=["Let $AD=p$ and $DB=q$. Then $p+q=10$ and $CD^2=pq=16$.",
 "$p(10-p)=16$ gives $p^2-10p+16=0$, so $(p-2)(p-8)=0$. Since $AD>DB$, $AD=8$ and $DB=2$.",
 "In triangle $ACD$: $AC=\\sqrt{8^2+4^2}=\\sqrt{%d}=4\\sqrt5$."%80,
 "$\\cos A=\\dfrac{AD}{AC}=\\dfrac{8}{4\\sqrt5}=%s$. Option (@@L@@)."%T(SOL['GT-133'])]
# ---- 136
S['GT-136']=["Let $BC=s$ (opposite $30^\\circ$). Then $AC=s\\sqrt3$ and $AB=2s$.",
 "For a right triangle, $r=\\dfrac{BC+AC-AB}{2}=\\dfrac{s+s\\sqrt3-2s}{2}=\\dfrac{s(\\sqrt3-1)}{2}=5$.",
 "$s=\\dfrac{10}{\\sqrt3-1}=\\dfrac{10(\\sqrt3+1)}{2}=5+5\\sqrt3$.",
 "$AC=s\\sqrt3=5\\sqrt3+15=%s$ (about $%s$). Option (@@L@@)."%(tex(SOL['GT-136']),dec(SOL['GT-136'],2))]
# ---- 143
S['GT-143']=["$\\tan A=\\dfrac{BC}{AC}=\\dfrac5{12}$, so $BC=5k$, $AC=12k$ and $AB=13k$.",
 "Area: $\\dfrac12(12k)(5k)=30k^2=120$, so $k=2$ and $AC=24$, $AB=26$.",
 "Leg rule: $AC^2=AD\\cdot AB$, so $AD=\\dfrac{24^2}{26}=\\dfrac{576}{26}=%s$. Option (@@L@@)."%T(SOL['GT-143'])]
# ---- 151
S['GT-151']=["Rewrite the cosine as a sine: $\\cos((x+14)^\\circ)=\\sin((76-x)^\\circ)$.",
 "Two angles with equal sines are either equal or supplementary (mod $360^\\circ$). Equal: $5x-20=76-x$, so $6x=96$ and $x=%d$."%round(SOL['GT-151'][0]),
 "Supplementary: $5x-20=180-(76-x)=104+x$, so $4x=124$ and $x=%d$."%round(SOL['GT-151'][1]),
 "Both are in $0<x<45$ and other multiples of $360^\\circ$ give nothing in range. Sum: $%d+%d=%d$."%(round(SOL['GT-151'][0]),round(SOL['GT-151'][1]),round(SOL['GT-151'][0]+SOL['GT-151'][1]))]
# ---- 154
S['GT-154']=["Let $AD=t$ and $DB=t+5$. The altitude rule gives $CD^2=AD\\cdot DB$: $36=t(t+5)$.",
 "$t^2+5t-36=0$ factors as $(t+9)(t-4)=0$, so $t=4$, $DB=9$ and $AB=13$.",
 "$BC^2=DB\\cdot AB=9\\cdot13=%d$, so in triangle $CDB$, $\\sin B=\\dfrac{CD}{BC}=\\dfrac{6}{3\\sqrt{13}}=%s$."%(117,T(SOL['GT-154'])),
 "Option (@@L@@). (Check: $AC^2=4\\cdot13=52$ and $\\dfrac{AC}{AB}=\\dfrac{2\\sqrt{13}}{13}$.)"]
# ---- 168
S['GT-168']=["This is the side-side-angle situation: $P=30^\\circ$, adjacent side $PR=14$, opposite side $QR=a$. The height from $R$ to line $PQ$ is $14\\sin30^\\circ=7$.",
 "$a<7$: $QR$ cannot reach, no triangle. $a=7$: it just touches, exactly one (right) triangle.",
 "$7<a<14$: two different triangles. $a=14$ or more: only one position for $Q$ works.",
 "One triangle for $a=7$ and $a=14,15,\\dots,20$: that is $1+7=%d$ values."%SOL['GT-168']]
# ---- 173
x=SOL['GT-173'][0]
S['GT-173']=["Sine of an angle equals cosine of its complement, so $x+(2x+9)=90$.",
 "$3x+9=90$, so $3x=81$.",
 "$x=%d$. Check: $2(%d)+9=%d$ and $%d+%d=90$, and $%d$ is between $0$ and $30$."%(round(x),round(x),round(2*x+9),round(x),round(2*x+9),round(x))]
# ---- 174
k=SOL['GT-174']
S['GT-174']=["$\\tan A=\\dfrac{BC}{AC}=\\dfrac{8}{15}$, so the sides are $8k$, $15k$ and $\\sqrt{8^2+15^2}\\,k=%dk$."%round(hyp(8,15)),
 "The hypotenuse is $%dk=51$, so $k=%d$."%(17,3),
 "Legs: $8k=%d$ and $15k=%d$. Perimeter $=%d+%d+51=%d$."%(24,45,24,45,round(k))]
# ---- 175
S['GT-175']=["Hypotenuse: $PR=\\sqrt{7^2+24^2}=\\sqrt{%d}=%d$."%(49+576,25),
 "Area two ways: $\\dfrac12(7)(24)=\\dfrac12(25)h$, so $25h=%d$."%(7*24),
 "$h=\\dfrac{%d}{25}=%s$."%(168,dec(SOL['GT-175'],2))]
# ---- 176
S['GT-176']=["Each leg is hypotenuse over $\\sqrt2$: $\\dfrac{14}{\\sqrt2}=7\\sqrt2$.",
 "Perimeter $=14+7\\sqrt2+7\\sqrt2=%s$ (about $%s$). Option (@@L@@)."%(tex(SOL['GT-176']),dec(SOL['GT-176'],1))]
# ---- 177
S['GT-177']=["The height of an equilateral triangle with side $s$ is $\\dfrac{s\\sqrt3}{2}$, so $\\dfrac{s\\sqrt3}{2}=6\\sqrt3$.",
 "Divide both sides by $\\sqrt3$: $\\dfrac s2=6$, so $s=%d$."%round(SOL['GT-177']/3),
 "Perimeter $=3s=%d$."%round(SOL['GT-177'])]
# ---- 178
S['GT-178']=["$\\cos(90^\\circ-\\theta)=\\sin\\theta=0.6$.",
 "$\\sin\\theta=\\dfrac35$, so the sides are $3,4,5$ and $\\cos\\theta=\\dfrac45$, $\\tan\\theta=\\dfrac34=%s$."%dec(0.75,2),
 "Sum: $0.6+0.75=%s$. Option (@@L@@)."%dec(SOL['GT-178'],2)]
# ---- 179
S['GT-179']=["The ladder is the hypotenuse ($13$ ft) and the base distance is a leg ($7$ ft): height $=\\sqrt{13^2-7^2}$.",
 "$13^2-7^2=%d-%d=%d$."%(169,49,120),
 "$\\sqrt{%d}\\approx %s$, which is $%s$ to the nearest tenth."%(120,dec(SOL['GT-179'],3),dec(round(SOL['GT-179'],1),1))]
# ---- 180
S['GT-180']=["$PR=\\sqrt{8^2+15^2}=\\sqrt{%d}=%d$."%(64+225,17),
 "Area two ways: $\\dfrac12(8)(15)=\\dfrac12(17)(QS)$, so $17\\cdot QS=%d$."%120,
 "$QS=%s$."%T(SOL['GT-180'])]
# ---- 181
S['GT-181']=["Subtract from a full turn: $\\dfrac{5\\pi}{3}=2\\pi-\\dfrac{\\pi}{3}$, a fourth-quadrant angle with reference angle $\\dfrac\\pi3$.",
 "Cosine is positive in the fourth quadrant and $\\cos\\dfrac\\pi3=\\dfrac12$.",
 "So $\\cos\\dfrac{5\\pi}{3}=%s$. Option (@@L@@)."%T(SOL['GT-181'])]
# ---- 182
S['GT-182']=["The string is the hypotenuse and the height is opposite the $38^\\circ$ angle, so use sine: $\\sin 38^\\circ=\\dfrac{h}{80}$.",
 "In degree mode $\\sin 38^\\circ\\approx %s$."%dec(sind(38),4),
 "$h=80\\sin 38^\\circ\\approx 80(%s)\\approx %s$, which is $%d$ meters to the nearest meter."%(dec(sind(38),4),dec(SOL['GT-182'],2),round(SOL['GT-182']))]
# ---- 183
S['GT-183']=["$\\sin=\\dfrac35$ means the sides are $3k$, $4k$ and $5k$ (a $3$-$4$-$5$ triangle).",
 "Area $=\\dfrac12(3k)(4k)=6k^2=24$, so $k^2=4$ and $k=2$.",
 "Hypotenuse $=5k=%d$."%round(SOL['GT-183'])]
# ---- 184
S['GT-184']=["$\\cos\\theta=\\dfrac{7}{25}$ means adjacent over hypotenuse, so the adjacent leg is $50\\cdot\\dfrac{7}{25}=%d$."%14,
 "Other leg: $\\sqrt{50^2-14^2}=\\sqrt{%d}=%d$."%(2500-196,48),
 "Area $=\\dfrac12(14)(48)=%d$."%round(SOL['GT-184'])]
# ---- 185
S['GT-185']=["Pythagorean theorem: $x^2+(x+5)^2=25^2$. Type %s and %s in Desmos."%(c('y=x^2+(x+5)^2'),c('y=625')),
 "Tap the intersection with a positive $x$: $(%d,\\,%d)$. So $x=%d$ and the legs are $%d$ and $%d$ (the other intersection has $x=-20$, impossible for a length)."%(15,625,15,15,20),
 "Area $=\\dfrac12(15)(20)=%d$."%round(SOL['GT-185'])]
# ---- 186
S['GT-186']=["Call the sides $12k$ and $35k$. The diagonal is $\\sqrt{(12k)^2+(35k)^2}=\\sqrt{%d}\\,k=%dk$."%(144+1225,37),
 "$37k=74$, so $k=2$ and the sides are $24$ and $70$.",
 "Area $=24\\cdot70=%d$."%round(SOL['GT-186'])]
# ---- circles
S['GT-004']=["Complete the square: $x^2-6x=(x-3)^2-9$ and $y^2+8y=(y+4)^2-16$.",
 "So $(x-3)^2+(y+4)^2=9+16=%d$."%25,
 "$r^2=25$, so $r=%d$. Option (@@L@@). (The option $25$ is $r^2$.)"%round(SOL['GT-004'])]
S['GT-005']=["Complete the square: $x^2+4x=(x+2)^2-4$ and $y^2-10y=(y-5)^2-25$.",
 "So $(x+2)^2+(y-5)^2=29-k$.",
 "The radius is $3$, so $r^2=9=29-k$ and $k=%d$."%round(SOL['GT-005'])]
S['GT-006']=["Arc length $s=r\\theta$ when $\\theta$ is in radians.",
 "$s=45\\cdot\\dfrac{5\\pi}{6}=\\dfrac{225\\pi}{6}=%s$ meters. Option (@@L@@)."%T(SOL['GT-006'])]
S['GT-015']=["Complete the square: $x^2+10x=(x+5)^2-25$ and $y^2-4y=(y-2)^2-4$.",
 "$(x+5)^2+(y-2)^2=25+4-13=%d$."%16,
 "$r=\\sqrt{16}=%d$. Option (@@L@@)."%round(SOL['GT-015'])]
S['GT-018']=["Complete the square: $x^2-8x=(x-4)^2-16$ and $y^2+2y=(y+1)^2-1$.",
 "$(x-4)^2+(y+1)^2=16+1+19=%d$, so the radius is $%d$."%(36,6),
 "Diameter $=2r=%d$."%round(SOL['GT-018'])]
S['GT-021']=["Inscribed Angle Theorem: an inscribed angle is half the central angle on the same arc.",
 "Angle $ACB$ looks at the minor arc $AB$ (the one cut off by the $100^\\circ$ central angle), so $\\angle ACB=\\dfrac{100^\\circ}{2}=%d^\\circ$."%round(SOL['GT-021'])]
S['GT-028']=["The two radii and the chord form an isosceles triangle with a $60^\\circ$ vertex angle, so the base angles are $\\dfrac{180^\\circ-60^\\circ}{2}=%d^\\circ$ each."%60,
 "All three angles are $60^\\circ$: the triangle is equilateral, so the chord equals the radius, $%d$. Option (@@L@@)."%round(SOL['GT-028'])]
S['GT-029']=["A tangent is perpendicular to the radius at the point of tangency, so triangle $OPQ$ has a right angle at $P$.",
 "$PQ=\\sqrt{OQ^2-OP^2}=\\sqrt{15^2-9^2}=\\sqrt{%d}=%d$. Option (@@L@@). (Recognize the $3$-$4$-$5$ triangle times $3$.)"%(225-81,round(SOL['GT-029']))]
S['GT-038']=["Circumference: $2\\pi(20\\sqrt3)=40\\sqrt3\\,\\pi$. The arc is $\\dfrac{10\\sqrt3\\,\\pi/3}{40\\sqrt3\\,\\pi}=\\dfrac1{12}$ of it.",
 "So $\\angle DAC=\\dfrac{360^\\circ}{12}=%d^\\circ$."%30,
 "The tangent is perpendicular to the radius, so triangle $ACD$ is a $30^\\circ$-$60^\\circ$-$90^\\circ$ triangle. $CD$ is opposite $30^\\circ$ and $AD=20\\sqrt3$ is the longer leg, so $CD=\\dfrac{20\\sqrt3}{\\sqrt3}=%d$."%round(SOL['GT-038'])]
S['GT-039']=["Circumference $36\\pi$ means radius $18$, but we only need the central angle.",
 "Quadrilateral $PAOB$ has angles $90^\\circ$ (at $A$), $90^\\circ$ (at $B$) and $100^\\circ$ (at $P$), which add to $%d^\\circ$, so $\\angle AOB=360^\\circ-%d^\\circ=%d^\\circ$."%(280,280,80),
 "Arc $=\\dfrac{80}{360}\\cdot36\\pi=%s$. Option (@@L@@)."%T(SOL['GT-039'])]
S['GT-040']=["The center is $(-4,b)$ and $r^2=100$. Plug in $(4,13)$: $8^2+(13-b)^2=100$, so $(13-b)^2=36$ and $b=7$ or $b=19$.",
 "Plug in $(-10,-1)$: $(-6)^2+(-1-b)^2=100$, so $(b+1)^2=64$ and $b=7$ or $b=-9$.",
 "The value in both lists is $b=%d$."%round(SOL['GT-040'][0])]
S['GT-052']=["Multiply by $\\dfrac{180^\\circ}{\\pi}$: $\\dfrac{7\\pi}{12}\\cdot\\dfrac{180}{\\pi}=7\\cdot15=%d$ degrees."%round(SOL['GT-052'])]
S['GT-053']=["Multiply by $\\dfrac{\\pi}{180}$: $540\\cdot\\dfrac{\\pi}{180}=%d\\pi$, so $a=%d$."%(3,round(SOL['GT-053']))]
if __name__=='__main__':
    import json
    ids=[o['id'] for o in json.load(open('items9.json'))]
    print(set(ids)-set(S),set(S)-set(ids))
