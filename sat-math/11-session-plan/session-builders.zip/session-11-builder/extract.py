import re,csv,json
txt=open('/home/claude/repo-check2/sat-bank/verified-item-bank/SAT_Bank_Verified_Item_Bank.md').read()
blocks=re.split(r'\n### ',txt)
B={}
for b in blocks[1:]:
    id_=b.split('\n')[0].strip()
    B[id_]=b
rows=[r for r in csv.DictReader(open('/home/claude/cb/session_plan_11.csv')) if r['session']=='11']
out=[]
for r in rows:
    b=B[r['id']]
    q=re.search(r'\*\*Question:\*\*(.*?)\n\n\*\*Correct Answer:\*\*',b,re.S).group(1).strip()
    ans=re.search(r'\*\*Correct Answer:\*\*(.*?)\n',b).group(1).strip()
    m_=re.search(r'\*\*Rationale:\*\*(.*?)(\n\n|$)',b,re.S); rat=m_.group(1).strip() if m_ else ''
    fmt=re.search(r'\*\*Format:\*\* ([^\n|]*)',b).group(1).strip()
    out.append(dict(id=r['id'],part=r['part'],d=r['difficulty'],fmt=fmt,q=q,ans=ans,rat=rat))
json.dump(out,open('raw_items.json','w'),indent=1)
for o in out:
    print('=====',o['id'],o['part'],o['d'],o['fmt']);print(o['q']);print('ANS:',o['ans']);print('RAT:',o['rat'])
