# Builds s11_items.json from raw_items.json (bank extract): context cleaning, figure-tag removal, option parsing,
# and the few deliberate rewrites (RESTATE / DEDUP) recorded in CHANGES.
import json,re
raw=json.load(open('raw_items.json'))
REPL={ # id -> list of (old,new) literal replacements (context only; math unchanged)
 'GT-008':[(' supplying a public fountain project in Jeddah',' supplying a public fountain')],
 'GT-009':[('A scale model of a cross-sectional segment of NEOM\'s "The Line" is','A scale model of a section of a long building is')],
 'GT-010':[('A mosque prayer hall is designed','A pavilion is designed')],
 'GT-016':[(' near Tabuk','')],
 'GT-019':[(' used in a heritage restoration project in AlUla',' used in a restoration project')],
 'GT-036':[('In a figure,','In the figure,')],
 'GT-037':[(' at a NEOM community project','')],
 'GT-041':[('A rectangular desalinated-water storage tank at a facility near Yanbu','A rectangular water storage tank at a facility')],
 'GT-060':[('rectangular Saudi flag replica banners','rectangular flag replica banners')],
 'GT-061':[('For a school engineering fair project in Jeddah, a team','For a school engineering fair project, a team')],
 'GT-078':[('in cm²','in square centimeters')],
}
# full rewrites: id -> (new question text, new answer, note)
REWRITE={
 'GT-058':("A cylindrical water tank has a base circumference of $44\\pi$ meters and a height of $15$ meters. The volume of the tank is $k\\pi$ cubic meters. What is the value of $k$?","$7260$",
           "context/format: Riyadh removed; 'in terms of pi' restated as k*pi so the answer is enterable (math identical)"),
 'GT-095':("A hexagon is formed by arranging $6$ equilateral triangles, each of which has a vertex at the center of the hexagon. If the length of one side of a triangle is $6$, the area of the hexagon is $k\\sqrt{3}$ square units. What is the value of $k$?","$54$",
           "format: answer in terms of sqrt(3) restated as k*sqrt(3) so it is enterable (math identical)"),
 'GT-096':("If the surface area of a cube is $96$ square centimeters, what is the volume of the cube, in cubic centimeters?","$64$",
           "near-duplicate of GT-032 (cube, SA 150 -> V 125): numbers changed to SA 96 -> V 64"),
 'GT-212':("A solid is formed by carving a hemispherical bowl of radius $3$ out of the top of a right circular cylinder of radius $3$ and height $7$. The volume of the solid is $k\\pi$. What is the value of $k$?","$45$",
           "near-duplicate of GT-010 (cylinder + hemisphere): changed to a cylinder with a hemispherical bowl carved out (volume 45 pi)"),
}
GT171=("A roof ornament is a solid pyramid whose base is a square of area $100$ square inches. The apex is directly above the center of the base, and each of the four edges from the apex to a corner of the base has length $13$ inches. What is the combined area, in square inches, of the four triangular lateral faces?",
       ["$240$","$260$","$120$","$340$"],"(A) $240$",
       "near-duplicate of GT-134 (square pyramid, V=400, lateral area 260): replaced by a lateral-edge version (edge 13, lateral area 240)")
FIG={'GT-007':'F007','GT-010':'F010','GT-016':'F016','GT-019':'F019','GT-022':'F022','GT-036':'F036','GT-078':'F078','GT-092':'F092','GT-095':'F095',
     'GT-142':'F142','GT-153':'F153','GT-158':'F158','GT-202':'F202','GT-205':'F205','GT-207':'F207','GT-212':'F212'}
def parse(q):
    stem=[];opts=[]
    for ln in q.split('\n'):
        m=re.match(r'^\(?([A-D])\)\s*(.*)$',ln.strip())
        if m and (opts or m.group(1)=='A'): opts.append(m.group(2).strip())
        elif opts and ln.strip()=='': continue
        elif opts: opts[-1]+=' '+ln.strip()
        else: stem.append(ln)
    return '\n'.join(stem).strip(),opts
out=[];changes=[]
for o in raw:
    q=re.sub(r'^\[Figure:[^\]]*\]\s*','',o['q']); ans=o['ans']; opts=None
    mcq='Multiple' in o['fmt']
    for a,b in REPL.get(o['id'],[]):
        assert a in q,(o['id'],a); q=q.replace(a,b)
    if o['id'] in REWRITE:
        q,ans,note=REWRITE[o['id']]; changes.append((o['id'],note))
    if o['id']=='GT-171':
        q,opts,ans,note=GT171; changes.append((o['id'],note))
    elif mcq:
        q,opts=parse(q); assert len(opts)==4 and len(set(opts))==4,o['id']
    for bad in ('SAR','Riyadh','Jeddah','NEOM','Saudi','AlUla','Tabuk','Yanbu','mosque','°','²'):
        assert bad not in q+''.join(opts or []),(o['id'],bad)
    out.append(dict(id=o['id'],part=o['part'],d=o['d'],mcq=mcq,q=q,opts=opts,ans=ans,fig=FIG.get(o['id']),bank_ans=o['ans']))
json.dump(out,open('s11_items.json','w'),indent=1); json.dump(changes,open('changes.json','w'),indent=1)
print(len(out),sum(o['part']=='In class' for o in out),'changes',len(changes))
for o in out:
    if o['id'] in ('GT-036','GT-092','GT-059','GT-171'): print(o['id'],o['q'],o['opts'],o['ans'])
