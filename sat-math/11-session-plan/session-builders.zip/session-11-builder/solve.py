# Independent solutions from the question text (numbers typed from the stems; numeric integration / coordinate
# geometry / sympy / brute force). Computed BEFORE looking at the bank answers; compared at the end.
import math, json, re, itertools
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq, fsolve
pi=math.pi
def revolve(profile,z0,z1):            # volume of a solid of revolution, pi * integral r(z)^2 dz
    return quad(lambda z:pi*profile(z)**2,z0,z1,epsabs=1e-12,epsrel=1e-12,limit=200)[0]
def shoelace(P):
    return abs(sum(P[i][0]*P[(i+1)%len(P)][1]-P[(i+1)%len(P)][0]*P[i][1] for i in range(len(P))))/2
def tri3(a,b,c): return np.linalg.norm(np.cross(np.subtract(b,a),np.subtract(c,a)))/2

M={}
def root(f,lo,hi): return brentq(f,lo,hi,xtol=1e-14,rtol=1e-14)
M['GT-007']=12*8+quad(lambda x:math.sqrt(16-x*x),-4,4)[0]          # rectangle + half disc (integral of the semicircle)
M['GT-008']=4500*pi/(pi*15**2)
M['GT-009']=3*20**3
M['GT-010']=revolve(lambda z:6,0,10)+revolve(lambda z:math.sqrt(36-(z-10)**2),10,16)
M['GT-016']=revolve(lambda z:4,0,12)+revolve(lambda z:4*(15-z)/3,12,15)
M['GT-019']=8*8*20-quad(lambda x:2*math.sqrt(4-x*x),-2,2)[0]*20
M['GT-022']=revolve(lambda z:6*z/8,0,4)                      # z measured from the apex
M['GT-026']=sum(2*a*b for a,b in itertools.combinations((8,5,4),2))
M['GT-032']=root(lambda s:6*s*s-150,0.1,100)**3
A_=np.array([0,0.]);Dv=np.array([33,0.])
hB=root(lambda h:12**2+h*h-400,0.1,100); B_=np.array([-12,hB]); M['GT-036']=abs(B_[0]*Dv[1]-B_[1]*Dv[0]-(A_[0]*Dv[1]-A_[1]*Dv[0]))   # |AB x AD|
L0=1.0; area0=L0*0.4*L0; area1=(L0-0.1*L0)*(0.4*L0-0.1*L0); M['GT-037']=(area0-area1)/area0*100
M['GT-041']=8*5*4.5*62.4
rr=root(lambda r:2*pi*r-44*pi,0.1,1000); M['GT-058']=rr**2*15                 # coefficient k of pi
M['GT-059']=revolve(lambda z:math.sqrt(18**2-z*z),0,18)
M['GT-060']=24*3**2
M['GT-061']=root(lambda r:1/3*pi*r*r*9-48*pi,0.1,100)
M['GT-077']=3.14*3**2*8
M['GT-078']=shoelace([(0,0),(22,0),(18,9),(4,9)])
M['GT-079']=3.14*quad(lambda z:(6*(10-z)/10)**2,0,10)[0]
M['GT-080']=4*3.14*5**2
M['GT-090']=4*root(lambda s:s*s-4*s,0.5,100)
M['GT-092']=8*math.sqrt(45)
M['GT-093']=8*pi*5**2*0.3
hexP=[(6*math.cos(k*pi/3),6*math.sin(k*pi/3)) for k in range(6)]; M['GT-095']=shoelace(hexP)/math.sqrt(3)   # k with area = k sqrt3
M['GT-096']=root(lambda s:6*s*s-96,0.1,100)**3
M['GT-110']=12/((972/36)**(1/3))
M['GT-113']=210*math.sqrt(2520/630)
M['GT-114']=(88/3)**2
M['GT-116']=root(lambda h:100+4*0.5*10*math.sqrt(h*h+25)-(100+100*math.sqrt(5)),0.1,100)
M['GT-119']=108*(math.sqrt(400/144))**3
M['GT-120']=375/(math.sqrt(325/208))**3
# 130: V=48pi, SA=56pi, h>2r : substitute h=48/r^2 and scan r
f130=lambda r:2*r*r+2*r*(48/r**2)-56
rs=[root(f130,a,b) for a,b in ((1,3),(3,5)) if f130(a)*f130(b)<0]
M['GT-130_all']=[(r,48/r**2) for r in rs]; M['GT-130']=[48/r**2 for r in rs if 48/r**2>2*r][0]
rA=8*pi/(2*pi); SAA=4*pi*rA**2; RB=math.sqrt((SAA+80*pi)/(4*pi)); M['GT-132']=(RB/rA)**3
side=math.sqrt((10*math.sqrt(2))**2/2); Hh=3*400/side**2; sl=math.sqrt(Hh**2+(side/2)**2); M['GT-134']=4*0.5*side*sl
M['GT-138']=root(lambda t:pi*15*(10**2-(10-t)**2)-765*pi,0.01,9.99)
a_=math.sqrt(13**2-12**2); b_=math.sqrt(20**2-12**2)
C4=[(a_,b_,0),(-a_,b_,0),(-a_,-b_,0),(a_,-b_,0)]; ap=(0,0,12)
M['GT-139']=sum(tri3(C4[i],C4[(i+1)%4],ap) for i in range(4))+(2*a_)*(2*b_)
M['GT-142']=shoelace([(0,0),(8,0),(8,3.5),(0,1.5)])*12/27*45
SAP=2*pi*2*(2+6); kk=math.sqrt(200*pi/SAP); M['GT-145']=pi*2**2*6*kk**3          # numeric value of the volume (375 pi)
SAP=2*(3*4+3*6+4*6); VP=3*4*6; kk=(1125/VP)**(1/3); M['GT-149']=SAP*kk**2
M['GT-153']=(revolve(lambda z:30,0,40)-revolve(lambda z:10,0,25))/1000*7.8
c_=root(lambda c:abs(5*c-60)/13-c,0.1,11.9)              # centre (0,c), radius c; slanted line 12x+5y=60
M['GT-158']=(4/3*pi*c_**3)/revolve(lambda z:5*(12-z)/12,0,12)
M['GT-163']=2.5*(math.sqrt(14.4/1.6))**3
M['GT-165']=400*(432/250)**(2/3)
bs=math.sqrt(100); hApex=math.sqrt(13**2-2*(bs/2)**2)
Bc=[(bs/2,bs/2,0),(-bs/2,bs/2,0),(-bs/2,-bs/2,0),(bs/2,-bs/2,0)]; M['GT-171']=sum(tri3(Bc[i],Bc[(i+1)%4],(0,0,hApex)) for i in range(4))
M['GT-027']=2*pi*5**2+quad(lambda z:2*pi*5,0,12)[0]
M['GT-201']=2*root(lambda r:pi*r*r*10-90*pi,0.1,100)*10
M['GT-202']=1/3*36*math.sqrt(10**2-6**2)
M['GT-203']=4/3*root(lambda r:4*pi*r*r-144*pi,0.1,100)**3
M['GT-204']=40*((27/8)**(1/3))**2
M['GT-205']=root(lambda h:6**2+8**2+h*h-26**2,0.1,100)
M['GT-206']=12**3/(40*30)
M['GT-207']=4*0.5*12*math.sqrt(8**2+6**2)
M['GT-208']=root(lambda e:math.sqrt(3)*e-9*math.sqrt(3),0.1,100)**3
M['GT-209']=sum(1 for x in range(0,10,2) for y in range(0,12,2) for z in range(0,16,2))
M['GT-210']=(pi*5**2*12)/((1/3)*pi*5**2*12)
M['GT-211']=((1.2)**3-1)*100
M['GT-212']=(revolve(lambda z:3,0,7)-revolve(lambda z:math.sqrt(9-(z-7)**2),4,7))/pi
json.dump({k:v for k,v in M.items() if not k.endswith('_all')},open('mine.json','w'),default=float)
# ---------------- compare with the items file ----------------
items=json.load(open('s11_items.json'))
def val(text):
    t=text.replace('$','').replace('{,}','').replace(',','')
    t=re.sub(r'(square units|square inches|cm\^3|cm|\^\\circ)','',t)
    t=t.replace('\\dfrac','\\frac'); t=re.sub(r'\\frac(\d)(\d)',r'((\1)/(\2))',t); t=re.sub(r'\\frac\{([^}]*)\}\{([^}]*)\}',r'((\1)/(\2))',t)
    t=re.sub(r'\\sqrt\{([^}]*)\}',r'sqrt(\1)',t); t=re.sub(r'\\sqrt(\d)',r'sqrt(\1)',t); t=t.replace('\\pi','pi')
    t=re.sub(r'(\d|\))\s*(pi|sqrt|\()',r'\1*\2',t)
    return eval(t,{'__builtins__':{}},dict(pi=pi,sqrt=math.sqrt))
PIITEMS={'GT-010','GT-016','GT-019','GT-022','GT-027','GT-059','GT-093','GT-007','GT-130'}
def target(i):
    """value the options are compared with (pi-containing option text evaluates numerically)"""
    return M[i]
# GT-027 and GT-145 etc. need a few extras
res=[];ok=True
for o in items:
    i=o['id']; m=M[i]
    if o['mcq']:
        vals=[val(x) for x in o['opts']]
        assert len(set(o['opts']))==4
        d=[abs(v-m) for v in vals]; k=int(np.argmin(d))
        # unique closest, and for exact items the match must be tight
        srt=sorted(d); tight=srt[0]<=0.0006*max(1,abs(m)) or i in ('GT-059','GT-077','GT-079','GT-080','GT-153')
        gap=srt[1]>5*srt[0]
        letter=re.match(r'^\(?([A-D])',o['ans'].strip()).group(1)
        res.append((i,'MCQ','ABCD'[k],letter,round(m,4),tight,gap))
        assert tight and gap and 'ABCD'[k]==letter,(i,vals,m,k,letter)
        # option text equal to the stated answer text
        assert o['opts']["ABCD".index(letter)]==o['opts'][k]
    else:
        v=val(o['ans']); res.append((i,'SPR',round(m,6),round(v,6)))
        assert abs(v-m)<1e-6*max(1,abs(v)),(i,v,m)
# bank answers vs mine for rewritten items
bank={o['id']:o['bank_ans'] for o in items}
print('GT-130 candidate (r,h):',M['GT-130_all'])
for r in res: print(r)
print('ALL',len(res),'items verified independently.')
# GT-058/GT-095: bank answer in terms of pi / sqrt3 corresponds to my k
assert abs(val(bank['GT-058'])-M['GT-058']*pi)<1e-6 and abs(val(bank['GT-095'])-M['GT-095']*math.sqrt(3))<1e-6
strip=lambda a:re.sub(r'^\(?[A-D]\)\s*','',a.strip())
print('bank answer differs from the (intentionally rewritten) item answer for:',[i for i in ('GT-096','GT-171','GT-212') if abs(val(strip(bank[i]))-val(strip(next(o for o in items if o['id']==i)['ans'])))>1e-9])
# keyed results for build.py: MCQ -> letter of the option nearest my value; SPR -> my value
KEY={}
for o in items:
    m=M[o['id']]
    if o['mcq']: KEY[o['id']]='ABCD'[int(np.argmin([abs(val(x)-m) for x in o['opts']]))]
    else: KEY[o['id']]=float(m)
json.dump(KEY,open('mykeys.json','w'))
