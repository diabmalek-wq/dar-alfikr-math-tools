"""TikZ figures for Session 11. Every coordinate is computed from the same numbers that appear in the item stem."""
import math
from figlib import FIGSTYLE
STY=r"""\tikzset{sh/.style={thick,BLUE},hid/.style={thick,BLUE,dashed},dim/.style={<->,>=Stealth,thin,GREY},ext/.style={thin,GREY,dotted},
 lab/.style={font=\scriptsize,inner sep=1.5pt},vl/.style={font=\footnotesize\bfseries,inner sep=1.5pt},
 fillA/.style={fill=BLUE!10},fillB/.style={fill=ORANGE!16},fillM/.style={fill=GREY!22}}"""
def gfig(body,u):
    return r"\begin{center}\begin{tikzpicture}[x=%gcm,y=%gcm]"%(u,u)+FIGSTYLE+STY+body+r"\end{tikzpicture}\end{center}"
def rt(x,y,s,dx,dy):   # right-angle mark at (x,y) with legs along (dx,0) and (0,dy)
    return r"\draw[thin,GREY] (%g,%g)--(%g,%g)--(%g,%g);"%(x+dx,y,x+dx,y+dy,x,y+dy)
def ell_front(cx,cy,rx,ry,style='sh'): return r"\draw[%s] (%g,%g) arc(180:360:%g and %g);"%(style,cx-rx,cy,rx,ry)
def ell_back(cx,cy,rx,ry): return r"\draw[hid] (%g,%g) arc(180:0:%g and %g);"%(cx-rx,cy,rx,ry)

def F007():
    w,h,r=12,8,4
    b=r"\fill[fillA] (0,0) rectangle (%g,%g);\fill[fillB] (%g,%g) ++(0,%g) arc(90:-90:%g) -- cycle;"%(w,h,w,h/2,r,r)
    b+=r"\draw[sh] (%g,0)--(0,0)--(0,%g)--(%g,%g);\draw[sh] (%g,%g) arc(90:-90:%g);\draw[dashed,GREY] (%g,0)--(%g,%g);"%(w,h,w,h,w,h,r,w,w,h)
    b+=r"\node[vl,below] at (%g,0){$%g$ m};\node[vl,left] at (0,%g){$%g$ m};\node[lab] at (%g,%g){$d=%g$ m};"%(w/2,w,h/2,h,w+r*0.5,h/2,h)
    return gfig(b,0.3)
def F010():
    r,h=6,10; ry=0.3*r
    b=r"\fill[fillA] (%g,0) arc(180:360:%g and %g)--(%g,%g) arc(0:180:%g and %g)--cycle;"%(-r,r,ry,r,h,r,ry)
    b+=r"\fill[fillA] (%g,%g) arc(180:0:%g);"%(-r,h,r)
    b+=ell_front(0,0,r,ry)+r"\draw[sh] (%g,0)--(%g,%g);\draw[sh] (%g,0)--(%g,%g);"%(-r,-r,h,r,r,h)
    b+=r"\draw[sh] (%g,%g) arc(180:0:%g);"%(-r,h,r)+ell_front(0,h,r,ry)+ell_back(0,h,r,ry)
    b+=r"\draw[dim] (0,%g)--(%g,%g) node[midway,fill=white,lab]{$%g$ m};"%(h,r,h,r)
    b+=r"\draw[ext] (%g,0)--(%g,0);\draw[ext] (%g,%g)--(%g,%g);\draw[dim] (%g,0)--(%g,%g) node[midway,fill=white,vl]{$%g$ m};"%(r,r+2.2,r,h,r+2.2,h,r+2,r+2,h,h)
    return gfig(b,0.26)
def F016():
    r,h,hc=4,12,3; ry=0.3*r
    b=r"\fill[fillA] (%g,0) arc(180:360:%g and %g)--(%g,%g)--(0,%g)--(%g,%g)--cycle;"%(-r,r,ry,r,h,h+hc,-r,h)
    b+=ell_front(0,0,r,ry)+r"\draw[sh] (%g,0)--(%g,%g)--(0,%g)--(%g,%g)--(%g,0);"%(-r,-r,h,h+hc,r,h,r)
    b+=ell_front(0,h,r,ry)+ell_back(0,h,r,ry)
    b+=r"\draw[dim] (0,%g)--(%g,%g) node[midway,fill=white,lab]{$%g$ m};"%(h,r,h,r)
    x=r+1.8
    b+=r"\draw[ext] (%g,0)--(%g,0);\draw[ext] (%g,%g)--(%g,%g);\draw[ext] (0,%g)--(%g,%g);"%(r,x,r,h,x,h,h+hc,x,h+hc)
    b+=r"\draw[dim] (%g,0)--(%g,%g) node[midway,fill=white,vl]{$%g$ m};\draw[dim] (%g,%g)--(%g,%g) node[midway,fill=white,vl]{$%g$ m};"%(x,x,h,h,x,h,x,h+hc,hc)
    return gfig(b,0.28)
def F019():
    a,L=8,20; k=0.45; ang=math.radians(35); dx=k*L*math.cos(ang); dy=k*L*math.sin(ang); r=2
    b=r"\fill[fillA] (0,0) rectangle (%g,%g);"%(a,a)
    b+=r"\fill[fill=BLUE!22] (0,%g)--(%g,%g)--(%g,%g)--(%g,%g)--cycle;\fill[fill=BLUE!22] (%g,0)--(%g,%g)--(%g,%g)--(%g,%g)--cycle;"%(a,dx,a+dy,a+dx,a+dy,a,a,a,a+dx,dy,a+dx,a+dy,a,a)
    b+=r"\draw[sh] (0,0) rectangle (%g,%g);\draw[sh] (0,%g)--(%g,%g)--(%g,%g)--(%g,%g);\draw[sh] (%g,0)--(%g,%g)--(%g,%g);"%(a,a,a,dx,a+dy,a+dx,a+dy,a,a,a,a+dx,dy,a+dx,a+dy)
    b+=r"\draw[hid] (0,0)--(%g,%g)--(%g,%g);\draw[hid] (%g,%g)--(%g,%g);"%(dx,dy,a+dx,dy,dx,dy,dx,a+dy)
    b+=r"\draw[hid] (%g,%g) circle(%g);\draw[hid] (%g,%g)--(%g,%g);\draw[hid] (%g,%g)--(%g,%g);"%(a/2+dx,a/2+dy,r,a/2,a/2+r,a/2+dx,a/2+r+dy,a/2,a/2-r,a/2+dx,a/2-r+dy)
    b+=r"\draw[sh,fill=white] (%g,%g) circle(%g);\draw[dim] (%g,%g)--(%g,%g) node[midway,above,lab]{$%g$};"%(a/2,a/2,r,a/2,a/2,a/2+r,a/2,r)
    b+=r"\node[vl,below] at (%g,0){$%g$ m};\node[vl,left] at (0,%g){$%g$ m};\node[vl,below right] at (%g,%g){$%g$ m};"%(a/2,a,a/2,a,a+dx/2,dy/2,L)
    return gfig(b,0.22)
def F022():
    R,H,hc=6,8,4; ry=0.3*R; r2=R*hc/H
    b=r"\fill[fillA] (%g,0) arc(180:360:%g and %g)--(0,%g)--cycle;"%(-R,R,ry,H)
    b+=r"\fill[fillB] (0,%g)--(%g,%g) arc(0:-180:%g and %g)--cycle;\fill[fillB] (%g,%g) arc(180:0:%g and %g);"%(H,r2,H-hc,r2,0.3*r2,-r2,H-hc,r2,0.3*r2)
    b+=ell_front(0,0,R,ry)+ell_back(0,0,R,ry)+r"\draw[sh] (%g,0)--(0,%g)--(%g,0);"%(-R,H,R)
    b+=ell_front(0,H-hc,r2,0.3*r2)+ell_back(0,H-hc,r2,0.3*r2)
    b+=r"\draw[dim] (0,0)--(%g,0) node[midway,fill=white,lab]{$%g$ cm};"%(R,R)
    x1=R+1.6;x2=R+3.4
    b+=r"\draw[ext] (0,%g)--(%g,%g);\draw[ext] (%g,%g)--(%g,%g);\draw[ext] (%g,0)--(%g,0);"%(H,x2,H,r2,H-hc,x2,H-hc,R,x2)
    b+=r"\draw[dim] (%g,%g)--(%g,%g) node[midway,fill=white,vl]{$%g$ cm};\draw[dim] (%g,0)--(%g,%g) node[midway,fill=white,vl]{$%g$ cm};"%(x1,H-hc,x1,H,hc,x2,x2,H,H)
    return gfig(b,0.3)
def F036():
    ab=math.sqrt(400); ae=12; ad=33; be=math.sqrt(ab**2-ae**2)
    A=(0,0);Dp=(ad,0);B=(-ae,be);C=(ad-ae,be);E=(-ae,0)
    sq=ab; x0=-ae-14-sq
    b=r"\fill[fillA] (%g,0) rectangle (%g,%g);"%(x0,x0+sq,sq)+r"\draw[sh] (%g,0) rectangle (%g,%g);"%(x0,x0+sq,sq)
    b+=r"\node[lab,below left] at (%g,0){$W$};\node[lab,below right] at (%g,0){$X$};\node[lab,above right] at (%g,%g){$Y$};\node[lab,above left] at (%g,%g){$Z$};"%(x0,x0+sq,x0+sq,sq,x0,sq)
    b+=r"\node[vl] at (%g,%g){area $400$};"%(x0+sq/2,sq/2)
    b+=r"\fill[fillB] (%g,%g)--(%g,%g)--(%g,%g)--(%g,%g)--cycle;"%(A+B+C+Dp)
    b+=r"\draw[sh] (%g,%g)--(%g,%g)--(%g,%g)--(%g,%g)--cycle;"%(A+B+C+Dp)
    b+=r"\draw[hid] (%g,%g)--(%g,%g);\draw[sh] (%g,%g)--(%g,%g);"%(B+E+E+A)
    b+=rt(-ae,0,'',1.6,1.6)
    for nm,P,pos in (('A',A,'below right'),('B',B,'above left'),('C',C,'above right'),('D',Dp,'below right'),('E',E,'below left')):
        b+=r"\node[lab,%s] at (%g,%g){$%s$};"%(pos,P[0],P[1],nm)
    b+=r"\node[vl,below] at (%g,-3){$%g$};\node[vl,below] at (%g,-3){$%g$};"%(-ae/2,ae,ad/2,ad)
    b+=r"\draw[dim] (%g,-3)--(%g,-3);\draw[dim] (0,-3)--(%g,-3);"%(-ae,0,ad)
    return gfig(b,0.18)
def F078():
    top,bot,h=14,22,9; off=(bot-top)/2
    b=r"\fill[fillA] (0,0)--(%g,0)--(%g,%g)--(%g,%g)--cycle;\draw[sh] (0,0)--(%g,0)--(%g,%g)--(%g,%g)--cycle;"%(bot,bot-off,h,off,h,bot,bot-off,h,off,h)
    b+=r"\draw[dashed,GREY] (%g,%g)--(%g,0);"%(off,h,off)
    b+=r"\draw[thin,GREY] (%g,0)--(%g,0.9)--(%g,0.9);"%(off+0.9,off+0.9,off)
    b+=r"\node[vl,below] at (%g,0){$%g$ cm};\node[vl,above] at (%g,%g){$%g$ cm};\node[vl,right] at (%g,%g){$%g$ cm};"%(bot/2,bot,bot/2,h,top,off+0.2,h/2,h)
    return gfig(b,0.24)
def F092():
    s=math.sqrt(45); w=8
    b=r"\fill[fillA] (0,0) rectangle (%g,%g);\fill[fillB] (0,0) rectangle (%g,%g);"%(s,w,s,-s)
    b+=r"\draw[sh] (0,0) rectangle (%g,%g);\draw[sh] (0,0) rectangle (%g,%g);"%(s,w,s,-s)
    for nm,P,pos in (('A',(0,w),'above left'),('B',(0,0),'left'),('C',(s,0),'right'),('D',(s,w),'above right'),('E',(s,-s),'below right'),('F',(0,-s),'below left')):
        b+=r"\node[lab,%s] at (%g,%g){$%s$};"%(pos,P[0],P[1],nm)
    b+=r"\node[vl,left] at (-0.5,%g){$%g$};\node[vl] at (%g,%g){area $45$};"%(w/2,w,s/2,-s/2)
    return gfig(b,0.3)
def F095():
    R=6; P=[(R*math.cos(k*math.pi/3),R*math.sin(k*math.pi/3)) for k in range(6)]
    b=""
    for k in range(6):
        t=(k%2==0)
        b+=r"\fill[%s] (0,0)--(%g,%g)--(%g,%g)--cycle;"%('fillA' if t else 'fillB',P[k][0],P[k][1],P[(k+1)%6][0],P[(k+1)%6][1])
    b+=r"\draw[sh] "+"--".join("(%g,%g)"%p for p in P)+"--cycle;"
    for p in P: b+=r"\draw[thin,BLUE] (0,0)--(%g,%g);"%p
    b+=r"\node[pt] at (0,0){};\node[vl,below] at (%g,%g){$%g$};"%((P[4][0]+P[5][0])/2,(P[4][1]+P[5][1])/2,R)
    return gfig(b,0.36)
def F142():
    w,d1,d2=8,1.5,3.5
    b=r"\fill[fillM] (0,0)--(%g,0)--(%g,%g)--(0,%g)--cycle;\fill[pattern=dots,pattern color=GREY] (0,0)--(%g,0)--(%g,%g)--(0,%g)--cycle;"%(w,w,d2,d1,w,w,d2,d1)
    b+=r"\draw[sh] (0,0)--(%g,0)--(%g,%g)--(0,%g)--cycle;"%(w,w,d2,d1)
    b+=r"\node[vl,below] at (%g,0){$%g$ ft};\node[vl,left] at (0,%g){$%g$ ft};\node[vl,right] at (%g,%g){$%g$ ft};"%(w/2,w,d1/2,d1,w,d2/2,d2)
    b+=r"\node[lab,GREY] at (%g,-1.2){cross-section, perpendicular to the length of the bed};"%(w/2)
    return gfig(b,0.55)
def F153():
    D,H,d,dep=60,40,20,25
    b=r"\fill[fillM] (%g,0) rectangle (%g,%g);\fill[white] (%g,%g) rectangle (%g,%g);"%(-D/2,D/2,H,-d/2,H-dep,d/2,H)
    b+=r"\draw[sh] (%g,%g)--(%g,%g)--(%g,%g)--(%g,%g)--(%g,%g)--(%g,%g)--(%g,%g)--(%g,%g)--cycle;"%(-D/2,H,-d/2,H,-d/2,H-dep,d/2,H-dep,d/2,H,D/2,H,D/2,0,-D/2,0)
    b+=r"\draw[dashed,GREY] (0,-2)--(0,%g);"%(H+4)
    b+=r"\draw[dim] (%g,-5)--(%g,-5) node[midway,fill=white,vl]{$%g$ mm};"%(-D/2,D/2,D)
    b+=r"\draw[dim] (%g,0)--(%g,%g) node[midway,fill=white,vl]{$%g$ mm};"%(D/2+6,D/2+6,H,H)
    b+=r"\draw[dim] (%g,%g)--(%g,%g) node[midway,above,vl]{$%g$ mm};"%(-d/2,H+5,d/2,H+5,d)
    b+=r"\draw[ext] (%g,%g)--(%g,%g);\draw[ext] (%g,%g)--(%g,%g);"%(-d/2,H,-d/2,H+8,d/2,H,d/2,H+8)
    b+=r"\draw[dim] (%g,%g)--(%g,%g) node[midway,fill=white,vl]{$%g$ mm};"%(-D/2+6,H,-D/2+6,H-dep,dep)
    b+=r"\node[lab,GREY] at (0,-13){cross-section through the axis};"
    return gfig(b,0.062)
def F158():
    r,h=5,12; sl=math.hypot(r,h); area=r*h; s=(sl+sl+2*r)/2; c=area/s     # inradius of the axial triangle
    dist=abs(h*0+r*c-r*h)/sl           # distance from centre (0,c) to line h x + r y = r h
    assert abs(dist-c)<1e-12
    b=r"\fill[fillA] (%g,0)--(%g,0)--(0,%g)--cycle;"%(-r,r,h)+r"\fill[fillB] (0,%g) circle(%g);"%(c,c)
    b+=r"\draw[sh] (%g,0)--(%g,0)--(0,%g)--cycle;\draw[sh,ORANGE] (0,%g) circle(%g);"%(-r,r,h,c,c)
    b+=r"\draw[dim] (0,0)--(%g,0) node[midway,below=1pt,lab]{$%g$};"%(r,r)
    b+=r"\draw[ext] (%g,0)--(%g,0);\draw[ext] (0,%g)--(%g,%g);\draw[dim] (%g,0)--(%g,%g) node[midway,fill=white,vl]{$%g$};"%(-r,-r-1.2,h,-r-1.2,h,-r-1.2,-r-1.2,h,h)
    return gfig(b,0.3)
def F202():
    r,sl=6,10; h=math.sqrt(sl**2-r**2); ry=0.25*r
    b=r"\fill[fillA] (%g,0) arc(180:360:%g and %g)--(0,%g)--cycle;"%(-r,r,ry,h)
    b+=ell_front(0,0,r,ry)+ell_back(0,0,r,ry)+r"\draw[sh] (%g,0)--(0,%g)--(%g,0);"%(-r,h,r)
    b+=r"\draw[hid,thin,GREY] (0,0)--(0,%g);\draw[dim] (0,0)--(%g,0) node[midway,below,lab]{$%g$};"%(h,r,r)
    b+=r"\node[vl,above right] at (%g,%g){$%g$};"%(r/2,h/2,sl)
    return gfig(b,0.4)
def F205():
    a,dd,hgt,diag=6,8,24,26; k=0.5; ang=math.radians(45); dx=k*dd*math.cos(ang); dy=k*dd*math.sin(ang)
    assert abs(math.sqrt(a*a+dd*dd+hgt*hgt)-diag)<1e-12
    b=r"\fill[fillA] (0,0) rectangle (%g,%g);\fill[fill=BLUE!22] (0,%g)--(%g,%g)--(%g,%g)--(%g,%g)--cycle;\fill[fill=BLUE!22] (%g,0)--(%g,%g)--(%g,%g)--(%g,%g)--cycle;"%(a,hgt,hgt,dx,hgt+dy,a+dx,hgt+dy,a,hgt,a,a+dx,dy,a+dx,hgt+dy,a,hgt)
    b+=r"\draw[sh] (0,0) rectangle (%g,%g);\draw[sh] (0,%g)--(%g,%g)--(%g,%g)--(%g,%g);\draw[sh] (%g,0)--(%g,%g)--(%g,%g);"%(a,hgt,hgt,dx,hgt+dy,a+dx,hgt+dy,a,hgt,a,a+dx,dy,a+dx,hgt+dy)
    b+=r"\draw[hid] (0,0)--(%g,%g)--(%g,%g);\draw[hid] (%g,%g)--(%g,%g);"%(dx,dy,a+dx,dy,dx,dy,dx,hgt+dy)
    b+=r"\draw[very thick,ORANGE] (0,0)--(%g,%g);"%(a+dx,hgt+dy)
    b+=r"\node[vl,fill=white,inner sep=1pt] at (%g,%g){$%g$};"%((a+dx)/2,(hgt+dy)/2,diag)
    b+=r"\node[vl,below] at (%g,0){$%g$};\node[vl,below right] at (%g,%g){$%g$};\node[vl,left] at (0,%g){$h$};"%(a/2,a,a+dx/2,dy/2,dd,hgt/2)
    return gfig(b,0.16)
def F207():
    a,hgt=12,8; k=0.5; ang=math.radians(45); dx=k*a*math.cos(ang); dy=k*a*math.sin(ang)
    P=[(0,0),(a,0),(a+dx,dy),(dx,dy)]; cx=a/2+dx/2; cy=dy/2; ap=(cx,cy+hgt)
    b=r"\fill[fillA] (%g,%g)--(%g,%g)--(%g,%g)--cycle;"%(P[0]+P[1]+ap)+r"\fill[fill=BLUE!22] (%g,%g)--(%g,%g)--(%g,%g)--cycle;"%(P[1]+P[2]+ap)
    b+=r"\draw[sh] (%g,%g)--(%g,%g)--(%g,%g)--cycle;\draw[sh] (%g,%g)--(%g,%g)--(%g,%g);"%(P[0]+P[1]+ap+P[1]+P[2]+ap)
    b+=r"\draw[hid] (%g,%g)--(%g,%g)--(%g,%g);\draw[hid] (%g,%g)--(%g,%g);"%(P[0]+P[3]+P[2]+P[3]+ap)
    b+=r"\draw[dashed,GREY] (%g,%g)--(%g,%g);\node[pt,inner sep=1pt] at (%g,%g){};"%(cx,cy,ap[0],ap[1],cx,cy)
    b+=r"\node[vl,left] at (%g,%g){$%g$};\node[vl,below] at (%g,0){$%g$};"%(cx,cy+hgt/2,hgt,a/2,a)
    return gfig(b,0.26)
def F212():
    r,h=3,7
    b=r"\fill[fillM] (%g,0) rectangle (%g,%g);\fill[white] (%g,%g) arc(180:360:%g)--cycle;"%(-r,r,h,-r,h,r)
    b+=r"\draw[sh] (%g,%g)--(%g,0)--(%g,0)--(%g,%g);\draw[sh] (%g,%g) arc(180:360:%g);\draw[sh] (%g,%g)--(%g,%g);"%(-r,h,-r,r,r,h,-r,h,r,-r,h,r,h)
    b+=r"\draw[dim] (0,%g)--(%g,%g) node[midway,above,lab]{$%g$};"%(h,r,h,r)
    b+=r"\draw[ext] (%g,0)--(%g,0);\draw[ext] (%g,%g)--(%g,%g);\draw[dim] (%g,0)--(%g,%g) node[midway,fill=white,vl]{$%g$};"%(r,r+1.6,r,h,r+1.6,h,r+1.4,r+1.4,h,h)
    b+=r"\node[lab,GREY] at (0,-1.1){cross-section through the axis};"
    return gfig(b,0.5)
FIG={k[1:]:v for k,v in list(globals().items()) if k.startswith('F') and k[1:].isdigit()}
FIG={('F'+k):v for k,v in FIG.items()}
