import json,re,sys,subprocess,os
HERE=os.path.dirname(os.path.abspath(__file__)); os.chdir(HERE); sys.path.insert(0,HERE)
from lib import *
from steps11 import S,T
import figs11
ESC={'\\':r'\textbackslash{}','{':r'\{','}':r'\}','^':r'\textasciicircum{}','_':r'\_','~':r'\textasciitilde{}','#':r'\#','%':r'\%','&':r'\&','$':r'\$'}
def code(m):
    c=m.group(1).replace('\\{','{').replace('\\}','}')
    return r"\dzc{"+"".join(ESC.get(ch,ch) for ch in c)+"}"
def conv(s): return re.sub(r"\[\[(.+?)\]\]",code,s)
items=json.load(open('s11_items.json')); KEY=json.load(open('mykeys.json'))
LINES=json.load(open('lines.json')) if os.path.exists('lines.json') else {}
P=[]
order=[o for o in items if o['part']=='In class']+[o for o in items if o['part']!='In class']
nA=sum(o['part']=='In class' for o in items)
for o in order:
    i=o['id']
    p=dict(lv='M' if o['d']=='Medium' else 'H',tool=T.get(i,'N'),q=o['q'],id=i)
    if o['fig']: p['fig']=figs11.FIG[o['fig']]()
    if o['mcq']:
        L=re.match(r'^\(?([A-D])',o['ans'].strip()).group(1)
        assert KEY[i]==L,i
        p['opts']=o['opts'];p['correct']="ABCD".index(L);p['norot']=False;p['chk']=lambda c="ABCD".index(KEY[i]):('idx',c)
    else:
        a=o['ans'].replace('$','').strip(); p['ans']=a
        val=float(__import__('fractions').Fraction(re.sub(r'\\dfrac\{(\d+)\}\{(\d+)\}',r'\1/\2',a))) if 'dfrac' in a else float(a)
        assert abs(val-KEY[i])<1e-6*max(1,val),i
        p['val']=val; p['chk']=lambda v=KEY[i]:v
        # prep compares with 1e-9: use the exact key value
        p['val']=KEY[i]
    p['steps']=[conv(x) for x in S[i]]; p['lines']=LINES.get(i,{'M':4,'H':5}[p['lv']])
    P.append(p)
P=prep(P)
for p in P: p['steps']=[x.replace('@@L@@',"ABCD"[p['correct']] if p.get('opts') else '?') for x in p['steps']]; assert '@@' not in ''.join(p['steps'])
json.dump([[p['id'],p['correct'] if p.get('opts') else p['val']] for p in P],open('keyed.json','w'))
meta=dict(title='Area and Volume',code='SAT-M \\textperiodcentered\\ Session 11',headfull='Session 11 \\textemdash\\ Area and Volume',
 time='3 hours: Part A in class (about 2 hours of solving), then Part B, the self-assessment, done independently (about 50 minutes), and a short error log.',
 topics='area of composite figures \\textperiodcentered\\ volume of prisms, cylinders, cones, spheres and pyramids \\textperiodcentered\\ surface area \\textperiodcentered\\ composite and carved solids \\textperiodcentered\\ similar figures and solids (scale factors for length, area, volume) \\textperiodcentered\\ right triangles inside solids \\textperiodcentered\\ unit conversion \\textperiodcentered\\ displacement and packing')
CHK=r"""\newcommand{\keyspacechk}[3]{\par\nopagebreak
 \setbox0\vbox{\hsize\linewidth\color{SOLGREEN}\small #3\par}%
 \setbox1\vbox{\foreach \i in {1,...,#2}{\par\vspace{0.74cm}{\color{LINE}\hrule height 0.4pt}}}%
 \ifdim\ht0>\ht1 \typeout{KEYOVER #1 \the\dimexpr\ht0-\ht1\relax}\dimen2=\ht0 \else \dimen2=\ht1 \fi
 \vbox to \dimen2{\nointerlineskip\vbox to 0pt{\box1\vss}\nointerlineskip\box0\vss}\par\vspace{4pt}}"""
def build_s(mode,out):
    key=(mode=='key')
    L=[PRE.replace("@@CODE@@",meta['code']).replace("@@HEAD@@",meta['headfull']).replace("\\begin{document}",EXTRA+CHK+r"\setmonofont[Scale=0.9]{DejaVu Sans Mono}\newcommand{\dzc}[1]{\colorbox{black!8}{\texttt{\small\textcolor{black}{#1}}}}"+"\n\\begin{document}")]
    L.append(r"""
\begin{tcolorbox}[enhanced,colback=NAVY!4,colframe=NAVY,boxrule=0.8pt,arc=3pt]
{\Large\bfseries\color{NAVY} SAT Math Mastery \textperiodcentered\ Session 11}\\[2pt]
{\large\bfseries %s}\\[3pt]
\begin{tabular}{@{}p{0.2\linewidth}p{0.75\linewidth}@{}}
\textbf{Time} & %s\\
\textbf{Topics} & %s\\
\textbf{Name / Date} & \rule{5.5cm}{0.3pt}\ \ \rule{3cm}{0.3pt}\\
\end{tabular}
\end{tcolorbox}
"""%(meta['title'],meta['time'],meta['topics']))
    L.append(r"\banner{Part A \textperiodcentered\ In class \textemdash\ %d problems}"%nA)
    L.append(r"\small Each problem states its tool. Write your work in the space below. Multiple choice: one correct option. Student-produced response (SPR): enter an exact value (fraction or decimal)."+(r" Grey boxes show exactly what to type in Desmos or on a calculator, one expression per line. Where a graph is used, tap a grey dot to read an intersection." if key else "")+r"\normalsize\par\vspace{4pt}")
    for i,p in enumerate(P,1):
        if i==nA+1: L.append(r"\par\needspace{9cm}\banner{Part B \textperiodcentered\ Self-assessment \textemdash\ %d problems}"%(len(P)-nA))
        t=problem_tex(i,p,mode)
        if key: t=t.replace(r"\keyspace{%d}{"%p['lines'],r"\keyspacechk{%d}{%d}{"%(i,p['lines']))
        L.append(t)
    L.append(r"\end{document}")
    open(out,'w').write("\n".join(L))
for mode,out in (('ws','S11_ws.tex'),('key','S11_key.tex')):
    build_s(mode,out)
    for _ in range(2): subprocess.run(['xelatex','-interaction=nonstopmode',out],capture_output=True,text=True)
    log=open(out[:-4]+'.log').read();print(out,'overfull',log.count('Overfull'),'err',len(re.findall(r'^!',log,re.M)))
    print(' '.join(re.findall(r'KEYOVER \d+ [\d.]+pt',log)))
