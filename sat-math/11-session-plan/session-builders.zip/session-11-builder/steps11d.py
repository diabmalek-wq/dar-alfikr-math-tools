"""Desmos steps for every Session 11 problem (overrides the first-pass steps for the items that had none)."""
from helpers import *
import math
D={}
def opt_check(good,bad,note=""):   # compare the correct option with a trap option, both typed
    return "Check the options by typing them: %s, and %s%s."%(lc(ret(good)),lc(ret(bad)),note)
D['GT-007']=["The courtyard is a rectangle plus a half circle. "+ret('12*8')+" for the rectangle.",
 "The half circle has radius $8\\div2=4$. "+ret('1/2*pi*(8/2)^2')+", which is $8\\pi$.",
 ret('12*8+1/2*pi*(8/2)^2')+" square meters.",
 "Type each option to match: "+lc(ret('96+8pi'))+", option (@@L@@). The option "+lc(ret('96+4pi'))+" does not match."]
D['GT-008']=[two('pi*15^2*x','4500*pi')+" (letting $x$ stand for the height).",
 "Tap the intersection: %s. Its $x$-value is the height."%inter('pi*15^2*x','4500*pi',0,100),
 ret('4500/15^2')+", the same height in meters.",
 "Check: "+lc(ret('pi*15^2*20'))+" equals "+lc(ret('4500pi'))+". Option (@@L@@)."]
D['GT-009']=["Volume scales with the cube of the scale factor. "+ret('20^3')+".",
 ret('3*20^3')+" cubic meters.",
 "Trap check: "+lc(ret('3*20^2'))+" and "+lc(ret('3*20'))+" come from the wrong power. Option (@@L@@)."]
D['GT-010']=["Cylinder: "+ret('pi*6^2*10')+", which is $360\\pi$.",
 "Hemisphere: "+ret('2/3*pi*6^3')+", which is $144\\pi$.",
 "Total: "+ret('pi*6^2*10+2/3*pi*6^3')+".",
 "Match the option: "+lc(ret('504pi'))+", option (@@L@@)."]
D['GT-016']=["Cylinder: "+ret('pi*4^2*12')+", which is $192\\pi$.",
 "Cone: "+ret('1/3*pi*4^2*3')+", which is $16\\pi$.",
 "Total: "+ret('pi*4^2*12+1/3*pi*4^2*3')+".",
 "Match the option: "+lc(ret('208pi'))+", option (@@L@@)."]
D['GT-019']=["Prism: "+ret('8*8*20')+".",
 "Channel (cylinder of radius $2$, length $20$): "+ret('pi*2^2*20')+", which is $80\\pi$.",
 "Remaining stone: "+ret('8*8*20-pi*2^2*20')+".",
 "Match the option: "+lc(ret('1280-80pi'))+", option (@@L@@)."]
D['GT-022']=["Whole cone: "+ret('1/3*pi*6^2*8')+".",
 "The small cone has height $4$, half of $8$, so every length is halved and the volume is multiplied by "+lc(ret('(4/8)^3'))+".",
 "Small cone: "+ret('1/3*pi*6^2*8*(4/8)^3')+".",
 "Match the option: "+lc(ret('12pi'))+", option (@@L@@)."]
D['GT-026']=["Area of the three different faces: "+ret('8*5')+", "+lc(ret('8*4'))+", "+lc(ret('5*4'))+".",
 "Each face appears twice. "+ret('2(8*5+8*4+5*4)')+".",
 "So the total surface area is $184$ square centimeters, option (@@L@@)."]
D['GT-027']=["Two bases: "+ret('2pi*5^2')+", which is $50\\pi$.",
 "Curved side: "+ret('2pi*5*12')+", which is $120\\pi$.",
 "Total: "+ret('2pi*5^2+2pi*5*12')+".",
 "Match the option: "+lc(ret('170pi'))+", option (@@L@@)."]
D['GT-032']=[two('6x^2','150')+" (letting $x$ stand for the edge $s$).",
 "Tap the intersection with $x>0$: %s. The edge is the $x$-value."%inter('6x^2','150',0.1,100),
 ret('5^3')+" cubic centimeters.",
 "Option (@@L@@)."]
D['GT-036']=["The square's side: "+ret('sqrt(400)')+", so $AB=20$.",
 "Leg $BE$ of the right triangle: "+ret('sqrt(20^2-12^2)')+".",
 "Area of the parallelogram, base times height: "+ret('33*16')+".",
 "Trap check: using the slanted side $AB$ as the height gives "+lc(ret('33*20'))+", which is wrong."]
D['GT-037']=["Pick $s=10$ so the numbers are easy. Original area: "+ret('10*0.4*10')+".",
 "New sides are $0.9s$ and $0.3s$. New area: "+ret('0.9*10*0.3*10')+".",
 "Percent decrease: "+ret('(40-27)/40*100')+".",
 "So the area decreases by $32.5\\%$. Enter $32.5$."]
D['GT-041']=None
D['GT-058']=None
D['GT-060']=["Area scales by the square of the scale factor. "+ret('3^2')+".",
 ret('24*3^2')+" square centimeters.",
 "Trap check: "+lc(ret('24*3'))+" would be the answer if area scaled like length.",
 "Enter $216$."]
D['GT-061']=[two('1/3*pi*x^2*9','48*pi')+" (letting $x$ stand for the radius).",
 "Tap the intersection with $x>0$: %s. The radius is the $x$-value."%inter('1/3*pi*x^2*9','48*pi',0.1,20),
 "Check: "+ret('1/3*pi*4^2*9')+" and "+lc(ret('48pi'))+" agree.",
 "The radius is $4$ centimeters."]
D['GT-078']=["Add the parallel sides and halve: "+ret('(14+22)/2')+".",
 "Multiply by the height: "+ret('(14+22)/2*9')+" square centimeters.",
 "Option (@@L@@)."]
D['GT-090']=[two('x^2','4x')+" (area and perimeter of a square with side $x$).",
 "Tap the intersection with $x>0$: %s. The side is $4$."%inter('x^2','4x',0.5,50),
 "Perimeter: "+ret('4*4')+".",
 "Enter $16$."]
D['GT-092']=["Side of the square: "+ret('sqrt(45)')+", which is $3\\sqrt5$.",
 "Rectangle area: "+ret('8*sqrt(45)')+".",
 "Match the option: "+lc(ret('24sqrt(5)'))+", option (@@L@@). The option "+lc(ret('45+8sqrt(5)'))+" does not match."]
D['GT-093']=["Radius: "+ret('10/2')+". Thickness in centimeters: "+lc(ret('3/10'))+".",
 "All $8$ coasters together: "+ret('8*pi*5^2*0.3')+".",
 "Match the option: "+lc(ret('60pi'))+", option (@@L@@)."]
D['GT-095']=["Area of one equilateral triangle with side $6$: "+ret('sqrt(3)/4*6^2')+", which is $9\\sqrt3$.",
 "Six triangles: "+ret('6*sqrt(3)/4*6^2')+".",
 "Divide by $\\sqrt3$ to find $k$: "+ret('6*6^2/4')+".",
 "Enter $54$."]
D['GT-096']=[two('6x^2','96')+" (letting $x$ stand for the edge).",
 "Tap the intersection with $x>0$: %s."%inter('6x^2','96',0.1,100),
 "Volume: "+ret('4^3')+" cubic centimeters.",
 "Enter $64$."]
D['GT-110']=["Volume ratio: "+ret('972/36')+".",
 "Scale factor: "+ret('(972/36)^(1/3)')+".",
 "Smaller edge: "+ret('12/3')+".",
 "Enter $4$."]
D['GT-113']=["Area ratio: "+ret('2520/630')+".",
 "Scale factor: "+ret('sqrt(2520/630)')+".",
 "Perimeter of the larger rectangle: "+ret('2*210')+".",
 "Option (@@L@@)."]
D['GT-114']=["Surface areas scale by the square of the edge ratio $B:A=\\dfrac{88}{3}$. "+ret('(88/3)^2')+".",
 "Match the fraction option: "+lc(ret('7744/9'))+".",
 "The reversed fraction gives "+lc(ret('(3/88)^2'))+", which is the trap. Option (@@L@@)."]
D['GT-116']=["Side of the base: "+ret('sqrt(100)')+".",
 "Slant height from the lateral area $100\\sqrt5$: "+ret('100sqrt(5)/(4*1/2*10)')+", which is $5\\sqrt5$.",
 "Height: "+ret('sqrt((100sqrt(5)/(4*1/2*10))^2-5^2)')+".",
 "Enter $10$."]
D['GT-119']=["Scale factor from the surface areas: "+ret('sqrt(400/144)')+", which is $\\dfrac53$.",
 "Volume of the larger crate: "+ret('108*(sqrt(400/144))^3')+".",
 "Option (@@L@@)."]
D['GT-120']=["Scale factor (small to large): "+ret('sqrt(208/325)')+", which is $\\dfrac45$.",
 "Volume of the smaller block: "+ret('375*(sqrt(208/325))^3')+".",
 "Enter $192$."]
D['GT-132']=["Radius of $A$: "+ret('8pi/(2pi)')+". Surface area of $A$: "+lc(ret('4pi*4^2'))+".",
 "Radius of $B$: "+ret('sqrt((4pi*4^2+80pi)/(4pi))')+".",
 "Volume ratio: "+ret('(6/4)^3')+".",
 "Match the option: "+lc(ret('27/8'))+", option (@@L@@)."]
D['GT-134']=["Side of the base: "+ret('10sqrt(2)/sqrt(2)')+".",
 "Height from the volume: "+ret('3*400/10^2')+".",
 "Slant height: "+ret('sqrt(12^2+5^2)')+".",
 "Lateral area: "+ret('4*1/2*10*13')+". Option (@@L@@)."]
D['GT-138']=[two('15*pi*(100-x^2)','765*pi')+" (letting $x$ stand for the inner radius).",
 "Tap the intersection with $0<x<10$: %s. The inner radius is $7$."%inter('15*pi*(100-x^2)','765*pi',0.01,9.99),
 "Thickness: "+ret('10-7')+".",
 "Enter $3$."]
D['GT-139']=["Half the base sides: "+ret('sqrt(13^2-12^2)')+" and "+lc(ret('sqrt(20^2-12^2)'))+", so the base is $10$ by $32$.",
 "Lateral area: "+ret('2*(1/2*32*13)+2*(1/2*10*20)')+".",
 "Total with the base: "+ret('2*(1/2*32*13)+2*(1/2*10*20)+10*32')+".",
 "Option (@@L@@)."]
D['GT-145']=["Surface area of $P$: "+ret('2pi*2^2+2pi*2*6')+", which is $32\\pi$.",
 "Scale factor: "+ret('sqrt(200pi/(32pi))')+".",
 "Volume of $Q$: "+ret('pi*(2*2.5)^2*(6*2.5)')+".",
 "Match the option: "+lc(ret('375pi'))+", option (@@L@@)."]
D['GT-149']=["Box $P$: surface area "+ret('2(3*4+3*6+4*6)')+" and volume $72$.",
 "Scale factor: "+ret('(1125/(3*4*6))^(1/3)')+".",
 "Surface area of $Q$: "+ret('108*2.5^2')+".",
 "Enter $675$."]
D['GT-158']=["Slanted side of the axial triangle: "+ret('sqrt(5^2+12^2)')+".",
 "Radius of the inscribed circle, area over semiperimeter: "+ret('(1/2*10*12)/((13+13+10)/2)')+", which is $\\dfrac{10}{3}$.",
 "Fraction of the cone filled: "+ret('(4/3*pi*(10/3)^3)/(1/3*pi*5^2*12)')+".",
 "Match the fraction: "+lc(ret('40/81'))+". Enter $\\dfrac{40}{81}$."]
D['GT-163']=["Surface-area ratio: "+ret('14.4/1.6')+".",
 "Scale factor: "+ret('sqrt(9)')+".",
 "Volume of the copy: "+ret('2.5*3^3')+".",
 "Option (@@L@@)."]
D['GT-171']=["Side of the base: "+ret('sqrt(100)')+".",
 "Height of one triangular face: "+ret('sqrt(13^2-5^2)')+".",
 "Four faces: "+ret('4*1/2*10*12')+".",
 "Option (@@L@@). Using $13$ as the face height gives "+lc(ret('4*1/2*10*13'))+", the trap."]
D['GT-201']=[two('pi*x^2*10','90*pi')+" (letting $x$ stand for the radius).",
 "Tap the intersection with $x>0$: %s. The radius is $3$."%inter('pi*x^2*10','90*pi',0.1,20),
 "Lateral area divided by $\\pi$: "+ret('2*3*10')+".",
 "Enter $60$."]
D['GT-202']=["Height from the right triangle: "+ret('sqrt(10^2-6^2)')+".",
 "Volume divided by $\\pi$: "+ret('1/3*6^2*8')+".",
 "Enter $96$."]
D['GT-203']=[two('4*pi*x^2','144*pi')+" (letting $x$ stand for the radius).",
 "Tap the intersection with $x>0$: %s. The radius is $6$."%inter('4*pi*x^2','144*pi',0.1,20),
 "Volume divided by $\\pi$: "+ret('4/3*6^3')+".",
 "Enter $288$."]
D['GT-204']=["Scale factor from the volume ratio $27:8$: "+ret('(27/8)^(1/3)')+".",
 "Surface area ratio: "+ret('1.5^2')+".",
 "Larger surface area: "+ret('40*1.5^2')+".",
 "Enter $90$."]
D['GT-205']=[two('6^2+8^2+x^2','26^2')+" (letting $x$ stand for the height).",
 "Tap the intersection with $x>0$: %s. The height is $24$."%inter('6^2+8^2+x^2','26^2',0.1,100),
 "Check: "+ret('sqrt(26^2-6^2-8^2)')+".",
 "Enter $24$."]
D['GT-207']=["Slant height of a face: "+ret('sqrt(8^2+6^2)')+".",
 "One face: "+ret('1/2*12*10')+".",
 "Four faces: "+ret('4*60')+".",
 "Enter $240$."]
D['GT-208']=["Edge from the space diagonal $e\\sqrt3=9\\sqrt3$: "+ret('9sqrt(3)/sqrt(3)')+".",
 "Volume: "+ret('9^3')+".",
 "Trap check: "+lc(ret('9^2'))+" is a face area, not the volume.",
 "Enter $729$."]
D['GT-209']=["Cubes along each edge: "+ret('10/2')+", "+lc(ret('12/2'))+", "+lc(ret('16/2'))+".",
 "Total: "+ret('5*6*8')+".",
 "Check with volumes: "+ret('10*12*16/2^3')+".",
 "Enter $240$."]
D['GT-210']=["Cylinder: "+ret('pi*5^2*12')+".",
 "Cone: "+ret('1/3*pi*5^2*12')+".",
 "Number of cones: "+ret('(pi*5^2*12)/(1/3*pi*5^2*12)')+".",
 "Enter $3$."]
D['GT-212']=["Cylinder: "+ret('pi*3^2*7')+".",
 "Bowl (hemisphere): "+ret('2/3*pi*3^3')+".",
 "Solid divided by $\\pi$: "+ret('(pi*3^2*7-2/3*pi*3^3)/pi')+".",
 "Enter $45$."]
