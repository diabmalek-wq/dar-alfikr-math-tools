"""Solution steps for Session 11. Numbers quoted in steps are computed here from the item data (given numbers typed once as constants),
and every typed expression that 'returns' a value is evaluated by ev(). 'option (@@L@@)' is filled with the correct letter at build time."""
import math
from fractions import Fraction as Fr
import numpy as np
from helpers import *
pi=math.pi
S={}; T={}   # steps ; tool tag (N default, C calculator, D desmos)
def sq(x): return x*x
# ---- 007
rect=12*8; r7=8/2; semi=0.5*sq(r7); trap7=0.5*sq(8)
S['GT-007']=["The courtyard is a rectangle plus a half circle. The rectangle has area $12\\times8=%s$."%n(rect),
 "The half circle has diameter $8$, so its radius is $%s$ (not $8$). Its area is $\\dfrac12\\pi r^2=\\dfrac12\\pi(%s)^2=%s$."%(n(r7),n(r7),Pi(semi)),
 "Add the two pieces: $%s+%s$, which is option (@@L@@). Using the diameter as the radius would give $\\dfrac12\\pi(8)^2=%s$, the trap."%(n(rect),n(semi)+"\\pi",Pi(trap7))]
# ---- 008
h8=4500/(15**2)
S['GT-008']=["Volume of a cylinder: $V=\\pi r^2h$. Put in $r=15$ and $V=4500\\pi$: $4500\\pi=\\pi(15)^2h=%s\\pi h$."%n(15**2),
 "Divide both sides by $%s\\pi$: $h=\\dfrac{4500}{%s}=%s$."%(n(15**2),n(15**2),n(h8)),
 "The height is $%s$ meters, option (@@L@@)."%n(h8)]
# ---- 009
k9=20; vol9=3*k9**3
S['GT-009']=["Lengths are $20$ times bigger, but volume is a cubic quantity, so the volume is multiplied by $20^3=%s$ (not by $20$ and not by $20^2=%s$)."%(n(k9**3),n(k9**2)),
 "Actual volume: $3\\times%s=%s$ cubic meters."%(n(k9**3),n(vol9)),
 "That is option (@@L@@). The trap answers come from multiplying by $20^2$, which gives $%s$, or by $20$, which gives $%s$."%(n(3*k9**2),n(3*k9))]
# ---- 010
cyl10=6**2*10; hem10=Fr(2,3)*6**3
S['GT-010']=["Split the building into a cylinder and a hemisphere. Cylinder: $\\pi r^2h=\\pi(6)^2(10)=%s$."%Pi(cyl10),
 "Hemisphere (half a sphere): $\\dfrac23\\pi r^3=\\dfrac23\\pi(6)^3=\\dfrac23\\pi(%s)=%s$."%(n(6**3),Pi(float(hem10))),
 "Add: $%s+%s=%s$, option (@@L@@)."%(n(cyl10)+"\\pi",n(float(hem10))+"\\pi",Pi(cyl10+float(hem10)))]
# ---- 016
cyl16=4**2*12; cone16=Fr(1,3)*4**2*3
S['GT-016']=["Split the silo into a cylinder and a cone. Cylinder: $\\pi r^2h=\\pi(4)^2(12)=%s$."%Pi(cyl16),
 "Cone: $\\dfrac13\\pi r^2h=\\dfrac13\\pi(4)^2(3)=%s$."%Pi(float(cone16)),
 "Add: $%s+%s=%s$, option (@@L@@)."%(n(cyl16)+"\\pi",n(float(cone16))+"\\pi",Pi(cyl16+float(cone16)))]
# ---- 019
pr19=8*8*20; hole19=2**2*20
S['GT-019']=["Remaining stone = whole prism minus the channel. Prism: $8\\times8\\times20=%s$."%n(pr19),
 "The channel is a cylinder of radius $2$ and length $20$: $\\pi r^2h=\\pi(2)^2(20)=%s$."%Pi(hole19),
 "Subtract: $%s-%s$, option (@@L@@)."%(n(pr19),n(hole19)+"\\pi")]
# ---- 022
full22=Fr(1,3)*6**2*8; sc22=Fr(4,8); rs22=6*sc22; small22=Fr(1,3)*rs22**2*4
S['GT-022']=["The cut is at $4$ cm from the apex, half of the full height $8$, so the small cone is similar to the big one with scale factor $\\dfrac12$. Its radius is $%s$ cm."%n(float(rs22)),
 "Small cone: $V=\\dfrac13\\pi r^2h=\\dfrac13\\pi(%s)^2(4)=%s$."%(n(float(rs22)),Pi(float(small22))),
 "Check with the scale factor: the whole cone is $\\dfrac13\\pi(6)^2(8)=%s$ and volume scales by $\\left(\\dfrac12\\right)^3=\\dfrac18$, so $%s\\div8=%s$. Option (@@L@@)."%(Pi(float(full22)),n(float(full22)),Pi(float(full22)/8))]
assert abs(float(small22)-float(full22)/8)<1e-12
# ---- 026
lw,lh,wh=8*5,8*4,5*4; sa26=2*(lw+lh+wh)
S['GT-026']=["A box has $6$ faces in $3$ pairs: length by width, length by height, width by height."%(),
 "The three face areas: $8\\times5=%s$, $8\\times4=%s$, $5\\times4=%s$. Their sum is $%s$."%(n(lw),n(lh),n(wh),n(lw+lh+wh)),
 "Each face appears twice: $2\\times%s=%s$ square centimeters, option (@@L@@)."%(n(lw+lh+wh),n(sa26))]
# ---- 027
b27=2*5**2; l27=2*5*12
S['GT-027']=["Total surface area includes both circular bases and the curved side: $SA=2\\pi r^2+2\\pi rh$."%(),
 "Two bases: $2\\pi(5)^2=%s$. Curved side: $2\\pi(5)(12)=%s$."%(Pi(b27),Pi(l27)),
 "Add: $%s+%s=%s$, option (@@L@@)."%(n(b27)+"\\pi",n(l27)+"\\pi",Pi(b27+l27))]
# ---- 032
s32=math.sqrt(150/6)
S['GT-032']=["A cube has $6$ equal square faces, so $6s^2=150$ and $s^2=\\dfrac{150}{6}=%s$."%n(150/6),
 "Then $s=\\sqrt{%s}=%s$ centimeters."%(n(150/6),n(s32)),
 "Volume: $s^3=%s^3=%s$, option (@@L@@)."%(n(s32),n(s32**3))]
# ---- 036
ab=math.sqrt(400); be=math.sqrt(ab**2-12**2); ar36=33*be
S['GT-036']=["The square has area $400$, so its side is $\\sqrt{400}=%s$. Side $AB$ equals a side of the square, so $AB=%s$."%(n(ab),n(ab)),
 "In right triangle $ABE$ the hypotenuse is $AB=%s$ and one leg is $AE=12$, so $BE=\\sqrt{%s^2-12^2}=\\sqrt{%s}=%s$. (This is the $3$-$4$-$5$ triangle scaled by $4$: $12,\\,%s,\\,%s$.)"%(n(ab),n(ab),n(ab**2-144),n(be),n(be),n(ab)),
 "$BE$ is the height of the parallelogram: it is perpendicular to the line of $AD$. The area is base times height: $33\\times%s=%s$."%(n(be),n(ar36)),
 "Do not use $AB=%s$ as the height. That is a slanted side, and would give $33\\times%s=%s$."%(n(ab),n(ab),n(33*ab))]
# ---- 037
a0=0.4; a1=0.9*0.3; pc=(a0-a1)/a0*100
S['GT-037']=["Original area: $s\\cdot0.4s=%ss^2$."%n(a0),
 "New sides: length $s-0.1s=0.9s$ and width $0.4s-0.1s=0.3s$. New area: $0.9s\\cdot0.3s=%ss^2$."%n(a1),
 "Percent decrease $=\\dfrac{\\text{old}-\\text{new}}{\\text{old}}=\\dfrac{%s-%s}{%s}=%s$, which is $%s\\%%$. (Do not subtract the percentages $10\\%%$ and $25\\%%$.)"%(n(a0),n(a1),n(a0),n((a0-a1)/a0),n(pc))]
# ---- 041
S['GT-041']=["Volume of water = base area times depth. "+ret('8*5*4.5')+" cubic feet.",
 "Weight = volume times density. "+ret('180*62.4')+" pounds.",
 "Enter $%s$ (no comma) as the answer."%n(ev('180*62.4'),0)]
# ---- 058
S['GT-058']=["The circumference of the base is $2\\pi r=44\\pi$, so $r=\\dfrac{44\\pi}{2\\pi}=%s$ meters."%n(44/2),
 "Volume of a cylinder: $V=\\pi r^2h=\\pi(22)^2(15)$. "+ret('22^2*15')+", so $V=%s$."%Pi(ev('22^2*15')),
 "The question writes the volume as $k\\pi$, so $k=%s$."%n(ev('22^2*15'),0)]
# ---- 059
S['GT-059']=["Hemisphere volume: $V=\\dfrac23\\pi r^3$ with $r=18$. First the cube: "+lc(ret('18^3'))+".",
 ret('2/3*pi*18^3')+", so the volume is about $%s$ cubic inches."%th(ev('2/3*pi*18^3')),
 "The closest option is $12{,}200$, option (@@L@@). The full sphere, $\\dfrac43\\pi r^3$, would be about $%s$, which is the trap option."%th(ev('4/3*pi*18^3'))]
T['GT-059']='C'
# ---- 060
S['GT-060']=["Similar rectangles: lengths scale by $3$, so areas scale by $3^2=%s$."%n(9),
 "Area of $A$ $=24\\times%s=%s$ square centimeters."%(n(9),n(24*9))]
S['GT-060'].append("The trap answer $24\\times3=%s$ forgets that area is two-dimensional."%n(24*3))
# ---- 061
r61=math.sqrt(48*3/9)
S['GT-061']=["Cone: $V=\\dfrac13\\pi r^2h$. Put in $V=48\\pi$ and $h=9$: $48\\pi=\\dfrac13\\pi r^2(9)=%s\\pi r^2$."%n(9/3),
 "Divide by $%s\\pi$: $r^2=\\dfrac{48}{%s}=%s$."%(n(9/3),n(9/3),n(48/(9/3))),
 "So $r=\\sqrt{%s}=%s$ centimeters."%(n(48/(9/3)),n(r61))]
# ---- 077
S['GT-077']=["Cylinder: $V=\\pi r^2h$ with $\\pi\\approx3.14$, $r=3$, $h=8$. "+ret('3.14*3^2*8')+".",
 "Round to one decimal place: $%s$, option (@@L@@)."%n(ev('3.14*3^2*8'),1),
 "Check the trap: using $r=6$ or forgetting to square $r$ gives a very different number, such as "+ret('3.14*3*8')[0].lower()+ret('3.14*3*8')[1:]+" (not an option)."]
S['GT-077'][2]="Check: forgetting to square the radius gives "+ret('3.14*3*8')[0].lower()+ret('3.14*3*8')[1:]+", which is not the best match."
T['GT-077']='C'
S['GT-077'][2]="Check the traps: forgetting to square $r$ gives $%s$, and using the diameter $6$ as the radius gives $%s$."%(n(ev('3.14*3*8'),1),n(ev('3.14*6^2*8'),1))
# ---- 078
sm78=14+22
S['GT-078']=["Trapezoid area: $\\dfrac12(b_1+b_2)h$, where $b_1$ and $b_2$ are the parallel sides and $h$ is the height (the perpendicular distance)."%(),
 "Add the parallel sides: $14+22=%s$."%n(sm78),
 "Area $=\\dfrac12(%s)(9)=%s$ square centimeters, option (@@L@@)."%(n(sm78),n(0.5*sm78*9))]
# ---- 079
S['GT-079']=["Cone volume: $V=\\dfrac13\\pi r^2h$ with $\\pi\\approx3.14$, $r=6$, $h=10$. "+ret('1/3*3.14*6^2*10')+".",
 "By hand: $6^2=%s$, and $\\dfrac13\\cdot3.14\\cdot%s\\cdot10=%s$, option (@@L@@)."%(n(36),n(36),n(ev('1/3*3.14*36*10'))),
 "Check the traps: forgetting the $\\dfrac13$ gives $%s$, and swapping $r$ and $h$ gives $%s$."%(n(ev('3.14*6^2*10'),1),n(ev('1/3*3.14*10^2*6'),1))]
T['GT-079']='C'
# ---- 080
S['GT-080']=["Sphere surface area: $SA=4\\pi r^2$ with $\\pi\\approx3.14$ and $r=5$. First $r^2=%s$."%n(25),
 ret('4*3.14*5^2')+".",
 "That is option (@@L@@). A wrong formula gives a trap: for example $2\\pi r^2$ gives $%s$."%n(ev('2*3.14*5^2'),1)]
T['GT-080']='C'
# ---- 090
S['GT-090']=["Let the side be $s$. Perimeter $=4s$ and area $=s^2$. Set them equal: $s^2=4s$.",
 "Rearrange: $s^2-4s=0$, so $s(s-4)=0$. The side cannot be $0$, so $s=4$.",
 "The perimeter is $4\\times4=%s$."%n(4*4)]
# ---- 092
bc=math.sqrt(45); ar92=8*bc
S['GT-092']=["The square $BCEF$ has area $45$, so its side is $BC=\\sqrt{45}=\\sqrt{9\\cdot5}=3\\sqrt5$ (about $%s$)."%n(bc,3),
 "The rectangle has sides $AB=8$ and $BC=3\\sqrt5$, so its area is $8\\cdot3\\sqrt5=24\\sqrt5$ (about $%s$)."%n(ar92,3),
 "That is option (@@L@@). The option $45+8\\sqrt5$ wrongly adds the two shapes' areas."]
# ---- 093
r93=10/2; t93=3/10; one93=r93**2*t93; tot93=8*one93
S['GT-093']=["Diameter $10$ cm means radius $%s$ cm. The thickness is $3$ mm, which is $%s$ cm (convert before multiplying)."%(n(r93),n(t93))," One coaster: $\\pi r^2h=\\pi(%s)^2(%s)=%s$ cubic centimeters."%(n(r93),n(t93),Pi(one93)),
 "Eight coasters: $8\\times%s=%s$ cubic centimeters, option (@@L@@)."%(n(one93)+"\\pi",Pi(tot93))]
S['GT-093'][1]=S['GT-093'][1].strip()
# ---- 095
t95=(math.sqrt(3)/4*6**2)/math.sqrt(3); hx95=6*t95
S['GT-095']=["Each small triangle is equilateral with side $6$. Area of an equilateral triangle: $\\dfrac{\\sqrt3}{4}s^2=\\dfrac{\\sqrt3}{4}(6)^2=%s\\sqrt3$."%n(t95),
 "The hexagon is $6$ of these triangles: $6\\times%s\\sqrt3=%s\\sqrt3$."%(n(t95),n(hx95)),
 "The question writes the area as $k\\sqrt3$, so $k=%s$."%n(hx95)]
# ---- 096
s96=math.sqrt(96/6)
S['GT-096']=["A cube has $6$ equal faces: $6s^2=96$, so $s^2=\\dfrac{96}{6}=%s$."%n(96/6),
 "Then $s=\\sqrt{%s}=%s$ centimeters."%(n(96/6),n(s96)),
 "Volume: $s^3=%s^3=%s$ cubic centimeters."%(n(s96),n(s96**3))]
# ---- 110
r110=972/36; k110=round(r110**(1/3))
S['GT-110']=["Volumes of similar solids: the ratio is the scale factor cubed. $\\dfrac{972}{36}=%s$."%n(r110),
 "The scale factor is $\\sqrt[3]{%s}=%s$ (because $%s^3=%s$)."%(n(r110),n(k110),n(k110),n(k110**3)),
 "The larger edge is $12$, so the smaller edge is $\\dfrac{12}{%s}=%s$."%(n(k110),n(12/k110))]
assert k110**3==r110
# ---- 113
ar113=2520/630; k113=math.sqrt(ar113)
S['GT-113']=["Area ratio of the similar rectangles: $\\dfrac{2520}{630}=%s$."%n(ar113),
 "Areas scale by the square of the scale factor, so the scale factor is $\\sqrt{%s}=%s$."%(n(ar113),n(k113)),
 "Perimeters scale by the scale factor itself: $n=%s\\times210=%s$, option (@@L@@). Multiplying by the area ratio $%s$ would give $%s$, the trap."%(n(k113),n(k113*210),n(ar113),n(ar113*210))]
# ---- 114
rat114=88/3
S['GT-114']=["The question asks for $B$ to $A$, so flip the given ratio: edge of $B$ to edge of $A$ is $\\dfrac{88}{3}$."%(),
 "Surface areas scale by the square of the edge ratio: $\\left(\\dfrac{88}{3}\\right)^2=\\dfrac{88^2}{3^2}=\\dfrac{%s}{%s}$."%(n(88**2),n(3**2)),
 "That is option (@@L@@). Options with $\\dfrac3{88}$ or $\\dfrac{88}{3}$ forget to square, and $\\dfrac{%s}{%s}$ has $B$ and $A$ the wrong way round."%(n(3**2),n(88**2))]
# ---- 116
side116=math.sqrt(100); lat116=100*math.sqrt(5); l116=lat116/(4*0.5*side116); h116=math.sqrt(l116**2-(side116/2)**2)
S['GT-116']=["The base is a square of area $100$, so its side is $%s$. The total surface area is base plus lateral, so the four triangular faces have area $100\\sqrt5$."%n(side116),
 "Each triangle has base $%s$ and slant height $\\ell$: $4\\cdot\\dfrac12(%s)\\ell=%s\\ell=100\\sqrt5$, so $\\ell=5\\sqrt5$ (and $\\ell^2=%s$)."%(n(side116),n(side116),n(4*0.5*side116),n(l116**2)),
 "Make a right triangle with the height $h$, half the base $%s$ and the slant height $\\ell$: $h^2+%s^2=\\ell^2$."%(n(side116/2),n(side116/2)),
 "So $h=\\sqrt{%s-%s}=\\sqrt{%s}=%s$."%(n(l116**2),n((side116/2)**2),n(l116**2-(side116/2)**2),n(h116))]
# ---- 119
k119=math.sqrt(400/144); v119=108*k119**3
S['GT-119']=["Surface areas of similar solids: ratio $\\dfrac{400}{144}=\\dfrac{%s}{%s}$, which is the square of the scale factor."%(n(25),n(9)),
 "So the scale factor is $\\sqrt{\\dfrac{%s}{%s}}=\\dfrac{%s}{%s}$, and the volume ratio is its cube: $\\left(\\dfrac53\\right)^3=\\dfrac{%s}{%s}$."%(n(25),n(9),n(5),n(3),n(5**3),n(3**3)),
 "Larger volume: $108\\times\\dfrac{%s}{%s}=%s\\times%s=%s$ cubic feet, option (@@L@@)."%(n(5**3),n(3**3),n(108/27),n(5**3),n(v119))]
assert abs(k119-5/3)<1e-12
# ---- 120
k120=math.sqrt(208/325); v120=375*k120**3
S['GT-120']=["Surface area ratio (small to large): $\\dfrac{208}{325}=\\dfrac{%s}{%s}$, the square of the scale factor."%(n(16),n(25)),
 "Scale factor (small to large): $\\sqrt{\\dfrac{%s}{%s}}=\\dfrac{%s}{%s}$. The volume ratio is its cube: $\\dfrac{%s}{%s}$."%(n(16),n(25),n(4),n(5),n(4**3),n(5**3)),
 "The smaller block has $375\\times\\dfrac{%s}{%s}=%s\\times%s=%s$ cubic centimeters."%(n(4**3),n(5**3),n(375/125),n(4**3),n(v120))]
assert abs(k120-4/5)<1e-12
# ---- 130
rts=sorted(np.roots([1,0,-28,48]).real)    # x^3-28x+48=0  <=>  x^2+48/x=28
S['GT-130']=["Volume: $\\pi r^2h=48\\pi$, so $h=\\dfrac{48}{r^2}$. Surface area: $2\\pi r^2+2\\pi rh=56\\pi$, so $r^2+rh=28$. Substitute $h$: $r^2+\\dfrac{48}{r}=28$.",
 "In Desmos type %s and %s (letting $x$ stand for $r$)."%(c('y=x^2+48/x'),c('y=28')),
 "Tap the intersections with $x>0$: %s and %s. (The point with $x=%s$ is not allowed: a radius cannot be negative.)"%(pt(round(rts[1]),28),pt(round(rts[2]),28),n(round(rts[0]))),
 "Heights: "+lc(ret('48/2^2'))+" for $r=2$, and "+lc(ret('48/4^2'))+" for $r=4$. Only $r=2$ has height greater than the diameter ($%s>%s$). The height is $%s$, option (@@L@@)."%(n(48/4),n(2*2),n(48/4))]
T['GT-130']='D'
# ---- 132
rA=8*pi/(2*pi); sA=4*rA**2; sB=sA+80; rB=math.sqrt(sB/4); vr=(rB/rA)**3
S['GT-132']=["Sphere $A$: a great circle has circumference $2\\pi r=8\\pi$, so $r_A=%s$. Its surface area is $4\\pi r^2=%s$."%(n(rA),Pi(sA)),
 "Sphere $B$ has $80\\pi$ more: $%s+80\\pi=%s$. Then $4\\pi r_B^2=%s$, so $r_B^2=%s$ and $r_B=%s$."%(n(sA)+"\\pi",Pi(sB),n(sB)+"\\pi",n(sB/4),n(rB)),
 "Volumes of spheres scale as the cube of the radius: $\\dfrac{V_B}{V_A}=\\left(\\dfrac{%s}{%s}\\right)^3=\\left(\\dfrac32\\right)^3=\\dfrac{%s}{%s}$, option (@@L@@)."%(n(rB),n(rA),n(27),n(8))]
assert abs(vr-27/8)<1e-12
# ---- 134
sd134=10; hh134=3*400/(sd134**2); sl134=math.sqrt(hh134**2+(sd134/2)**2); lat134=4*0.5*sd134*sl134
S['GT-134']=["The base is a square whose diagonal is $10\\sqrt2$, so its side is $\\dfrac{10\\sqrt2}{\\sqrt2}=%s$ and its area is $%s$."%(n(sd134),n(sd134**2)),
 "Volume $=\\dfrac13(\\text{base area})h$: $400=\\dfrac13(%s)h$, so $h=\\dfrac{3\\cdot400}{%s}=%s$."%(n(sd134**2),n(sd134**2),n(hh134)),
 "Slant height: right triangle with the height $%s$ and half the base $%s$, so $\\ell=\\sqrt{%s^2+%s^2}=\\sqrt{%s}=%s$."%(n(hh134),n(sd134/2),n(hh134),n(sd134/2),n(hh134**2+(sd134/2)**2),n(sl134)),
 "Four faces: $4\\cdot\\dfrac12(%s)(%s)=%s$ square centimeters, option (@@L@@)."%(n(sd134),n(sl134),n(lat134))]
# ---- 138
r_in=math.sqrt(100-765/15); t138=10-r_in
S['GT-138']=["Metal volume $=$ (outer circle area $-$ inner circle area) times length: $\\pi(10^2-r^2)(15)=765\\pi$, where $r=10-t$ is the inner radius."%(),
 "Divide by $15\\pi$: $10^2-r^2=\\dfrac{765}{15}=%s$, so $r^2=%s-%s=%s$."%(n(765/15),n(100),n(765/15),n(100-765/15)),
 "So $r=%s$, and the wall thickness is $t=10-r=10-%s=%s$."%(n(r_in),n(r_in),n(t138))]
# ---- 139
a139=math.sqrt(13**2-12**2); b139=math.sqrt(20**2-12**2)
f13=0.5*(2*b139)*13; f20=0.5*(2*a139)*20; base139=(2*a139)*(2*b139); tot139=2*f13+2*f20+base139
S['GT-139']=["Look at the right triangle formed by the height $12$, the slant height and the distance from the center of the base to the edge. For slant height $13$: distance $=\\sqrt{13^2-12^2}=%s$. For slant height $20$: distance $=\\sqrt{20^2-12^2}=%s$."%(n(a139),n(b139)),
 "So the base measures $2(%s)=%s$ by $2(%s)=%s$. The faces with slant height $13$ sit on the long sides (length $%s$), the faces with slant height $20$ on the short sides (length $%s$)."%(n(a139),n(2*a139),n(b139),n(2*b139),n(2*b139),n(2*a139)),
 "Face areas: two of $\\dfrac12(%s)(13)=%s$ and two of $\\dfrac12(%s)(20)=%s$, so the lateral area is $%s+%s=%s$."%(n(2*b139),n(f13),n(2*a139),n(f20),n(2*f13),n(2*f20),n(2*f13+2*f20)),
 "Add the base $%s\\times%s=%s$: total $%s+%s=%s$ square centimeters, option (@@L@@)."%(n(2*a139),n(2*b139),n(base139),n(2*f13+2*f20),n(base139),n(tot139))]
# ---- 142
area142=ev('(1.5+3.5)/2*8'); vol142=area142*12; cost142=vol142/27*45
S['GT-142']=["The soil's cross-section is a trapezoid with parallel sides $1.5$ and $3.5$ and width $8$. "+ret('(1.5+3.5)/2*8')+" square feet.",
 "Volume $=$ cross-section area $\\times$ length. "+ret('20*12')+" cubic feet.",
 "Convert to cubic yards: $1$ yard $=3$ feet, so $1$ cubic yard $=3^3=%s$ cubic feet. "%n(27)+ret('240/27*45')+" dollars.",
 "The cost is $%s$ dollars."%n(cost142)]
T['GT-142']='C'
assert abs(area142-20)<1e-12 and abs(vol142-240)<1e-12
# ---- 145
sa_p=2*2**2+2*2*6; kk=math.sqrt(200/sa_p); rq=2*kk; hq=6*kk; vq=rq**2*hq
S['GT-145']=["Surface area of $P$: $2\\pi r^2+2\\pi rh=2\\pi(2)^2+2\\pi(2)(6)=%s+%s=%s$."%(n(2*2**2)+"\\pi",n(2*2*6)+"\\pi",Pi(sa_p)),
 "Surface areas of similar solids scale by $k^2$: $k^2=\\dfrac{200}{%s}=%s$, so the scale factor is $k=%s$."%(n(sa_p),n(200/sa_p),n(kk)),
 "Cylinder $Q$ has radius $2\\times%s=%s$ and height $6\\times%s=%s$. Check: $2\\pi(%s)^2+2\\pi(%s)(%s)=%s\\pi$."%(n(kk),n(rq),n(kk),n(hq),n(rq),n(rq),n(hq),n(2*rq**2+2*rq*hq)),
 "Volume of $Q$: $\\pi r^2h=\\pi(%s)^2(%s)=%s$, option (@@L@@)."%(n(rq),n(hq),Pi(vq))]
assert abs(2*rq**2+2*rq*hq-200)<1e-9
# ---- 149
vP=3*4*6; saP=2*(3*4+3*6+4*6); kq=(1125/vP)**(1/3); saQ=saP*kq**2
S['GT-149']=["Box $P$: volume $3\\cdot4\\cdot6=%s$ and surface area $2(12+18+24)=%s$."%(n(vP),n(saP)),
 "Volume ratio $\\dfrac{1125}{%s}=%s$, which is the cube of the scale factor $k$. So $k=\\sqrt[3]{%s}=%s$."%(n(vP),n(1125/vP),n(1125/vP),n(kq)),
 "Surface areas scale by $k^2=%s$: $%s\\times%s=%s$ square inches."%(n(kq**2),n(saP),n(kq**2),n(saQ)),
 "Check: box $Q$ is $%s\\times%s\\times%s$ and $2(%s+%s+%s)=%s$."%(n(3*kq),n(4*kq),n(6*kq),n(3*kq*4*kq),n(3*kq*6*kq),n(4*kq*6*kq),n(2*(3*kq*4*kq+3*kq*6*kq+4*kq*6*kq)))]
# ---- 153
S['GT-153']=["Convert to centimeters first ($10$ mm $=1$ cm): the cylinder has radius $3$ cm and height $4$ cm, and the hole has radius $1$ cm and depth $2.5$ cm.",
 "Whole cylinder: "+ret('pi*3^2*4')+" (cm$^3$). Hole: "+lc(ret('pi*1^2*2.5'))+" (cm$^3$).",
 "Metal left: "+ret('pi*3^2*4-pi*1^2*2.5')+" (cm$^3$).",
 "Mass $=$ volume $\\times$ density. "+ret('(pi*3^2*4-pi*1^2*2.5)*7.8')+", so about $821$ grams, option (@@L@@). Ignoring the hole gives $"+n(ev('pi*3^2*4*7.8'),0)+"$, the trap."]
T['GT-153']='C'
# ---- 158
hc,rc=12,5; sl=math.hypot(hc,rc); area=0.5*2*rc*hc; semi_p=(2*sl+2*rc)/2; rho=area/semi_p
vs=Fr(4,3)*Fr(10,3)**3; vc=Fr(1,3)*25*12; ratio=vs/vc
S['GT-158']=["Cut the cone and sphere through the axis: you see an isosceles triangle (base $2\\times5=%s$, height $12$) with the sphere as its inscribed circle. The slanted side is $\\sqrt{5^2+12^2}=%s$."%(n(2*rc),n(sl)),
 "The inscribed circle's radius is $\\dfrac{\\text{area}}{\\text{semiperimeter}}=\\dfrac{\\frac12(%s)(12)}{(%s+%s+%s)/2}=\\dfrac{%s}{%s}=\\dfrac{10}{3}$."%(n(2*rc),n(sl),n(sl),n(2*rc),n(area),n(semi_p)),
 "Sphere volume: $\\dfrac43\\pi\\left(\\dfrac{10}{3}\\right)^3=\\dfrac{%s\\pi}{%s}$. Cone volume: $\\dfrac13\\pi(5)^2(12)=%s\\pi$."%(n(vs.numerator*Fr(1,1).numerator if False else (vs).numerator),n(vs.denominator),n(float(vc))),
 "Fraction occupied: $\\dfrac{%s/%s}{%s}=\\dfrac{%s}{%s}$."%(n(vs.numerator),n(vs.denominator),n(float(vc)),n(ratio.numerator),n(ratio.denominator))]
assert abs(rho-10/3)<1e-12 and ratio==Fr(40,81)
# ---- 163
rs163=14.4/1.6; k163=math.sqrt(rs163); v163=2.5*k163**3
S['GT-163']=["Sealant is proportional to surface area, so the surface area ratio is $\\dfrac{14.4}{1.6}=%s$."%n(rs163),
 "Surface area scales by $k^2$, so the scale factor is $k=\\sqrt{%s}=%s$."%(n(rs163),n(k163)),
 "Volume scales by $k^3=%s^3=%s$: $2.5\\times%s=%s$ cubic feet, option (@@L@@)."%(n(k163),n(k163**3),n(k163**3),n(v163))]
# ---- 165
S['GT-165']=["Volume ratio of the aquariums: $\\dfrac{432}{250}=%s$. Volumes scale by $k^3$, so find $k$: "%n(432/250)+ret('(432/250)^(1/3)')+".",
 "Glass area scales by $k^2$. "+ret('400*1.2^2')+" square decimeters.",
 "The larger aquarium has $%s$ square decimeters of glass. (Using $k^3$ instead would give $%s$.)"%(n(ev('400*1.2^2'),0),n(ev('400*1.2^3'),1))]
T['GT-165']='C'
# ---- 171
sd=math.sqrt(100); sl171=math.sqrt(13**2-(sd/2)**2); lat171=4*0.5*sd*sl171
S['GT-171']=["The base has area $100$, so its side is $\\sqrt{100}=%s$. Each triangular face has base $%s$ and two equal sides of length $13$ (the edges from the apex)."%(n(sd),n(sd)),
 "Draw the height of one face, from the apex edge down to the middle of the base. It splits the base in halves of $%s$, so $h_{\\text{face}}=\\sqrt{13^2-%s^2}=\\sqrt{%s}=%s$."%(n(sd/2),n(sd/2),n(13**2-(sd/2)**2),n(sl171)),
 "One face: $\\dfrac12(%s)(%s)=%s$. Four faces: $4\\times%s=%s$ square inches, option (@@L@@)."%(n(sd),n(sl171),n(0.5*sd*sl171),n(0.5*sd*sl171),n(lat171)),
 "The trap: treating $13$ as the face height gives $4\\cdot\\dfrac12(%s)(13)=%s$."%(n(sd),n(4*0.5*sd*13))]
# ---- 201
r201=math.sqrt(90/10); lat201=2*r201*10
S['GT-201']=["Volume: $\\pi r^2(10)=90\\pi$, so $r^2=\\dfrac{90}{10}=%s$ and $r=%s$."%(n(90/10),n(r201)),
 "Lateral surface (no bases): $2\\pi rh=2\\pi(%s)(10)=%s$."%(n(r201),Pi(lat201)),
 "So $k=%s$."%n(lat201)]
# ---- 202
h202=math.sqrt(10**2-6**2); v202=36*h202/3
S['GT-202']=["The radius, height and slant height form a right triangle: $h=\\sqrt{10^2-6^2}=\\sqrt{%s}=%s$."%(n(10**2-6**2),n(h202)),
 "Volume: $\\dfrac13\\pi r^2h=\\dfrac13\\pi(36)(%s)=%s$."%(n(h202),Pi(v202)),
 "So $k=%s$."%n(v202)]
# ---- 203
r203=math.sqrt(144/4); v203=4/3*r203**3
S['GT-203']=["Surface area: $4\\pi r^2=144\\pi$, so $r^2=\\dfrac{144}{4}=%s$ and $r=%s$."%(n(144/4),n(r203)),
 "Volume: $\\dfrac43\\pi r^3=\\dfrac43\\pi(%s)^3=\\dfrac43\\pi(%s)=%s$."%(n(r203),n(r203**3),Pi(v203)),
 "So $k=%s$."%n(v203)]
# ---- 204
kl=(27/8)**(1/3); sa204=40*(kl)**2
S['GT-204']=["Volumes of similar solids are in the ratio $8:27=2^3:3^3$, so the lengths are in the ratio $2:3$, that is the scale factor is $\\dfrac32$."%(),
 "Surface areas scale by the square: $\\left(\\dfrac32\\right)^2=\\dfrac{%s}{%s}$."%(n(9),n(4)),
 "Larger surface area: $40\\times\\dfrac{%s}{%s}=%s$."%(n(9),n(4),n(sa204))]
assert abs(kl-1.5)<1e-12
# ---- 205
b205=6**2+8**2; h205=math.sqrt(26**2-b205)
S['GT-205']=["The space diagonal $d$ of a box satisfies $d^2=\\text{length}^2+\\text{width}^2+h^2$, so $6^2+8^2+h^2=26^2$."%(),
 "Compute: $%s+h^2=%s$, so $h^2=%s$."%(n(b205),n(26**2),n(26**2-b205)),
 "So $h=\\sqrt{%s}=%s$."%(n(26**2-b205),n(h205))]
# ---- 206
S['GT-206']=["The water level rises because the cube pushes aside its own volume of water. "+ret('12^3')+" cubic centimeters.",
 "That extra volume spreads over the base of the tank. "+ret('40*30')+" square centimeters.",
 "Rise $=\\dfrac{\\text{volume}}{\\text{base area}}$: "+ret('1728/1200',2)+" centimeters."]
T['GT-206']='C'
# ---- 207
sl207=math.sqrt(8**2+6**2); f207=0.5*12*sl207
S['GT-207']=["Each triangular face has base $12$. Its height (the slant height) comes from a right triangle with the pyramid's height $8$ and half the base $%s$: $\\sqrt{8^2+%s^2}=\\sqrt{%s}=%s$."%(n(6),n(6),n(8**2+6**2),n(sl207)),
 "One face: $\\dfrac12(12)(%s)=%s$."%(n(sl207),n(f207)),
 "Four faces: $4\\times%s=%s$. Do not use the height $8$ as the face height: that would give $4\\cdot\\dfrac12(12)(8)=%s$."%(n(f207),n(4*f207),n(4*0.5*12*8))]
# ---- 208
e208=9*math.sqrt(3)/math.sqrt(3)
S['GT-208']=["The space diagonal of a cube with edge $e$ is $e\\sqrt3$. So $e\\sqrt3=9\\sqrt3$ and $e=%s$."%n(e208),
 "Volume: $e^3=%s^3=%s$."%(n(e208),n(e208**3))]
S['GT-208'].append("Check the trap: the face area $%s^2=%s$ is not the volume."%(n(e208),n(e208**2)))
# ---- 209
nx,ny,nz=10//2,12//2,16//2
S['GT-209']=["Count how many cubes fit along each edge: $\\dfrac{10}{2}=%s$, $\\dfrac{12}{2}=%s$, $\\dfrac{16}{2}=%s$."%(n(nx),n(ny),n(nz)),
 "Cubes fit in a $%s\\times%s\\times%s$ grid, so the total is $%s\\times%s\\times%s=%s$."%(n(nx),n(ny),n(nz),n(nx),n(ny),n(nz),n(nx*ny*nz)),
 "Check by volumes: $\\dfrac{10\\cdot12\\cdot16}{2^3}=\\dfrac{%s}{%s}=%s$."%(n(10*12*16),n(2**3),n(10*12*16/8))]
# ---- 210
cyl210=5**2*12; cone210=cyl210/3
S['GT-210']=["Cylinder volume: $\\pi r^2h=\\pi(5)^2(12)=%s$."%Pi(cyl210),
 "Cone volume (one third of the cylinder with the same base and height): $\\dfrac13\\pi(5)^2(12)=%s$."%Pi(cone210),
 "Number of cones: $\\dfrac{%s}{%s}=%s$."%(n(cyl210)+"\\pi",n(cone210)+"\\pi",n(cyl210/cone210))]
# ---- 211
S['GT-211']=["Increasing the radius by $20\\%$ multiplies it by $1.2$. Volume depends on $r^3$, so the volume is multiplied by $1.2^3$: "+ret('1.2^3')+".",
 "A multiplier of $1.728$ means an increase of $%s\\%%$: "%n((ev('1.2^3')-1)*100,1)+ret('(1.2^3-1)*100',1)+".",
 "Enter $%s$. (The trap $3\\times20=60$ forgets that the change compounds.)"%n((ev('1.2^3')-1)*100,1)]
T['GT-211']='C'
# ---- 212
cy212=3**2*7; bowl212=Fr(2,3)*3**3
S['GT-212']=["The solid is the cylinder with the hemispherical bowl taken away. Cylinder: $\\pi r^2h=\\pi(3)^2(7)=%s$."%Pi(cy212),
 "Hemisphere (the bowl): $\\dfrac23\\pi r^3=\\dfrac23\\pi(3)^3=%s$."%Pi(float(bowl212)),
 "Subtract: $%s-%s=%s$, so $k=%s$."%(n(cy212)+"\\pi",n(float(bowl212))+"\\pi",Pi(cy212-float(bowl212)),n(cy212-float(bowl212)))]
# tidy double spaces
for k in S: S[k]=[x.replace('  ',' ') for x in S[k]]
