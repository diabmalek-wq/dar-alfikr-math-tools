# Builds s6_items.json from the bank extract: context clean-up (no Saudi/SAR/Arabic names), duplicate-trick fixes,
# and the one geometrically impossible item (PS-112). Math of every unchanged item is untouched.
import json,re
raw=json.load(open('raw_items.json'))
GEN=[("SAR $340.00$","$\\$340.00$"),("SAR $378.20$","$\\$378.20$"),("SAR $90{,}000$","$\\$90{,}000$"),("SAR $61{,}200$","$\\$61{,}200$"),("SAR $63{,}750$","$\\$63{,}750$"),("SAR $65{,}025$","$\\$65{,}025$"),("SAR $76{,}500$","$\\$76{,}500$"),
 ("SAR $3{,}200$","$\\$3{,}200$"),("SAR $256$","$\\$256$"),("final price of the laptop, in SAR?","final price of the laptop, in dollars?"),("original price, in SAR, of the jacket","original price, in dollars, of the jacket"),
 ("Fahad purchased","Marcus purchased"),("A Vision 2030 renewable-energy report","A renewable-energy report"),("For a construction project at NEOM, a concrete","For a construction project, a concrete"),
 ("An architect built a scale model of a tower planned for the King Abdullah Financial District, where","An architect built a scale model of a planned tower, where"),
 ("A desalination plant in the Eastern Province produces fresh water","A water treatment plant produces fresh water"),("A bus rapid transit line in Riyadh carries","A bus rapid transit line carries"),
 ("A survey of $850$ Grade 11 students","A survey of $850$ eleventh-grade students"),("and then $15\\%$ VAT is added","and then a $15\\%$ sales tax is added"),
 ("A $84$-gram sample","An $84$-gram sample")]
OVR={}  # id -> dict(q=..., ans=..., why=...)
OVR['PS-017']=dict(q="A recipe for granola bars requires oats, honey, and raisins in the ratio $5 : 2 : 3$ by weight. If a bakery uses $18$ kilograms of raisins to prepare a large batch, how many kilograms of oats are used?\n\nA) $12$\nB) $24$\nC) $30$\nD) $36$",why='context (Saudi dish, dates)')
OVR['PS-072']=dict(q="A gift box contains almonds and cashews, in a ratio of $7$ to $5$. When $8$ almonds and $8$ cashews are removed from the box, the ratio of almonds to cashews becomes $3$ to $2$. How many cashews were originally in the box?\n\n(A) $24$\n(B) $32$\n(C) $40$\n(D) $48$",why='context (Ajwa/Sukkari dates)')
OVR['PS-082']=dict(q="The price of an item is increased by $40\\%$, and then the new price is decreased by $25\\%$. The final price is what percent of the original price?\n\n(A) $65\\%$\n(B) $100\\%$\n(C) $105\\%$\n(D) $115\\%$",ans="(C) $105\\%$",why='DUPLICATE TRICK with PS-068 (up p%, down p%); numbers changed (bank: +30%/-30%, answer 91%)')
OVR['PS-084']=dict(q="A town's population decreased by $20\\%$ in $2023$ and then increased by $15\\%$ in $2024$, ending at $9{,}200$. What was the population before the $2023$ decrease?",ans="$10000$",why='DUPLICATE TRICK with PS-083 (undo two successive percent changes); order and numbers changed (bank: +10%/-20%, ending 8,800)')
OVR['PS-115']=dict(q="A chemist has $x$ liters of an acid solution that is $30\\%$ acid and mixes in $15$ liters of pure acid. She then adds $25$ liters of a second acid solution that is $10\\%$ acid. The final solution is $35\\%$ acid. What is the total volume, in liters, of the final solution?\n\n(A) $125$\n(B) $70$\n(C) $85$\n(D) $110$",why='DUPLICATE wording with PS-097 (metalworker melts alloy, pure metal added); context changed to an acid solution, math identical')
OVR['PS-064']=dict(q="A school's enrollment decreased from $720$ students to $640$ students over one year. What is the percent decrease in enrollment?\n\nA) $10\\%$\nB) $11.1\\%$\nC) $12.5\\%$\nD) $14.3\\%$",ans="B) $11.1\\%$",why='DUPLICATE TRICK with PS-025 (percent increase from two numbers); changed to a percent decrease (bank: 640 to 720, answer 12.5%)')
OVR['PS-089']=dict(q="A train travels at a constant speed of $45$ miles per hour. What is the train's speed, in feet per second? ($1$ mile $=5280$ feet)\n\n(A) $12.5$\n(B) $66$\n(C) $3{,}960$\n(D) $237{,}600$",ans="(B) $66$",why='NEAR-DUPLICATE of PS-054 (90 km/h to m/s); replaced by mph to ft/s (bank answer 25)')
OVR['PS-090']=dict(q="A rectangular storage box is $0.4$ meter long, $0.5$ meter wide and $0.3$ meter tall. What is the volume of the box, in cubic centimeters? ($1$ meter $=100$ centimeters.)",ans="$60000$",why='SAME TRICK as PS-087 (square meters to square centimeters); changed to a volume in cubic centimeters (bank: 1.2 m by 0.5 m mat, answer 6000)')
OVR['PS-101']=dict(q="A region has a population density of $1{,}250$ people per square kilometer. Using $1$ mile $=1.6$ kilometers, how many people are there per square mile?",ans="$3200$",why='SAME TRICK as PS-093 (acceleration with a squared time unit); changed to a squared length unit in the denominator (bank: 0.5 m/s^2 to km/h^2, answer 6480)')
OVR['PS-112']=dict(q="A rectangular banner has width $w$ and length $1.8w$, where $w>0$. The area of the banner equals the combined area of $4$ identical square tiles. The side length of each tile is $k\\,w\\sqrt5$, where $k$ is a positive constant. What is the value of $k$?",ans="$0.3$",why='FLAWED ITEM: 4 identical squares cannot cover a 1 : 1.8 rectangle exactly (w would have to be a whole multiple of the tile side, but w / (0.3 w sqrt5) is not an integer); reworded to equal areas, answer unchanged')
ESC=lambda s:s
out=[]
for o in raw:
    q=o['q']
    for a,b in GEN: q=q.replace(a,b)
    ans=o['ans']; why=None
    if o['id'] in OVR:
        v=OVR[o['id']]; q=v['q']; ans=v.get('ans',ans); why=v['why']
    elif q!=o['q']: why='context only'
    if o['id']=='PS-017' or o['id']=='PS-072': pass
    assert not re.search(r'SAR|Riyadh|NEOM|Jeddah|Saudi|Vision 2030|Fahad|Ajwa|Sukkari|Eastern Province|King Abdullah|VAT|desalination|Al-',q),o['id']
    out.append(dict(id=o['id'],part=o['part'],d=o['d'],q=q,ans=ans,bank_ans=o['ans'],changed=why))
json.dump(out,open('s6_items_raw.json','w'),indent=1)
print(len(out),sum(1 for o in out if o['changed']))
