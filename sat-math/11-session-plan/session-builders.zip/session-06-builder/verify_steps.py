# Desmos-syntax-aware re-evaluation of EVERY typed [[expr]] in the Session 6 Answers, plus tapped points and final answers.
import re,json,math,sys
sys.path.insert(0,'.')
from steps2 import S,V,CHK,PTS,TOOLT
from steps import ev as _ev
def ev(e,**kw):
    # Desmos syntax: a^2, implicit multiplication, sqrt, nCr, mean, stdev, pi
    env=dict(sqrt=math.sqrt,abs=abs,pi=math.pi,nCr=lambda a,b:math.comb(int(a),int(b)),mean=lambda L:sum(L)/len(L),
             stdev=lambda L:(sum((v-sum(L)/len(L))**2 for v in L)/(len(L)-1))**0.5,**kw)
    e=e.replace('{,}','').replace('^','**'); e=re.sub(r'(\d|\))\s*(\(|[a-zA-Z])',r'\1*\2',e)
    return eval(e,{'__builtins__':{}},env)
solved=json.load(open('solved.json'))
bad=0;cnt=0;boxes=0;probs_with=set();ret_n=0
for iid,steps in S.items():
    for st in steps:
        allb=re.findall(r"\[\[([^\]]+)\]\]",st); boxes+=len(allb)
        if allb: probs_with.add(iid)
        returned=set()
        for m in re.finditer(r"\[\[([^\]]+)\]\]: it returns \$([^$]+)\$",st):
            expr,val=m.group(1),m.group(2).replace('{,}',''); returned.add(expr); ret_n+=1
            want=float(val); got=ev(expr)
            if abs(got-want)>6e-5*max(1,abs(want)): print('MISMATCH',iid,expr,got,want); bad+=1
        for e in allb:
            if e in returned: continue
            if e.startswith('y='):
                try: ev(e[2:],x=1.5)       # graph line must parse
                except Exception as ex: print('BAD graph syntax',iid,e,ex); bad+=1
            else: print('UNCHECKED box',iid,e); bad+=1
# tapped intersections: both curves agree at the tapped x, and the printed coordinates are right
for iid,l,r,x0 in CHK:
    a,b=ev(l,x=x0),ev(r,x=x0)
    if abs(a-b)>1e-9*max(1,abs(b)): print('BAD intersection',iid,l,r,x0,a,b); bad+=1
    xs=n=None
    txt=''.join(S[iid]); y=b
    pt='$(%s,\\,%s)$'
    from steps import g, n
    if x0>0 and iid!='PS-122' or iid=='PS-122':
        want=pt%(n(x0,4),n(y,4))
        if want not in txt: print('POINT TEXT MISSING',iid,want); bad+=1
for iid,e,x0,y0 in PTS:
    if abs(ev(e,x=x0)-y0)>1e-12: print('BAD point',iid); bad+=1
    if '$(%d,\\,%s)$'%(x0,y0) not in ''.join(S[iid]): print('POINT TEXT',iid)
# final answers: V (what steps arrive at) == independent solve.py value
for iid,v in V.items():
    if abs(v-solved[iid])>1e-9*max(1,abs(v)): print('VALUE MISMATCH',iid,v,solved[iid]); bad+=1
# and the last typed answer-bearing value in each solution equals the answer
assert set(V)==set(S)==set(solved)
for iid,st in S.items():
    if not 3<=len(st)<=4: print('STEP COUNT',iid,len(st)); bad+=1
    if iid not in probs_with: print('NO DESMOS BOX',iid); bad+=1
print('problems with >=1 box',len(probs_with),'of',len(S),'| total boxes',boxes,'| "returns" values checked',ret_n,'| intersections',len(CHK),'| bad',bad)
print('tags',{t:sum(1 for v in TOOLT.values() if v==t) for t in set(TOOLT.values())})
