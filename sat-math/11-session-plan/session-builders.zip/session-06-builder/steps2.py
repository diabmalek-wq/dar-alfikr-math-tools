"""Session 6 Answers: every problem is worked in Desmos (3-4 numbered steps, grey boxes via [[expr]]).
All numbers come from code. Intersection / tapped-point claims are registered in CHK and re-evaluated by verify_steps.py."""
import math, re
import steps as _s
from steps import n, g, ev, c, m, pc, dol, ret, T, V, fr
S = {}; CHK = []   # CHK: (id, lhs, rhs, root)  -> lhs(root) must equal rhs(root); PTS: (id, expr, x, y)
PTS = []
def X(iid, lhs, rhs, root, note='', d=6):
    """graph two curves and tap the intersection at x=root"""
    y = ev(rhs, x=root); CHK.append((iid, lhs, rhs, root))
    assert abs(ev(lhs, x=root) - y) < 1e-9 * max(1, abs(y)), (iid, lhs, rhs, root)
    return "Type %s and %s%s. Tap the intersection: $(%s,\\,%s)$." % (c('y=' + lhs), c('y=' + rhs), note, n(root, 4), n(y, 4))
def R(e, d=6, unit='.', lead='Type'):
    for a, b in ((' is ', ', which is '), (' equals ', ', which equals '), (' comes from', ', which comes from')):
        if unit.startswith(a): unit = b + unit[len(a):]; break
    return ret(e, d, unit).replace('Type', lead, 1)
def num(x): return n(x, 8)

# ---------------- Part A
S['PS-027'] = ["Club C is $p\\%$ of club A, so $p=\\dfrac{\\text{club C}}{\\text{club A}}\\times100$. Only these two clubs matter; ignore B, D and the total.",
 R('1100/500*100'),
 "Check: " + R('500*220/100', 6, ', which is the club C count.', 'type')]
S['PS-028'] = ["The share that is defective and mislabeled is $45\\%$ of $40\\%$. " + R('0.45*0.4*100', 6, ' percent of the batch.'),
 "Everything else is NOT in that group: " + R('100-18', 6, ' percent.'),
 "Trap check: " + R('100-45', 6, ' is only the share of defective items that are not mislabeled; the question is about the whole batch.', 'type')]
S['PS-068'] = ["A $10\\%$ increase multiplies by $1.1$. " + R('5000*1.1'),
 "The $10\\%$ decrease is taken from the new $5{,}500$: " + R('5500*0.9', 6, ' people.', 'type'),
 "One-line check: " + R('5000*1.1*0.9', 6, ', which is ', 'type') + "$%s$ below the start because $10\\%%$ of the larger number is bigger." % g(5000 - 4950)]
S['PS-069'] = ["Percent error divides the error by the actual amount. " + R('480-432', 6, ' gigawatt-hours.'),
 R('48/432*100', 4, r', which rounds to $11.1\%$.'),
 "Wrong-base check: " + R('48/480*100', 6, r' is the tempting answer from dividing by the estimate.', 'type')]
S['PS-082'] = ["Pick a starting price of $100$. A $40\\%$ increase: " + R('100*1.4'),
 "The $25\\%$ decrease is taken from the new price: " + R('140*0.75', 6, ' dollars.', 'type'),
 "One-line check: " + R('1.4*0.75*100', 6, r', so the final price is $105\%$ of the original. Subtracting the percents would give $115\%$, a trap.', 'type')]
S['PS-083'] = ["Let $x$ stand for the cost. Selling at $40\\%$ above cost is $1.4x$, and the $25\\%$ discount leaves $75\\%$ of that, so the discounted price is $0.75\\times1.4x$.",
 X('PS-083', '0.75*1.4*x', '210', float(_s.cost83), ' (zoom out)'),
 "Check: " + R('200*1.4*0.75', 6, ' dollars, the discounted price.', 'type')]
S['PS-084'] = ["Let $x$ stand for the population before $2023$. After a $20\\%$ decrease and a $15\\%$ increase it is $0.8\\times1.15x$.",
 X('PS-084', '0.8*1.15*x', '9200', float(_s.p84), ' (zoom out)'),
 "Check: " + R('10000*0.8*1.15', 6, ', the ending population.', 'type')]
S['PS-085'] = ["Take $z=100$. $y$ is $20\\%$ less than $z$: " + R('100*0.8', 6, '.', 'type'),
 "$x$ is $50\\%$ greater than $y$: " + R('80*1.5', 6, '.', 'type'),
 "One-line check: " + R('1.5*0.8*100', 6, r', so $x$ is $120\%$ of $z$. ($50-20=30$ would be wrong.)', 'type')]
S['PS-086'] = ["Start with $100$. First $10\\%$ increase: " + R('100*1.1', 6, '.', 'type'),
 "Second $10\\%$ increase, taken from $110$: " + R('110*1.1', 6, '.', 'type'),
 "The $20\\%$ decrease: " + R('121*0.8', 6, '.', 'type'),
 "Decrease from $100$: " + R('100-96.8', 6, ' percent.', 'type')]
S['PS-095'] = ["Let $x$ stand for the width $w$. The length is $1.5w$, so the area is $1.5w^2=540$.",
 X('PS-095', '1.5*x^2', '540', math.sqrt(360), ' (use the positive crossing)'),
 "The width is $c\\sqrt{10}$, so $c=\\dfrac{w}{\\sqrt{10}}$: " + R('sqrt(360)/sqrt(10)', 6, '.', 'type')]
S['PS-097'] = ["Nickel in grams: alloy X gives $0.2\\times150$, alloy Y gives $0.5m$, pure nickel gives $40$. The final alloy has mass $150+m+40$ and is $40\\%$ nickel. Let $x$ stand for $m$.",
 X('PS-097', '0.2*150+0.5*x+40', '0.4*(150+x+40)', float(_s.mm)),
 "Check: " + R('(30+0.5*60+40)/(150+60+40)', 6, ', which is $40\\%$ nickel.', 'type')]
S['PS-100'] = ["Let $x$ stand for the yearly growth rate as a decimal. Three years of growth give $(1+x)^3=1.331$.",
 X('PS-100', '(1+x)^3', '1.331', 0.1),
 "Convert to a percent: " + R('0.1*100', 6, ' percent per year.', 'type'),
 "Check: " + R('1.1^3', 6, ', the $33.1\\%$ growth over three years.', 'type')]
S['PS-103'] = ["Take last year's mugs as $M=1$ and let $x$ stand for the plates $P$. This year: mugs $1.3$, plates $0.9x$, total $1.06(1+x)$.",
 X('PS-103', '1.3+0.9*x', '1.06*(1+x)', float(_s.ratio)),
 "Mugs this year are $1.3$ and plates are $0.9\\times1.5=1.35$. Share of mugs: " + R('1.3/(1.3+0.9*1.5)*100', 4, '.', 'type'),
 "That rounds to $49.1\\%$, the share of mugs this year."]
S['PS-106'] = ["Take city N to be $100$. City M is $20\\%$ greater: " + R('100*1.2', 6, '.', 'type'),
 "In $2024$: " + R('120*1.15', 6, ' for city M,', 'type') + " and " + R('100*0.92', 6, ' for city N.', 'type'),
 "M compared with N: " + R('(138-92)/92*100', 6, ' percent greater.', 'type')]
S['PS-107'] = ["Write $b$, $c$, $d$ with $a$: $b=0.006a$, $c=0.05b$, $d=1.5c$. Add the multipliers: " + R('0.006+0.05*0.006+1.5*0.05*0.006', 8, ', so $0.00675a=27$.', 'type'),
 R('27/0.00675', 4, '.'),
 "Check: " + R('4000*0.006', 6, ' is $b$;', 'type') + " " + R('24*0.05', 6, ' is $c$;', 'type') + " " + R('1.2*1.5', 6, ' is $d$;', 'type') + " " + R('24+1.2+1.8', 6, ', the required sum.', 'type')]
S['PS-114'] = ["Total sales $T$ are equal, so the rise in online sales comes only from the $8$-point rise in share. " + R('25200-18000', 6, ' dollars, which is $8\\%$ of $T$.'),
 R('7200/0.08', 6, ' dollars.'),
 "Check the shares: " + R('18000/90000*100', 6, ' percent in March,', 'type') + " " + R('25200/90000*100', 6, ' percent in April, which is $8$ more.', 'type')]
S['PS-115'] = ["Count the acid, with $x$ standing for the first solution's volume: $0.3x+15+0.1(25)$. The final volume is $x+15+25$ and is $35\\%$ acid.",
 X('PS-115', '0.3*x+15+0.1*25', '0.35*(x+15+25)', float(_s.x115)),
 "The question asks for the total volume: " + R('70+15+25', 6, ' liters.', 'type')]
S['PS-121'] = ["Take the current fiction books as $30$. After the $20\\%$ increase: " + R('1.2*30', 6, '.', 'type'),
 "Nonfiction after a $10\\%$ drop equals this, so current nonfiction is " + R('36/0.9', 6, '.', 'type'),
 "Let $x$ stand for the reference books. After the changes the total is $36+36+x$, and it is $1.01(30+40+x)$. " + X('PS-121', '36+36+x', '1.01*(30+40+x)', float(_s.Rv)),
 "Share that is reference: " + R('130/(30+40+130)*100', 6, ' percent.', 'type')]
S['PS-122'] = list(_s.S['PS-122'])
CHK.append(('PS-122', '(1+x/100)*(1-(x-13)/100)', '1.1', 25.0)); CHK.append(('PS-122', '(1+x/100)*(1-(x-13)/100)', '1.1', -12.0))
S['PS-125'] = ["Start from $S=100$. $R$ is $50\\%$ greater than $S$: " + R('100*1.5', 6, '.', 'type'),
 "$R$ is $25\\%$ less than $Q$, so $R=0.75Q$: " + R('150/0.75', 6, ' is $Q$.', 'type'),
 "$Q$ is $60\\%$ greater than $P$: " + R('200/1.6', 6, ' is $P$.', 'type'),
 "$P$ compared with $S$: " + R('(125-100)/100*100', 6, ' percent greater.', 'type')]
S['PS-126'] = ["Let $x$ stand for the copper-plus-zinc mass $s$. Tin is half of it, so the whole sample is $x+\\dfrac{x}{2}=84$.",
 X('PS-126', '1.5*x', '84', float(_s.ssum)),
 "Tin is half of that: " + R('56/2', 6, ' grams.', 'type'),
 "Check with the other clue: " + R('(56-5)/3', 6, ' is the zinc;', 'type') + " " + R('2*17+5', 6, ' is the copper;', 'type') + " " + R('39+17+28', 6, ' is the total.', 'type')]
S['PS-003'] = ["The ratio $1:2:3$ has " + R('1+2+3', 6, ' parts.', 'type').replace('Type','type'),
 "Gravel is $3$ of the $6$ parts and is made at $6$ tons per hour, so the whole mixture is made at " + R('6/(3/6)', 6, ' tons per hour.', 'type'),
 "Time for $90$ tons: " + R('90/12', 6, ' hours.', 'type')]
S['PS-003'][0] = "The ratio $1:2:3$ has total parts: " + R('1+2+3', 6, '.', 'type')
S['PS-059'] = list(_s.S['PS-059'])
S['PS-060'] = ["Density is mass divided by volume. " + R('540/60', 6, ' grams per cubic centimeter.'),
 "Use the given conversion, $1{,}000$ kilograms per cubic meter for each gram per cubic centimeter: " + R('9*1000', 6, ' kilograms per cubic meter.', 'type'),
 "One-line check: " + R('540/60*1000', 6, '.', 'type')]
S['PS-061'] = list(_s.S['PS-061'])
S['PS-062'] = ["Direct variation: $y=kx$. Find $k$: " + R('45/9'),
 "Now $y$ when $x=14$: " + R('5*14', 6, '.', 'type'),
 "Graph check: type %s and tap $x=14$: the point is $(14,\\,%s)$." % (c('y=5x'), g(5 * 14))]
PTS.append(('PS-062', '5*x', 14, 70))
S['PS-063'] = ["Rate: " + R('15000/6', 6, ' passengers per hour.'),
 "For $2.5$ hours: " + R('2500*2.5', 6, ' passengers.', 'type'),
 "One-line check: " + R('15000*2.5/6', 6, '.', 'type')]
S['PS-073'] = ["Count laps. Car A gains on Car B at $\\dfrac1{12}-\\dfrac1{20}$ lap per second: " + R('1/12-1/20', 6, '. (That is $\\dfrac1{30}$.)').replace('Type', 'Type', 1),
 "One lap of gain takes " + R('1/(1/12-1/20)', 6, ' seconds.', 'type'),
 "Check: " + R('30/12', 6, ' laps for A and ', 'type') + R('30/20', 6, ' laps for B: A is exactly one lap ahead.', 'type')]
S['PS-088'] = ["Volume of the tank: " + R('12*5*2', 6, ' cubic meters.'),
 "Time at $0.8$ cubic meter per minute: " + R('120/0.8', 6, ' minutes.', 'type'),
 "In hours: " + R('150/60', 6, '.', 'type')]
S['PS-093'] = ["Feet to miles means dividing by $5{,}280$: " + R('22/5280', 6, ' miles per second squared.'),
 "Seconds squared to minutes squared means multiplying by $60^2$: " + R('22/5280*60^2', 6, ' miles per minute squared.', 'type'),
 "Check the slips: " + R('22*3600', 6, ' (forgot to divide by $5{,}280$) and ', 'type') + R('22/5280', 6, '. Neither is the answer.', 'type')]
S['PS-098'] = ["Work in kilometers: " + R('40*1.6', 6, ' kilometers per gallon.'),
 "Gallons for $304$ kilometers: " + R('304/64', 6, ' gallons.', 'type'),
 "Liters: " + R('4.75*3.8', 6, ' liters.', 'type')]
S['PS-101'] = list(_s.S['PS-101'])
S['PS-104'] = ["Pressure $\\times$ area is force. Let $x$ stand for $A$. At first the weight is $4\\times12x=48x$. After adding $120$ it is $48x+120$, shared by $3$ legs that each carry $24x$, so $\\dfrac{48x+120}{3}=24x$.",
 X('PS-104', '(48*x+120)/3', '24*x', float(_s.Av), ' (zoom out)'),
 "Check the pressure: " + R('(48*5+120)/3/5', 6, ' newtons per square centimeter on each of $3$ legs.', 'type')]
S['PS-108'] = ["Blue to not-blue is $3:11$, so blue is $\\dfrac{3}{14}$ of the drives: " + R('140*3/14', 6, ', the blue drives.', 'type'),
 "The rest: " + R('140-30', 6, ' not blue, split $7:4$ into red and green. ', 'type') + R('110*7/11', 6, ' red.', 'type'),
 "Red minus blue: " + R('70-30', 6, '.', 'type')]
S['PS-110'] = list(_s.S['PS-110'])
# ---------------- Part B
S['PS-024'] = ["\\textquotedblleft$24\\%$ greater than $75$\\textquotedblright\\ means $m=75+0.24(75)$: " + R('75+0.24*75', 6, '.', 'type'),
 "$m=75r$, so $r=\\dfrac{m}{75}$: " + R('93/75'),
 "Check: " + R('75*1.24', 6, ', which is $m$. ($0.24$ is only the increase.)', 'type')]
S['PS-025'] = ["Increase in the bill: " + R('378.2-340', 6, ' dollars.'),
 "Percent increase over the old bill: " + R('38.2/340*100', 4, r', which is $11.2\%$ to the nearest tenth.', 'type'),
 "Wrong-base check: " + R('38.2/378.2*100', 4, ' comes from dividing by the new bill.', 'type')]
S['PS-026'] = ["Each year the value is multiplied by $0.85$. After one year: " + R('90000*0.85', 6, ' dollars.', 'type'),
 "After the second year: " + R('76500*0.85', 6, ' dollars.', 'type'),
 "One-line check: " + R('90000*0.85^2', 6, '.', 'type')]
S['PS-064'] = ["Decrease in enrollment: " + R('720-640', 6, ' students.'),
 "Percent decrease uses the starting value: " + R('80/720*100', 4, r', about $11.1\%$.', 'type'),
 "Wrong-base check: " + R('80/640*100', 6, ' comes from dividing by the new value.', 'type')]
S['PS-065'] = ["Pay $85\\%$ after the discount: " + R('3200*0.85', 6, ' dollars.', 'type'),
 "Add $15\\%$ tax to that price: " + R('2720*1.15', 6, ' dollars.', 'type'),
 "One-line check: " + R('0.85*1.15', 6, ' is the overall multiplier, so the price is below $3{,}200$.', 'type')]
S['PS-066'] = ["After a $20\\%$ discount you pay $80\\%$ of the original, so $0.8p=256$: " + R('256/0.8', 6, ' dollars.', 'type'),
 "Check: " + R('320*0.8', 6, ', the sale price.', 'type'),
 "Trap: adding $20\\%$ to $256$ gives " + R('256*1.2', 6, ', which is wrong.', 'type')]
S['PS-067'] = ["Find $34\\%$ of $850$. " + R('0.34*850', 6, ' students.', 'type'),
 "Check by pieces: " + R('850*0.1*3', 6, ' is $30\\%$,', 'type') + " " + R('850*0.04', 6, ' is $4\\%$.', 'type'),
 "Sanity check: " + R('850/3', 4, ', one third of $850$, is a little less than the answer, as expected for $34\\%$.', 'type')]
S['PS-071'] = ["Let $y=1$ and $x$ stand for the unknown coefficient. The left side is $0.3\\times0.4x$ and the right side is $0.5-0.2$.",
 X('PS-071', '0.3*0.4*x', '0.5-0.2', 2.5),
 "So $x=2.5y$. Check with $y=2$, $x=5$: " + R('0.3*0.4*5', 6, ' on the left and ', 'type') + R('0.5*2-0.2*2', 6, ' on the right.', 'type')]
S['PS-075'] = ["Let $x$ stand for $k$. Object B is $1.3x$ and is $66$ more than A, so $1.3x=x+66$.",
 X('PS-075', '1.3*x', 'x+66', float(_s.kk), ' (zoom out)'),
 "Check: " + R('1.3*220-220', 6, ' grams more, as required.', 'type')]
S['PS-076'] = list(_s.S['PS-076'])
S['PS-004'] = ["Rate per kilometer: " + R('6.5/100', 6, ' liter per kilometer.'),
 "For $340$ kilometers: " + R('6.5/100*340', 6, ' liters.', 'type'),
 "Check by scaling: " + R('6.5*3.4', 6, ', the same amount.', 'type')]
S['PS-017'] = ["Raisins are $3$ parts and weigh $18$ kilograms: " + R('18/3', 6, ' kilograms per part.'),
 "Oats are $5$ parts: " + R('5*6', 6, ' kilograms.', 'type'),
 "Check the ratio oats to raisins: " + R('30/18', 6, ' equals ', 'type') + R('5/3', 6, '.', 'type')]
S['PS-054'] = ["Meters per hour is $90\\times1{,}000$, and there are $3{,}600$ seconds in an hour: " + R('90*1000/3600', 6, ' meters per second.', 'type'),
 "Shortcut check: " + R('90/3.6', 6, '.', 'type'),
 "Reverse check: " + R('25*3.6', 6, ' kilometers per hour.', 'type')]
S['PS-055'] = ["The new batch is " + R('24/8', 6, ' times as large.', 'type'),
 "Orange juice: " + R('3*3', 6, ' cups.', 'type'),
 "Check that the ratio is kept: " + R('9/(9+15)', 6, ' equals ', 'type') + R('3/8', 6, '. (The $15$ is the water.)', 'type')]
S['PS-056'] = ["Unit rate: " + R('480/8', 6, ' boxes per hour.'),
 "For $5.5$ hours: " + R('60*5.5', 6, ' boxes.', 'type'),
 "One-line check: " + R('480*5.5/8', 6, '.', 'type')]
S['PS-057'] = ["Each centimeter on the model is $2.5$ meters: " + R('18*2.5', 6, ' meters.'),
 "Check backward: " + R('45/2.5', 6, ' centimeters, the model height.', 'type'),
 "Pieces check: " + R('10*2.5+8*2.5', 6, '.', 'type')]
S['PS-058'] = ["The ratio $2:15$ has " + R('2+15', 6, ' parts in all.', 'type'),
 "One part: " + R('51/17', 6, ' liters.', 'type'),
 "Salt is $2$ parts: " + R('2*3', 6, ' liters.', 'type'),
 "Check in one line: " + R('51*2/17', 6, '.', 'type')]
S['PS-072'] = ["Write $7k$ almonds and $5k$ cashews, and let $x$ stand for $k$. After removing $8$ of each the ratio is $\\dfrac{7x-8}{5x-8}=\\dfrac32$.",
 X('PS-072', '(7*x-8)/(5*x-8)', '1.5', 8.0, ' (zoom out)'),
 "Cashews at the start are $5k$: " + R('5*8', 6, '.', 'type') + " Check: " + R('(7*8-8)/(5*8-8)', 6, '.', 'type')]
S['PS-087'] = list(_s.S['PS-087'])
S['PS-089'] = ["Feet per hour: " + R('45*5280', 6, '.', 'type').replace('Type', 'Type'),
 "Divide by $3{,}600$ seconds: " + R('237600/3600', 6, ' feet per second.', 'type'),
 "Landmark check: " + R('88*45/60', 6, ', since $60$ mph is $88$ ft/s.', 'type')]
S['PS-090'] = ["Volume in cubic meters: " + R('0.4*0.5*0.3'),
 "One cubic meter is $100^3$ cubic centimeters: " + R('0.06*100^3', 6, ' cubic centimeters.', 'type'),
 "Check using centimeters first: " + R('40*50*30', 6, '.', 'type')]
S['PS-112'] = ["The banner's area is $1.8w^2$ and $4$ tiles have area $4\\times5k^2w^2=20k^2w^2$. Dividing by $w^2$, with $x$ standing for $k$: $20x^2=1.8$.",
 X('PS-112', '20*x^2', '1.8', 0.3, ' (use the positive crossing)'),
 "Check: " + R('4*5*0.3^2', 6, ', the banner area divided by $w^2$.', 'type')]
# fix ids for those taken from steps.py which have capital 'Type' mid-sentence handled by fixcase
def _fixcase(t):
    return re.sub(r'Type \[\[', lambda mo: ('type [[' if t[:mo.start()].rstrip() and not t[:mo.start()].rstrip().endswith('.') else 'Type [['), t)
for _k in S: S[_k] = [_fixcase(x) for x in S[_k]]
assert set(S) == set(V), set(V) ^ set(S)
NTAG = set("PS-027 PS-024 PS-060 PS-062 PS-063 PS-054 PS-055 PS-056 PS-057 PS-058 PS-017 PS-066 PS-088 PS-090".split())
TOOLT = {k: ('N' if k in NTAG else 'D') for k in S}
