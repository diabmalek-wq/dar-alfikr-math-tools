"""Worked steps for Session 6 (percentages, ratios, rates, units).
Every number quoted in a step is computed here from the item data (never typed by hand);
every typed calculator/Desmos expression that 'returns' a value is evaluated by ev() through ret()."""
import math, re
from fractions import Fraction as Fr

def n(v, d=6):
    v = float(v)
    s = ('%.*f' % (d, round(v, d))).rstrip('0').rstrip('.')
    return '0' if s in ('-0', '') else s
def g(v, d=6):
    """number with {,} thousands grouping (LaTeX), trimmed decimals"""
    s = n(v, d); neg = s.startswith('-'); s = s.lstrip('-')
    ip, _, fp = s.partition('.')
    if len(ip) >= 4: ip = '{,}'.join([ip[max(0, i - 3):i] for i in range(len(ip), 0, -3)][::-1])
    return ('-' if neg else '') + ip + ('.' + fp if fp else '')
def ev(expr, **kw):
    e = expr.replace('{,}', '').replace('^', '**')
    e = re.sub(r'(\d|\))\s*(\(|[a-zA-Z])', r'\1*\2', e)
    return eval(e, {'__builtins__': {}}, dict(sqrt=math.sqrt, abs=abs, **kw))
def c(e): return '[[%s]]' % e.replace('{,}', '')
def m(x, d=6): return '$' + g(x, d) + '$'
def pc(x, d=6): return '$' + g(x, d) + r'\%$'
def dol(x, d=6): return r'$\$' + g(x, d) + '$'
def ret(e, d=6, unit=''):
    return "Type %s: it returns $%s$%s" % (c(e), g(ev(e), d), unit)
def T(_t, /, **kw):
    for k, v in kw.items(): _t = _t.replace('<%s>' % k, str(v))
    assert not re.search(r'<[a-z0-9]+>', _t), _t   # every placeholder must be filled
    return _t
def fr(a, b): return r'\dfrac{%s}{%s}' % (g(a), g(b))

S = {}; V = {}   # V: value each item's steps arrive at (checked against solve.py by verify_steps.py)

# ---------------------------------------------------------------- Part A
# PS-027
cA, cC = 500, 1100; r = Fr(cC, cA); p27 = r * 100
S['PS-027'] = [T(r"Club C is $p\%$ of club A, so $p=<q>\times100$. Only these two clubs matter; ignore B, D and the total.", q=r'\dfrac{\text{club C}}{\text{club A}}'),
 T(r"$p=<f>\times100$, and $<f>=<r>$.", f=fr(cC, cA), r=g(float(r))),
 T(r"$<r>\times100=<p>$. It is over $100$ because club C is larger than club A.", r=g(float(r)), p=g(float(p27)))]
V['PS-027'] = p27

# PS-028
d28, mis = Fr(40, 100), Fr(45, 100); both = d28 * mis
S['PS-028'] = [T(r"Take $<a>\%$ of the $<b>\%$ that are defective: $<x>\times<y>=<z>$. So $<zp>\%$ of the whole batch is defective and mislabeled.", a=g(45), b=g(40), x=g(float(mis)), y=g(float(d28)), z=g(float(both)), zp=g(float(both * 100))),
 T(r"The question asks for the items that are NOT in that group, so subtract from the whole: $100\%-<zp>\%=<a>\%$.", zp=g(float(both * 100)), a=g(float((1 - both) * 100))),
 T(r"Watch out: $<w>\%$ is only the share of defective items that are not mislabeled; the question is about the whole batch.", w=g(float((1 - mis) * 100)))]
V['PS-028'] = float((1 - both) * 100)

# PS-068
st = 5000; y1 = st * Fr(11, 10); y2 = y1 * Fr(9, 10)
S['PS-068'] = [T(r"A $10\%$ increase multiplies by $1.1$: $<s>\times1.1=<a>$.", s=g(st), a=g(float(y1))),
 T(r"The $10\%$ decrease is taken from the new population, $<a>$, not from $<s>$: $<a>\times0.9=<b>$.", a=g(float(y1)), s=g(st), b=g(float(y2))),
 T(r"The decrease removes $<d>$ people but the increase added only $<i>$, so the town ends $<e>$ below where it started, not back at $<s>$.", d=g(float(y1 * Fr(1, 10))), i=g(float(st * Fr(1, 10))), e=g(float(st - y2)), s=g(st))]
V['PS-068'] = float(y2)

# PS-069
est, act = 480, 432; err = est - act
S['PS-069'] = [T(r"Percent error here is the size of the error divided by the actual amount. The error is $<e>-<a>=<d>$ gigawatt-hours.", e=est, a=act, d=err),
 ret('%d/%d*100' % (err, act), 4) + r", which rounds to $11.1\%$.",
 T(r"Divide by the actual $<a>$, as the question says. Dividing by the estimate $<e>$ instead gives $<w>\%$, the tempting wrong choice.", a=act, e=est, w=g(err / est * 100))]
V['PS-069'] = err / act * 100

# PS-082  (+40%, -25%)
inc, dec = 40, 25; a82 = 100 + inc; b82 = a82 * (100 - dec) / 100
S['PS-082'] = [T(r"Pick an easy starting price, $100$. A $<i>\%$ increase gives $100\times1.4=<a>$.", i=inc, a=g(a82)),
 T(r"The $<d>\%$ decrease is taken from the new price: $<a>\times0.75=<b>$.", d=dec, a=g(a82), b=g(b82)),
 T(r"So the final price is $<b>$ out of the original $100$, which is $<b>\%$ of it. Subtracting the percents ($<i>-<d>=<s>$) would suggest $<w>\%$, but the $<d>\%$ is taken from a larger price.", b=g(b82), i=inc, d=dec, s=inc - dec, w=100 + inc - dec)]
V['PS-082'] = b82

# PS-083
f83 = Fr(14, 10) * Fr(75, 100); cost83 = Fr(210) / f83
S['PS-083'] = [T(r"Let the cost be $c$. Selling at $40\%$ above cost gives $1.4c$. A $25\%$ discount leaves $75\%$ of that, so the discounted price is $0.75\times1.4c=<f>c$.", f=g(float(f83))),
 T(r"The discounted price is $\$210$, so $<f>c=210$.", f=g(float(f83))),
 ret('210/%s' % g(float(f83)).replace('{,}', ''), 6) + T(r" dollars. Check: $<c>\times1.4=<u>$ and $<u>\times0.75=210$.", c=g(float(cost83)), u=g(float(cost83 * Fr(14, 10))))]
V['PS-083'] = float(cost83)

# PS-084  (-20%, +15%, ends 9,200)
end84 = 9200; f84 = Fr(80, 100) * Fr(115, 100); p84 = Fr(end84) / f84
S['PS-084'] = [T(r"Let $P$ be the population before $2023$. A $20\%$ decrease multiplies by $0.8$ and a $15\%$ increase multiplies by $1.15$, so the final population is $P\times0.8\times1.15$."),
 T(r"$0.8\times1.15=<f>$, so $<f>P=<e>$.", f=g(float(f84)), e=g(end84)),
 ret('%d/%s' % (end84, g(float(f84))), 6) + T(r". Check: $<p>\times0.8=<a>$ and $<a>\times1.15=<e>$.", p=g(float(p84)), a=g(float(p84 * Fr(8, 10))), e=g(end84))]
V['PS-084'] = float(p84)

# PS-085
z85 = 100; y85 = z85 - 20; x85 = y85 * Fr(15, 10)
S['PS-085'] = [T(r"Percent questions about ratios work with any positive $z$, so take $z=<z>$. Then $y$ is $20\%$ less than $z$: $y=<z>-20=<y>$.", z=z85, y=y85),
 T(r"$x$ is $50\%$ greater than $y$: $x=<y>\times1.5=<x>$.", y=y85, x=g(float(x85))),
 T(r"So $x=<x>$ when $z=<z>$, which means $x$ is $<x>\%$ of $z$. (The percents do not simply add: $50-20=30$ would be wrong.)", x=g(float(x85)), z=z85)]
V['PS-085'] = float(x85)

# PS-086
s86 = 100; a86 = s86 * 1.1; b86 = a86 * 1.1; c86 = b86 * 0.8
S['PS-086'] = [T(r"Start with $100$. The first $10\%$ increase gives $100\times1.1=<a>$.", a=g(a86)),
 T(r"The second $10\%$ increase is taken from $<a>$: $<a>\times1.1=<b>$.", a=g(a86), b=g(b86)),
 ret('100*1.1*1.1*0.8', 6) + T(r" after the $20\%$ decrease."),
 T(r"The quantity went from $100$ to $<c>$, so it decreased by $100-<c>=<d>$ percent.", c=g(c86), d=g(100 - c86))]
V['PS-086'] = 100 - c86

# PS-095
area = 540; w2 = Fr(area) / Fr(3, 2); sq = w2 / 10; cc = math.isqrt(int(sq)); assert cc * cc == sq
S['PS-095'] = [T(r"Let the width be $w$. The length is $150\%$ of the width, so it is $1.5w$, and the area is $w\times1.5w=1.5w^2=<a>$.", a=area),
 T(r"$w^2=<a>\div1.5=<w2>$, so $w=\sqrt{<w2>}=\sqrt{<s>\times10}=<r>\sqrt{10}$.", a=area, w2=g(float(w2)), s=g(float(sq)), r=cc),
 T(r"The width is also $c\sqrt{10}$, so $c=<r>$.", r=cc)]
V['PS-095'] = cc

# PS-097
nx = Fr(20, 100) * 150; ny_coef = Fr(50, 100); pure = 40
tot0 = 150 + pure; right0 = Fr(40, 100) * tot0
cst = nx + pure; mm = (right0 - cst) / (ny_coef - Fr(40, 100))
S['PS-097'] = [T(r"Count the nickel in grams. Alloy X gives $0.2\times150=<a>$. Alloy Y gives $0.5m$. The pure nickel gives $<p>$. Total nickel: $<a>+0.5m+<p>=<c>+0.5m$.", a=g(float(nx)), p=pure, c=g(float(cst))),
 T(r"The final alloy has mass $150+m+<p>=<t>+m$ and is $40\%$ nickel, so its nickel is $0.4(<t>+m)=<r>+0.4m$.", p=pure, t=tot0, r=g(float(right0))),
 T(r"Set the nickel equal: $<c>+0.5m=<r>+0.4m$, so $0.1m=<d>$ and $m=<m>$.", c=g(float(cst)), r=g(float(right0)), d=g(float(right0 - cst)), m=g(float(mm))),
 T(r"Check: nickel is $<a>+<b>+<p>=<s>$ grams out of $<t>$ grams, and $<s>\div<t>=0.4$, which is $40\%$.", a=g(float(nx)), b=g(float(ny_coef * mm)), p=pure, s=g(float(nx + ny_coef * mm + pure)), t=g(float(tot0 + mm)))]
V['PS-097'] = float(mm)

# PS-100
S['PS-100'] = [T(r"Let $g$ be the yearly growth factor. Three years of growth multiply the area by $g^3$, and three years give $33.1\%$ growth, so $g^3=1.331$."),
 ret('1.331^(1/3)', 6) + T(r", the cube root."),
 T(r"A yearly factor of $<g>$ means $<p>\%$ growth each year. Check: ", g=g(ev('1.331^(1/3)')), p=g((ev('1.331^(1/3)') - 1) * 100)) + ret('1.1^3', 6, ', which is the $33.1\\%$ growth over three years.')]
V['PS-100'] = (ev('1.331^(1/3)') - 1) * 100

# PS-103
mug, plate, tot = Fr(13, 10), Fr(9, 10), Fr(106, 100)
ratio = (mug - tot) / (tot - plate)    # P/M
mugs_now = mug * 1; plates_now = plate * ratio; total_now = tot * (1 + ratio)
assert mugs_now + plates_now == total_now
S['PS-103'] = [T(r"Let last year's sales be $M$ mugs and $P$ plates. This year: $1.3M$ mugs, $0.9P$ plates, and $1.06(M+P)$ items in total."),
 T(r"The totals must agree: $1.3M+0.9P=1.06M+1.06P$, so $<a>M=<b>P$ and $P=<r>M$.", a=g(float(mug - tot)), b=g(float(tot - plate)), r=g(float(ratio))),
 T(r"Take $M=1$, so $P=<r>$. This year there are $<m1>$ mugs, $0.9\times<r>=<pl>$ plates, and $<t>$ items in all.", r=g(float(ratio)), m1=g(float(mugs_now)), pl=g(float(plates_now)), t=g(float(total_now))),
 ret('%s/%s*100' % (g(float(mugs_now)), g(float(total_now))), 4) + r", which is $49.1\%$ to the nearest tenth."]
V['PS-103'] = float(mugs_now / total_now * 100)

# PS-106
N0 = 100; M0 = N0 * 1.2; M1 = M0 * 1.15; N1 = N0 * 0.92
S['PS-106'] = [T(r"Take city N to be $<n>$ in $2020$. City M is $20\%$ greater, so M is $<m>$.", n=N0, m=g(M0)),
 T(r"In $2024$, city M grew $15\%$ and city N fell $8\%$. ") + ret('%s*1.15' % g(M0), 6, ' for city M') + T(r", and ") + ret('%d*0.92' % N0, 6, ' for city N') + ".",
 T(r"M compared with N: ") + ret('(%s-%s)/%s*100' % (g(M1), g(N1), g(N1)), 6) + T(r", so M is $<p>\%$ greater than N.", p=g((M1 - N1) / N1 * 100))]
V['PS-106'] = (M1 - N1) / N1 * 100

# PS-107
b_c = 0.006; c_c = 0.05 * b_c; d_c = 1.5 * c_c; sm = b_c + c_c + d_c
S['PS-107'] = [T(r"Write everything with $a$. $b=0.6\%$ of $a$ is $<b>a$. $c=5\%$ of $b$ is $0.05\times<b>a=<c>a$. $d=150\%$ of $c$ is $1.5\times<c>a=<d>a$.", b=g(b_c, 8), c=g(c_c, 8), d=g(d_c, 8)),
 T(r"Add them: $b+c+d=(<b>+<c>+<d>)a=<s>a$, and this equals $27$.", b=g(b_c, 8), c=g(c_c, 8), d=g(d_c, 8), s=g(sm, 8)),
 ret('27/%s' % g(sm, 8), 4, '.')]
V['PS-107'] = 27 / sm

# PS-114
T114 = Fr(25200 - 18000) / Fr(8, 100); p114 = Fr(18000) / T114 * 100
S['PS-114'] = [T(r"Total sales are the same in both months, so online sales rose from $\$18{,}000$ to $\$25{,}200$ only because the share rose by $8$ percentage points. That rise is $8\%$ of the total $T$."),
 T(r"$25{,}200-18{,}000=<d>$, so $0.08T=<d>$ and $T=<d>\div0.08=<t>$.", d=g(25200 - 18000), t=g(float(T114))),
 T(r"Check: March online share is $<a>\div<t>=<p>\%$, and April is $<b>\div<t>=<q>\%$, which is $8$ more.", a=g(18000), t=g(float(T114)), p=g(float(p114)), b=g(25200), q=g(float(Fr(25200) / T114 * 100)))]
V['PS-114'] = float(T114)

# PS-115  (acid solution)
x115 = (Fr(35, 100) * 40 - 15 - Fr(25, 10)) / (Fr(3, 10) - Fr(35, 100)); tot115 = x115 + 40
S['PS-115'] = [T(r"Track the acid. The first solution holds $0.3x$ liters of acid, the pure acid adds $15$, and the second solution adds $0.1\times25=<a>$. Total acid: $0.3x+<s>$.", a=g(2.5), s=g(15 + 2.5)),
 T(r"The final volume is $x+15+25=x+40$, and $35\%$ of it is acid: $0.35(x+40)=0.35x+<k>$.", k=g(0.35 * 40)),
 T(r"Set the acid equal: $0.3x+<s>=0.35x+<k>$, so $0.05x=<d>$ and $x=<x>$.", s=g(17.5), k=g(14), d=g(float(Fr(35, 10) )), x=g(float(x115))),
 T(r"The question asks for the total volume, not $x$: $<x>+15+25=<t>$ liters.", x=g(float(x115)), t=g(float(tot115)))]
V['PS-115'] = float(tot115)

# PS-121
F0 = 30; Fn = 1.2 * F0; N0_ = Fn / 0.9; Rv = (1.01 * (F0 + N0_) - (Fn + 0.9 * N0_)) / (1 - 1.01); Tc = F0 + N0_ + Rv
S['PS-121'] = [T(r"Percent changes are easier with a convenient number. Let the current fiction books be $<f>$. After a $20\%$ increase there will be $<f>\times1.2=<fn>$.", f=F0, fn=g(Fn)),
 T(r"Nonfiction falls $10\%$ to $0.9N$, and that must equal the new fiction count: $0.9N=<fn>$. ", fn=g(Fn)) + ret('%s/0.9' % g(Fn), 6, ', the current number of nonfiction books.'),
 T(r"Let $R$ be the reference books. Now the total is $<f>+<n>+R=<t0>+R$. After the changes it is $<fn>+<fn>+R=<t1>+R$, which is $1.01(<t0>+R)=<a>+1.01R$.", f=F0, n=g(N0_), t0=g(F0 + N0_), fn=g(Fn), t1=g(2 * Fn), a=g(1.01 * (F0 + N0_))),
 T(r"So $<d>=0.01R$ and $R=<r>$. The current total is $<t>$ books. ", d=g(2 * Fn - 1.01 * (F0 + N0_)), r=g(Rv), t=g(Tc)) + ret('%s/%s*100' % (g(Rv), g(Tc)), 6, r', so reference books are $%s\%%$ of the collection.' % g(Rv / Tc * 100))]
V['PS-121'] = Rv / Tc * 100

# PS-122 (Desmos)
f122 = lambda r_: (1 + r_ / 100) * (1 - (r_ - 13) / 100)
roots = sorted(np_r for np_r in [(13 - math.sqrt(169 + 1200)) / 2, (13 + math.sqrt(169 + 1200)) / 2])
S['PS-122'] = [T(r"A raise of $r$ percent multiplies the price by $1+\dfrac{r}{100}$ and a cut of $(r-13)$ percent multiplies by $1-\dfrac{r-13}{100}$. Together they give $1.1$."),
 "Type %s and %s (letting $x$ stand for $r$; zoom out to see both crossings)." % (c('y=(1+x/100)(1-(x-13)/100)'), c('y=1.1')),
 T(r"Tap the intersections: $(<a>,\,<v>)$ and $(<b>,\,<v>)$. A raise needs $r>0$ (and a cut needs $r-13>0$), so ", a=g(roots[0]), b=g(roots[1]), v=g(f122(roots[1]))) + T(r"$r=<b>$.", b=g(roots[1])),
 "Check: " + ret('(1+25/100)(1-(25-13)/100)', 6, ', which matches the target.')]
V['PS-122'] = roots[1]

# PS-125
S0 = 100; R125 = S0 * 1.5; Q125 = R125 / 0.75; P125 = Q125 / 1.6
S['PS-125'] = [T(r"Start from $S$ and work upward. Take $S=<s>$. $R$ is $50\%$ greater than $S$: $R=<s>\times1.5=<r>$.", s=S0, r=g(R125)),
 T(r"$R$ is $25\%$ less than $Q$, so $R=0.75Q$ and $Q=<r>\div0.75=<q>$.", r=g(R125), q=g(Q125)),
 T(r"$Q$ is $60\%$ greater than $P$, so $Q=1.6P$ and $P=<q>\div1.6=<p>$.", q=g(Q125), p=g(P125)),
 T(r"$P=<p>$ and $S=<s>$, so $P$ is $<d>\%$ greater than $S$.", p=g(P125), s=S0, d=g((P125 - S0) / S0 * 100))]
V['PS-125'] = (P125 - S0) / S0 * 100

# PS-126
tot126 = 84; ssum = Fr(tot126) / Fr(3, 2); tin = ssum / 2; zn = (ssum - 5) / 3; cu = 2 * zn + 5
assert cu + zn == ssum and cu + zn + tin == tot126
S['PS-126'] = [T(r"Let $s$ be the combined mass of copper and zinc. The tin is half of $s$, so the whole sample is $s+\dfrac{s}{2}=1.5s=<t>$.", t=tot126),
 T(r"$s=<t>\div1.5=<s>$ grams, so the tin is $<s>\div2=<n>$ grams.", t=tot126, s=g(float(ssum)), n=g(float(tin))),
 T(r"Check with the other clue: copper is $2z+5$, so $3z+5=<s>$, giving zinc $<z>$ and copper $<c>$. Then $<c>+<z>+<n>=<t>$.", s=g(float(ssum)), z=g(float(zn)), c=g(float(cu)), n=g(float(tin)), t=g(float(cu + zn + tin)))]
V['PS-126'] = float(tin)

# PS-003
parts = 1 + 2 + 3; gr = 3; mixrate = Fr(6) / Fr(gr, parts); tm = Fr(90) / mixrate
S['PS-003'] = [T(r"The ratio $1:2:3$ has $1+2+3=<p>$ parts, and gravel is $<g>$ of them, which is $<f>$ of the mixture.", p=parts, g=gr, f=fr(gr, parts) + r'=' + g(float(Fr(gr, parts)))),
 T(r"If gravel is made at $6$ tons per hour and is $<f>$ of the mixture, the plant makes mixture at $6\div<f>=<r>$ tons per hour.", f=g(float(Fr(gr, parts))), r=g(float(mixrate))),
 T(r"Time $=90\div<r>=<t>$ hours. (Using $6$ tons per hour for the whole mixture would give $<w>$, the common slip.)", r=g(float(mixrate)), t=g(float(tm)), w=g(90 / 6))]
V['PS-003'] = float(tm)

# PS-059
sa, sb = 240 / 3, 350 / 4.5
S['PS-059'] = ["Speed is distance divided by time. Car A: " + ret('240/3', 6, ' kilometers per hour.'),
 "Car B: " + ret('350/4.5', 4, ' kilometers per hour.'),
 "How much faster A is: " + ret('240/3-350/4.5', 4) + ", which is closest to $%s$." % g(round(sa - sb, 1))]
V['PS-059'] = sa - sb

# PS-060
dens = 540 / 60
S['PS-060'] = [T(r"Density is mass divided by volume: $<m>\div<v>=<d>$ grams per cubic centimeter.", m=540, v=60, d=g(dens)),
 T(r"The problem says $1$ gram per cubic centimeter equals $1{,}000$ kilograms per cubic meter, so multiply by $1{,}000$: $<d>\times1{,}000=<k>$.", d=g(dens), k=g(dens * 1000)),
 T(r"Sanity check: water is $1{,}000$ kilograms per cubic meter and this metal is $<d>$ times as dense, so $<k>$ is reasonable; $<d>$ is just the unconverted number.", d=g(dens), k=g(dens * 1000))]
V['PS-060'] = dens * 1000

# PS-061
rate61 = 1250000; day = rate61 * 24
S['PS-061'] = ["One day has $24$ hours, so multiply the hourly rate by $24$. " + ret('1250000*24', 6, ' liters.'),
 "There are $1{,}000$ liters in a cubic meter, so divide by $1{,}000$. " + ret('%d/1000' % day, 6, ' cubic meters.'),
 T(r"Check: $<r>$ liters per hour is $<c>$ cubic meters per hour, and $<c>\times24=<d>$.", r=g(rate61), c=g(rate61 / 1000), d=g(rate61 / 1000 * 24))]
V['PS-061'] = day / 1000

# PS-062
k62 = 45 / 9; y62 = k62 * 14
S['PS-062'] = [T(r"Direct variation means $y=kx$ for a constant $k$."),
 T(r"Use $x=9,\ y=45$ to find $k$: $k=<y>\div<x>=<k>$.", y=45, x=9, k=g(k62)),
 T(r"Now $y=<k>\times14=<y>$ when $x=14$.", k=g(k62), y=g(y62))]
V['PS-062'] = y62

# PS-063
r63 = 15000 / 6; p63 = r63 * 2.5
S['PS-063'] = [T(r"Find the rate: $<p>\div6=<r>$ passengers per hour.", p=g(15000), r=g(r63)),
 T(r"Multiply by the $2.5$-hour window: $<r>\times2.5=<q>$ passengers.", r=g(r63), q=g(p63)),
 T(r"Sanity check: $2.5$ hours is a bit less than half of $6$ hours, so the answer should be a bit less than half of $15{,}000$, which is $<h>$. It is.", h=g(15000 / 2))]
V['PS-063'] = p63

# PS-073
from math import lcm
gain = Fr(1, 12) - Fr(1, 20); tpass = 1 / gain
S['PS-073'] = [T(r"Count laps. In $t$ seconds Car A completes $\dfrac{t}{12}$ laps and Car B completes $\dfrac{t}{20}$ laps. Car A passes Car B again when it has gained exactly one full lap."),
 T(r"Gain per second: $\dfrac{1}{12}-\dfrac{1}{20}=\dfrac{5}{60}-\dfrac{3}{60}=\dfrac{2}{60}=<g>$ lap per second.", g=fr(gain.numerator, gain.denominator)),
 T(r"One lap of gain takes $1\div<g>=<t>$ seconds. (The number $<l>$ is when both cars are back at the start together, not when A next passes B.)", g=fr(gain.numerator, gain.denominator), t=g(float(tpass)), l=lcm(12, 20))]
V['PS-073'] = float(tpass)

# PS-088
vol88 = 12 * 5 * 2; min88 = vol88 / 0.8; hr88 = min88 / 60
S['PS-088'] = [T(r"Volume of the tank: $12\times5\times2=<v>$ cubic meters.", v=vol88),
 T(r"Time $=$ volume $\div$ rate $=<v>\div0.8=<m>$ minutes.", v=vol88, m=g(min88)),
 T(r"The answer is in hours: $<m>\div60=<h>$.", m=g(min88), h=g(hr88))]
V['PS-088'] = hr88

# PS-093
a93 = 22 * 3600 / 5280
S['PS-093'] = ["Convert one unit at a time. Feet to miles: divide by $5{,}280$. Seconds squared to minutes squared: one minute is $60$ seconds, so one second squared is $\\dfrac{1}{60^2}$ of a minute squared, and the number gets multiplied by $60^2=%s$." % g(60 ** 2),
 ret('22*3600/5280', 6) + ", so $22$ feet per second squared is $%s$ miles per minute squared." % g(a93),
 T(r"Slips to avoid: multiplying by $<s>$ but forgetting to divide by $<f>$ gives $<w>$; dividing only by $<f>$ gives $<u>$.", s=g(3600), f=g(5280), w=g(22 * 3600), u=fr(22, 5280) + r'=' + fr(1, 240))]
V['PS-093'] = a93

# PS-098
kmgal = 40 * 1.6; gal98 = 304 / kmgal; L98 = gal98 * 3.8
S['PS-098'] = [T(r"Work in kilometers. $40$ miles per gallon is $40\times1.6=<k>$ kilometers per gallon.", k=g(kmgal)),
 T(r"Gallons needed for $304$ kilometers: $304\div<k>=<g>$ gallons.", k=g(kmgal), g=g(gal98)),
 "Convert to liters at $3.8$ liters per gallon in one line: " + ret('304/(40*1.6)*3.8', 6, ' liters.')]
V['PS-098'] = L98

# PS-101  (population density, squared length unit)
sqmi = 1.6 ** 2; d101 = 1250 * sqmi
S['PS-101'] = ["A square mile is a square that is $1$ mile on each side, so it measures $1.6$ km by $1.6$ km. " + ret('1.6^2', 6, ' square kilometers.'),
 "Each square kilometer holds $1{,}250$ people, so one square mile holds " + ret('1250*2.56', 6, ' people.'),
 T(r"Squared unit, so use $1.6^2$, not $1.6$. Multiplying by only $1.6$ would give $<w>$.", w=g(1250 * 1.6))]
V['PS-101'] = d101

# PS-104
B104 = 4 * 12; extra = 120; per3 = 3 * 24; Av = Fr(extra) / (per3 - B104)
S['PS-104'] = [T(r"Force $=$ pressure $\times$ area. At first each of the $4$ legs carries $12A$ newtons, so the table and box weigh $4\times12A=<b>A$ newtons.", b=B104),
 T(r"After the extra $<e>$ newtons, the total is $<b>A+<e>$, shared by $3$ legs that each carry $24A$: $3\times24A=<p>A$.", e=extra, b=B104, p=per3),
 T(r"Set them equal: $<b>A+<e>=<p>A$, so $<e>=<d>A$ and $A=<a>$.", b=B104, e=extra, p=per3, d=per3 - B104, a=g(float(Av)))]
V['PS-104'] = float(Av)

# PS-108
blue = 140 * 3 // 14; nb = 140 - blue; red = nb * 7 // 11; green = nb - red
assert blue == 30 and 4 * red == 7 * green
S['PS-108'] = [T(r"Blue to not-blue is $3:11$, so blue is $3$ of every $3+11=<s>$ equal parts of the $140$ drives. One part is $140\div<s>=<p>$, so blue is $3\times<p>=<b>$ and not-blue is $<n>$.", s=14, p=140 // 14, b=blue, n=nb),
 T(r"The $<n>$ non-blue drives are red and green in the ratio $7:4$, which is $7+4=<s>$ parts. One part is $<n>\div<s>=<p>$, so red is $7\times<p>=<r>$ and green is $4\times<p>=<gr>$.", n=nb, s=11, p=nb // 11, r=red, gr=green),
 T(r"Red minus blue is $<r>-<b>=<d>$.", r=red, b=blue, d=red - blue)]
V['PS-108'] = red - blue

# PS-110
m_per_cm = 40 / 1.25; Wm = 7.5 * m_per_cm; Hm = 5 * m_per_cm; Am = Wm * Hm; ha = Am / 10000
wrong = (7.5 * 40) * (5 * 40) / 10000
S['PS-110'] = ["The copy is $125\\%$ of the plan, so every length on the copy is $1.25$ times its length on the plan. Thus $1.25$ cm on the copy is $40$ m of ground, and $1$ cm on the copy is: " + ret('40/1.25', 6, ' meters.'),
 "The parcel measures $7.5$ cm by $5$ cm on the copy. Its length: " + ret('7.5*%s' % g(m_per_cm), 6, ' meters.') + " Its width: " + ret('5*%s' % g(m_per_cm), 6, ' meters.'),
 "Area: " + ret('%s*%s' % (g(Wm), g(Hm)), 6, ' square meters.') + " Hectares: " + ret('%s/10000' % g(Am), 6, ' hectares.'),
 T(r"Slip to avoid: using $1$ cm $=40$ m without allowing for the enlargement gives $<w>$ hectares.", w=g(wrong))]
V['PS-110'] = ha

# ---------------------------------------------------------------- Part B
# PS-024
S['PS-024'] = [T(r"\textquotedblleft$24\%$ greater than $75$\textquotedblright\ means $75$ plus $24\%$ of $75$: $m=75+0.24(75)$."),
 T(r"Factor out the $75$: $m=75(1+0.24)=75(<r>)$.", r=g(1.24)),
 T(r"The problem says $m=75r$, so $r=<r>$. Watch out: $0.24$ is only the increase, not the full multiplier.", r=g(1.24))]
V['PS-024'] = 1.24

# PS-025
old, new = 340.00, 378.20; inc25 = new - old
S['PS-025'] = [T(r"Percent increase $=\dfrac{\text{new}-\text{old}}{\text{old}}\times100$. The increase is $<n>-<o>=<d>$ dollars.", n=g(new), o=g(old), d=g(inc25)),
 ret('%s/%d*100' % (g(inc25), old), 4) + r", which is $11.2\%$ to the nearest tenth.",
 T(r"Divide by the old bill, $<o>$, not the new one. Dividing by $<n>$ gives $<w>\%$ instead.", o=g(old), n=g(new), w=g(inc25 / new * 100, 1))]
V['PS-025'] = inc25 / old * 100

# PS-026
yr1 = 90000 * 0.85; yr2 = yr1 * 0.85
S['PS-026'] = ["Losing $15\\%$ each year means the value is multiplied by $0.85$ each year, so after $2$ years it is $90{,}000\\times0.85^2$.",
 ret('90000*0.85^2', 6, ' dollars.'),
 T(r"One year gives only $<y>$ dollars, which is a different answer choice. The second year's loss is $15\%$ of $<y>$, not of $90{,}000$.", y=g(yr1))]
V['PS-026'] = yr2

# PS-064 (decrease)
dec64 = 720 - 640
S['PS-064'] = [T(r"Percent decrease $=\dfrac{\text{old}-\text{new}}{\text{old}}\times100$. The enrollment dropped by $720-640=<d>$ students.", d=dec64),
 ret('%d/720*100' % dec64, 4) + r", which is about $11.1\%$.",
 T(r"Divide by the starting value, $720$. Dividing by $640$ gives $<w>\%$, the tempting wrong choice.", w=g(dec64 / 640 * 100))]
V['PS-064'] = dec64 / 720 * 100

# PS-065
disc = 3200 * 0.85; fin = disc * 1.15
S['PS-065'] = ["Discount first: paying $85\\%$ of the listed price. " + ret('3200*0.85', 6, ' dollars.'),
 "Now add $15\\%$ tax to the discounted price: " + ret('%s*1.15' % g(disc), 6, ' dollars.'),
 T(r"The tax is taken from $<d>$, a smaller base than $3{,}200$, so the final price is below $3{,}200$. In one line: $0.85\times1.15=<f>$, which is $<p>\%$ of the listed price.", d=g(disc), f=g(0.85 * 1.15), p=g(0.85 * 1.15 * 100))]
V['PS-065'] = fin

# PS-066
orig = 256 / 0.8
S['PS-066'] = [T(r"After a $20\%$ discount you pay $80\%$ of the original price $p$, so $0.8p=256$."),
 T(r"$p=256\div0.8=<p>$ dollars.", p=g(orig)),
 T(r"Check: $20\%$ of $<p>$ is $<d>$ and $<p>-<d>=256$. (Adding $20\%$ to $256$ would give $<w>$, which is wrong because the discount was taken from the original price.)", p=g(orig), d=g(orig * 0.2), w=g(256 * 1.2))]
V['PS-066'] = orig

# PS-067
v67 = 850 * 0.34
S['PS-067'] = ["Find $34\\%$ of $850$. " + ret('0.34*850', 6, ' students.'),
 T(r"Check by pieces: $10\%$ of $850$ is $<a>$, so $30\%$ is $<b>$, and $4\%$ is $<c>$. Then $<b>+<c>=<d>$.", a=g(85.0), b=g(255.0), c=g(850 * 0.04), d=g(255.0 + 850 * 0.04)),
 T(r"Sanity check: $34\%$ is a little more than one third, and one third of $850$ is about $<t>$, so $<v>$ students fits.", t=g(850 / 3, 1), v=g(v67))]
V['PS-067'] = v67

# PS-071
lhs = 0.3 * 0.4; rhs = 0.5 - 0.2
S['PS-071'] = [T(r"\textquotedblleft Of\textquotedblright\ means multiply, so $30\%$ of $40\%$ of $x$ is $0.3\times0.4\,x=<a>x$.", a=g(lhs)),
 T(r"Right side: $50\%$ of $y$ minus $20\%$ of $y$ is $0.5y-0.2y=<b>y$.", b=g(rhs)),
 T(r"$<a>x=<b>y$, so $x=\dfrac{<b>}{<a>}\,y=<r>y$.", a=g(lhs), b=g(rhs), r=g(rhs / lhs))]
V['PS-071'] = rhs / lhs

# PS-075
kk = 66 / 0.3
S['PS-075'] = [T(r"Object B has mass $1.3k$ and is $66$ grams more than A, so $1.3k=k+66$."),
 T(r"Subtract $k$: $0.3k=66$, so $k=66\div0.3=<k>$.", k=g(kk)),
 T(r"Check: B is $1.3\times<k>=<b>$, and $<b>-<k>=<d>$.", k=g(kk), b=g(1.3 * kk), d=g(1.3 * kk - kk))]
V['PS-075'] = kk

# PS-076
g1 = 0.003 * 40; g2 = 0.0005 * 60; sal = g1 + g2
S['PS-076'] = ["Find the grams of sodium chloride in each solution. First: " + ret('0.003*40', 6, ' grams') + " (that is $0.3\\%$ of $40$).",
 "Second: " + ret('0.0005*60', 6, ' grams') + " (that is $0.05\\%$ of $60$).",
 T(r"Together: $<a>+<b>=<s>$ grams of salt in $100$ grams of mixture, so the mixture is $<p>\%$ sodium chloride. (Averaging $0.3$ and $0.05$ to get $<w>$ ignores that the amounts differ.)", a=g(g1), b=g(g2), s=g(sal), p=g(sal / 100 * 100), w=g((0.3 + 0.05) / 2))]
V['PS-076'] = sal / 100 * 100

# PS-004
fuel = 6.5 / 100 * 340
S['PS-004'] = [T(r"The rate is $6.5$ liters for every $100$ kilometers, which is $<u>$ liter per kilometer.", u=g(6.5 / 100)),
 "For $340$ kilometers: " + ret('6.5/100*340', 6, ' liters.'),
 T(r"Check by scaling: $340$ km is $3.4$ times $100$ km. ") + ret('6.5*3.4', 6, ', the same amount.')]
V['PS-004'] = fuel

# PS-017
rais = 18; per = rais / 3; oats = 5 * per
S['PS-017'] = [T(r"Raisins are $3$ parts of the ratio $5:2:3$ (oats : honey : raisins) and weigh $<r>$ kilograms.", r=rais),
 T(r"One part is $<r>\div3=<p>$ kilograms.", r=rais, p=g(per)),
 T(r"Oats are $5$ parts: $5\times<p>=<o>$ kilograms.", p=g(per), o=g(oats))]
V['PS-017'] = oats

# PS-054
ms = 90 * 1000 / 3600
S['PS-054'] = [T(r"Use $1$ km $=1{,}000$ m and $1$ hour $=3{,}600$ s. Then $90$ km per hour is $<m>$ m per $<s>$ s.", m=g(90000), s=g(3600)),
 T(r"$<m>\div<s>=<v>$ meters per second.", m=g(90000), s=g(3600), v=g(ms)),
 T(r"Shortcut to remember: kilometers per hour divided by $3.6$ gives meters per second, and $90\div3.6=<v>$.", v=g(90 / 3.6))]
V['PS-054'] = ms

# PS-055
sc = 24 / 8
S['PS-055'] = [T(r"The new batch serves $24\div8=<s>$ times as many people, so every ingredient is multiplied by $<s>$.", s=g(sc)),
 T(r"Orange juice: $3\times<s>=<j>$ cups.", s=g(sc), j=g(3 * sc)),
 T(r"The water would be $5\times<s>=<w>$ cups, which is a different answer choice. The question asks for orange juice.", s=g(sc), w=g(5 * sc))]
V['PS-055'] = 3 * sc

# PS-056
rate56 = 480 / 8; q56 = rate56 * 5.5
S['PS-056'] = [T(r"Unit rate: $480\div8=<r>$ boxes per hour.", r=g(rate56)),
 T(r"For $5.5$ hours: $<r>\times5.5=<q>$ boxes.", r=g(rate56), q=g(q56)),
 T(r"Check in pieces: $5$ hours is $<a>$ boxes and half an hour is $<b>$ boxes, and $<a>+<b>=<q>$.", a=g(rate56 * 5), b=g(rate56 * 0.5), q=g(q56))]
V['PS-056'] = q56

# PS-057
h57 = 18 * 2.5
S['PS-057'] = [T(r"Every $1$ cm on the model is $2.5$ m on the real tower, so multiply the model height by $2.5$."),
 T(r"$18\times2.5=<h>$ meters.", h=g(h57)),
 T(r"Check in pieces: $10$ cm is $<a>$ m and $8$ cm is $<b>$ m, and $<a>+<b>=<h>$.", a=g(10 * 2.5), b=g(8 * 2.5), h=g(h57))]
V['PS-057'] = h57

# PS-058
parts58 = 2 + 15; part58 = 51 / parts58; salt58 = 2 * part58
S['PS-058'] = [T(r"Salt to water is $2:15$, so the $51$ liters of solution are split into $2+15=<p>$ equal parts.", p=parts58),
 T(r"One part is $51\div<p>=<u>$ liters.", p=parts58, u=g(part58)),
 T(r"Salt is $2$ parts: $2\times<u>=<s>$ liters. (The water is $15\times<u>=<w>$ liters, and $<u>$ liters is just one part.)", u=g(part58), s=g(salt58), w=g(15 * part58))]
V['PS-058'] = salt58

# PS-072  (almonds and cashews)
kk72 = Fr(3 * 8 - 2 * 8, 15 - 14)   # 14k-16=15k-24
al, ca = 7 * kk72, 5 * kk72
S['PS-072'] = [T(r"Write the amounts as $7k$ almonds and $5k$ cashews, since the ratio is $7:5$."),
 T(r"After removing $8$ of each, $\dfrac{7k-8}{5k-8}=\dfrac{3}{2}$. Cross-multiply: $2(7k-8)=3(5k-8)$, so $<a>k-<b>=<c>k-<d>$.", a=2 * 7, b=2 * 8, c=3 * 5, d=3 * 8),
 T(r"Solve: $<d>-<b>=<c>k-<a>k$, so $k=<k>$.", d=3 * 8, b=2 * 8, c=15, a=14, k=g(float(kk72))),
 T(r"Cashews at the start: $5k=<c>$. Check: $<a>-8=<a2>$ almonds and $<c>-8=<c2>$ cashews, and $<a2>\div<c2>=\dfrac{3}{2}$.", c=g(float(ca)), a=g(float(al)), a2=g(float(al - 8)), c2=g(float(ca - 8)))]
V['PS-072'] = float(ca)

# PS-087
wcm, hcm = 2.4 * 100, 1.5 * 100; acm = wcm * hcm; cost = acm * 0.05
S['PS-087'] = ["The price is per square centimeter, so change the sides to centimeters first: $2.4$ m $=%s$ cm and $1.5$ m $=%s$ cm." % (g(wcm), g(hcm)),
 "Area: " + ret('%s*%s' % (g(wcm), g(hcm)), 6, ' square centimeters.'),
 "Cost: " + ret('%s*0.05' % g(acm), 6, ' dollars.') + T(r" Slip to avoid: one square meter is $100\times100=<u>$ square centimeters, not $100$.", u=g(100 * 100))]
V['PS-087'] = cost

# PS-089  (mph to ft/s)
fts = 45 * 5280 / 3600
S['PS-089'] = ["Change miles to feet and hours to seconds: $45$ miles per hour is $45\\times5{,}280$ feet per $3{,}600$ seconds.",
 ret('45*5280/3600', 6, ' feet per second.'),
 T(r"Check with a landmark: $60$ miles per hour is exactly $<a>$ feet per second, and $<a>\times\dfrac{45}{60}=<f>$. Forgetting to divide by $3{,}600$ would give $<w>$.", a=g(60 * 5280 / 3600), f=g(60 * 5280 / 3600 * 45 / 60), w=g(45 * 5280))]
V['PS-089'] = fts

# PS-090  (volume in cm^3)
vm3 = 0.4 * 0.5 * 0.3; vcm = vm3 * 100 ** 3
S['PS-090'] = [T(r"Volume in cubic meters: $0.4\times0.5\times0.3=<v>$.", v=g(vm3)),
 T(r"One cubic meter is $100\times100\times100=<u>$ cubic centimeters, because all three lengths are converted.", u=g(100 ** 3)),
 T(r"$<v>\times<u>=<c>$ cubic centimeters. Check by converting the sides first: $40\times50\times30=<c2>$.", v=g(vm3), u=g(100 ** 3), c=g(vcm), c2=g(40 * 50 * 30))]
V['PS-090'] = vcm

# PS-112
A112 = 1.8; k2 = A112 / 20; k112 = math.sqrt(k2)
S['PS-112'] = [T(r"The banner's area is $w\times1.8w=<a>w^2$.", a=g(A112)),
 T(r"Each tile is a square with side $kw\sqrt5$, so its area is $(kw\sqrt5)^2=5k^2w^2$, and $4$ tiles have area $<t>k^2w^2$.", t=g(4 * 5)),
 T(r"Set the areas equal: $<t>k^2w^2=<a>w^2$, so $k^2=<a>\div<t>=<k2>$ and $k=<k>$, taking the positive root.", t=g(20), a=g(A112), k2=g(k2), k=g(k112))]
V['PS-112'] = k112

# tool tags (honest choice per problem)
TOOLT = {}
for i in "PS-027 PS-028 PS-068 PS-082 PS-085 PS-095 PS-097 PS-114 PS-115 PS-125 PS-126 PS-003 PS-060 PS-062 PS-063 PS-073 PS-088 PS-104 PS-108 PS-024 PS-066 PS-071 PS-075 PS-017 PS-054 PS-055 PS-056 PS-057 PS-058 PS-072 PS-090 PS-112".split(): TOOLT[i] = 'N'
for i in "PS-069 PS-083 PS-084 PS-086 PS-100 PS-103 PS-106 PS-107 PS-121 PS-059 PS-061 PS-093 PS-098 PS-101 PS-110 PS-025 PS-026 PS-064 PS-065 PS-067 PS-076 PS-004 PS-087 PS-089".split(): TOOLT[i] = 'C'
TOOLT['PS-122'] = 'D'


def _fixcase(t):
    return re.sub(r'Type \[\[', lambda mo: ('type [[' if t[:mo.start()].rstrip() and not t[:mo.start()].rstrip().endswith('.') else 'Type [['), t)
for _k in S: S[_k] = [_fixcase(x) for x in S[_k]]
