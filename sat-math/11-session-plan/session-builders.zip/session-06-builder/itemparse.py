import re,json
def tab(md):
    rows=[r.strip().strip('|').split('|') for r in md.strip().split('\n') if r.strip().startswith('|') and not re.match(r'^\|\s*-',r.strip())]
    n=len(rows[0]);t=r"\begin{center}\renewcommand{\arraystretch}{1.6}\begin{tabular}{|"+"c|"*n+"}\hline "
    for r in rows: t+=" & ".join(c.strip() for c in r)+r" \\ \hline "
    return t+r"\end{tabular}\end{center}"
def parse(o):
    lines=o['q'].split('\n');stem=[];opts=[]
    for ln in lines:
        m=re.match(r'^\(?([A-D])\)\s*(.*)$',ln.strip())
        if m and (opts or m.group(1)=='A') and (len(opts)==ord(m.group(1))-65): opts.append(m.group(2).strip())
        elif opts and ln.strip()=='' : continue
        elif opts: opts[-1]+=' '+ln.strip()
        else: stem.append(ln)
    stem='\n'.join(stem).strip()
    tl=[l for l in stem.split('\n') if l.strip().startswith('|')]
    if tl:
        tb=tab('\n'.join(tl)); L=stem.split('\n'); first=L.index(tl[0])
        pre='\n'.join(L[:first]).strip();post='\n'.join(L[first+len(tl):]).strip()
        stem=(pre+'\n\n' if pre else '')+tb+('\n\n'+post if post else '')
    stem=re.sub(r'\n\s*\n','\n\n',stem)
    return stem,(opts if opts else None)
def optnum(x):
    t=x.replace('\\$','').replace('\\%','').replace('$','').replace('{,}','').replace(',','').replace('\\dfrac','\\frac').strip()
    t=re.sub(r'^x=','',t); t=re.sub(r'y$','',t)
    m=re.match(r'^\\frac\{?(\d+)\}?\{?(\d+)\}?$',t)
    if m: return int(m.group(1))/int(m.group(2))
    t=t.replace('\\,','')
    return float(t)
def bank_letter(ans,opts):
    m=re.match(r'^\(?([A-D])(?:\)|$|\s)',ans.strip()); assert m,ans; return "ABCD".index(m.group(1))
