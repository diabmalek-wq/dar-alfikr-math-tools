import re,json,csv
B=open('/home/claude/repo-check2/sat-bank/verified-item-bank/SAT_Bank_Verified_Item_Bank.md').read()
blocks=re.split(r'\n(?=### )',B)
bank={}
for b in blocks:
    m=re.match(r'### (\S+)',b)
    if not m: continue
    iid=m.group(1)
    d={}
    sk=re.search(r'\*\*Skill:\*\*\s*([^\n|]*)',b); df=re.search(r'\*\*Difficulty:\*\*\s*(\w+)',b); fm=re.search(r'\*\*Format:\*\*\s*([^\n]+)',b)
    if not(sk and df and fm): continue
    d['skill']=sk.group(1).strip(); d['diff']=df.group(1); d['fmt']=fm.group(1).strip()
    q=re.search(r'\*\*Question:\*\*\s*(.*?)\n\n\*\*Correct Answer:\*\*',b,re.S)
    a=re.search(r'\*\*Correct Answer:\*\*\s*(.*?)(?:\n\n|\Z)',b,re.S)
    r=re.search(r'\*\*Rationale[^\n]*\*\*:?\s*(.*?)(\n\n\*\*Misc|\n\n\*\*Mis|\n---|\Z)',b,re.S)
    if q: d['q']=q.group(1).strip()
    if a: d['ans']=a.group(1).strip()
    if r: d['rat']=r.group(1).strip()
    bank[iid]=d
rows=[r for r in csv.DictReader(open('/home/claude/cb/session_plan_11.csv')) if r['session']=='6']
A=[r for r in rows if r['part']=='In class']; Bp=[r for r in rows if r['part']!='In class']
out=[]
for r in A+Bp:
    d=bank[r['id']]; assert d['diff']==r['difficulty'] and r['skill'] in d['skill'],(r,d.get('skill'),d.get('diff'))
    out.append(dict(id=r['id'],part=r['part'],d=d['diff'],fmt=d['fmt'],q=d['q'],ans=d['ans'],rat=d.get('rat','')))
json.dump(out,open('raw_items.json','w'),indent=1)
print(len(A),len(Bp),len(out))
