# Independent solutions computed from the question text only (exact fractions, linear solver, numpy/scipy roots, brute force).
# Bank answers are read only in the comparison loop at the bottom.
import json,math,itertools
from fractions import Fraction as F
import numpy as np
from scipy.optimize import brentq
from itemparse import *
def linsolve(A,b):
    """exact Gaussian elimination over Fractions"""
    n=len(A); M_=[[F(x) for x in row]+[F(bb)] for row,bb in zip(A,b)]
    for i in range(n):
        p=next(r for r in range(i,n) if M_[r][i]!=0); M_[i],M_[p]=M_[p],M_[i]
        M_[i]=[x/M_[i][i] for x in M_[i]]
        for r in range(n):
            if r!=i: M_[r]=[x-M_[r][i]*y for x,y in zip(M_[r],M_[i])]
    return [M_[i][n] for i in range(n)]
P=lambda a,b=100:F(a)/b
M={}
# ---- Part A (in class)
M['PS-027']=F(1100,500)*100
M['PS-028']=100*(1-P(40)*P(45))
M['PS-068']=5000*P(110)*P(90)
M['PS-069']=100*F(abs(480-432),432)
M['PS-082']=100*P(140)*P(75)                        # +40%, -25%  (replacement numbers)
M['PS-083']=F(210)/(P(140)*P(75))
M['PS-084']=F(9200)/(P(80)*P(115))                  # -20%, +15%  (replacement numbers)
M['PS-085']=100*(P(150)*P(80))                      # x=1.5y, y=0.8z, so x/z
M['PS-086']=100*(1-P(110)*P(110)*P(80))
# 095: area = w*(1.5w)=540 -> w^2=360 ; w = c*sqrt(10) -> c^2*10=360
w2=F(540)/F(3,2); M['PS-095']=math.sqrt(w2/10)
# 097: 150*.2+.5m+40 = .4(190+m) -> linear in m: coefficient and constant, solved exactly
a1=P(50)-P(40); b1=P(40)*190-(150*P(20)+40); M['PS-097']=b1/a1
M['PS-100']=100*(brentq(lambda r:(1+r)**3-1.331,0,1,xtol=1e-14))
# 103: 1.3M+0.9P=1.06(M+P) -> P/M ; this-year mugs share
rat=(P(130)-P(106))/(P(106)-P(90)); M['PS-103']=100*P(130)/(P(130)+P(90)*rat)
M['PS-106']=100*(P(120)*P(115)/P(92)-1)
M['PS-107']=F(27)/(P(6,1000)*(1+P(5)+P(5)*P(150)))
# 114: both months same total T, online share p% -> p/100*T=18000, (p+8)/100*T=25200
T=(F(25200)-F(18000))/F(8,100); M['PS-114']=T
# 115 (acid): .3x+15+2.5=.35(x+40)
x=(F(35,100)*40-F(15)-F(25,10))/(F(3,10)-F(35,100)); M['PS-115']=x+40
# 121: F=3k,N: 1.2F=.9N; use exact solve with F=30 (scale): unknowns N,R,T
Fv=F(30); Nv=P(120)*Fv/P(90); Rv=(P(101)*(Fv+Nv)-(P(120)*Fv+P(90)*Nv))/(1-P(101)); M['PS-121']=100*Rv/(Fv+Nv+Rv)
# 122: (1+r/100)(1-(r-13)/100)=1.1 ; scan integers and refine with numpy roots of -r^2+13r+11300-11000
roots=np.roots([1,-13,-300]); M['PS-122']=max(roots)
M['PS-125']=100*(1/(P(150)**-1*P(75)*P(160))-1)   # S = R/1.5 = .75*1.6P/1.5 ; P/S - 1
# 126 exact: copper=2z+5, tin=(copper+z)/2, total 84 -> unknowns z,c,t
z,c,t=linsolve([[2,-1,0],[1,1,-2],[1,1,1]],[-5,0,84]); M['PS-126']=t
M['PS-003']=F(90)/(F(6)*F(1+2+3,3))
M['PS-059']=F(240,3)-F(350)/F(9,2)
M['PS-060']=F(540,60)*1000
M['PS-061']=F(1250000)*24/1000
M['PS-062']=F(45,9)*14
M['PS-063']=F(15000,6)*F(5,2)
M['PS-073']=min(F(i,100) for i in range(1,100000) if F(i,100)/12-F(i,100)/20==1)   # first time A has gained one full lap
M['PS-088']=F(12*5*2)/F(8,10)/60
M['PS-093']=F(22)*3600/5280
M['PS-098']=F(304)/F(16,10)/40*F(38,10)
M['PS-101']=F(1250)*F(16,10)**2
# 104: pressure*area per leg: (4*12*A+120)/3 = 24*A -> (48A+120)=72A
M['PS-104']=F(120)/(F(24*3)-F(4*12))
sol=[(rd,g,b_) for b_ in range(0,141) for rd in range(0,141) for g in range(0,141) if rd+g+b_==140 and 4*rd==7*g and 11*b_==3*(rd+g)]; assert len(sol)==1; M['PS-108']=sol[0][0]-sol[0][2]
M['PS-110']=(F(75,10)*40/F(125,100))*(F(5)*40/F(125,100))/10000
# ---- Part B
M['PS-024']=(75+75*P(24))/75
M['PS-025']=100*(F(37820,100)-340)/340
M['PS-026']=90000*P(85)**2
M['PS-064']=100*F(720-640,720)      # decrease (replacement)
M['PS-065']=F(3200)*P(85)*P(115)
M['PS-066']=F(256)/P(80)
M['PS-067']=F(850)*P(34)
M['PS-071']=(P(50)-P(20))/(P(30)*P(40))       # x/y
M['PS-075']=F(66)/(P(130)-1)
M['PS-076']=100*(F(40)*P(3,1000)+F(60)*P(5,10000))/100
M['PS-004']=F(65,10)/100*340
M['PS-017']=F(18)/3*5
M['PS-054']=F(90)*1000/3600
M['PS-055']=F(3)*24/8
M['PS-056']=F(480,8)*F(11,2)
M['PS-057']=F(18)*F(25,10)
M['PS-058']=F(51)*2/17
sol=[(a1,s1) for a1 in range(1,400) for s1 in range(1,400) if 5*a1==7*s1 and 2*(a1-8)==3*(s1-8)]; assert len(sol)==1; M['PS-072']=sol[0][1]
M['PS-087']=F(240)*F(150)*P(5)
M['PS-089']=F(45)*5280/3600
M['PS-090']=F(4,10)*100*F(5,10)*100*F(3,10)*100
# 112: 4*(k*sqrt5)^2 w^2 = 1.8 w^2 -> k^2=1.8/20
M['PS-112']=math.sqrt(F(18,10)/20)
# ---------- comparison with the bank (read only now)
items=json.load(open('s6_items_raw.json'))
fails=[];checked=0;LET={}
ROUND1=('PS-103','PS-025','PS-064','PS-069','PS-059')
for o in items:
    stem,opts=parse(o); v=float(M[o['id']])
    if opts:
        assert len(opts)==4 and len(set(opts))==4,(o['id'],opts)
        vals=[optnum(t) for t in opts]
        tgt=round(v,1) if o['id'] in ROUND1 else v
        hit=[i for i,u in enumerate(vals) if abs(u-tgt)<1e-9]
        assert len(hit)==1,(o['id'],vals,v,hit)
        got=hit[0]; LET[o['id']]=got; want=bank_letter(o['ans'],opts); ok=(got==want)
        if o['changed'] in (None,'context only'): assert o['ans']==o['bank_ans']
        print('%s MCQ  mine=%s(%s) key=%s %s'%(o['id'],"ABCD"[got],opts[got],"ABCD"[want],'OK' if ok else 'MISMATCH'))
    else:
        a=o['ans'].replace('$','').replace('{,}','').strip(); want=float(F(a)); ok=abs(want-v)<1e-9
        print('%s SPR  mine=%s key=%s %s'%(o['id'],round(v,6),a,'OK' if ok else 'MISMATCH'))
    if not ok: fails.append(o['id'])
    checked+=1
print('checked',checked,'fails',fails)
json.dump(LET,open('letters.json','w')); json.dump({k:float(v) for k,v in M.items()},open('solved.json','w'),indent=1)
