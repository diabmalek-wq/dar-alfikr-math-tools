# bank_raw.json (extracted from the bank, CSV order) -> s3_items.json (final text: private-tutoring clean, fixes applied)
import json,re
raw=json.load(open('bank_raw.json'))
CLEAN={  # context rewrites (math unchanged)
 'A-124':[("Layla","Emma"),("Noura","Grace")],
 'AM-009':[("As part of a heritage-tourism marketing campaign in AlUla, aligned with Vision 2030, the number of visitors","As part of a tourism marketing campaign, the number of visitors")],
 'AM-054':[("A transportation company serving pilgrims in Makkah uses","A taxi company uses"),("fare per passenger, in SAR","fare per passenger, in dollars"),("fixed service charge, in SAR","fixed service charge, in dollars")],
 'AM-070':[("in thousands of SAR","in thousands of dollars"),("price of the product in SAR","price of the product in dollars")],
 'AM-077':[("in millions of SAR","in millions of dollars")],
 'AM-075':[("cm²","$\\text{cm}^2$"),("$30$ $\\text{cm}^2$","$30\\ \\text{cm}^2$")],
}
FIX={}   # id -> dict(q=..., ans=..., why=...)  substantive math fixes / de-duplication edits
FIX['AM-052']=dict(why='FIX: two options were correct ((0,2) and (1,7) both satisfy both equations). Option B changed from (0,2) to (0,5); key stays D.',
                   sub=[("B) $(0,2)$","B) $(0,5)$")])
FIX['AM-014']=dict(why='DEDUP (same trick and layout as AM-007: sum of x-coordinates): asks for the PRODUCT of the x-coordinates; answer 7 -> -6.',
                   sub=[("What is the sum of the $x$-coordinates of these two points?","What is the product of the $x$-coordinates of these two points?")],ans='$-6$')
FIX['AM-009']=dict(why='DEDUP (same count-the-nonnegative-solutions idea as AM-077, both answered 2): quadratic changed from x^2-2x-3 to x^2+2x-3, so one of the two roots is negative; answer C -> B.',
                   sub=[("$v = x^{2} - 2x - 3$","$v = x^{2} + 2x - 3$")],ans='B')
FIX['AM-034']=dict(why='DEDUP (same extraneous-root equation shape as AM-112, both with denominator x-3): numbers changed to denominator x-2; answer stays D.',
                   sub=[("\\dfrac{x}{x-3} = \\dfrac{3}{x-3} + 2","\\dfrac{x}{x-2} = \\dfrac{2}{x-2} + 3"),("A) $x=3$ only","A) $x=2$ only"),("B) $x=9$ only","B) $x=4$ only"),("C) $x=3$ and $x=9$","C) $x=2$ and $x=4$")])
out=[]
for o in raw:
    q=o['q']; iid=o['id']
    q=re.sub(r'^\*\*Tool:\*\*[^\n]*\n','',q).strip()
    for a,b in CLEAN.get(iid,[]):
        assert a in q,(iid,a); q=q.replace(a,b)
    f=FIX.get(iid)
    ans=o['ans'].split('\n')[0].strip()
    if f:
        for a,b in f['sub']:
            assert a in q,(iid,a); q=q.replace(a,b)
        if 'ans' in f: ans=f['ans']
    # leading inline-math line becomes display math
    q=re.sub(r'^\$([^$\n]+)\$\s+(?=[A-Z])',lambda m:'$$'+m.group(1)+'$$\n',q)
    q=re.sub(r'\$\$\s*\$\$',r'$$\n$$',q)
    # split "$$..$$ Text" so the sentence after display math starts a new line
    q=re.sub(r'(\$\$)[ \t]+(?=[A-Z])',r'\1\n',q)
    out.append(dict(id=iid,part=o['part'],d=o['d'],q=q,ans=ans,orig_ans=o['ans'].split('\n')[0].strip(),fix=(f or {}).get('why')))
json.dump(out,open('s3_items.json','w'),indent=1)
print(len(out),sum(1 for o in out if o['part']=='In class'),sum(1 for o in out if o['part']!='In class'))
for o in out:
    if o['fix'] or o['id'] in ('AM-142','AM-177','AM-232','AM-087','AM-053','AM-075','AM-054','A-124','AM-070'): print('---',o['id'],o['ans'],'\n',o['q'])
