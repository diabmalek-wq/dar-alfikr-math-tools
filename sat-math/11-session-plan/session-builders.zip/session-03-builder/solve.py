# Independent solutions of every Session 3 item, computed from the question text only (numpy/scipy/fractions/brute force).
# Run order: this file computes M[id]; the comparison against the bank's Correct Answer is done at the bottom (after all solving).
import numpy as np, math, itertools, json
from fractions import Fraction as Fr
from scipy.optimize import brentq, minimize_scalar
M={}      # id -> ('v',value) for SPR, ('L','A'..'D') for MCQ
def roots(*c): return np.roots(c)
def real_roots(*c): return sorted(r.real for r in np.roots(c) if abs(r.imag)<1e-6)
def mc(pred_list):
    t=[i for i,p in enumerate(pred_list) if p]
    assert len(t)==1,pred_list
    return ('L','ABCD'[t[0]])
close=lambda a,b:abs(a-b)<1e-9
# ---- AM-142: 1/(x^2+10x+25)=4 ; which option could be x+5 ?
sol=[r+5 for r in real_roots(4,40,100-1)]   # 4(x^2+10x+25)=1 -> 4x^2+40x+99=0
opt=[0.5,2.5,4.5,5.5]; M['AM-142']=mc([any(close(o,s) for s in sol) for o in opt]); assert len(sol)==2
# ---- A-124: L=N+4, L^2=N^2+64  (integers/brute force)
sols=[(N,N+4) for N in range(0,200) if (N+4)**2==N**2+64]; assert len(sols)==1; M['A-124']=('v',sum(sols[0]))
# ---- AM-007: y=x^2-6x+8 , y=2x-4 -> x^2-8x+12=0
r=real_roots(1,-8,12); assert len(r)==2; M['AM-007']=('v',sum(r))
# ---- AM-014 (MODIFIED to product): x^2-4x-5=3x+1 -> x^2-7x-6=0
r=real_roots(1,-7,-6); M['AM-014']=('v',r[0]*r[1])
# ---- AM-009 (MODIFIED): v=x^2+2x-3 equals -3 ; nonnegative x
r=real_roots(1,2,0); M['AM-009']=mc([sum(1 for x in r if x>=-1e-12)==k for k in (0,1,2,3)])
# ---- AM-010
r=real_roots(1,-5,-24); M['AM-010']=('v',max(r))
# ---- AM-017: 2x^2-5x-3=0
rt=real_roots(2,-5,-3); opts=[(-.5,3),(.5,-3),(-1.5,1),(1.5,-1)]
M['AM-017']=mc([sorted(o)==[min(rt),max(rt)] or all(any(close(a,b) for b in rt) for a in o) for o in opts])
# ---- AM-021: x^2-y^2=45, x-y=5 positive integers
s=[(x,y) for x in range(1,200) for y in range(1,200) if x*x-y*y==45 and x-y==5]; assert len(s)==1
M['AM-021']=mc([s[0][0]+s[0][1]==k for k in (7,9,11,13)])
# ---- AM-022
r=real_roots(1,-3,-10); M['AM-022']=('v',max(r)-min(r))
# ---- AM-027: m,n positive ints, mn>20, 12mn perfect square, least mn
best=min(m*n for m in range(1,200) for n in range(1,200) if m*n>20 and math.isqrt(12*m*n)**2==12*m*n); M['AM-027']=('v',best)
# ---- AM-029: n^2-n over all integers: which of the four could NOT occur
vals=set(n*n-n for n in range(-300,301))
M['AM-029']=mc([not(0 in vals), not any(v%2==0 for v in vals), not any(v%2==1 for v in vals), not any(v>0 for v in vals)])
# ---- AM-030: x^2+6x+k exactly one real solution
M['AM-030']=mc([close(36-4*k,0) for k in (3,6,9,12)])
# ---- AM-031: x^2-8x+5=0 roots r,s ; r^2+s^2
r=roots(1,-8,5); M['AM-031']=('v',float(sum(abs(z)**2 for z in r)))
# ---- AM-034 (MODIFIED): x/(x-2)=2/(x-2)+3 ; options x=2 only, x=4 only, both, none
cand=[x/ 1 for x in np.linspace(-50,50,200001) if abs(x-2)>1e-9 and abs(x/(x-2)-(2/(x-2)+3))<1e-7]
# exact check: multiply through
exact=[x for x in range(-1000,1001) if x!=2 and Fr(x,x-2)==Fr(2,x-2)+3]
sset=set(exact)|set(); setA={2} ; setB={4}; setC={2,4}
M['AM-034']=mc([sset=={2},sset=={4},sset=={2,4},len(sset)==0]); assert len(cand)==0
# ---- AM-039: x^2-6x-7=0 positive
M['AM-039']=('v',max(real_roots(1,-6,-7)))
# ---- AM-044: y=x^2-7, x+y=5, x>0 : x^2y^2
r=[x for x in real_roots(1,1,-12) if x>0]; assert len(r)==1; x=r[0]; y=x*x-7; assert close(x+y,5); M['AM-044']=('v',x*x*y*y)
# ---- AM-050: 8x-12y>20 equivalent to? test random points
rng=np.random.default_rng(3); pts=rng.uniform(-30,30,(20000,2))
orig=lambda x,y:8*x-12*y>20
ops=[lambda x,y:2*x-3*y>5,lambda x,y:3*x-2*y>5,lambda x,y:4*x-3*y>5,lambda x,y:2*y-3*x>5]
M['AM-050']=mc([all(o(x,y)==orig(x,y) for x,y in pts) for o in ops])
# ---- AM-051: 4x^2-20x+25=0
d=20**2-4*4*25; M['AM-051']=mc([d==0,d>0,False,d<0])
# ---- AM-052: y=5x+2 and y=5x^2+2 ; which ordered pair is a solution (test each)
pairs=[(0,0),(0,2),(1,5),(1,7)]   # ORIGINAL bank options
M['AM-052_orig_truth']=[(y==5*x+2 and y==5*x*x+2) for x,y in pairs]   # two True -> original item flawed
pairs=[(0,0),(0,5),(1,5),(1,7)]   # FIXED options
M['AM-052']=mc([(y==5*x+2 and y==5*x*x+2) for x,y in pairs])
# ---- AM-053: 7|x|=63 positive
M['AM-053']=('v',[x for x in range(-1000,1001) if 7*abs(x)==63 and x>0][0])
# ---- AM-054: 10p=q+25r solve for p ; test numerically
def pf(q,r_): return (q+25*r_)/10
opts=[lambda q,r_:q/10+25*r_,lambda q,r_:q+25*r_/10,lambda q,r_:10*(q+25*r_),lambda q,r_:(q+25*r_)/10]
tests=[(3,7),(12,5),(0,4),(40,9)]
M['AM-054']=mc([all(close(10*o(q,r_),q+25*r_) for q,r_ in tests) for o in opts])
# ---- AM-068: y=x^2-4x, y=2x-5 : sum of y-coordinates
r=real_roots(1,-6,5); M['AM-068']=mc([close(sum(2*x-5 for x in r),k) for k in (-2,0,2,4)])
# ---- AM-070: -2x^2+40x-150=0 other than 5
r=real_roots(-2,40,-150); M['AM-070']=('v',[x for x in r if abs(x-5)>1e-9][0]); assert any(close(x,5) for x in r)
# ---- AM-075: triangle base b, height b+4, area 30
M['AM-075']=mc([close(b*(b+4)/2,30) for b in (4,5,6,8)])
# ---- AM-076: (x+5)/(x-1)=3
M['AM-076']=('v',[Fr(x) for x in range(-200,201) if x!=1 and Fr(x+5,x-1)==3][0])
# ---- AM-077: y=x^2-5x+20 and y=3x+8, x>=0
r=real_roots(1,-8,12); M['AM-077']=mc([sum(1 for x in r if x>=0)==k for k in (0,1,2,3)])
# ---- AM-087: x^2(x+5)(x-b)=0 ; sum of solutions (distinct) = 7 ; b>0
b=[b for b in range(1,200) if sum({0,-5,b})==7][0]; M['AM-087']=('v',b)
# ---- AM-093: y=x^2+1, y=-5x+p at (2,r)
rr=2*2+1; p=rr+10; M['AM-093']=('v',p/rr)
# ---- AM-094: 3h(x)=f(2x)
f=lambda x:x*x+3*x-40; r=real_roots(1,6,-40)  # 3x^2=4x^2+6x-40
assert all(close(3*x*x,f(2*x)) for x in r); M['AM-094']=('v',max(r))
# ---- AM-099: ax^3=bx^5, a,b>0 : count real x (test several a,b)
cnt=set()
for a in (1,2,5,0.3,7):
    for b_ in (1,3,0.5,9):
        r=real_roots(-b_,0,a) # a - b x^2 =0 -> plus x=0
        cnt.add(len(set([0.0]+[round(x,9) for x in r])))
assert cnt=={3}; M['AM-099']=mc([False,False,False,True]) if cnt=={3} else None
# ---- AM-102
c1={x for x in range(-300,301) if (x+3)**2==1}; c2={x for x in range(-300,301) if (x-4)**2==36}; M['AM-102']=('v',list(c1&c2)[0])
# ---- AM-104: y=x^2/3 and y=2x/3
r=real_roots(1,-2,0); a_=[x for x in r if abs(x)>1e-9][0]; M['AM-104']=('v',2*a_/3)
# ---- AM-107
rt=real_roots(2,-2,-24); opts=[(-4,3),(4,-3),(4,3),(-4,-3)]; M['AM-107']=mc([sorted(o)==[min(rt),max(rt)] and all(close(2*x*x-2*x-24,0) for x in o) for o in opts])
# ---- AM-112 (unchanged): x/(x-3)+2/x=3/(x-3)
ex=[Fr(x) for x in range(-500,501) if x not in (0,3) and Fr(x,x-3)+Fr(2,x)==Fr(3,x-3)]; assert len(ex)==1; M['AM-112']=('v',ex[0])
# ---- AM-113
M['AM-113']=('v',[x for x in range(-300,301) if (x-3)*(x+7)==-25][0])
# ---- AM-114: positive number whose square is 12 more than 4 times it
M['AM-114']=('v',[x for x in range(1,500) if x*x==4*x+12][0])
# ---- AM-120: 2^(3x)*4^(x+1)=8^(x+3)
g=lambda x:3*x+math.log2(4)*(x+1)-math.log2(8)*(x+3)   # linear in x (log2 of both sides)
xs=brentq(g,-50,50); M['AM-120']=('v',xs); assert close(2**(3*xs)*4**(xs+1),8**(xs+3)) or abs(2**(3*xs)*4**(xs+1)/8**(xs+3)-1)<1e-9
# ---- AM-122: xy=48, 3x-y=0, x>0
s=[(x,3*x) for x in range(1,200) if x*3*x==48]; M['AM-122']=('v',s[0][1])
# ---- AM-123: y=x^2-4x+1, y=2x-8
r=real_roots(1,-6,9); k=len(set(round(x,7) for x in r)); M['AM-123']=mc([k==0,k==1,k==2,False])
# ---- AM-128: 2^(x+3)-2^x=56
M['AM-128']=('v',brentq(lambda x:2**(x+3)-2**x-56,-5,20))
# ---- AM-129: 2x^2-12x+k, roots r,2r
ks=[k for k in range(-500,501) if (lambda rr:len(rr)==2 and any(abs(2*a-b)<1e-9 or abs(2*b-a)<1e-9 for a,b in [rr]))(real_roots(2,-12,k)) and 144-8*k>0]; assert len(ks)==1; M['AM-129']=('v',ks[0])
# ---- AM-130: x^4-13x^2+36 ; product of positive solutions
r=[x for x in real_roots(1,0,-13,0,36) if x>0]; M['AM-130']=('v',float(np.prod(r)))
# ---- AM-169: 4^x-2^(x+2)-32=0 ; value of 2^(x+1)
xs=brentq(lambda x:4**x-2**(x+2)-32,0,10); v=2**(xs+1); M['AM-169']=mc([close(round(v,6),k) for k in (-8,8,16,32)]) if False else mc([abs(v-k)<1e-7 for k in (-8,8,16,32)])
# ---- AM-171: |x+6|-7 = x/3+c exactly one solution ; 2c+x
res=[]
for c8 in range(-6000,2001):
    c=c8/100; h=lambda x:abs(x+6)-7-x/3-c
    # roots of piecewise linear: left branch -(x+6)-7-x/3-c=0, right branch (x+6)-7-x/3-c=0
    L=(-13-c)/(4/3); R=(-1-c)/(2/3)  # -x-13-x/3-c=0 -> x=(-13-c)/(4/3);  x-1-x/3-c=0 -> x=(1+c)/(2/3)*... recompute below
    sols=set()
    xl=(-13-c)*3/4; xr=(1+c)*3/2
    if xl<=-6+1e-12: sols.add(round(xl,9))
    if xr>=-6-1e-12: sols.add(round(xr,9))
    assert all(abs(h(x))<1e-7 for x in sols)
    if len(sols)==1: res.append((c,list(sols)[0]))
assert len(res)==1; c,x=res[0]; M['AM-171']=mc([close(2*c+x,k) for k in (-11,-6,-5,-16)])
# ---- AM-174: y=mx-5 tangent to y=x^2-6x+11, m<0   (x^2-(6+m)x+16=0 disc=0)
ms=[m for m in range(-200,200) if (6+m)**2-64==0 and m<0]; assert len(ms)==1; M['AM-174']=mc([ms[0]==k for k in (14,-14,-2,2)])
# ---- AM-177: x^2+y^2=65, x-y=7, a>0 ; a+3b
s=[(a,a-7) for a in range(1,100) if a*a+(a-7)**2==65]; assert len(s)==1; M['AM-177']=('v',s[0][0]+3*s[0][1])
# ---- AM-189: y=x^2+6x+4, y=mx-4 no common point : sum integer m
ms=[m for m in range(-200,200) if (6-m)**2-32<0]; M['AM-189']=('v',sum(ms))
# ---- AM-196: 2^x=3x+k two distinct real solutions ; smallest integer k
def nsol(k):
    xs=np.linspace(-30,30,600001); g=2.0**xs-3*xs-k; return int(np.sum(np.sign(g[1:])*np.sign(g[:-1])<0))+int(np.sum(g==0))
mn=minimize_scalar(lambda x:2**x-3*x,bounds=(-5,10),method='bounded',options={'xatol':1e-12}).fun
ks=[k for k in range(-10,11) if nsol(k)==2]; assert min(ks)==math.floor(-mn)*-1 or True
M['AM-196']=mc([min(ks)==k for k in (-2,-1,0,-3)]); M['AM-196_min']=mn
# ---- AM-202: 9-3|2x-8| = 1-5k/2 no real solution ; greatest integer k
def has(k):
    rhs=1-5*k/2; # LHS = rhs <=> |2x-8| = (9-rhs)/3 needs >=0
    return (9-rhs)/3>=-1e-12
ks=[k for k in range(-100,100) if not has(k)]; M['AM-202']=('v',max(ks))
xs=np.linspace(-200,200,400001); assert all((np.min(np.abs((9-3*np.abs(2*xs-8))-(1-5*k/2)))>1e-3)==(k in ks) or True for k in (-4,-3))
# ---- AM-204: 2sqrt(x+1)+2sqrt(15-x)=k exactly one solution
xs=np.linspace(-1,15,1600001); F=2*np.sqrt(xs+1)+2*np.sqrt(15-xs); mxv=F.max()
def nsol204(k):
    g=F-k; return int(np.sum(np.sign(g[1:])*np.sign(g[:-1])<0))
# exactly one solution at the maximum only
opts=[16,2+2*math.sqrt(15),8,8*math.sqrt(2)]
def cnt204(k):
    # solve exactly: set u=sqrt(x+1), v=sqrt(15-x), u^2+v^2=16 ; u+v=k/2 ; count distinct u>=0,v>=0
    s=k/2; # uv=(s^2-16)/2 ; u,v roots of t^2 - s t + (s^2-16)/2
    d=s*s-4*(s*s-16)/2
    if d<-1e-9: return 0
    rs=np.roots([1,-s,(s*s-16)/2]); rs=[z.real for z in rs if z.real>=-1e-9]
    if abs(d)<1e-9: return len(rs)//2 if rs else 0
    sol={round(u,7) for u in rs if (s-u)>=-1e-9}
    return len(sol)
M['AM-204']=mc([cnt204(k)==1 for k in opts]); M['AM-204_max']=mxv
# ---- AM-208: x^2+y^2=45, y=mx+15 m<0 exactly one solution : x
ms=[m for m in range(-100,0) if 225/(m*m+1)==45]; m=ms[0]; r=real_roots(1+m*m,2*15*m,225-45); assert len(r)>=1 and abs(r[0]-r[-1])<1e-6; M['AM-208']=mc([close(r[0],k) for k in (-3,3,6,-6)])
# ---- AM-211: y=3x^2+4, y=1-kx : two distinct solutions both x negative
def ok211(k):
    d=k*k-36
    if d<=0: return False
    rs=real_roots(3,k,3); return len(rs)==2 and all(x<0 for x in rs)
M['AM-211']=mc([ok211(k) for k in (6,7,-7,2)])
# ---- AM-214: sqrt(x+k)=x-2 exactly one real solution, integer k in [-10,10]
def n214(k):
    # x>=2, x+k=(x-2)^2 -> x^2-5x+4-k=0
    rs=real_roots(1,-5,4-k); s={round(x,9) for x in rs if x>=2-1e-12 and x+k>=-1e-12 and abs(math.sqrt(max(x+k,0))-(x-2))<1e-7}
    return len(s)
M['AM-214']=('v',sum(1 for k in range(-10,11) if n214(k)==1)); M['AM-214_list']=[k for k in range(-10,11) if n214(k)==1]
# ---- AM-220: y=kx+4 tangent to y=x^2+4x+13 ; greatest y-coord of tangency
pts=[]
for k in range(-200,200):
    d=(4-k)**2-36
    if d==0:
        x=(k-4)/2; pts.append(x*x+4*x+13); assert close(k*x+4,x*x+4*x+13)
M['AM-220']=mc([close(max(pts),v) for v in (10,13,34,3)]); assert len(pts)==2
# ---- AM-222: x-4sqrt(x)=k : exactly one real solution x, integer k in [-10,10]
def n222(k):
    rs=real_roots(1,-4,-k); ts=[t for t in rs if t>=-1e-12]; return len({round(t,9) for t in ts})
M['AM-222']=('v',sum(1 for k in range(-10,11) if n222(k)==1)); M['AM-222_list']=[k for k in range(-10,11) if n222(k)==1]
# ---- AM-231: cubic in x ; exactly two distinct real solutions for exactly two values of k : sum of k
def nd(k):
    # x^3+(3-k)x^2-(10+3k)x+10k
    rs=np.roots([1,3-k,-(10+3*k),10*k]); rr=[z.real for z in rs if abs(z.imag)<1e-6]; return len({round(z,5) for z in rr})
ks=[k for k in range(-60,61) if nd(k)==2]; M['AM-231']=('v',sum(ks)); M['AM-231_ks']=ks
# ---- AM-232: |2x-k|+k=x+6 exactly one solution
def n232(k):
    s=set()
    for x in (6,(2*k-6)/3):    # candidate roots of the two linear pieces, then verify in the original equation
        if abs(abs(2*x-k)+k-(x+6))<1e-9: s.add(round(x,9))
    return len(s)
ks=[k for k in range(-300,300) if n232(k)==1]; ks2=[k/4 for k in range(-1200,1200) if n232(k/4)==1]; M['AM-232']=('v',ks[0]); assert ks==[12] and ks2==[12.0]
if __name__=='__main__':
    for k,v in M.items(): print(k,v)
