"""Desmos-first solutions for EVERY Session 3 problem (3-4 steps each, at least one typed grey box).
Items already written as Desmos solutions in steps3.py (AM-171,177,189,196,204,214,222,232) are kept.
All quoted numbers are computed; every tap is registered in TAPS and re-evaluated by verify_steps.py."""
import math
import numpy as np
from fractions import Fraction as Fr
from steps3 import *
import steps3

def rhs(e): return e.split('=', 1)[1]
def yv(e, x, par): return float(ev(rhs(e), x=x, **par))
def TI(iid, e1, e2, x, **par):
    y = yv(e1, x, par) if e1.startswith('y=') else yv(e2, x, par)
    return tap(iid, [e1, e2], x, y, **par)
def TZ(iid, e, x, **par): return tap(iid, [e, 'y=0'], x, 0, **par)
def TV(iid, e, x, **par): return tap(iid, [e], x, yv(e, x, par), 'vertex', **par)
def TO(iid, e, x, **par): return tap(iid, [e], x, yv(e, x, par), 'on', **par)
def zs(a, b, cc): return [float(r) for r in qr(a, b, cc)]
S2 = {}
def put(iid, steps): S2[iid] = steps

# ---------------- Part A
i = 'AM-142'; e1, e2 = 'y=1/(x^2+10x+25)', 'y=4'; xs = [float(t) for t in xs142[::-1]]  # -5.5, -4.5
put(i, ["Type %s and %s." % (c(e1), c(e2)),
        "Tap the two intersections: %s and %s. These are the values of $x$." % (TI(i, e1, e2, xs[0]), TI(i, e1, e2, xs[1])),
        "The question asks for $x+5$. " + ret('%s+5' % n(xs[0])) + " and " + ret('%s+5' % n(xs[1])).replace('Type ', 'type ') + ".",
        "Only $\\dfrac{1}{2}$ is among the options, so the answer is (@@L@@)."])
i = 'A-124'; e1, e2 = 'y=(x+4)^2', 'y=x^2+64'
put(i, ["Let $x$ be Grace's age, so Emma's age is $x+4$. Type %s (the square of Emma's age) and %s (the square of Grace's age plus $64$)." % (c(e1), c(e2)),
        "Tap the intersection: %s. Its $x$-value is Grace's age." % TI(i, e1, e2, 6),
        "Emma is $6+4$: " + ret('6+4') + ".",
        ret('6+10') + ". The sum of their ages is $16$."])
i = 'AM-007'; e1, e2 = 'y=x^2-6x+8', 'y=2x-4'
put(i, ["Type %s and %s." % (c(e1), c(e2)),
        "Tap the two intersections: %s and %s." % (TI(i, e1, e2, 2), TI(i, e1, e2, 6)),
        ret('2+6') + ", the sum of the $x$-coordinates."])
i = 'AM-014'; e1, e2 = 'y=x^2-4x-5', 'y=3x+1'; q14 = ((7 + math.sqrt(73))/2, (7 - math.sqrt(73))/2)
put(i, ["Type %s and %s." % (c(e1), c(e2)),
        "Tap the two intersections: %s and %s." % (TI(i, e1, e2, q14[1]), TI(i, e1, e2, q14[0])),
        "The $x$-values are not whole numbers, so use the exact forms $\\dfrac{7\\pm\\sqrt{73}}{2}$. " + ret('(7+sqrt(73))/2*(7-sqrt(73))/2') + ".",
        "That is the product of the $x$-coordinates: $-6$."])
i = 'AM-022'; e1, e2 = 'y=x^2-x-14', 'y=2x-4'
put(i, ["Type %s and %s." % (c(e1), c(e2)),
        "Tap the two intersections: %s and %s." % (TI(i, e1, e2, -2), TI(i, e1, e2, 5)),
        ret('5-(-2)') + ", the positive difference of the $x$-coordinates."])
i = 'AM-027'
put(i, ["$12mn$ is a perfect square exactly when $mn=3k^2$. Type %s: Desmos lists the possible values of $mn$: %s." % (c('3*[1...5]^2'), v(ev('3*[1...5]^2'))),
        "The first value above $20$ is $%d$." % mn27,
        ret('sqrt(12*27)') + ", a whole number, so $12mn$ is a perfect square.",
        "Compare a value that is not on the list: " + ret('sqrt(12*24)').replace('Type ', 'type ') + ", not a whole number. So the least value is $27$."])
i = 'AM-031'; e = 'y=x^2-8x+5'; zz = zs(1, -8, 5)
put(i, ["Type %s and tap its two zeros: %s and %s (these are $r$ and $s$)." % (c(e), TZ(i, e, zz[0]), TZ(i, e, zz[1])),
        "They are $4\\pm\\sqrt{11}$. Type the exact squares: " + ret('(4-sqrt(11))^2+(4+sqrt(11))^2'),
        "Check with the formula $(r+s)^2-2rs$: " + ret('8^2-2*5') + ". So $r^2+s^2=54$."])
i = 'AM-039'; e1, e2 = 'y=(x-3)^2', 'y=16'
put(i, ["Completing the square turns $x^2-6x-7=0$ into $(x-3)^2=16$. Type %s and %s." % (c(e1), c(e2)),
        "Tap the two intersections: %s and %s." % (TI(i, e1, e2, -1), TI(i, e1, e2, 7)),
        "The positive solution is $x=7$. Check: " + ret('7^2-6*7-7') + "."])
i = 'AM-044'; e1, e2 = 'y=x^2-7', 'y=5-x'
put(i, ["Rewrite $x+y=5$ as $y=5-x$. Type %s and %s." % (c(e1), c(e2)),
        "Tap the two intersections: %s and %s. We need $x>0$, so $(x,y)=(3,\\,2)$." % (TI(i, e1, e2, -4), TI(i, e1, e2, 3)),
        ret('3^2*2^2') + ". So $x^2y^2=36$."])
i = 'AM-054'
put(i, ["Test numbers: let $q=20$ and $r=4$. Type " + c('20+25*4') + ": it returns $%s$, so $10p=%s$ and $p=%s$ (type %s: it returns $%s$)." % (n(ev('20+25*4')), n(ev('20+25*4')), n(ev('(20+25*4)/10')), c('(20+25*4)/10'), n(ev('(20+25*4)/10'))),
        "Test option $\\dfrac{q+25r}{10}$: " + ret('(20+25*4)/10') + ", a match.",
        "Test the others: " + ret('20/10+25*4') + ", " + ret('20+25*4/10').replace('Type ', 'type ') + " and " + ret('10*(20+25*4)').replace('Type ', 'type ') + ", none equal to $12$.",
        "Only $p=\\dfrac{q+25r}{10}$ works, which is option (@@L@@)."])
i = 'AM-070'; e = 'y=-2x^2+40x-150'
put(i, ["Break even means $P(x)=0$. Type %s (letting $x$ stand for the price)." % c(e),
        "Tap the two zeros: %s and %s." % (TZ(i, e, 5), TZ(i, e, 15)),
        "Other than $x=5$ the price is $15$. Check: " + ret('-2*15^2+40*15-150') + "."])
i = 'AM-077'; e1, e2 = 'y=x^2-5x+20', 'y=3x+8'
put(i, ["Type %s and %s." % (c(e1), c(e2)),
        "Tap the two intersections: %s and %s." % (TI(i, e1, e2, 2), TI(i, e1, e2, 6)),
        "Both have $x\\ge0$, so the models are equal for $2$ values of $x$. The answer is (@@L@@)."])
i = 'AM-087'; e = 'y=x^2*(x+5)*(x-b)'
put(i, ["Type %s (accept the slider for $b$)." % c(e),
        "Slide $b$ and tap the zeros on the $x$-axis. At $b=12$ they are %s, %s and %s (the zero at $0$ is counted once)." % (TZ(i, e, -5, b=12), TZ(i, e, 0, b=12), TZ(i, e, 12, b=12)),
        ret('-5+0+12') + ", which is the required sum $7$. So $b=12$."])
i = 'AM-093'; e1, e2 = 'y=x^2+1', 'y=-5x+p'
put(i, ["Type %s and tap the point on it with $x=2$: %s. So $r=5$." % (c(e1), TO(i, e1, 2)),
        "Type %s (accept the slider for $p$) and slide $p$ until the line passes through %s: $p=15$. (At $p=15$ the line is at height %s when $x=2$.)" % (c(e2), pt(2, 5), ret('-5*2+15').replace('Type ', 'type ')),
        ret('15/5') + "."])
SL.append(('AM-093', ['y=x^2+1', 'y=-5x+p'], {'p': 15}, 2, 5))
i = 'AM-094'; e1, e2 = 'y=3x^2', 'y=(2x)^2+3(2x)-40'
put(i, ["$f(2x)$ means putting $2x$ in for $x$ in $f$. Type %s ($3h(x)$) and %s ($f(2x)$)." % (c(e1), c(e2)),
        "Tap the two intersections: %s and %s." % (TI(i, e1, e2, -10), TI(i, e1, e2, 4)),
        "The positive value is $x=4$. Check: " + ret('3*4^2') + " and " + ret('(2*4)^2+3*(2*4)-40').replace('Type ', 'type ') + "."])
i = 'AM-099'; e1, e2 = 'y=a*x^3', 'y=b*x^5'
put(i, ["Type %s and %s (accept sliders for $a$ and $b$, and keep both positive)." % (c(e1), c(e2)),
        "With $a=1$ and $b=1$ tap the intersections: %s, %s and %s." % (TI(i, e1, e2, -1, a=1, b=1), TI(i, e1, e2, 0, a=1, b=1), TI(i, e1, e2, 1, a=1, b=1)),
        "Change the sliders to $a=2$ and $b=0.5$: the intersections are %s, %s and %s. Still three." % (TI(i, e1, e2, -2, a=2, b=0.5), TI(i, e1, e2, 0, a=2, b=0.5), TI(i, e1, e2, 2, a=2, b=0.5)),
        "For any positive $a$ and $b$ there are $3$ values of $x$ (the answer is (@@L@@))."])
i = 'AM-102'
put(i, ["Type %s and %s. Tap the intersections: %s and %s." % (c('y=(x+3)^2'), c('y=1'), TI(i, 'y=(x+3)^2', 'y=1', -4), TI(i, 'y=(x+3)^2', 'y=1', -2)),
        "Type %s and %s. Tap the intersections: %s and %s." % (c('y=(x-4)^2'), c('y=36'), TI(i, 'y=(x-4)^2', 'y=36', -2), TI(i, 'y=(x-4)^2', 'y=36', 10)),
        "The only $x$ in both lists is $-2$. Check: " + ret('(-2+3)^2') + " and " + ret('(-2-4)^2').replace('Type ', 'type ') + "."])
i = 'AM-112'; e1, e2 = 'y=x/(x-3)+2/x', 'y=3/(x-3)'
put(i, ["Type %s and %s." % (c(e1), c(e2)),
        "Tap the intersection: %s. (There is no point at $x=3$: both graphs have a break there.)" % TI(i, e1, e2, -2),
        "Check $x=-2$: " + ret('-2/(-2-3)+2/(-2)') + " and " + ret('3/(-2-3)').replace('Type ', 'type ') + "."])
i = 'AM-120'; e1, e2 = 'y=3x+2(x+1)', 'y=3(x+3)'
put(i, ["Write both sides with base $2$: the exponents are $3x+2(x+1)$ on the left and $3(x+3)$ on the right. Type %s and %s." % (c(e1), c(e2)),
        "Tap the intersection: %s. Its $x$-value is the solution, $x=3.5$." % TI(i, e1, e2, 3.5),
        "Check in the original equation: " + ret('2^(3*3.5)*4^(3.5+1)') + " and " + ret('8^(3.5+3)').replace('Type ', 'type ') + ". The answer is $\\dfrac72$."])
i = 'AM-123'; e1, e2 = 'y=x^2-4x+1', 'y=2x-8'
put(i, ["Type %s and %s." % (c(e1), c(e2)),
        "The line just touches the parabola at one point: %s." % TI(i, e1, e2, 3),
        "Confirm with the discriminant of $x^2-6x+9=0$: " + ret('(-6)^2-4*1*9') + ", so there is exactly one solution, option (@@L@@)."])
i = 'AM-129'; e = 'y=2x^2-12x+k'
put(i, ["Type %s (accept the slider for $k$)." % c(e),
        "Slide $k$ until the two zeros are in the ratio $2:1$. At $k=16$ they are %s and %s." % (TZ(i, e, 2, k=16), TZ(i, e, 4, k=16)),
        ret('4/2') + ", so one solution is twice the other. Hence $k=16$."])
i = 'AM-169'; e = 'y=4^x-2^(x+2)-32'
put(i, ["Type %s." % c(e),
        "Tap the zero: %s. So $x=3$." % TZ(i, e, 3),
        "The question asks for $2^{x+1}$: " + ret('2^(3+1)') + ". The answer is (@@L@@)."])
# kept Desmos items
for k_ in ('AM-171', 'AM-177', 'AM-189', 'AM-196', 'AM-204', 'AM-214', 'AM-222', 'AM-232'): S2[k_] = steps3.S[k_]
i = 'AM-174'; e1, e2 = 'y=x^2-6x+11', 'y=m*x-5'
put(i, ["Type %s and %s (accept the slider for $m$)." % (c(e1), c(e2)),
        "Slide $m$ until the line just touches the parabola. This happens at $m=2$, touching at %s, and at $m=-14$, touching at %s." % (TI(i, e1, e2, 4, m=2), TI(i, e1, e2, -4, m=-14)),
        "The problem says $m$ is negative, so $m=-14$. Check the touch point: " + ret('(-4)^2-6*(-4)+11') + " and " + ret('-14*(-4)-5').replace('Type ', 'type ') + ". The answer is (@@L@@)."])
i = 'AM-202'; e1, e2 = 'y=9-3abs(2x-8)', 'y=1-5k/2'
put(i, ["Type %s and tap its highest point: %s." % (c(e1), TV(i, e1, 4)),
        "Type %s (accept the slider for $k$). At $k=-3$ the line is at height $8.5$ and meets the graph at %s and %s." % (c(e2), TI(i, e1, e2, 4 - 1/12, k=-3), TI(i, e1, e2, 4 + 1/12, k=-3)),
        "At $k=-4$ the line is higher than the top of the graph: " + ret('1-5*(-4)/2') + ", which is above $9$, so there is no solution.",
        "So the greatest integer with no solution is $-4$."])
i = 'AM-208'; e1, e2 = 'x^2+y^2=45', 'y=m*x+15'
put(i, ["Type %s (a circle) and %s (accept the slider for $m$)." % (c(e1), c(e2)),
        "Slide $m$ (negative) until the line touches the circle at exactly one point. At $m=-2$ the point is %s." % tap(i, [e1, e2], 6, 3, 'on', m=-2),
        "Check: " + ret('6^2+3^2') + " and " + ret('-2*6+15').replace('Type ', 'type ') + ". So $x=6$, option (@@L@@)."])
i = 'AM-211'; e1, e2 = 'y=3x^2+4', 'y=1-k*x'; q7 = [float(t) for t in qr(3, 7, 3)]
put(i, ["Type %s and %s (accept the slider for $k$)." % (c(e1), c(e2)),
        "Set $k=7$: the line meets the parabola at %s and %s, both with negative $x$." % (TI(i, e1, e2, q7[0], k=7), TI(i, e1, e2, q7[1], k=7)),
        "Try the other options: $k=6$ only touches, at %s; $k=2$ never meets the parabola; $k=-7$ meets it at two points with positive $x$." % TI(i, e1, e2, -1, k=6),
        "So the answer is $k=7$, option (@@L@@)."])
i = 'AM-220'; e1, e2 = 'y=x^2+4x+13', 'y=k*x+4'
put(i, ["Type %s and %s (accept the slider for $k$)." % (c(e1), c(e2)),
        "Slide $k$ until the line just touches the parabola. This happens at $k=-2$, touching at %s, and at $k=10$, touching at %s." % (TI(i, e1, e2, -3, k=-2), TI(i, e1, e2, 3, k=10)),
        "The greater $y$-coordinate is $34$ (option (@@L@@)). Check: " + ret('3^2+4*3+13') + "."])
i = 'AM-231'; e = 'y=x^3+(3-k)x^2-(10+3k)x+10k'
put(i, ["Type %s (accept the slider for $k$). The solutions are the zeros of the graph." % c(e),
        "At $k=0$ there are three zeros: %s, %s and %s." % (TZ(i, e, -5, k=0), TZ(i, e, 0, k=0), TZ(i, e, 2, k=0)),
        "At $k=2$ and at $k=-5$ the graph has only two zeros, %s and %s, because one of them is a touching zero." % (TZ(i, e, -5, k=2), TZ(i, e, 2, k=2)),
        ret('2+(-5)') + ", the sum of the two values of $k$."])

# ---------------- Part B
i = 'AM-009'; e1, e2 = 'y=x^2+2x-3', 'y=-3'
put(i, ["Type %s and %s." % (c(e1), c(e2)),
        "Tap the two intersections: %s and %s." % (TI(i, e1, e2, -2), TI(i, e1, e2, 0)),
        "Only $x=0$ is nonnegative, so the estimates are equal for $1$ value of $x$: option (@@L@@)."])
i = 'AM-010'; e = 'y=x^2-5x-24'
put(i, ["Type %s." % c(e), "Tap the two zeros: %s and %s." % (TZ(i, e, -3), TZ(i, e, 8)), "The positive solution is $8$. Check: " + ret('8^2-5*8-24') + "."])
i = 'AM-017'; e = 'y=2x^2-5x-3'
put(i, ["Type %s." % c(e), "Tap the two zeros: %s and %s." % (TZ(i, e, -0.5), TZ(i, e, 3)),
        "The solutions are $x=-\\dfrac12$ and $x=3$, option (@@L@@). Check: " + ret('2*3^2-5*3-3') + "."])
i = 'AM-021'; e1, e2 = 'x^2-y^2=45', 'y=x-5'
put(i, ["Type %s and %s (from $x-y=5$)." % (c(e1), c(e2)),
        "Tap the intersection: %s. Both coordinates are positive integers." % tap(i, [e1, e2], 7, 2),
        ret('7+2') + ". So $x+y=9$, option (@@L@@)."])
i = 'AM-029'
put(i, ["Type %s: it lists $n^2-n$ for $n=-3,\\ldots,4$: %s." % (c('[-3...4]^2-[-3...4]'), v(ev('[-3...4]^2-[-3...4]'))),
        "Look at the remainders after dividing by $2$: type %s: it returns %s." % (c('mod([-3...4]^2-[-3...4],2)'), v(ev('mod([-3...4]^2-[-3...4],2)'))),
        "Every remainder is $0$, so the result is always even. It can be $0$, an even integer or a positive integer, but never odd: option (@@L@@)."])
i = 'AM-030'; e = 'y=x^2+6x+k'
put(i, ["Type %s (accept the slider for $k$)." % c(e),
        "Slide $k$. For $k=3$ the parabola crosses the $x$-axis twice, but at $k=9$ it only touches it at %s." % TZ(i, e, -3, k=9),
        "Confirm with the discriminant: " + ret('6^2-4*1*9') + ". So $k=9$, option (@@L@@)."])
i = 'AM-034'; e1, e2 = 'y=x/(x-2)', 'y=2/(x-2)+3'
put(i, ["Type %s and %s." % (c(e1), c(e2)),
        "The graphs never meet: no intersection dot appears. Check the gap at a few $x$-values: " + ret('4/(4-2)-(2/(4-2)+3)') + " and " + ret('10/(10-2)-(2/(10-2)+3)').replace('Type ', 'type ') + ".",
        "The difference is always $-2$, never $0$, so there is no solution: option (@@L@@)."])
i = 'AM-050'
put(i, ["Type %s. Desmos shades the region." % c('8x-12y>20'),
        "Type %s: the shading is exactly the same, so this is equivalent." % c('2x-3y>5'),
        "Type %s: the shading differs. Test the point $(2,0)$: " % c('3x-2y>5') + ret('3*2-2*0') + " (more than $5$) but " + ret('8*2-12*0').replace('Type ', 'type ') + " (not more than $20$).",
        "So the equivalent inequality is $2x-3y>5$, option (@@L@@)."])
i = 'AM-051'; e = 'y=4x^2-20x+25'
put(i, ["Type %s." % c(e), "The graph touches the $x$-axis at one point only: %s." % TV(i, e, 2.5),
        "Confirm with the discriminant: " + ret('(-20)^2-4*4*25') + ". Exactly one real solution: option (@@L@@)."])
i = 'AM-052'; e1, e2 = 'y=5x+2', 'y=5x^2+2'
put(i, ["Type %s and %s." % (c(e1), c(e2)),
        "Tap the intersections: %s and %s." % (TI(i, e1, e2, 0), TI(i, e1, e2, 1)),
        "Only $(1,7)$ is among the options, so the answer is (@@L@@). (The point $(0,5)$ fails: " + ret('5*0+2') + ", not $5$.)"])
i = 'AM-053'; e1, e2 = 'y=7abs(x)', 'y=63'
put(i, ["Type %s and %s." % (c(e1), c(e2)), "Tap the intersections: %s and %s." % (TI(i, e1, e2, -9), TI(i, e1, e2, 9)),
        "The positive solution is $x=9$."])
i = 'AM-068'; e1, e2 = 'y=x^2-4x', 'y=2x-5'
put(i, ["Type %s and %s." % (c(e1), c(e2)), "Tap the intersections: %s and %s." % (TI(i, e1, e2, 1), TI(i, e1, e2, 5)),
        ret('-3+5') + ", the sum of the $y$-coordinates: option (@@L@@)."])
i = 'AM-075'; e1, e2 = 'y=x*(x+4)/2', 'y=30'
put(i, ["Base $x$ and height $x+4$ give area $\\dfrac{x(x+4)}{2}$. Type %s and %s." % (c(e1), c(e2)),
        "Tap the intersections: %s and %s. A length is positive." % (TI(i, e1, e2, -10), TI(i, e1, e2, 6)),
        "The base is $6$ cm, option (@@L@@). Check: " + ret('6*(6+4)/2') + "."])
i = 'AM-076'; e1, e2 = 'y=(x+5)/(x-1)', 'y=3'
put(i, ["Type %s and %s." % (c(e1), c(e2)), "Tap the intersection: %s." % TI(i, e1, e2, 4),
        "Check: " + ret('(4+5)/(4-1)') + ". So $x=4$."])
i = 'AM-104'; e1, e2 = 'y=x^2/3', 'y=2x/3'
put(i, ["Type %s and %s." % (c(e1), c(e2)),
        "Tap the intersections: %s (the origin) and %s." % (TI(i, e1, e2, 0), TI(i, e1, e2, 2)),
        "So $a=2$ and $b$ is the height: " + ret('2*2/3') + ", which is $\\dfrac43$."])
i = 'AM-107'; e = 'y=2x^2-2x-24'
put(i, ["Type %s." % c(e), "Tap the two zeros: %s and %s." % (TZ(i, e, -3), TZ(i, e, 4)),
        "The solutions are $x=4$ and $x=-3$, option (@@L@@). Check: " + ret('2*4^2-2*4-24') + "."])
i = 'AM-113'; e1, e2 = 'y=(x-3)(x+7)', 'y=-25'
put(i, ["Type %s and %s." % (c(e1), c(e2)),
        "The line touches the lowest point of the parabola: %s. So $x=-2$." % TV(i, e1, -2),
        "Check: " + ret('(-2-3)*(-2+7)') + "."])
i = 'AM-114'; e1, e2 = 'y=x^2', 'y=4x+12'
put(i, ["Type %s (the square) and %s ($4$ times the number plus $12$)." % (c(e1), c(e2)),
        "Tap the intersections: %s and %s. The number is positive." % (TI(i, e1, e2, -2), TI(i, e1, e2, 6)),
        "The number is $6$. Check: " + ret('6^2') + " and " + ret('4*6+12').replace('Type ', 'type ') + "."])
i = 'AM-122'; e1, e2 = 'x*y=48', 'y=3x'
put(i, ["From $3x-y=0$ we get $y=3x$. Type %s and %s." % (c(e1), c(e2)),
        "Tap the two intersections: %s and %s. We need $x>0$." % (tap(i, [e1, e2], -4, -12), tap(i, [e1, e2], 4, 12)),
        "So $y=12$. Check: " + ret('4*12') + "."])
i = 'AM-128'; e1, e2 = 'y=2^(x+3)-2^x', 'y=56'
put(i, ["Type %s and %s." % (c(e1), c(e2)), "Tap the intersection: %s. So $x=3$." % TI(i, e1, e2, 3),
        "Check: " + ret('2^(3+3)-2^3') + "."])
i = 'AM-130'; e = 'y=x^4-13x^2+36'
put(i, ["Type %s." % c(e),
        "Tap the four zeros: %s, %s, %s and %s." % (TZ(i, e, -3), TZ(i, e, -2), TZ(i, e, 2), TZ(i, e, 3)),
        "The positive solutions are $2$ and $3$: " + ret('2*3') + "."])

S = {k: S2[k] for k in steps3.S}
assert set(S2) == set(steps3.S), set(steps3.S) ^ set(S2)
TOOL = {k: 'D' for k in S}
V = steps3.V
if __name__ == '__main__':
    print(len(S), 'items;', len(TAPS), 'taps;', sum(len(re.findall(r'\[\[', ''.join(x))) for x in S.values()), 'boxes;', sum(1 for x in S.values() if '[[' in ''.join(x)), 'items with box')
