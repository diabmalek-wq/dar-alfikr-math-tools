import json,re,sys,subprocess,os,math
HERE=os.path.dirname(os.path.abspath(__file__)); os.chdir(HERE); sys.path.insert(0,HERE)
from lib import *
import desmos3, solve
from desmos3 import S,TOOL
ESC={'\\':r'\textbackslash{}','{':r'\{','}':r'\}','^':r'\textasciicircum{}','_':r'\_','~':r'\textasciitilde{}','#':r'\#','%':r'\%','&':r'\&','$':r'\$'}
def code(m):
    c=m.group(1).replace('\\{','{').replace('\\}','}')
    return r"\dzc{"+"".join(ESC.get(ch,ch) for ch in c)+"}"
def conv(s): return re.sub(r"\[\[((?:(?!\[\[).)+?)\]\](?!\])",code,s)
items=json.load(open('s3_items.json'))
items=[o for o in items if o['part']=='In class']+[o for o in items if o['part']!='In class']  # CSV order kept within each part
def parse(q):
    stem=[];opts=[]
    for ln in q.split('\n'):
        m=re.match(r'^\(?([A-D])\)\s*(.*)$',ln.strip())
        if m and (opts or m.group(1)=='A'): opts.append(m.group(2).strip())
        elif opts and ln.strip()=='': continue
        elif opts: opts[-1]+=' '+ln.strip()
        else: stem.append(ln)
    return '\n'.join(stem).strip(), (opts if len(opts)==4 else None)
def spr(a):
    a=a.replace('$','').strip()
    if '(or' in a: return r"\dfrac{7}{2}\ \text{(or }3.5\text{)}"
    return a
LINES=json.load(open('lines.json')) if os.path.exists('lines.json') else {}
P=[]
for o in items:
    stem,opts=parse(o['q']); iid=o['id']
    p=dict(id=iid,lv='M' if o['d']=='Medium' else 'H',tool=TOOL.get(iid,'N'),q=stem)
    r=solve.M[iid]
    if opts:
        L=re.match(r'^\(?([A-D])',o['ans']).group(1); assert L==r[1],iid
        p['opts']=opts;p['correct']="ABCD".index(L)
    else:
        assert not opts; p['ans']=spr(o['ans'])
    p['steps']=[conv(x.replace('@@L@@',L if opts else '?')) for x in S[iid]]
    assert '@@' not in ''.join(p['steps'])
    p['lines']=LINES.get(iid,5 if p['lv']=='M' else 6)
    P.append(p)
nA=sum(1 for o in items if o['part']=='In class'); assert all(o['part']=='In class' for o in items[:nA])
# letter claims in steps vs option text
O={p['id']:p['opts'] for p in P if p.get('opts')}
assert O['AM-029']==['$0$','An even integer','An odd integer','A positive integer']
meta=dict(title='Nonlinear Equations and Systems',code='SAT-M \\textperiodcentered\\ Session 3',headfull='Session 3 \\textemdash\\ Nonlinear Equations and Systems',
 time='3 hours: Part A in class (about 2 hours of solving), then Part B, the self-assessment, done independently (about 50 minutes), and a short error log.',
 topics='solving quadratics: factoring, completing the square, discriminant, sum and product of roots \\textperiodcentered\\ line and parabola, line and circle systems \\textperiodcentered\\ number of solutions and unknown constants \\textperiodcentered\\ rational equations and extraneous solutions \\textperiodcentered\\ exponential equations \\textperiodcentered\\ absolute value, radical and higher-degree equations')
MEAS=r"\renewcommand{\keyspace}[2]{\par\nopagebreak\setbox0\vbox{\hsize\linewidth\color{SOLGREEN}\small #2\par}\setbox1\vbox{\foreach \i in {1,...,#1}{\par\vspace{0.74cm}{\color{LINE}\hrule height 0.4pt}}}\immediate\write16{KS #1 \the\ht0 \the\ht1}\ifdim\ht0>\ht1 \dimen2=\ht0 \else \dimen2=\ht1 \fi\vbox to \dimen2{\nointerlineskip\vbox to 0pt{\box1\vss}\nointerlineskip\box0\vss}\par\vspace{4pt}}"
def build_s3(mode,out,measure=False):
    key=(mode=='key')
    ex=r"\setmonofont[Scale=0.9]{DejaVu Sans Mono}\newcommand{\dzc}[1]{\colorbox{black!8}{\texttt{\small\textcolor{black}{#1}}}}"+(MEAS if measure else "")
    L=[PRE.replace("@@CODE@@",meta['code']).replace("@@HEAD@@",meta['headfull']).replace("\\begin{document}",EXTRA+ex+"\n\\begin{document}")]
    L.append(r"""
\begin{tcolorbox}[enhanced,colback=NAVY!4,colframe=NAVY,boxrule=0.8pt,arc=3pt]
{\Large\bfseries\color{NAVY} SAT Math Mastery \textperiodcentered\ Session 3}\\[2pt]
{\large\bfseries %s}\\[3pt]
\begin{tabular}{@{}p{0.2\linewidth}p{0.75\linewidth}@{}}
\textbf{Time} & %s\\
\textbf{Topics} & %s\\
\textbf{Name / Date} & \rule{5.5cm}{0.3pt}\ \ \rule{3cm}{0.3pt}\\
\end{tabular}
\end{tcolorbox}
"""%(meta['title'],meta['time'],meta['topics']))
    L.append(r"\banner{Part A \textperiodcentered\ In class \textemdash\ %d problems}"%nA)
    L.append(r"\small Each problem states its tool. Write your work in the space below. Multiple choice: one correct option. Student-produced response (SPR): enter an exact value (fraction or decimal)."+(r" Grey boxes show exactly what to type in Desmos, one expression per line; tap a grey dot to read an intersection, intercept or vertex. A letter such as $a$, $c$ or $k$ becomes a slider when you accept Desmos's offer to add one." if key else "")+r"\normalsize\par\vspace{4pt}")
    for i,p in enumerate(P,1):
        if i==nA+1: L.append(r"\par\needspace{9cm}\banner{Part B \textperiodcentered\ Self-assessment \textemdash\ %d problems}"%(len(P)-nA))
        L.append(problem_tex(i,p,mode))
    L.append(r"\end{document}")
    open(out,'w').write("\n".join(L))
def comp(out):
    for _ in range(2): subprocess.run(['xelatex','-interaction=nonstopmode',out],capture_output=True,text=True)
    log=open(out[:-4]+'.log').read(); return log
if __name__=='__main__':
    # auto-tune work lines so that no solution is taller than its work space (keeps both PDFs paginated identically)
    for it in range(6):
        build_s3('key','S3_key.tex',True); log=comp('S3_key.tex')
        ks=re.findall(r'^KS (\d+) (\d+)sp? ?(\d+)',log,re.M) or []
        rows=re.findall(r'^KS (\d+) ([\d.]+)pt\s*([\d.]+)pt',log,re.M)
        # the \write16 lines appear on two passes; keep the last pass
        rows=rows[-len(P):]; assert len(rows)==len(P),(len(rows),len(P))
        ch=0
        for p,(nl,h0,h1) in zip(P,rows):
            nl=int(nl); h0=float(h0); h1=float(h1)
            if h0>h1+0.01:
                per=h1/nl; need=math.ceil(h0/per); LINES[p['id']]=need; p['lines']=need; ch+=1
        print('tune pass',it,'changed',ch)
        json.dump(LINES,open('lines.json','w'))
        if not ch: break
    for mode,out in (('ws','S3_ws.tex'),('key','S3_key.tex')):
        build_s3(mode,out); log=comp(out)
        print(out,'overfull',log.count('Overfull'),'err',len(re.findall(r'^!',log,re.M)))
