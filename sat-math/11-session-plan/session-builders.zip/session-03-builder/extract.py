import csv,re,json
B=open('/home/claude/repo-check2/sat-bank/verified-item-bank/SAT_Bank_Verified_Item_Bank.md').read()
rows=[r for r in csv.reader(open('/home/claude/cb/session_plan_11.csv')) ]
hdr=rows[0];print(hdr)
rows=[r for r in rows[1:] if r[0]=='3']
blocks={}
for m in re.finditer(r'^### ([A-Z]+-\d+)\n(.*?)(?=^### |^## |\Z)',B,re.M|re.S): blocks.setdefault(m.group(1),m.group(2))
out=[]
for r in rows:
    iid=r[2]; b=blocks[iid]
    def fld(name,nxt):
        m=re.search(r'\*\*%s:\*\*\s*(.*?)(?=\n\*\*(?:%s):\*\*|\n---|\Z)'%(name,nxt),b,re.S); return m.group(1).strip() if m else None
    q=fld('Question','Correct Answer'); ans=fld('Correct Answer','Rationale'); rat=fld('Rationale','Misconception addressed|Source|Trap')
    fmt=fld('Format','Source|Question')
    out.append(dict(id=iid,part=r[1],d=r[5],fmt=fmt,q=q,ans=ans,rat=rat))
json.dump(out,open('bank_raw.json','w'),indent=1)
print(len(out),[o['id'] for o in out if not o['q'] or not o['ans']])
