# Compares solve.py's independent answers with the (final) item answers; also the ORIGINAL bank answers, to list true bank errors.
import json,re,sys
from fractions import Fraction as Fr
import solve
M=solve.M
items=json.load(open('s3_items.json'))
def parse_opts(q):
    opts=[]
    for ln in q.split('\n'):
        m=re.match(r'^\(?([A-D])\)\s*(.*)$',ln.strip())
        if m and (opts or m.group(1)=='A'): opts.append(m.group(2).strip())
    return opts
def spr_val(a):
    a=a.replace('$','').replace('{,}','').strip()
    a=re.sub(r'\s*\(or.*\)','',a)
    m=re.match(r'^(-?)\\dfrac\{(\d+)\}\{(\d+)\}$',a)
    if m: return float(Fr(int(m.group(2)),int(m.group(3)))*(-1 if m.group(1) else 1))
    return float(a)
bad=0;nm=0
for o in items:
    r=M[o['id']]; opts=parse_opts(o['q'])
    for which,a in (('final',o['ans']),('orig',o['orig_ans'])):
        if which=='orig' and o['fix'] is None: continue
        if r[0]=='L':
            L=re.match(r'^\(?([A-D])',a).group(1); ok=(L==r[1])
        else: ok=abs(spr_val(a)-float(r[1]))<1e-9
        if not ok:
            if which=='final': bad+=1
            print('MISMATCH' if which=='final' else 'ORIG-BANK-DIFFERS',o['id'],which,a,r)
    if r[0]=='L':
        assert len(opts)==4 and len(set(opts))==4,(o['id'],opts); nm+=1
    else: assert not opts,o['id']
print('items',len(items),'MCQ',nm,'mismatches vs final',bad)
print('AM-052 raw option truth before fix [A,B,C,D]:',M['AM-052_orig_truth'],'-> bank key D but B also true (original B=(0,2))')
