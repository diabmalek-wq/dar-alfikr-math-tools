import math
from lib import *

EX = []
sq = Fn(lambda x: x * x, lambda xl: r'(%s)^2' % xl)
inv = Fn(lambda x: 1 / x, lambda xl: r'\dfrac{1}{%s}' % xl)
ex_ = Fn(math.exp, lambda xl: r'e^{%s}' % xl)

# ---------- Example 1
st, v = rule('T', sq, 0, 2, 4)
I = 8 / 3
reg('E1', 'rule', R='T', f='x**2', a=0, b=2, n=4, val=v)
reg('E1', 'claim', R='T', f='x**2', a=0, b=2, n=4, sign='over')
st += [
 r'Exact value for comparison, by the Fundamental Theorem of Calculus: $$\int_0^2 x^2\,dx=\Big[\dfrac{x^3}{3}\Big]_0^2=\dfrac{2^3}{3}-\dfrac{0^3}{3}=\dfrac{8}{3}\approx 2.666667.$$',
 errline('T_4', v, I),
 r'Reason from concavity: $f(x)=x^2$ has $f^{\prime}(x)=2x$ and $f^{\prime\prime}(x)=2>0$, so the graph is concave up. On each subinterval the chord joining two points of the graph lies **above** the graph, so each trapezoid has more area than the region under the curve. Hence $T_4>\displaystyle\int_0^2x^2\,dx$, which agrees with the computed difference $+0.083333$.']
EX.append(dict(level='Foundational', title='Trapezoidal Rule, basic computation',
 stmt=r'Approximate $\displaystyle\int_0^2 x^2\,dx$ using $T_4$.', steps=st, ans=r'$T_4=2.75$, an overestimate of the exact value $\dfrac{8}{3}\approx2.6667$ (the graph is concave up).'))

# ---------- Example 2
st, v = rule('M', sq, 0, 2, 4)
reg('E2', 'rule', R='M', f='x**2', a=0, b=2, n=4, val=v)
reg('E2', 'claim', R='M', f='x**2', a=0, b=2, n=4, sign='under')
eT = 2.75 - I; eM = I - v
st += [
 errline('M_4', v, I),
 r'Reason from concavity: on a subinterval with midpoint $\bar x$, the rectangle of height $f(\bar x)$ has the same area as the trapezoid under the **tangent line** at $\bar x$ (the tangent line has average height $f(\bar x)$ over a symmetric interval). For a concave-up function the graph lies above its tangent lines, so the area under the curve is larger than the rectangle area. Hence $M_4<\displaystyle\int_0^2x^2\,dx$, in agreement with the sign $-0.041667$ found above.',
 T(r'Compare the sizes of the two errors from Example 1 and this example: $$|I-T_4|=2.75-\dfrac{8}{3}=@eT@,\qquad |I-M_4|=\dfrac{8}{3}-2.625=@eM@,$$ and $\dfrac{@eT@}{@eM@}=@r@$, so the Trapezoidal error is twice the Midpoint error here, as the bounds $\dfrac{K(b-a)^3}{12n^2}$ and $\dfrac{K(b-a)^3}{24n^2}$ (ratio $2$) suggest.', eT=fm(eT, 5), eM=fm(eM, 5), r=fm(eT / eM, 3))]
EX.append(dict(level='Foundational', title='Midpoint Rule: same integral, opposite sign of error',
 stmt=r'Approximate $\displaystyle\int_0^2 x^2\,dx$ using $M_4$.', steps=st, ans=r'$M_4=2.625$, an underestimate of $\dfrac{8}{3}\approx2.6667$; $|I-T_4|=2\,|I-M_4|$.'))

# ---------- Example 3
st, v = rule('S', sq, 0, 2, 4)
reg('E3', 'rule', R='S', f='x**2', a=0, b=2, n=4, val=v)
st = st[:-1] + [r'Multiply by the front factor: $$S_4=\dfrac{0.5}{3}\times 16=\dfrac{16}{6}=\dfrac{8}{3}\approx 2.666667.$$',
 r'Compare with the exact value $\displaystyle\int_0^2x^2\,dx=\dfrac{8}{3}$ (Example 1): the two agree, so $S_4$ has **zero error**.',
 r'Two explanations of the zero error. (i) Simpson’s Rule fits a parabola through each three consecutive grid points and integrates the parabola exactly; $f(x)=x^2$ already is a parabola, so each piece is reproduced exactly (the same holds for every polynomial of degree $\leq3$). (ii) The error bound is $\dfrac{M(b-a)^5}{180n^4}$ with $|f^{(4)}(x)|\leq M$; here $f^{\prime}(x)=2x$, $f^{\prime\prime}(x)=2$, $f^{(3)}(x)=0$, $f^{(4)}(x)=0$, so $M=0$ and the error bound is $0$.']
EX.append(dict(level='Foundational', title="Simpson's Rule: exact for low-degree polynomials",
 stmt=r"Approximate $\displaystyle\int_0^2 x^2\,dx$ using $S_4$.", steps=st, ans=r'$S_4=\dfrac{8}{3}$, exactly (no error).'))

# ---------- Example 4
T10 = calc('T', lambda x: 1 / x, 1, 2, 10)
reg('E4', 'rule', R='T', f='1/x', a=1, b=2, n=10, val=T10)
reg('E4', 'bound', R='T', f='1/x', f2='2/x**3', a=1, b=2, n=10, K=2.0, val=2 / 1200)
st = [
 r'Identify the pieces: $f(x)=\dfrac{1}{x}=x^{-1}$, $a=1$, $b=2$, $n=10$, and the Trapezoidal bound is $$E_T\leq\dfrac{K(b-a)^3}{12n^2},\qquad K\ \text{with}\ |f^{\prime\prime}(x)|\leq K\ \text{on}\ [1,2].$$',
 r'Differentiate twice: $f^{\prime}(x)=-x^{-2}=-\dfrac{1}{x^2}$ and $f^{\prime\prime}(x)=2x^{-3}=\dfrac{2}{x^3}$.',
 r'Find the maximum of $|f^{\prime\prime}|$ on $[1,2]$. On this interval $x>0$, so $|f^{\prime\prime}(x)|=\dfrac{2}{x^3}$. Its derivative is $f^{(3)}(x)=-6x^{-4}=-\dfrac{6}{x^4}<0$, so $|f^{\prime\prime}|$ is **decreasing** on $[1,2]$ and its maximum is at the left endpoint $x=1$: $$K=|f^{\prime\prime}(1)|=\dfrac{2}{1^3}=2.$$ (At the other end, $|f^{\prime\prime}(2)|=\dfrac{2}{8}=0.25$, which is smaller.)',
 r'Substitute $K=2$, $b-a=2-1=1$, $n=10$: $$E_T\leq\dfrac{2\cdot1^3}{12\cdot10^2}=\dfrac{2}{12\cdot100}=\dfrac{2}{1200}.$$',
 r'Simplify: $\dfrac{2}{1200}=\dfrac{1}{600}\approx0.001667$. So $|\ln 2-T_{10}|\leq\dfrac{1}{600}\approx 0.00167$.',
 T(r'Reference check (computed independently): $T_{10}=@t@$ and $\ln 2=0.693147$, so the actual error is $@e@\leq0.001667$, consistent with the bound.', t=fm(T10), e=fm(abs(T10 - math.log(2)), 3))]
EX.append(dict(level='Intermediate', title='Error bound for the Trapezoidal Rule',
 stmt=r'Find a bound on the error when approximating $\displaystyle\int_1^2\dfrac{1}{x}\,dx$ using $T_{10}$.', steps=st,
 ans=r'$E_T\leq\dfrac{1}{600}\approx0.00167$ (with $K=2$).'))

# ---------- Example 5
S4s = calc('S', math.sin, 0, 1, 4)
reg('E5', 'rule', R='S', f='np.sin(x)', a=0, b=1, n=4, val=S4s)
reg('E5', 'nmin', R='S', f4='np.sin(x)', a=0, b=1, tol=1e-4, even=True, val=4)
st = [
 r"Identify the pieces: $f(x)=\sin x$, $a=0$, $b=1$, and the Simpson error bound $$E_S\leq\dfrac{M(b-a)^5}{180n^4},\qquad |f^{(4)}(x)|\leq M\ \text{on}\ [0,1].$$ We want $E_S<0.0001$ and $n$ even.",
 r'Differentiate four times: $f^{\prime}(x)=\cos x$, $f^{\prime\prime}(x)=-\sin x$, $f^{(3)}(x)=-\cos x$, $f^{(4)}(x)=\sin x$.',
 r'Bound $|f^{(4)}(x)|=|\sin x|$: for every real $x$, $|\sin x|\leq1$, so we may take $M=1$.',
 r'Require the bound to be below the tolerance: $$\dfrac{1\cdot(1-0)^5}{180n^4}<0.0001\ \Longrightarrow\ \dfrac{1}{180n^4}<0.0001.$$',
 r'Multiply both sides by $n^4>0$ and divide by $0.0001$: $$n^4>\dfrac{1}{180\times0.0001}=\dfrac{1}{0.018}=55.5556.$$',
 r'Take the fourth root (positive numbers, so the inequality direction is preserved): $$n>(55.5556)^{1/4}\approx2.7298.$$ Check: $2.7298^2=7.4518$ and $7.4518^2=55.53$.',
 r'$n$ must be an **even integer** greater than $2.7298$. The even integers are $2,4,6,\ldots$; $n=2$ is not greater than $2.7298$, so the smallest choice is $n=4$.',
 r'Verify $n=4$: $\dfrac{1}{180\cdot4^4}=\dfrac{1}{180\cdot256}=\dfrac{1}{46080}=2.1701\times10^{-5}<10^{-4}$. Verify $n=2$ fails: $\dfrac{1}{180\cdot2^4}=\dfrac{1}{2880}=3.4722\times10^{-4}>10^{-4}$.',
 T(r'Reference check: $S_4=@s@$ and $\displaystyle\int_0^1\sin x\,dx=1-\cos 1=0.459698$, so the actual error is $@e@$, far below $0.0001$.', s=fm(S4s), e=fm(abs(S4s - (1 - math.cos(1))), 3))]
EX.append(dict(level='Intermediate', title="Choosing $n$ in advance for Simpson's Rule",
 stmt=r"How large must (even) $n$ be so that $S_n$ approximates $\displaystyle\int_0^1 \sin x\,dx$ with error less than $0.0001$?", steps=st, ans=r'$n=4$.'))

# ---------- Example 6 table of data
tab = {0.0: 12, 5.0: 15, 10.0: 19, 15.0: 22, 20.0: 20, 25.0: 17, 30.0: 13}
fr = data_fn(tab, 'r')
ts = [0, 5, 10, 15, 20, 25, 30]
vT = [tab[float(t)] for t in ts]
stT, vt = rule('T', fr, 0, 30, 6, override=vT)
stS, vs = rule('S', fr, 0, 30, 6, override=vT)
stM, vm = rule('M', fr, 0, 30, 3, override=[15, 22, 17], nm='M_{3}')
reg('E6', 'data', R='T', y=vT, h=5, val=vt)
reg('E6', 'data', R='S', y=vT, h=5, val=vs)
reg('E6', 'data', R='M', y=[15, 22, 17], h=10, val=vm)
st = ([r'Set up the integral. The rate $r(t)$ (litres per minute) is known only at $t=0,5,10,\ldots,30$ minutes (table above), so the total volume $V=\displaystyle\int_0^{30}r(t)\,dt$ (litres) cannot be found by an antiderivative; use the rules with the tabulated values. The data are equally spaced with spacing $5$, so the grid is $x_i=t_i$ with $n=6$.',
       r'**Trapezoidal Rule with $n=6$.**'] + stT +
      [r'**Simpson’s Rule with $n=6$** (even, so allowed; same data).'] + stS +
      [r'**Midpoint Rule.** The midpoints of subintervals of width $5$ are $2.5,7.5,\ldots$, which are **not** in the table. Use subintervals of width $10$ instead: $n=3$, intervals $[0,10],[10,20],[20,30]$, whose midpoints $5,15,25$ **are** in the table.'] + stM +
      [T(r'Summary: $T_6=@t@$ litres, $S_6=@s@$ litres, $M_3=@m@$ litres. The three estimates agree to within about $@sp@\%$; with only tabulated data there is no formula for $f^{\prime\prime}$ or $f^{(4)}$, so an error bound cannot be computed and Simpson’s Rule (which uses the most information per subinterval) is taken as the best single estimate.', t=fm(vt, 4), s=fm(vs, 4), m=fm(vm, 4), sp=fm((max(vt, vs, vm) - min(vt, vs, vm)) / vs * 100, 2))])
EX.append(dict(level='Intermediate', title='Numerical integration from a table of data',
 stmt=r'Water flows into a tank at a rate $r(t)$ litres per minute, measured every $5$ minutes: \begin{center}\renewcommand{\arraystretch}{1.35}\setlength{\tabcolsep}{7pt}\begin{tabular}{|c|c|c|c|c|c|c|c|}\hline $t$ (min) & $0$ & $5$ & $10$ & $15$ & $20$ & $25$ & $30$ \\ \hline $r(t)$ & $12$ & $15$ & $19$ & $22$ & $20$ & $17$ & $13$ \\ \hline\end{tabular}\end{center} Estimate the total volume $\displaystyle\int_0^{30}r(t)\,dt$ using the Trapezoidal Rule $T_6$, Simpson’s Rule $S_6$ and the Midpoint Rule $M_3$ (with $n=3$ subintervals of width $10$).',
 steps=st, ans=T(r'$T_6=@t@$ L, $S_6=@s@$ L, $M_3=@m@$ L.', t=fm(vt, 6), s=fm(vs, 6), m=fm(vm, 6))))

# ---------- Example 7 Simpson S_6 with bound
g = Fn(lambda x: 1 / (1 + x), lambda xl: r'\dfrac{1}{1+%s}' % xl)
labs = ['0', r'\dfrac{1}{3}', r'\dfrac{2}{3}', '1', r'\dfrac{4}{3}', r'\dfrac{5}{3}', '2']
st, v = rule('S', g, 0, 2, 6, lab=labs, dxtex=r'\dfrac{1}{3}', coeftex=r'\dfrac{1}{9}')
Iln3 = math.log(3)
Bd = 24 * 32 / (180 * 6 ** 4)
reg('E7', 'rule', R='S', f='1/(1+x)', a=0, b=2, n=6, val=v)
reg('E7', 'exact', f='1/(1+x)', a=0, b=2, val=Iln3)
reg('E7', 'bound', R='S', f='1/(1+x)', f4='24/(1+x)**5', a=0, b=2, n=6, K=24.0, val=Bd)
st = st + [
 T(r'Exact value for comparison: $\displaystyle\int_0^2\dfrac{dx}{1+x}=\Big[\ln|1+x|\Big]_0^2=\ln3-\ln1=\ln 3\approx@I@$, so the actual error is $|\ln3-S_6|=|@I@-@v@|=@e@$ ($S_6$ is slightly larger).', I=fm(Iln3), v=fm(v), e=fm(abs(v - Iln3), 3)),
 r'Now the error **bound**. Write $f(x)=(1+x)^{-1}$ and differentiate four times: $$f^{\prime}(x)=-(1+x)^{-2},\quad f^{\prime\prime}(x)=2(1+x)^{-3},\quad f^{(3)}(x)=-6(1+x)^{-4},\quad f^{(4)}(x)=24(1+x)^{-5}=\dfrac{24}{(1+x)^5}.$$',
 r'Maximise $|f^{(4)}|$ on $[0,2]$: for $x\geq0$ we have $1+x\geq1$, so $f^{(4)}(x)=\dfrac{24}{(1+x)^5}>0$ and it is a decreasing function of $x$ (the denominator grows). The maximum is at $x=0$: $$M=f^{(4)}(0)=\dfrac{24}{1^5}=24.$$',
 T(r'Insert into $E_S\leq\dfrac{M(b-a)^5}{180n^4}$ with $b-a=2$, $n=6$: $$E_S\leq\dfrac{24\cdot2^5}{180\cdot6^4}=\dfrac{24\cdot32}{180\cdot1296}=\dfrac{768}{233280}=@B@.$$', B=fm(Bd, 5)),
 T(r'Check: the actual error $@e@$ is smaller than the guaranteed bound $@B@$, as it must be.', e=fm(abs(v - Iln3), 3), B=fm(Bd, 4))]
EX.append(dict(level='Advanced', title="Simpson's Rule with its error bound",
 stmt=r"Approximate $\displaystyle\int_0^2\dfrac{1}{1+x}\,dx$ using $S_6$, compare with the exact value, and find the Simpson error bound for $n=6$.",
 steps=st, ans=T(r'$S_6\approx@v@$; exact value $\ln3\approx@I@$; $E_S\leq@B@$.', v=fm(v, 6), I=fm(Iln3), B=fm(Bd, 4))))

# ---------- Example 8 bracketing with concavity
stT, vt = rule('T', ex_, 0, 1, 4)
stM, vm = rule('M', ex_, 0, 1, 4)
Ie = math.e - 1
reg('E8', 'rule', R='T', f='np.exp(x)', a=0, b=1, n=4, val=vt)
reg('E8', 'rule', R='M', f='np.exp(x)', a=0, b=1, n=4, val=vm)
reg('E8', 'claim', R='T', f='np.exp(x)', a=0, b=1, n=4, sign='over')
reg('E8', 'claim', R='M', f='np.exp(x)', a=0, b=1, n=4, sign='under')
st = ([r'Plan: decide the direction of each error from the sign of $f^{\prime\prime}$, then compute both rules. For $f(x)=e^x$: $f^{\prime}(x)=e^x$ and $f^{\prime\prime}(x)=e^x>0$ for every $x$, so the graph is concave up on $[0,1]$.',
       r'Concave up means: every trapezoid lies above the curve, so $T_4\geq\displaystyle\int_0^1e^x\,dx$; every midpoint rectangle has the area of a tangent-line trapezoid lying below the curve, so $M_4\leq\displaystyle\int_0^1e^x\,dx$. Hence $$M_4\leq\int_0^1e^x\,dx\leq T_4.$$',
       r'**Compute $T_4$.**'] + stT + [r'**Compute $M_4$.**'] + stM +
      [T(r'Conclusion: $$@m@\leq\int_0^1e^x\,dx\leq@t@,$$ so the integral lies in an interval of length $@L@$ found without any antiderivative.', m=fm(vm), t=fm(vt), L=fm(vt - vm, 3)),
       T(r'Check against the exact value $\displaystyle\int_0^1e^x\,dx=e-1=@I@$: indeed $@m@<@I@<@t@$. Check against the error bounds with $K=e$: $E_T\leq\dfrac{e}{12\cdot16}=@bt@$ and $E_M\leq\dfrac{e}{24\cdot16}=@bm@$; the actual errors $@et@$ and $@em@$ satisfy them.', I=fm(Ie), m=fm(vm), t=fm(vt),
         bt=fm(math.e / 192, 4), bm=fm(math.e / 384, 4), et=fm(vt - Ie, 3), em=fm(Ie - vm, 3))])
EX.append(dict(level='Advanced', title='Bracketing an integral using concavity',
 stmt=r'Use the sign of $f^{\prime\prime}$ to decide whether $T_4$ and $M_4$ over- or under-estimate $\displaystyle\int_0^1e^x\,dx$, compute both, and state the interval that must contain the integral.',
 steps=st, ans=T(r'$M_4\approx@m@\leq\displaystyle\int_0^1e^xdx\leq T_4\approx@t@$ ($T_4$ over, $M_4$ under).', m=fm(vm, 5), t=fm(vt, 5))))
