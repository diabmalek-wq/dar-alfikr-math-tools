#!/usr/bin/env bash
# Week 6 builder (same pipeline as Weeks 3-5: gen.py -> pandoc/xelatex with pre_g.tex).
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
python3 gen.py
python3 verify.py
for k in plain solutions; do
  pandoc Week-06-worksheet-$k.md -o Week-06-$k.pdf --pdf-engine=xelatex -V geometry:margin=0.9in -V fontsize=11pt \
    -V colorlinks=true -H pre_g.tex --from markdown+raw_tex
  pdfinfo Week-06-$k.pdf | grep Pages
done
