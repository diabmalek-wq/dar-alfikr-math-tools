"""Independent numerical verification (numpy/scipy only; no shared code with lib.py)."""
import json, sys, math
import numpy as np
from scipy import integrate

REG = json.load(open('/home/claude/c2w6/reg.json'))
bad = 0; n = 0
def ev(s):
    return float(eval(str(s), {'np': np, 'math': math})) if isinstance(s, str) else float(s)
def F(expr):
    return lambda x: eval(expr, {'np': np, 'x': np.asarray(x, dtype=float)}) + 0 * np.asarray(x, dtype=float)
def chk(cond, msg):
    global bad, n
    n += 1
    if not cond:
        bad += 1; print('FAIL', msg)
def rule_np(R, f, a, b, m):
    x = np.linspace(a, b, m + 1)
    dx = (b - a) / m
    if R == 'T': return float(np.trapezoid(f(x), x))
    if R == 'M':
        mid = (x[:-1] + x[1:]) / 2
        return float(dx * np.sum(f(mid)))
    return float(integrate.simpson(f(x), x=x))
def Kmax(fd, a, b):
    x = np.linspace(a, b, 2000001)
    return float(np.max(np.abs(F(fd)(x))))
def check_deriv(f, fd, order, a, b):
    # finite-difference check of the analytic derivative expression
    x = np.linspace(a + 0.05 * (b - a), b - 0.05 * (b - a), 7)
    h = 1e-2 if order == 4 else 1e-3
    ff = F(f)
    if order == 2:
        num = (ff(x + h) - 2 * ff(x) + ff(x - h)) / h ** 2
    else:
        num = (ff(x + 2 * h) - 4 * ff(x + h) + 6 * ff(x) - 4 * ff(x - h) + ff(x - 2 * h)) / h ** 4
    return np.allclose(num, F(fd)(x), rtol=2e-3, atol=2e-3)
def nmin(R, K, a, b, tol, even):
    L = b - a
    m = 1
    while True:
        if not (even and m % 2):
            B = {'T': K * L ** 3 / (12 * m * m), 'M': K * L ** 3 / (24 * m * m), 'S': K * L ** 5 / (180 * m ** 4)}[R]
            if B < tol: return m
        m += 1
for r in REG:
    k, pid = r['kind'], r['pid']
    tol = float(r.get('tol') or 3e-5)
    if k == 'rule':
        f = F(r['f']); a, b = ev(r['a']), ev(r['b'])
        ref = rule_np(r['R'], f, a, b, int(r['n']))
        v = float(r['val'])
        chk(abs(ref - v) <= tol * max(1, abs(ref)), f"{pid} rule {r['R']}{r['n']}: doc {v} vs numpy {ref}")
    elif k == 'exact':
        f = F(r['f']); a, b = ev(r['a']), ev(r['b'])
        q = integrate.quad(lambda t: float(f(t)), a, b, epsabs=1e-13)[0]
        chk(abs(q - float(r['val'])) <= max(float(r.get('tol') or 1e-9), 1e-9) * max(1, abs(q)), f"{pid} exact {r['val']} vs quad {q}")
    elif k == 'claim':
        f = F(r['f']); a, b = ev(r['a']), ev(r['b'])
        q = integrate.quad(lambda t: float(f(t)), a, b, epsabs=1e-13)[0]
        ref = rule_np(r['R'], f, a, b, int(r['n']))
        got = 'over' if ref > q else 'under'
        chk(got == r['sign'], f"{pid} claim {r['R']}{r['n']} {r['sign']}: numerics say {got} ({ref} vs {q})")
    elif k == 'bound':
        key = 'f4' if r['R'] == 'S' else 'f2'
        order = 4 if r['R'] == 'S' else 2
        fd = r[key]
        a, b = ev(r['a']), ev(r['b'])
        chk(check_deriv(r['f'], fd, order, a, b), f"{pid} derivative expr {fd} mismatches f")
        K = Kmax(fd, a, b)
        chk(abs(K - float(r['K'])) < 1e-4 * max(1, K), f"{pid} K {r['K']} vs sampled max {K}")
        L = b - a; m = int(r['n'])
        B = {'T': K * L ** 3 / (12 * m * m), 'M': K * L ** 3 / (24 * m * m), 'S': K * L ** 5 / (180 * m ** 4)}[r['R']]
        chk(abs(B - float(r['val'])) <= max(float(r.get('tol') or 1e-6), 1e-6) * max(B, 1e-3) , f"{pid} bound {r['val']} vs {B}")
        # the bound must really bound the true error
        f = F(r['f'])
        q = integrate.quad(lambda t: float(f(t)), a, b, epsabs=1e-13)[0]
        err = abs(rule_np(r['R'], f, a, b, m) - q)
        chk(err <= B * (1 + 1e-9), f"{pid} actual error {err} exceeds bound {B}")
    elif k == 'Kmax':
        order = int(r.get('order') or 2)
        a, b = ev(r['a']), ev(r['b'])
        chk(check_deriv(r['f'], r['fd'], order, a, b), f"{pid} Kmax derivative expr mismatch")
        K = Kmax(r['fd'], a, b)
        chk(abs(K - float(r['K'])) < 1e-4 * max(1, K), f"{pid} Kmax {r['K']} vs {K}")
    elif k == 'nmin':
        a, b = ev(r['a']), ev(r['b'])
        K = float(r['K']) if r.get('K') not in (None, 'None') else Kmax(r['f4'], a, b)
        m = nmin(r['R'], K, a, b, float(r['tol']), r['even'] in (True, 'True'))
        chk(m == int(r['val']), f"{pid} nmin {r['R']}: doc {r['val']} vs {m}")
    elif k == 'data':
        y = np.array(r['y'], dtype=float) if not isinstance(r['y'], str) else np.array(eval(r['y']), dtype=float)
        h = float(r['h'])
        if r['R'] == 'T': ref = float(np.trapezoid(y, dx=h))
        elif r['R'] == 'S': ref = float(integrate.simpson(y, dx=h))
        else: ref = float(h * y.sum())
        chk(abs(ref - float(r['val'])) < 1e-6 * max(1, abs(ref)), f"{pid} data {r['R']}: doc {r['val']} vs {ref}")
    elif k == 'claimdata':
        f = F(r['model']); a, b = ev(r['a']), ev(r['b'])
        q = integrate.quad(lambda t: float(f(t)), a, b)[0]
        chk(float(r['T']) < q < float(r['M']) and float(r['T']) < float(r['S']) < float(r['M']), f"{pid} T<I<M ordering fails ({r['T']},{q},{r['M']})")
        chk(abs(float(r['S']) - q) < abs(float(r['T']) - q), f"{pid} Simpson not closer than T")
    elif k == 'plain':
        loc = {kk: ev(vv) for kk, vv in r.items() if kk not in ('pid', 'kind', 'expr', 'val', 'tol')}
        loc['np'] = np
        ref = float(eval(r['expr'], {'np': np}, loc))
        chk(abs(ref - float(r['val'])) < 2e-5 * max(1, abs(ref)), f"{pid} plain {r['expr']}: doc {r['val']} vs {ref}")
    elif k == 'order':
        f = F(r['f']); a, b = ev(r['a']), ev(r['b']); m = int(r['n'])
        v = r['vals']
        x = np.linspace(a, b, m + 1); dx = (b - a) / m
        Lr = dx * f(x[:-1]).sum(); Rr = dx * f(x[1:]).sum()
        Tr = rule_np('T', f, a, b, m); Mr = rule_np('M', f, a, b, m)
        q = integrate.quad(lambda t: float(f(t)), a, b)[0]
        chk(Lr < Tr < q < Mr < Rr, f"{pid} order fails")
        for nm_, ref in zip('LTIMR', (Lr, Tr, q, Mr, Rr)):
            chk(abs(float(v[nm_]) - ref) < 2e-5, f"{pid} {nm_}: doc {v[nm_]} vs {ref}")
    else:
        print('unknown kind', k)
# the identity S_2n = (2 M_n + T_n)/3 on random smooth functions
rng = np.random.default_rng(1)
for _ in range(20):
    c = rng.normal(size=4)
    f = lambda x, c=c: c[0] + c[1] * np.sin(c[2] * x + 1) + c[3] * x ** 3
    for m in (2, 4, 6):
        lhs = rule_np('S', f, 0, 2, 2 * m)
        rhs = (2 * rule_np('M', f, 0, 2, m) + rule_np('T', f, 0, 2, m)) / 3
        chk(abs(lhs - rhs) < 1e-10, 'identity S2n=(2M+T)/3')
        chk(abs(rule_np('T', f, 0, 2, 2 * m) - (rule_np('T', f, 0, 2, m) + rule_np('M', f, 0, 2, m)) / 2) < 1e-10, 'identity T2n=(T+M)/2')
# exactness of Simpson for cubics
for _ in range(20):
    c = rng.normal(size=4)
    f = lambda x, c=c: c[0] + c[1] * x + c[2] * x ** 2 + c[3] * x ** 3
    ex_ = c[0] * 3 + c[1] * 9 / 2 + c[2] * 27 / 3 + c[3] * 81 / 4
    chk(abs(rule_np('S', f, 0, 3, 2) - ex_) < 1e-9, 'Simpson exact cubic')
print('checks:', n, 'failures:', bad)
sys.exit(1 if bad else 0)
