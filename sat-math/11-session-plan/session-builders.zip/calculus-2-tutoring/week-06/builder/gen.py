import sys, os, subprocess, json
sys.path.insert(0, '/home/claude/repo-check2/calculus-2-tutoring/tools')
sys.path.insert(0, '/home/claude/c2w6')
from render import md2tex
import ex
from pr3 import PR as _pr, SA, SB, SC, SD, SE, SF, SG
import lib
EX = ex.EX
ORDER = [SA, SB, SC, SD, SE, SF, SG]
for p in _pr: assert p['sec'] in ORDER, p['sec']
PR = sorted(_pr, key=lambda p: ORDER.index(p['sec']))   # stable: keeps authored order inside a section
TITLE = r"Numerical Integration: Midpoint, Trapezoidal and Simpson’s Rule"
INTRO = r"""**Recap and orientation**

Weeks 1-5 built the exact toolkit for $\int_a^b f(x)\,dx$: antiderivatives, integration techniques and improper integrals. This week covers the situation where **no elementary antiderivative is available** (for example $e^{-x^2}$, $\sin(x^2)$, $\dfrac{\sin x}{x}$), or where $f$ is known only from a **table of measured values**. The integral is then approximated to any desired accuracy using only values of $f$, together with a guaranteed **error bound**.

**Why this matters**

The three rules differ in how much of the graph they capture on each subinterval: a rectangle (Midpoint), a straight chord (Trapezoidal) or a parabola (Simpson). Knowing the error bounds lets you choose $n$ in advance, and the sign of $f''$ tells you in which direction each rule errs.
"""
FACTS = [("definitionbox", "Setting: Approximating a Definite Integral", r"""To approximate $\displaystyle\int_a^b f(x)\,dx$, divide $[a,b]$ into $n$ equal subintervals of width
$$\Delta x=\dfrac{b-a}{n},\qquad x_i=a+i\,\Delta x,\quad x_0=a<x_1<\cdots<x_n=b.$$
All rules use only values of $f$ at points of this grid (or at the midpoints of its subintervals)."""),
("factbox", "The Midpoint Rule", r"""$$M_n=\Delta x\Big[f(\bar x_1)+f(\bar x_2)+\cdots+f(\bar x_n)\Big],\qquad \bar x_i=\dfrac{x_{i-1}+x_i}{2}\ \text{(midpoint of the $i$-th subinterval).}$$
Geometrically, $M_n$ sums the areas of rectangles whose height is the function value at each subinterval's midpoint."""),
("factbox", "The Trapezoidal Rule", r"""$$T_n=\dfrac{\Delta x}{2}\Big[f(x_0)+2f(x_1)+2f(x_2)+\cdots+2f(x_{n-1})+f(x_n)\Big].$$
Geometrically, $T_n$ sums the areas of trapezoids formed by joining consecutive points $(x_{i-1},f(x_{i-1}))$ and $(x_i,f(x_i))$ with straight lines. Weights: $1$ at the two end points, $2$ at every interior grid point."""),
("factbox", "Error Bounds for $M_n$ and $T_n$", r"""If $|f''(x)|\leq K$ for all $x\in[a,b]$, then the errors $E_M=\left|\displaystyle\int_a^b f\,dx-M_n\right|$ and $E_T=\left|\displaystyle\int_a^b f\,dx-T_n\right|$ satisfy
$$E_M\leq\dfrac{K(b-a)^3}{24n^2},\qquad E_T\leq\dfrac{K(b-a)^3}{12n^2}.$$
The Trapezoidal bound is exactly twice the Midpoint bound. For a function of one concavity, $M_n$ and $T_n$ err in opposite directions."""),
("factbox", "Simpson's Rule", r"""For **even** $n$,
$$S_n=\dfrac{\Delta x}{3}\Big[f(x_0)+4f(x_1)+2f(x_2)+4f(x_3)+2f(x_4)+\cdots+4f(x_{n-1})+f(x_n)\Big].$$
Weights: $1$ at the end points, then $4,2,4,2,\ldots,4$ at the interior points (the interior run starts and ends with $4$ because $n$ is even). Simpson's Rule fits a parabola through each consecutive triple of grid points, so it integrates every polynomial of degree $\leq3$ **exactly**."""),
("factbox", "Error Bound for $S_n$", r"""If $\left|f^{(4)}(x)\right|\leq M$ for all $x\in[a,b]$, then
$$E_S=\left|\int_a^b f\,dx-S_n\right|\leq\dfrac{M(b-a)^5}{180n^4}.$$
The $n^4$ (versus $n^2$ for $M_n$ and $T_n$) means that doubling $n$ divides the Trapezoidal bound by $4$ and the Simpson bound by $16$."""),
("factbox", "Concavity and the Relationship Between the Rules", r"""If $f''>0$ on $[a,b]$ (concave up), then $M_n\leq\displaystyle\int_a^bf\,dx\leq T_n$. If $f''<0$ (concave down), then $T_n\leq\displaystyle\int_a^bf\,dx\leq M_n$. Simpson's Rule is built from the two:
$$S_{2n}=\dfrac{2M_n+T_n}{3}.$$""")]
def box(env, title, body): return "\\begin{%s}{%s}\n\n%s\n\n\\end{%s}\n\n" % (env, title, md2tex(body), env)
def steps_md(steps): return "\n\n\\smallskip\n\n".join(("\\Needspace{5cm}\n\n" if s.startswith("**") else "") + "**Step %d.** %s" % (i, s) for i, s in enumerate(steps, 1))
def head():
    t = "\\worksheettitle{06}{%s}{}\n\n" % TITLE + INTRO + "\n"
    for e, ti, b in FACTS: t += box(e, ti, b)
    return t
def examples():
    t = "\\Needspace{10cm}\n\n\\sectionbanner{Worked Examples}\n\n"
    for i, e in enumerate(EX, 1):
        body = "\\textit{Level: %s. %s}\\par\\smallskip\n\n" % (e['level'], e['title']) + md2tex(e['stmt']) + "\n\n" + md2tex(steps_md(e['steps'])) + "\n\n" + md2tex("**Answer.** " + e['ans'])
        t += "\\Needspace{7cm}\n\n\\begin{examplebox}{%d}\n\n%s\n\n\\end{examplebox}\n\n" % (i, body)
    return t
def nl(p): return min(14 if 'tabular' in p['stmt'] else 17, max(8, int(round(p['lines'] * 1.1))))
def practice(ans):
    t = "\\Needspace{10cm}\n\n\\sectionbanner{Practice Problems}\n\n"
    if ans: t += "*Worked-solutions version: every step of each solution is shown in green beneath its problem.*\n\n"
    cur = None
    for n, p in enumerate(PR, 1):
        need = 9 if ans else min(22.5, 3.4 + 1.1 * nl(p) + (1.8 if 'tabular' in p['stmt'] else 0))
        t += "\\Needspace{%.1fcm}\n\n" % need
        if p['sec'] != cur:
            cur = p['sec']; t += "\\vspace{6pt}\\noindent{\\bfseries\\large %s}\\par\\vspace{2pt}\n\n" % cur
        t += "**%d.** %s\n\n" % (n, p['stmt'])
        if ans:
            t += "\\begin{solbox}\\sollabel\n\n%s\n\n%s\n\\end{solbox}\n\\vspace{4pt}\n\n" % (md2tex(steps_md(p['steps'])), md2tex("**Answer.** " + p['ans']))
        else:
            t += "\\worklines{%d}\n\\vspace{6pt}\n\n" % nl(p)
    return t
out = '/home/claude/c2w6'
open(out + '/Week-06-worksheet-plain.md', 'w').write(head() + examples() + practice(False))
open(out + '/Week-06-worksheet-solutions.md', 'w').write(head() + examples() + practice(True))
json.dump(lib.REG, open(out + '/reg.json', 'w'), default=str, indent=0)
json.dump([dict(n=i + 1, sec=p['sec'], ans=p['ans']) for i, p in enumerate(PR)], open(out + '/pr_index.json', 'w'), indent=0)
print(len(EX), len(PR), len(lib.REG))
