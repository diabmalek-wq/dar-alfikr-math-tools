"""Helpers for the Week-6 numerical-integration content: every number shown in the
steps is produced here (6 s.f. by-hand style) so text and values cannot drift apart."""
import math
from decimal import Decimal as Dc, getcontext
getcontext().prec = 50

def sf(x, n=6):
    if abs(x) < 1e-12: return 0.0
    return round(x, n - 1 - int(math.floor(math.log10(abs(x)))))

def fm(x, n=6):
    """string of x rounded to n significant figures, fixed notation, trailing zeros stripped"""
    if abs(x) < 1e-12: return '0'
    d = n - 1 - int(math.floor(math.log10(abs(x))))
    v = round(x, d)
    s = ('%.*f' % (max(d, 0), v))
    if '.' in s: s = s.rstrip('0').rstrip('.')
    return s

def dc(x): return Dc(fm(x))
def exs(d):
    t = format(d.normalize(), 'f')
    return t

def T(_t, **kw):
    for k, v in kw.items(): _t = _t.replace('@%s@' % k, str(v))
    assert '@' not in _t, _t
    return _t

REG = []   # registry of numerical claims for the independent verifier
def reg(pid, kind, **kw):
    REG.append(dict(pid=pid, kind=kind, **kw))

def paren(s):
    return '(' + s + ')' if (s.startswith('-') or '+' in s or '-' in s[1:]) else s

class Fn:
    """f: callable; sub: label-tex -> tex of substituted expression"""
    def __init__(self, f, sub, name='f'):
        self.f, self.sub, self.name = f, sub, name

def lab_dec(x): return fm(x)

def mkgrid(a, b, n, lab=None):
    dx = (b - a) / n
    xs = [a + i * dx for i in range(n + 1)]
    lab = lab or [fm(x) for x in xs]
    return xs, lab, dx

def rows(pairs, per=2):
    """aligned display of equations given as list of (lhs, rhs) tex"""
    lines = []
    for i in range(0, len(pairs), per):
        chunk = pairs[i:i + per]
        lines.append(r' &\quad '.join('%s&=%s' % (l, r) for l, r in chunk))
    return r'$$\begin{aligned}' + r'\\ '.join(lines) + r'\end{aligned}$$'

def wrap_sum(terms, per=5, lead='='):
    lines = []
    for i in range(0, len(terms), per):
        ch = ' + '.join(terms[i:i + per])
        lines.append(('&%s\\ ' % lead if i == 0 else '&\\quad +\\ ') + ch)
    return r'$$\begin{aligned}' + r'\\ '.join(lines) + r'\end{aligned}$$'

def fvals(fn, xs, override=None):
    out = []
    for i, x in enumerate(xs):
        out.append(override[i] if override else sf(fn.f(x)))
    return out

def terms_list(weights, vals):
    return [(('%s(%s)' % (fm(w), fm(v))) if w != 1 else fm(v)) for w, v in zip(weights, vals)]

def wsum(weights, vals):
    return sum(Dc(w) * dc(v) for w, v in zip(weights, vals))

def bracket_general(rule, n):
    if rule == 'T':
        if n <= 5:
            return '+'.join(['f(x_0)'] + ['2f(x_%d)' % i for i in range(1, n)] + ['f(x_%d)' % n])
        return 'f(x_0)+2f(x_1)+2f(x_2)+\\cdots+2f(x_{%d})+f(x_{%d})' % (n - 1, n)
    if rule == 'M':
        if n <= 6:
            return '+'.join('f(\\bar x_%d)' % i for i in range(1, n + 1))
        return 'f(\\bar x_1)+f(\\bar x_2)+\\cdots+f(\\bar x_{%d})' % n
    if rule == 'S':
        if n <= 6:
            ws = [1] + [4 if i % 2 else 2 for i in range(1, n)] + [1]
            return '+'.join(('%df(x_%d)' % (w, i) if w != 1 else 'f(x_%d)' % i) for i, w in enumerate(ws))
        return 'f(x_0)+4f(x_1)+2f(x_2)+4f(x_3)+\\cdots+2f(x_{%d})+4f(x_{%d})+f(x_{%d})' % (n - 2, n - 1, n)


def bracket_display(name, coef, terms, per=5, close=True):
    lines = []
    for i in range(0, len(terms), per):
        ch = ' + '.join(terms[i:i + per])
        if i == 0:
            lines.append('&%s=%s\\Big[\\,%s' % (name, coef, ch))
        else:
            lines.append('&\\qquad +\\ %s' % ch)
    lines[-1] += '\\,\\Big]'
    return r'$$\begin{aligned}' + r'\\ '.join(lines) + r'\end{aligned}$$'

def sum_display(prods, S, per=6):
    lines = []
    for i in range(0, len(prods), per):
        ch = ' + '.join(prods[i:i + per])
        lines.append(('&\\text{bracket}=\\ ' if i == 0 else '&\\qquad +\\ ') + ch)
    lines[-1] += '\\ =\\ %s' % S
    return r'$$\begin{aligned}' + r'\\ '.join(lines) + r'\end{aligned}$$'

def rule(R, fn, a, b, n, atex=None, btex=None, lab=None, dxtex=None, override=None, nm=None, coeftex=None, midlab=None, rnd=6):
    """Return (steps, value). R in 'T','M','S'. nm = display name like T_{4}."""
    atex = atex or fm(a); btex = btex or fm(b)
    if R == 'S': assert n % 2 == 0
    xs, lab0, dx = mkgrid(a, b, n, lab)
    exact_dec = abs(dx - round(dx, 6)) < 1e-12 and dxtex is None
    dxt = dxtex or fm(dx)
    full = {'T': ('Trapezoidal Rule', r'T_{%d}', 2), 'M': ('Midpoint Rule', r'M_{%d}', 1), 'S': ("Simpson's Rule", r'S_{%d}', 3)}[R]
    name = nm or full[1] % n
    st = []
    gen = bracket_general(R, n)
    k = full[2]
    if R == 'M':
        form = r'M_n=\Delta x\,\Big[f(\bar x_1)+f(\bar x_2)+\cdots+f(\bar x_n)\Big]'
        fr = r'\Delta x'
    elif R == 'T':
        form = r'T_n=\dfrac{\Delta x}{2}\Big[f(x_0)+2f(x_1)+\cdots+2f(x_{n-1})+f(x_n)\Big]'
        fr = r'\dfrac{\Delta x}{2}'
    else:
        form = r"S_n=\dfrac{\Delta x}{3}\Big[f(x_0)+4f(x_1)+2f(x_2)+\cdots+2f(x_{n-2})+4f(x_{n-1})+f(x_n)\Big]"
        fr = r'\dfrac{\Delta x}{3}'
    st.append('Formula used (%s, $n=%d$): $$%s.$$ For $n=%d$ this is $$%s=%s\Big[%s\Big].$$' % (full[0], n, form, n, name, fr, gen))
    if exact_dec:
        st.append(T(r'Width of each subinterval: $$\Delta x=\dfrac{b-a}{n}=\dfrac{@b@-@a@}{@n@}=@dx@.$$', a=paren(atex), b=btex, n=n, dx=dxt))
    else:
        st.append(T(r'Width of each subinterval: $$\Delta x=\dfrac{b-a}{n}=\dfrac{@b@-@a@}{@n@}=@dx@\approx @dxn@.$$', a=paren(atex), b=btex, n=n, dx=dxt, dxn=fm(dx)))
    if R in ('T', 'S'):
        npairs = [('x_{%d}' % i, lab0[i] + ('' if (lab0[i] == fm(xs[i])) else '\\approx %s' % fm(xs[i]))) for i in range(n + 1)]
        st.append(r'Grid points $x_i=a+i\,\Delta x$ for $i=0,1,\ldots,%d$:%s' % (n, rows(npairs, 5 if n <= 5 else 4)))
        vals = fvals(fn, xs, override)
        pairs = [('f(x_{%d})' % i, '%s=%s' % (fn.sub(lab0[i]), fm(vals[i]))) for i in range(n + 1)]
        note = '' if override else ' (rounded to 6 significant figures where necessary)'
        st.append('Function values at the grid points%s: %s' % (note, rows(pairs, 2 if n <= 8 else 3)))
        w = [1] + [(4 if i % 2 else 2) if R == 'S' else 2 for i in range(1, n)] + [1]
        tl = terms_list(w, vals)
        coef = coeftex or (r'\dfrac{%s}{%d}' % (dxt, k))
        st.append('Insert the weights (%s) and the function values: %s' % (
            '$1,2,2,\\ldots,2,1$' if R == 'T' else '$1,4,2,4,\\ldots,2,4,1$', bracket_display(name, coef, tl)))
        prods = [exs(Dc(wi) * dc(v)) for wi, v in zip(w, vals)]
        S = wsum(w, vals)
        st.append('Do each multiplication inside the bracket and add the results: %s' % sum_display(prods, exs(S)))
        val = float(S) * dx / k
        cf = fm(dx / k) if exact_dec and abs(dx / k - round(dx / k, 6)) < 1e-12 else (coef + r'\,(\approx %s)' % fm(dx / k))
        st.append(T(r'Multiply by the front factor: $$@nm@=@cf@\times @S@=@v@.$$', nm=name, cf=cf, S=exs(S), v=fm(val)))
    else:
        mids = [(xs[i] + xs[i + 1]) / 2 for i in range(n)]
        if midlab:
            mp = [('\\bar x_{%d}' % (i + 1), '\\dfrac{%s+%s}{2}=%s\\approx %s' % (lab0[i], lab0[i + 1], midlab[i], fm(mids[i]))) for i in range(n)]
        else:
            mp = [('\\bar x_{%d}' % (i + 1), '\\dfrac{%s+%s}{2}=%s' % (paren(fm(xs[i])), paren(fm(xs[i + 1])), fm(mids[i]))) for i in range(n)]
        st.append(r'Midpoints of the subintervals, $\bar x_i=\dfrac{x_{i-1}+x_i}{2}$: %s' % rows(mp, 1 if midlab else (2 if n <= 8 else 3)))
        vals = fvals(fn, mids, override)
        pairs = [('f(\\bar x_{%d})' % (i + 1), '%s=%s' % (fn.sub(midlab[i] if midlab else fm(mids[i])), fm(vals[i]))) for i in range(n)]
        note = '' if override else ' (rounded to 6 significant figures where necessary)'
        st.append('Function values at the midpoints%s: %s' % (note, rows(pairs, 2 if n <= 8 else 3)))
        S = wsum([1] * n, vals)
        st.append('Add the %d midpoint values (all weights are $1$): %s' % (n, sum_display([exs(dc(v)) for v in vals], exs(S))))
        val = float(S) * dx
        st.append(T(r'Multiply by $\Delta x$: $$@nm@=@dxn@\times @S@=@v@.$$', nm=name, dxn=dxt if exact_dec else dxt + r'\,(\approx ' + fm(dx) + ')', S=exs(S), v=fm(val)))
    return st, val

def calc(R, f, a, b, n):
    """plain float reference value (unrounded)"""
    dx = (b - a) / n
    if R == 'M':
        return dx * sum(f(a + (i + .5) * dx) for i in range(n))
    if R == 'T':
        return dx / 2 * (f(a) + f(b) + 2 * sum(f(a + i * dx) for i in range(1, n)))
    w = [1] + [4 if i % 2 else 2 for i in range(1, n)] + [1]
    return dx / 3 * sum(wi * f(a + i * dx) for i, wi in enumerate(w))

def compact(R, fn, a, b, n, nm=None, lab=None, override=None):
    """One step: delta x, node->value pairs and the full weighted sum, no sub-steps. Returns (tex, value)."""
    xs, lab0, dx = mkgrid(a, b, n, lab)
    k = {'T': 2, 'M': 1, 'S': 3}[R]
    name = nm or '%s_{%d}' % (R, n)
    if R == 'M':
        pts = [(xs[i] + xs[i + 1]) / 2 for i in range(n)]
        w = [1] * n
        lbls = [fm(p) for p in pts]
    else:
        pts = xs
        lbls = lab0
        w = [1] + [(4 if i % 2 else 2) if R == 'S' else 2 for i in range(1, n)] + [1]
    vals = fvals(fn, pts, override)
    pairs = [('f(%s)' % lbls[i], fm(vals[i])) for i in range(len(pts))]
    S = wsum(w, vals)
    coefv = dx / k
    terms = terms_list(w, vals)
    val = float(S) * coefv
    cdisp = fm(coefv)
    tex = ('with $\\Delta x=%s$, the %s are at $x=%s$, and the function values are %s' % (
        fm(dx), 'midpoints' if R == 'M' else 'nodes', ',\\ '.join(lbls), rows(pairs, 3 if len(pts) > 6 else 2))
        + bracket_display(name, cdisp, terms)
        + '$$%s=%s\\times %s=%s.$$' % (name, cdisp, exs(S), fm(val)))
    return tex, val

def errline(name, val, I, Itex=None):
    d = val - I
    kind = 'overestimates' if d > 0 else 'underestimates'
    return T(r'Error: $$@nm@-I=@v@-@I@=@d@,\qquad |I-@nm@|=@e@.$$ The difference is @sg@, so @nm2@ **@kind@** the exact value.',
             nm=name, v=fm(val), I=fm(I), d=fm(d), e=fm(abs(d), 4), sg='positive' if d > 0 else 'negative', nm2='$%s$' % name, kind=kind)

def data_fn(table, nm='r'):
    return Fn(lambda x: table[round(x, 9)], lambda xl: '%s(%s)' % (nm, xl))
