import math
from lib import *
from pr2 import *

def cmpfx(pid, R, fn, fstr, a, b, n, nm, exact, sign, lab=None, atex=None, btex=None):
    tex, v = compact(R, fn, a, b, n, nm=nm, lab=lab)
    reg(pid, 'rule', R=R, f=fstr, a=a, b=b, n=n, val=v)
    reg(pid, 'claim', R=R, f=fstr, a=a, b=b, n=n, sign=sign)
    return tex, v

# ============================================================ F
# P22 four parts
parts = []
st = []
# (a)
tT, vT = cmpfx('P22a', 'T', inv, '1/x', 1, 3, 4, 'T_4', None, 'over')
tM, vM = cmpfx('P22a', 'M', inv, '1/x', 1, 3, 4, 'M_4', None, 'under')
Ia = math.log(3)
st += [r'**(a) $f(x)=\dfrac{1}{x}$ on $[1,3]$.** $f^{\prime}(x)=-x^{-2}$ and $f^{\prime\prime}(x)=\dfrac{2}{x^3}>0$ on $[1,3]$, so $f$ is concave up: $T_n$ **overestimates** and $M_n$ **underestimates**.',
       'Numerical check with $n=4$ (exact value $\\ln3=%s$). Trapezoidal: %s Midpoint: %s' % (fm(Ia), tT, tM),
       T(r'Result: $T_4-I=@a@>0$ and $M_4-I=@b@<0$, confirming the prediction.', a=fm(vT - Ia, 3), b=fm(vM - Ia, 3))]
# (b)
tT, vT = cmpfx('P22b', 'T', ln, 'np.log(x)', 1, 5, 4, 'T_4', None, 'under')
tM, vM = cmpfx('P22b', 'M', ln, 'np.log(x)', 1, 5, 4, 'M_4', None, 'over')
Ib = 5 * math.log(5) - 4
st += [r'**(b) $f(x)=\ln x$ on $[1,5]$.** $f^{\prime}(x)=\dfrac{1}{x}$ and $f^{\prime\prime}(x)=-\dfrac{1}{x^2}<0$, so $f$ is concave down: $T_n$ **underestimates** and $M_n$ **overestimates**.',
       'Numerical check with $n=4$ (exact value $\\int_1^5\\ln x\\,dx=[x\\ln x-x]_1^5=5\\ln5-4=%s$). Trapezoidal: %s Midpoint: %s' % (fm(Ib), tT, tM),
       T(r'Result: $T_4-I=@a@<0$ and $M_4-I=+@b@>0$, confirming the prediction.', a=fm(vT - Ib, 3), b=fm(vM - Ib, 3))]
# (c)
c3 = Fn(lambda x: x ** 3, lambda xl: r'(%s)^3' % xl)
tT, vT = cmpfx('P22c', 'T', c3, 'x**3', 0, 2, 4, 'T_4', None, 'over')
tM, vM = cmpfx('P22c', 'M', c3, 'x**3', 0, 2, 4, 'M_4', None, 'under')
st += [r'**(c) $f(x)=x^3$ on $[0,2]$.** $f^{\prime}(x)=3x^2$ and $f^{\prime\prime}(x)=6x\geq0$ on $[0,2]$ (strictly positive for $x>0$), so $f$ is concave up: $T_n$ **overestimates** and $M_n$ **underestimates**.',
       'Numerical check with $n=4$ (exact value $\\int_0^2x^3\\,dx=\\left[\\dfrac{x^4}{4}\\right]_0^2=4$). Trapezoidal: %s Midpoint: %s' % (tT, tM),
       T(r'Result: $T_4-4=@a@>0$ and $M_4-4=@b@<0$, confirming the prediction.', a=fm(vT - 4, 3), b=fm(vM - 4, 3))]
# (d)
tT, vT = cmpfx('P22d', 'T', sn, 'np.sin(x)', 0, math.pi, 4, 'T_4', None, 'under', lab=L4)
tM, vM = cmpfx('P22d', 'M', sn, 'np.sin(x)', 0, math.pi, 4, 'M_4', None, 'over')
st += [r'**(d) $f(x)=\sin x$ on $[0,\pi]$.** $f^{\prime}(x)=\cos x$ and $f^{\prime\prime}(x)=-\sin x\leq0$ on $[0,\pi]$ (since $\sin x\geq0$ there), so $f$ is concave down: $T_n$ **underestimates** and $M_n$ **overestimates**.',
       'Numerical check with $n=4$ (exact value $\\int_0^\\pi\\sin x\\,dx=2$; here $\\Delta x=\\dfrac{\\pi}{4}=0.785398$). Trapezoidal: %s Midpoint: %s' % (tT.replace('with $\\Delta x=0.785398$', 'with $\\Delta x=0.785398$'), tM),
       T(r'Result: $T_4-2=@a@<0$ and $M_4-2=+@b@>0$, confirming the prediction.', a=fm(vT - 2, 3), b=fm(vM - 2, 3))]
P(SF, r'Without computing any sum, use the sign of $f^{\prime\prime}$ to decide whether $T_n$ and $M_n$ overestimate or underestimate each integral. Then confirm with $T_4$ and $M_4$. (a) $\displaystyle\int_1^3\dfrac{1}{x}\,dx$. (b) $\displaystyle\int_1^5\ln x\,dx$. (c) $\displaystyle\int_0^2x^3\,dx$. (d) $\displaystyle\int_0^\pi\sin x\,dx$.',
  st, r'(a) $T$ over, $M$ under; (b) $T$ under, $M$ over; (c) $T$ over, $M$ under; (d) $T$ under, $M$ over (concave up gives $M_n\leq I\leq T_n$, concave down gives $T_n\leq I\leq M_n$).', 18)
vT22d, vM22d = vT, vM

# P23 source 9
reg('P23', 'plain', expr='(2*M+T)/3', val=5.10, M=5.05, T=5.20)
st = [r'The identity connecting the three rules is $S_{2n}=\dfrac{2M_n+T_n}{3}$. Here $M_n=M_4$ and $T_n=T_4$ (so $n=4$), hence the Simpson value obtained is for $2n=8$ subintervals: $S_8$.',
 r'Substitute $T_4=5.20$ and $M_4=5.05$: $$S_8=\dfrac{2(5.05)+5.20}{3}.$$',
 r'Evaluate the numerator: $2(5.05)=10.10$ and $10.10+5.20=15.30$. Divide: $$S_8=\dfrac{15.30}{3}=5.10.$$',
 r'Independent check by another route. The Trapezoidal Rule with doubled $n$ is the average $T_{2n}=\dfrac{T_n+M_n}{2}$, so $T_8=\dfrac{5.20+5.05}{2}=5.125$. Simpson’s Rule can also be written $S_{2n}=\dfrac{4T_{2n}-T_n}{3}$, which gives $$S_8=\dfrac{4(5.125)-5.20}{3}=\dfrac{20.5-5.2}{3}=\dfrac{15.3}{3}=5.10,$$ the same value.',
 r'Meaning of the data: $T_4=5.20>M_4=5.05$ is the pattern of a concave-up integrand ($M$ under, $T$ over), so the exact integral lies between $5.05$ and $5.20$, and $5.10$ is in that interval.',
 r'Why the $2:1$ weighting reduces the error: for a smooth integrand the leading error terms satisfy $I-M_n\approx e$ and $I-T_n\approx-2e$ (same size ratio as the bound constants $\dfrac{1}{24}$ and $\dfrac{1}{12}$, opposite signs). Then $$I-\dfrac{2M_n+T_n}{3}\approx\dfrac{2e+(-2e)}{3}=0,$$ so the leading term cancels. With the given numbers, $T_4-M_4=3e=0.15$ gives $e=0.05$ and $I\approx M_4+e=5.10$, matching $S_8$.',
 r'An equal-weight average does not cancel the leading term: $I-\dfrac{T_n+M_n}{2}\approx\dfrac{-2e+e}{2}=-\dfrac{e}{2}\neq0$, so $\dfrac{T_4+M_4}{2}=5.125$ is a worse estimate than $5.10$ (and it is $T_8$, not $S_8$).']
P(SF, r'A student computes $T_4$ and $M_4$ for the same integral and gets $T_4=5.20$ and $M_4=5.05$. Without further calculation, give the best available estimate for the Simpson value with $8$ subintervals using the identity $S_{2n}=\dfrac{2M_n+T_n}{3}$, and explain why this weighted average reduces the error compared with either $T_4$ or $M_4$ alone.',
  st, r'$S_8=\dfrac{2(5.05)+5.20}{3}=5.10$.', 12)

# P24 identity check on 1/x
stT, vT = rule('T', inv, 1, 2, 2); stM, vM = rule('M', inv, 1, 2, 2)
S4v = calc('S', lambda x: 1 / x, 1, 2, 4)
comb = (2 * float(dc(vM)) + float(dc(vT))) / 3
reg('P24', 'rule', R='T', f='1/x', a=1, b=2, n=2, val=vT)
reg('P24', 'rule', R='M', f='1/x', a=1, b=2, n=2, val=vM)
reg('P24', 'rule', R='S', f='1/x', a=1, b=2, n=4, val=S4v)
reg('P24', 'plain', expr='(2*M+T)/3', val=comb, M=vM, T=vT, tol=1e-5)
st = [r'**Compute $T_2$** for $\displaystyle\int_1^2\dfrac{dx}{x}$.'] + stT + [r'**Compute $M_2$.**'] + stM + [
 T(r'Combine with $S_{2n}=\dfrac{2M_n+T_n}{3}$ for $n=2$: $$S_4=\dfrac{2(@m@)+@t@}{3}=\dfrac{@n1@+@t@}{3}=\dfrac{@n2@}{3}=@c@.$$', m=fm(vM), t=fm(vT), n1=fm(2 * float(dc(vM)), 7), n2=fm(2 * float(dc(vM)) + float(dc(vT)), 7), c=fm(comb)),
 T(r'Compare with the direct Simpson computation in Problem 8: $S_4=@s@$. The two agree (to the rounding used), confirming the identity for this integral.', s=fm(S4v))]
P(SF, r"For $\displaystyle\int_1^2\dfrac{1}{x}\,dx$, compute $T_2$ and $M_2$, then use $S_{2n}=\dfrac{2M_n+T_n}{3}$ to obtain $S_4$. Compare with the value of $S_4$ computed directly in Problem 8.", st, T(r'$T_2\approx@t@$, $M_2\approx@m@$, so $S_4=\dfrac{2M_2+T_2}{3}\approx@c@$, equal to the direct value.', t=fm(vT, 6), m=fm(vM, 6), c=fm(comb, 6)), 12)

# P25 source 10
reg('P25', 'plain', expr='2/(12*100)', val=1 / 600)
reg('P25', 'plain', expr='2/(12*400)', val=1 / 2400)
reg('P25', 'plain', expr='24/(180*4**4)', val=1 / 1920)
reg('P25', 'plain', expr='24/(180*8**4)', val=1 / 30720)
st = [r'Write the bounds with their $n$-dependence: $$B_T(n)=\dfrac{K(b-a)^3}{12n^2},\qquad B_S(n)=\dfrac{M(b-a)^5}{180n^4}.$$ ($B_M(n)=\dfrac{K(b-a)^3}{24n^2}$ behaves like $B_T$.)',
 r'Replace $n$ by $2n$ in the Trapezoidal bound: $$B_T(2n)=\dfrac{K(b-a)^3}{12(2n)^2}=\dfrac{K(b-a)^3}{12\cdot4n^2}=\dfrac{1}{4}\cdot\dfrac{K(b-a)^3}{12n^2}=\dfrac{1}{4}B_T(n).$$ Since $(2n)^2=4n^2$, the bound is divided by $4$.',
 r'Replace $n$ by $2n$ in the Simpson bound: $$B_S(2n)=\dfrac{M(b-a)^5}{180(2n)^4}=\dfrac{M(b-a)^5}{180\cdot16n^4}=\dfrac{1}{16}\cdot\dfrac{M(b-a)^5}{180n^4}=\dfrac{1}{16}B_S(n).$$ Since $(2n)^4=16n^4$, the bound is divided by $16$.',
 T(r'Numerical illustration for $\displaystyle\int_1^2\dfrac{dx}{x}$ (with $K=2$ and $M=24$ from Example 4 and Problem 16): $$B_T(10)=\dfrac{2}{12\cdot100}=\dfrac{1}{600}=@a@,\quad B_T(20)=\dfrac{2}{12\cdot400}=\dfrac{1}{2400}=@b@,\quad \dfrac{B_T(10)}{B_T(20)}=4,$$ $$B_S(4)=\dfrac{24}{180\cdot256}=\dfrac{1}{1920}=@c@,\quad B_S(8)=\dfrac{24}{180\cdot4096}=\dfrac{1}{30720}=@d@,\quad \dfrac{B_S(4)}{B_S(8)}=16.$$', a=fm(1 / 600, 4), b=fm(1 / 2400, 4), c=fm(1 / 1920, 4), d=fm(1 / 30720, 4)),
 r'Consequence: to gain one more decimal digit of accuracy (error divided by $10$), the Trapezoidal Rule needs $n$ multiplied by $\sqrt{10}\approx3.16$, whereas Simpson’s Rule needs $n$ multiplied only by $10^{1/4}\approx1.78$. This is why Simpson’s Rule reaches high accuracy with far fewer function evaluations.']
P(SF, r'Explain, using the error-bound formulas, why doubling $n$ reduces the Trapezoidal error bound by a factor of $4$ but reduces the Simpson error bound by a factor of $16$.', st, r'$B_T(2n)=\dfrac{1}{4}B_T(n)$ because $(2n)^2=4n^2$; $B_S(2n)=\dfrac{1}{16}B_S(n)$ because $(2n)^4=16n^4$.', 10)

# P26 rates of convergence
Ir = math.log(2)
tT2, vT2 = compact('T', inv, 1, 2, 2, nm='T_2')
tT4, vT4 = compact('T', inv, 1, 2, 4, nm='T_4')
tS2, vS2 = compact('S', inv, 1, 2, 2, nm='S_2')
tS4, vS4 = compact('S', inv, 1, 2, 4, nm='S_4')
for R_, n_, vv in (('T', 2, vT2), ('T', 4, vT4), ('S', 2, vS2), ('S', 4, vS4)):
    reg('P26', 'rule', R=R_, f='1/x', a=1, b=2, n=n_, val=vv)
eT2, eT4, eS2, eS4 = [abs(calc(R_, lambda x: 1 / x, 1, 2, n_) - Ir) for R_, n_ in (('T', 2), ('T', 4), ('S', 2), ('S', 4))]
S8v = calc('S', lambda x: 1 / x, 1, 2, 8); eS8 = abs(S8v - Ir)
reg('P26', 'plain', expr='abs(S8-np.log(2))', val=eS8, S8=S8v)
st = [r'Exact value: $\displaystyle\int_1^2\dfrac{dx}{x}=\ln2=0.693147$.',
 r'**Trapezoidal Rule, $n=2$:** ' + tT2, r'**Trapezoidal Rule, $n=4$:** ' + tT4,
 T(r'Errors and ratio: $$|I-T_2|=@a@,\qquad|I-T_4|=@b@,\qquad\dfrac{|I-T_2|}{|I-T_4|}=\dfrac{@a@}{@b@}=@r@.$$ Doubling $n$ cut the error by a factor of about $4$, as the $n^{-2}$ behaviour predicts.', a=fm(eT2, 4), b=fm(eT4, 4), r=fm(eT2 / eT4, 3)),
 r"**Simpson’s Rule, $n=2$:** " + tS2, r"**Simpson’s Rule, $n=4$:** " + tS4,
 T(r'Errors and ratio: $$|I-S_2|=@a@,\qquad|I-S_4|=@b@,\qquad\dfrac{|I-S_2|}{|I-S_4|}=\dfrac{@a@}{@b@}=@r@.$$ The error fell by a factor of about $@r2@$. The bound predicts a factor of $16$ in the worst case; at such small $n$ the observed factor is still below $16$, and it approaches $16$ as $n$ grows (a further computer check gives $|I-S_8|=@c@$, so $|I-S_4|/|I-S_8|\approx@r3@$).', a=fm(eS2, 4), b=fm(eS4, 4), r=fm(eS2 / eS4, 3), r2=fm(eS2 / eS4, 2), c=fm(eS8, 3), r3=fm(eS4 / eS8, 3)),
 T(r'Comparison: with the same data ($n=4$, five function values) Simpson’s error $@b@$ is about $@x@$ times smaller than the Trapezoidal error $@t@$.', b=fm(eS4, 3), t=fm(eT4, 3), x=fm(eT4 / eS4, 2))]
P(SF, r"For $\displaystyle\int_1^2\dfrac{dx}{x}$, compute $T_2$, $T_4$, $S_2$, $S_4$, the actual error of each against $\ln2$, and the ratios $\dfrac{|I-T_2|}{|I-T_4|}$ and $\dfrac{|I-S_2|}{|I-S_4|}$. Compare them with the factors $4$ and $16$ predicted by the error bounds.",
  st, T(r'Error ratios $\approx@r1@$ (Trapezoidal) and $\approx@r2@$ (Simpson), compared with the predicted factors $4$ and $16$.', r1=fm(eT2 / eT4, 3), r2=fm(eS2 / eS4, 3)), 14)

# P27 pi
pf = Fn(lambda x: 4 / (1 + x * x), lambda xl: r'\dfrac{4}{1+(%s)^2}' % xl)
stT, vT = rule('T', pf, 0, 1, 4); stM, vM = rule('M', pf, 0, 1, 4); stS, vS = rule('S', pf, 0, 1, 4)
for R_, vv in (('T', vT), ('M', vM), ('S', vS)):
    reg('P27', 'rule', R=R_, f='4/(1+x**2)', a=0, b=1, n=4, val=vv)
reg('P27', 'exact', f='4/(1+x**2)', a=0, b=1, val=math.pi)
reg('P27', 'claim', R='T', f='4/(1+x**2)', a=0, b=1, n=4, sign='under')
reg('P27', 'claim', R='M', f='4/(1+x**2)', a=0, b=1, n=4, sign='over')
reg('P27', 'claim', R='S', f='4/(1+x**2)', a=0, b=1, n=4, sign='under')
st = [r'Exact value: $\displaystyle\int_0^1\dfrac{4}{1+x^2}\,dx=4\Big[\arctan x\Big]_0^1=4\left(\dfrac{\pi}{4}-0\right)=\pi\approx3.141593$.', r'**Trapezoidal Rule $T_4$.**'] + stT + [r'**Midpoint Rule $M_4$.**'] + stM + [r"**Simpson’s Rule $S_4$.**"] + stS + [
 T(r'Errors (computed from unrounded function values, so they may differ slightly from the differences of the rounded results above): $$T_4-\pi=@a@,\qquad M_4-\pi=+@b@,\qquad S_4-\pi=@c@.$$', a=fm(calc('T', lambda x: 4/(1+x*x), 0, 1, 4) - math.pi, 4), b=fm(calc('M', lambda x: 4/(1+x*x), 0, 1, 4) - math.pi, 4), c=fm(calc('S', lambda x: 4/(1+x*x), 0, 1, 4) - math.pi, 3)),
 T(r'Ranking by absolute error: $S_4$ ($@c2@$) $<M_4$ ($@b2@$) $<T_4$ ($@a2@$). Simpson’s value $@s@$ agrees with $\pi$ to $3$ decimal places ($3.1416$ when rounded to $4$ places) using only five function values. Also $|{\pi-T_4}|\approx2|{M_4-\pi}|$ ($@a2@\approx2\times@b2@$).', a2=fm(abs(calc('T', lambda x: 4/(1+x*x), 0, 1, 4) - math.pi), 3), b2=fm(abs(calc('M', lambda x: 4/(1+x*x), 0, 1, 4) - math.pi), 3), c2=fm(abs(calc('S', lambda x: 4/(1+x*x), 0, 1, 4) - math.pi), 2), s=fm(vS, 6))]
P(SF, r'The integral $\displaystyle\int_0^1\dfrac{4}{1+x^2}\,dx$ equals $\pi$. Approximate it using $T_4$, $M_4$ and $S_4$, compute the actual error of each, and rank the three rules from most to least accurate.', st,
  T(r'$T_4\approx@t@$, $M_4\approx@m@$, $S_4\approx@s@$ against $\pi\approx3.141593$; ranking $S_4$, $M_4$, $T_4$.', t=fm(vT, 6), m=fm(vM, 6), s=fm(vS, 6)), 16)

# P28 ordering L, T, I, M, R
Iord = 3 * math.log(3) - 2
xs_ = [1, 1.5, 2, 2.5, 3]
fl = [math.log(x) for x in xs_]
Lv = 0.5 * sum(sf(v) for v in fl[:4]); Rv = 0.5 * sum(sf(v) for v in fl[1:])
tTc, vTc = compact('T', ln, 1, 3, 4, nm='T_4')
tMc, vMc = compact('M', ln, 1, 3, 4, nm='M_4')
reg('P28', 'order', f='np.log(x)', a=1, b=3, n=4, vals=dict(L=Lv, T=vTc, I=Iord, M=vMc, R=Rv))
st = [r'Recall the endpoint sums for $\Delta x=\dfrac{b-a}{n}$: $L_n=\Delta x\big[f(x_0)+f(x_1)+\cdots+f(x_{n-1})\big]$ (left endpoints) and $R_n=\Delta x\big[f(x_1)+\cdots+f(x_n)\big]$ (right endpoints). Adding them, the interior points appear twice and the end points once, so $T_n=\dfrac{L_n+R_n}{2}$.',
 r'Order from the properties of $f(x)=\ln x$ on $[1,3]$: $f^{\prime}(x)=\dfrac{1}{x}>0$, so $f$ is **increasing**; therefore on each subinterval the left-endpoint height is the smallest and the right-endpoint height the largest, giving $L_n<I<R_n$ and $L_n<T_n<R_n$ (the average of two numbers lies between them). Also each midpoint height is less than the right-endpoint height, so $M_n<R_n$. And $f^{\prime\prime}(x)=-\dfrac{1}{x^2}<0$, so $f$ is **concave down**, giving $T_n<I<M_n$.',
 r'Combine: $L_n<T_n<I<M_n<R_n$. Now confirm numerically with $n=4$ ($\Delta x=0.5$, nodes $1,1.5,2,2.5,3$): $\ln1=0$, $\ln1.5=0.405465$, $\ln2=0.693147$, $\ln2.5=0.916291$, $\ln3=1.098612$.',
 T(r'Left sum: $L_4=0.5\,[0+0.405465+0.693147+0.916291]=0.5\times2.014903=@L@$. Right sum: $R_4=0.5\,[0.405465+0.693147+0.916291+1.098612]=0.5\times3.113515=@R@$.', L=fm(Lv), R=fm(Rv)),
 r'Trapezoidal Rule: ' + tTc, r'Midpoint Rule: ' + tMc,
 T(r'Exact value: $\displaystyle\int_1^3\ln x\,dx=\Big[x\ln x-x\Big]_1^3=(3\ln3-3)-(0-1)=3\ln3-2=@I@$.', I=fm(Iord)),
 T(r'Ordering: $$L_4=@L@<T_4=@T@<I=@I@<M_4=@M@<R_4=@R@.$$ (Also $T_4=\dfrac{L_4+R_4}{2}=\dfrac{@L@+@R@}{2}=@T@$.)', L=fm(Lv), T=fm(vTc), I=fm(Iord), M=fm(vMc), R=fm(Rv))]
P(SF, r'Let $f(x)=\ln x$ on $[1,3]$ with $n=4$. Without computing, put $L_4$, $R_4$, $T_4$, $M_4$ and the exact integral $I$ in increasing order, justifying each inequality from the monotonicity and concavity of $f$; then confirm numerically. ($L_4$ and $R_4$ are the left- and right-endpoint Riemann sums.)',
  st, T(r'$L_4<T_4<I<M_4<R_4$, i.e. $@L@<@T@<@I@<@M@<@R@$.', L=fm(Lv, 5), T=fm(vTc, 5), I=fm(Iord, 5), M=fm(vMc, 5), R=fm(Rv, 5)), 14)

# ============================================================ G error diagnosis
# P29 weights
bad = (0.5 / 3) * (0 + 2 * 0.25 + 4 * 1 + 2 * 2.25 + 4)
reg('P29', 'plain', expr='(0.5/3)*(0+2*0.25+4*1+2*2.25+4)', val=bad)
st = [r'Recall the Simpson weights for $n=4$: the end points get $1$ and the interior points alternate $4,2,4$, so the bracket is $f(x_0)+4f(x_1)+2f(x_2)+4f(x_3)+f(x_4)$. The student used $2,4,2$ instead.',
 r'Check the student’s arithmetic: $f(0)=0$, $f(0.5)=0.25$, $f(1)=1$, $f(1.5)=2.25$, $f(2)=4$. Student’s bracket: $0+2(0.25)+4(1)+2(2.25)+4=0+0.5+4+4.5+4=13$, and $\dfrac{0.5}{3}\times13=\dfrac{13}{6}=2.1667$.',
 r'Correct bracket: $f(0)+4f(0.5)+2f(1)+4f(1.5)+f(2)=0+4(0.25)+2(1)+4(2.25)+4=0+1+2+9+4=16$.',
 r'Correct value: $S_4=\dfrac{0.5}{3}\times16=\dfrac{8}{3}=2.6667$.',
 r'Check against the exact value: $\displaystyle\int_0^2x^2\,dx=\dfrac{8}{3}$. The correct $S_4$ equals it, as expected because Simpson’s Rule is exact for $x^2$ (degree $\leq3$). The student’s conclusion that the rule “is broken” is wrong: the rule was applied with the wrong weights, and $2.1667$ is far from $\dfrac{8}{3}$ ($-0.5$ error).']
P(SG, r'A student approximates $\displaystyle\int_0^2x^2\,dx$ with $S_4$ and writes $$S_4=\dfrac{0.5}{3}\big[f(0)+2f(0.5)+4f(1)+2f(1.5)+f(2)\big]=\dfrac{13}{6}\approx2.167.$$ The student says that since Simpson’s Rule is exact for polynomials of degree at most $3$, the rule must be wrong for this problem. Find the error and give the correct result.',
  st, r'Wrong weights ($2,4,2$ instead of $4,2,4$); correct $S_4=\dfrac{8}{3}$, exact.', 8)

# P30 midpoint constant
reg('P30', 'nmin', R='M', K=math.e, a=0, b=1, tol=1e-3, even=False, val=11)
st = [r'The student used the denominator $12$ in $\dfrac{K(b-a)^3}{12n^2}$, which is the **Trapezoidal** bound. The Midpoint bound is $E_M\leq\dfrac{K(b-a)^3}{24n^2}$.',
 r'Redo the calculation with $f(x)=e^x$, $K=e\approx2.718282$ (since $f^{\prime\prime}(x)=e^x$ is increasing, its maximum on $[0,1]$ is at $x=1$): $$\dfrac{2.718282\cdot1^3}{24n^2}<0.001.$$',
 r'Solve: $$n^2>\dfrac{2.718282}{24\times0.001}=\dfrac{2.718282}{0.024}=113.262\ \Longrightarrow\ n>\sqrt{113.262}\approx10.64.$$',
 r'The smallest integer greater than $10.64$ is $n=11$. Verify: $n=11$: $\dfrac{2.718282}{24\cdot121}=\dfrac{2.718282}{2904}=9.360\times10^{-4}<0.001$ (holds); $n=10$: $\dfrac{2.718282}{24\cdot100}=1.1326\times10^{-3}>0.001$ (fails).',
 r'Assessment of the student’s answer: $n=16$ does guarantee the accuracy (its bound with the correct constant is $\dfrac{2.718282}{24\cdot256}=4.42\times10^{-4}<0.001$), but it is not the smallest $n$; the question asks how large $n$ must be, and the correct minimum is $n=11$ (the student’s calculation actually finds the minimum for the Trapezoidal Rule).']
P(SG, r'To make the Midpoint Rule $M_n$ approximate $\displaystyle\int_0^1e^x\,dx$ with error less than $0.001$, a student writes $$\dfrac{e\cdot1^3}{12n^2}<0.001\ \Longrightarrow\ n^2>226.5\ \Longrightarrow\ n=16.$$ Find the error and give the correct smallest $n$.',
  st, r'The student used the Trapezoidal constant $12$; with $24$ the smallest $n$ is $11$.', 9)

# P31 trapezoid always over
tT, vT = compact('T', sn, 0, math.pi, 4, nm='T_4', lab=L4)
reg('P31', 'rule', R='T', f='np.sin(x)', a=0, b='np.pi', n=4, val=vT)
reg('P31', 'claim', R='T', f='np.sin(x)', a=0, b='np.pi', n=4, sign='under')
st = [r'The claim is false; the direction of the Trapezoidal error depends on concavity, not on the sign of $f$. A single counterexample suffices. Take $f(x)=\sin x\geq0$ on $[0,\pi]$.',
 r'Compute $T_4$ ($\Delta x=\dfrac{\pi}{4}$): ' + tT,
 T(r'The exact value is $\displaystyle\int_0^\pi\sin x\,dx=\Big[-\cos x\Big]_0^\pi=2$. Since $T_4=@t@<2$, the Trapezoidal Rule **underestimates** here even though $f\geq0$.', t=fm(vT, 6)),
 r'Explanation: $f^{\prime\prime}(x)=-\sin x\leq0$ on $[0,\pi]$, so $f$ is concave down and every chord lies below the graph. Correct statement: $T_n$ overestimates when $f^{\prime\prime}>0$ (concave up) and underestimates when $f^{\prime\prime}<0$ (concave down).',
 r'Contrast: $f(x)=x^2$ on $[0,2]$ (Example 1) has $f^{\prime\prime}=2>0$ (concave up), which is why $T_4=2.75$ overestimated there.']
P(SG, r'A student claims: “For a positive function, the Trapezoidal Rule always overestimates the integral, because the trapezoids stick out above the curve.” Find the error by computing $T_4$ for $\displaystyle\int_0^\pi\sin x\,dx$, and state the correct rule.',
  st, T(r'False: $T_4\approx@t@<2$ for $\sin x$ on $[0,\pi]$; the sign of the error is determined by the concavity ($f^{\prime\prime}$).', t=fm(vT, 5)), 10)
