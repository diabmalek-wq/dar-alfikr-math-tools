import math
from lib import *

PR = []
def P(sec, stmt, steps, ans, lines=8):
    PR.append(dict(sec=sec, stmt=stmt, steps=steps, ans=ans, lines=lines))

SA = 'Midpoint and Trapezoidal Rules'
SB = "Simpson’s Rule"
SC = 'Numerical integration from tables of data'
SD = 'Error bounds'
SE = 'Choosing $n$ for a required accuracy'
SF = 'Concavity, comparison of the rules and exact values'
SG = 'Error diagnosis'

sq = Fn(lambda x: x * x, lambda xl: r'(%s)^2' % xl)
sqrt = Fn(math.sqrt, lambda xl: r'\sqrt{%s}' % xl)
inv = Fn(lambda x: 1 / x, lambda xl: r'\dfrac{1}{%s}' % xl)
ex_ = Fn(math.exp, lambda xl: r'e^{%s}' % xl)
ln = Fn(math.log, lambda xl: r'\ln %s' % xl)

# ============================================================ A
# P1  (source 1)
I1 = 16 / 3
st, v1 = rule('T', sqrt, 0, 4, 4, override=[0, 1, 1.414, 1.732, 2])
reg('P1', 'rule', R='T', f='np.sqrt(x)', a=0, b=4, n=4, val=v1, tol=2e-3)
reg('P1', 'claim', R='T', f='np.sqrt(x)', a=0, b=4, n=4, sign='under')
reg('P1', 'exact', f='np.sqrt(x)', a=0, b=4, val=I1)
st = [r'Setup: $f(x)=\sqrt x$ on $[0,4]$ with $n=4$; the given approximations $\sqrt0=0$, $\sqrt1=1$, $\sqrt2\approx1.414$, $\sqrt3\approx1.732$, $\sqrt4=2$ are used for the function values.'] + st + [
 r'Exact value for comparison: $\displaystyle\int_0^4\sqrt x\,dx=\Big[\dfrac{2}{3}x^{3/2}\Big]_0^4=\dfrac{2}{3}\cdot8=\dfrac{16}{3}\approx5.333333$.',
 errline('T_4', v1, I1),
 r'This matches the concavity: $f^{\prime\prime}(x)=-\dfrac{1}{4}x^{-3/2}<0$ for $x>0$, so the graph is concave down, the chords lie below the graph, and $T_4$ underestimates.']
P(SA, r'Approximate $\displaystyle\int_0^4 \sqrt{x}\,dx$ using $T_4$ (grid points $0,1,2,3,4$; use $\sqrt0=0,\ \sqrt1=1,\ \sqrt2\approx1.414,\ \sqrt3\approx1.732,\ \sqrt4=2$).',
  st, r'$T_4\approx5.146$ (an underestimate of the exact value $\dfrac{16}{3}\approx5.333$).', 9)

# P2 (source 2)
st, v2 = rule('M', sqrt, 0, 4, 4, override=[0.707, 1.225, 1.581, 1.871])
reg('P2', 'rule', R='M', f='np.sqrt(x)', a=0, b=4, n=4, val=v2, tol=2e-3)
reg('P2', 'claim', R='M', f='np.sqrt(x)', a=0, b=4, n=4, sign='over')
st = [r'Setup: $f(x)=\sqrt x$ on $[0,4]$ with $n=4$, $\Delta x=1$; the midpoints are $0.5,1.5,2.5,3.5$ and the given approximations $\sqrt{0.5}\approx0.707$, $\sqrt{1.5}\approx1.225$, $\sqrt{2.5}\approx1.581$, $\sqrt{3.5}\approx1.871$ are used.'] + st + [
 errline('M_4', v2, I1),
 r'This matches the concavity: $f$ is concave down ($f^{\prime\prime}(x)=-\dfrac{1}{4}x^{-3/2}<0$), the tangent line at each midpoint lies above the graph, so each midpoint rectangle has more area than the region under the curve and $M_4$ overestimates. (Compare Problem 1: $T_4$ underestimates while $M_4$ overestimates; here $|I-T_4|=0.1873$ and $|I-M_4|=0.0507$.)']
P(SA, r'Approximate the same integral, $\displaystyle\int_0^4\sqrt{x}\,dx$, using $M_4$ (midpoints $0.5,1.5,2.5,3.5$; use $\sqrt{0.5}\approx0.707,\ \sqrt{1.5}\approx1.225,\ \sqrt{2.5}\approx1.581,\ \sqrt{3.5}\approx1.871$).',
  st, r'$M_4\approx5.384$ (an overestimate of $\dfrac{16}{3}\approx5.333$).', 8)

# P3 cos on [0, pi/2]
cs = Fn(math.cos, lambda xl: r'\cos\left(%s\right)' % xl)
L = ['0', r'\dfrac{\pi}{8}', r'\dfrac{\pi}{4}', r'\dfrac{3\pi}{8}', r'\dfrac{\pi}{2}']
ML = [r'\dfrac{\pi}{16}', r'\dfrac{3\pi}{16}', r'\dfrac{5\pi}{16}', r'\dfrac{7\pi}{16}']
stT, vT = rule('T', cs, 0, math.pi / 2, 4, lab=L, btex=r'\dfrac{\pi}{2}', dxtex=r'\dfrac{\pi}{8}', coeftex=r'\dfrac{\pi}{16}')
stM, vM = rule('M', cs, 0, math.pi / 2, 4, lab=L, btex=r'\dfrac{\pi}{2}', dxtex=r'\dfrac{\pi}{8}', midlab=ML)
reg('P3', 'rule', R='T', f='np.cos(x)', a=0, b='np.pi/2', n=4, val=vT)
reg('P3', 'rule', R='M', f='np.cos(x)', a=0, b='np.pi/2', n=4, val=vM)
reg('P3', 'claim', R='T', f='np.cos(x)', a=0, b='np.pi/2', n=4, sign='under')
reg('P3', 'claim', R='M', f='np.cos(x)', a=0, b='np.pi/2', n=4, sign='over')
st = [r'**Trapezoidal Rule $T_4$.**'] + stT + [r'**Midpoint Rule $M_4$.**'] + stM + [
 r'Exact value: $\displaystyle\int_0^{\pi/2}\cos x\,dx=\Big[\sin x\Big]_0^{\pi/2}=\sin\dfrac{\pi}{2}-\sin0=1$.',
 T(r'Errors: $T_4-1=@a@$ (underestimate) and $M_4-1=+@b@$ (overestimate). Reason: $f^{\prime\prime}(x)=-\cos x\leq0$ on $\left[0,\dfrac{\pi}{2}\right]$, so the graph is concave down; trapezoids lie below the curve and midpoint rectangles (tangent-line trapezoids) lie above it.', a=fm(vT - 1, 4), b=fm(vM - 1, 4))]
P(SA, r'Approximate $\displaystyle\int_0^{\pi/2}\cos x\,dx$ using $T_4$ and $M_4$ (so $\Delta x=\dfrac{\pi}{8}$). Compare both with the exact value, and say whether each rule over- or under-estimates and why.',
  st, T(r'$T_4\approx@t@$ (under), $M_4\approx@m@$ (over); exact value $1$.', t=fm(vT, 5), m=fm(vM, 5)), 14)

# P4 e^{-x^2} on [0,1]
gs = Fn(lambda x: math.exp(-x * x), lambda xl: r'e^{-(%s)^2}' % xl)
stT, vT = rule('T', gs, 0, 1, 4); stM, vM = rule('M', gs, 0, 1, 4); stS, vS = rule('S', gs, 0, 1, 4)
Ig = 0.746824
reg('P4', 'rule', R='T', f='np.exp(-x**2)', a=0, b=1, n=4, val=vT)
reg('P4', 'rule', R='M', f='np.exp(-x**2)', a=0, b=1, n=4, val=vM)
reg('P4', 'rule', R='S', f='np.exp(-x**2)', a=0, b=1, n=4, val=vS)
reg('P4', 'exact', f='np.exp(-x**2)', a=0, b=1, val=Ig, tol=1e-6)
st = [r'The antiderivative of $e^{-x^2}$ is not an elementary function, so the integral is approximated; use $f(x)=e^{-x^2}$, $a=0$, $b=1$, $n=4$.', r'**Trapezoidal Rule $T_4$.**'] + stT + [r'**Midpoint Rule $M_4$.**'] + stM + [r"**Simpson’s Rule $S_4$.**"] + stS + [
 T(r'Compare with the computer value $0.746824$ (6 decimal places): $$|0.746824-T_4|=@a@,\qquad |0.746824-M_4|=@b@,\qquad |0.746824-S_4|=@c@.$$', a=fm(abs(Ig - vT), 3), b=fm(abs(Ig - vM), 3), c=fm(abs(Ig - vS), 3)),
 T(r'Ranking from best to worst: $S_4$ (error about $@c@$), then $M_4$ ($@b@$), then $T_4$ ($@a@$). Note $T_4<I<M_4$ here; the concavity argument does not apply because $f^{\prime\prime}(x)=(4x^2-2)e^{-x^2}$ changes sign on $[0,1]$ (at $x=\dfrac{1}{\sqrt2}\approx0.7071$).', a=fm(abs(Ig - vT), 2), b=fm(abs(Ig - vM), 2), c=fm(abs(Ig - vS), 2))]
P(SA, r'The integral $\displaystyle\int_0^1 e^{-x^2}\,dx$ has no elementary antiderivative. Approximate it using $T_4$, $M_4$ and $S_4$, and compare each with the value $0.746824$ obtained by computer.',
  st, T(r'$T_4\approx@t@$, $M_4\approx@m@$, $S_4\approx@s@$; Simpson is the most accurate.', t=fm(vT, 5), m=fm(vM, 5), s=fm(vS, 5)), 16)

# P5 semicircle
sc = Fn(lambda x: math.sqrt(1 - x * x), lambda xl: r'\sqrt{1-(%s)^2}' % xl)
stT, vT = rule('T', sc, -1, 1, 4); stM, vM = rule('M', sc, -1, 1, 4)
reg('P5', 'rule', R='T', f='np.sqrt(1-x**2)', a=-1, b=1, n=4, val=vT)
reg('P5', 'rule', R='M', f='np.sqrt(1-x**2)', a=-1, b=1, n=4, val=vM)
reg('P5', 'claim', R='T', f='np.sqrt(1-x**2)', a=-1, b=1, n=4, sign='under')
reg('P5', 'claim', R='M', f='np.sqrt(1-x**2)', a=-1, b=1, n=4, sign='over')
Ip = math.pi / 2
st = [r'The integral is the area of the upper half of the unit disc, so its exact value is $\dfrac{1}{2}\pi(1)^2=\dfrac{\pi}{2}\approx1.570796$. Use $f(x)=\sqrt{1-x^2}$ on $[-1,1]$, $n=4$.', r'**Trapezoidal Rule $T_4$.**'] + stT + [r'**Midpoint Rule $M_4$.**'] + stM + [
 errline('T_4', vT, Ip), errline('M_4', vM, Ip),
 r'Concavity: $f^{\prime}(x)=-\dfrac{x}{\sqrt{1-x^2}}$ and $f^{\prime\prime}(x)=-\dfrac{1}{(1-x^2)^{3/2}}<0$ on $(-1,1)$, so the graph is concave down: trapezoids underestimate and midpoint rectangles overestimate, as found.',
 r'Error bound: $f^{\prime\prime}(x)=-(1-x^2)^{-3/2}\to-\infty$ as $x\to\pm1$, so no finite $K$ with $|f^{\prime\prime}(x)|\leq K$ on $[-1,1]$ exists. The error-bound theorem therefore cannot be applied, and the errors are larger than the bounds would suggest for a smooth function (for instance $|I-T_4|$ is about $3.5$ times $|I-M_4|$, not $2$ times).']
P(SA, r'Approximate the area of the half-disc $\displaystyle\int_{-1}^{1}\sqrt{1-x^2}\,dx$ using $T_4$ and $M_4$. Compare with the exact area $\dfrac{\pi}{2}$, explain the signs of the errors using $f^{\prime\prime}$, and explain why the error-bound theorem cannot be used for this integral.',
  st, T(r'$T_4\approx@t@$ (under), $M_4\approx@m@$ (over); exact $\dfrac{\pi}{2}\approx1.5708$; $f^{\prime\prime}$ is unbounded near $\pm1$.', t=fm(vT, 5), m=fm(vM, 5)), 16)

# ============================================================ B
# P6 (source 3)
cub = Fn(lambda x: x ** 3 + 1, lambda xl: r'(%s)^3+1' % xl)
st, v = rule('S', cub, 0, 2, 4)
reg('P6', 'rule', R='S', f='x**3+1', a=0, b=2, n=4, val=v)
reg('P6', 'exact', f='x**3+1', a=0, b=2, val=6.0)
st = st + [
 r'Exact value: $\displaystyle\int_0^2(x^3+1)\,dx=\Big[\dfrac{x^4}{4}+x\Big]_0^2=\Big(\dfrac{16}{4}+2\Big)-(0+0)=4+2=6$.',
 r'Comparison: $S_4=6$ equals the exact value $6$, so the error is exactly $0$.',
 r'Why the two must match: Simpson’s Rule integrates every polynomial of degree $\leq3$ exactly, and $f(x)=x^3+1$ has degree $3$. Equivalently, $f^{(4)}(x)=0$ for all $x$ (differentiate: $3x^2$, $6x$, $6$, $0$), so the error bound $\dfrac{M(b-a)^5}{180n^4}$ has $M=0$ and the error is $0$.']
P(SB, r'Approximate $\displaystyle\int_0^2 (x^3+1)\,dx$ using $S_4$ (grid points $0,0.5,1,1.5,2$), and compare to the exact value. Explain why the two must match exactly.',
  st, r'$S_4=6$, equal to the exact value $6$ (Simpson is exact for polynomials of degree $\leq3$).', 9)

# P7 (source 4)
sn = Fn(math.sin, lambda xl: r'\sin\left(%s\right)' % xl)
L4 = ['0', r'\dfrac{\pi}{4}', r'\dfrac{\pi}{2}', r'\dfrac{3\pi}{4}', r'\pi']
st, v = rule('S', sn, 0, math.pi, 4, lab=L4, btex=r'\pi', dxtex=r'\dfrac{\pi}{4}', coeftex=r'\dfrac{\pi}{12}', override=[0, 0.707, 1, 0.707, 0])
reg('P7', 'rule', R='S', f='np.sin(x)', a=0, b='np.pi', n=4, val=v, tol=2e-3)
Bs = math.pi ** 5 / (180 * 256)
reg('P7', 'bound', R='S', f='np.sin(x)', f4='np.sin(x)', a=0, b='np.pi', n=4, K=1.0, val=Bs)
st = [r'Setup: $f(x)=\sin x$ on $[0,\pi]$, $n=4$, with the given values $\sin0=0$, $\sin\dfrac{\pi}{4}\approx0.707$, $\sin\dfrac{\pi}{2}=1$, $\sin\dfrac{3\pi}{4}\approx0.707$, $\sin\pi=0$.'] + st + [
 T(r'Exact value: $\displaystyle\int_0^\pi\sin x\,dx=\Big[-\cos x\Big]_0^\pi=-\cos\pi+\cos0=1+1=2$. So the error is $|2-@v@|=@e@$, i.e. about $@p@\%$ of the exact value.', v=fm(v, 5), e=fm(abs(v - 2), 3), p=fm(abs(v - 2) / 2 * 100, 2)),
 T(r'Why it is close but not exact: $\sin x$ is not a polynomial of degree $\leq3$ ($f^{(4)}(x)=\sin x\neq0$). The bound with $M=1$ is $\dfrac{1\cdot\pi^5}{180\cdot4^4}=@B@$, and the error $@e@$ lies below it.', B=fm(Bs, 4), e=fm(abs(v - 2), 3))]
P(SB, r'Approximate $\displaystyle\int_0^{\pi} \sin x\,dx$ using $S_4$ (grid points $0,\dfrac{\pi}{4},\dfrac{\pi}{2},\dfrac{3\pi}{4},\pi$; use $\sin0=0,\ \sin\dfrac{\pi}{4}\approx0.707,\ \sin\dfrac{\pi}{2}=1,\ \sin\dfrac{3\pi}{4}\approx0.707,\ \sin\pi=0$), and compare to the exact value $2$.',
  st, T(r'$S_4\approx@v@$ against the exact value $2$ (error about $0.004$).', v=fm(v, 4)), 9)

# P8 S4 for 1/x on [1,2]
st, v8 = rule('S', inv, 1, 2, 4)
reg('P8', 'rule', R='S', f='1/x', a=1, b=2, n=4, val=v8)
reg('P8', 'exact', f='1/x', a=1, b=2, val=math.log(2))
st = st + [
 T(r'Exact value: $\displaystyle\int_1^2\dfrac{dx}{x}=\Big[\ln x\Big]_1^2=\ln2-\ln1=\ln2\approx0.693147$.'),
 T(r'Error: $S_4-\ln2=@v@-0.693147=@d@$, so $|\ln2-S_4|=@e@$ (about $@p@\%$ of $\ln 2$), a slight overestimate. Compare with the Trapezoidal Rule in Example 4: even with $n=4$ the Simpson error is far smaller.', v=fm(v8), d=fm(v8 - math.log(2), 3), e=fm(abs(v8 - math.log(2)), 3), p=fm(abs(v8 - math.log(2)) / math.log(2) * 100, 2))]
P(SB, r"Approximate $\displaystyle\int_1^2\dfrac{1}{x}\,dx$ using Simpson’s Rule $S_4$ and compare with the exact value $\ln 2$.",
  st, T(r'$S_4\approx@v@$ against $\ln2\approx0.693147$ (error about $@e@$).', v=fm(v8, 6), e=fm(abs(v8 - math.log(2)), 2)), 9)

# P9 cubic S_2 on [-1,3]
cf = Fn(lambda x: x ** 3 - 2 * x ** 2 + 4 * x - 1, lambda xl: r'(%s)^3-2(%s)^2+4(%s)-1' % (xl, xl, xl))
st, v = rule('S', cf, -1, 3, 2)
reg('P9', 'rule', R='S', f='x**3-2*x**2+4*x-1', a=-1, b=3, n=2, val=v)
reg('P9', 'exact', f='x**3-2*x**2+4*x-1', a=-1, b=3, val=40 / 3)
st = st + [
 r'Exact value, term by term: $$\int_{-1}^{3}(x^3-2x^2+4x-1)\,dx=\Big[\dfrac{x^4}{4}-\dfrac{2x^3}{3}+2x^2-x\Big]_{-1}^{3}.$$',
 r'Upper limit $x=3$: $\dfrac{81}{4}-\dfrac{2\cdot27}{3}+2\cdot9-3=20.25-18+18-3=17.25$. Lower limit $x=-1$: $\dfrac{1}{4}-\dfrac{2(-1)}{3}+2(1)-(-1)=0.25+0.666667+2+1=3.916667$. Subtract: $17.25-3.916667=13.333333=\dfrac{40}{3}$.',
 r'Comparison: $S_2=\dfrac{40}{3}$ equals the exact value, with only $n=2$ subintervals (three function values). Reason: $f$ is a cubic, $f^{(4)}(x)=0$, so the Simpson error bound is $0$ for every even $n$.']
P(SB, r"Use Simpson’s Rule with $n=2$ to approximate $\displaystyle\int_{-1}^{3}\left(x^3-2x^2+4x-1\right)dx$. Compute the exact value and explain the result.",
  st, r'$S_2=\dfrac{40}{3}\approx13.3333$, exactly equal to the integral.', 10)

# P10 x^4 S2, S4
q4 = Fn(lambda x: x ** 4, lambda xl: r'(%s)^4' % xl)
stA, v2_ = rule('S', q4, 0, 2, 2); stB, v4_ = rule('S', q4, 0, 2, 4)
reg('P10', 'rule', R='S', f='x**4', a=0, b=2, n=2, val=v2_)
reg('P10', 'rule', R='S', f='x**4', a=0, b=2, n=4, val=v4_)
reg('P10', 'exact', f='x**4', a=0, b=2, val=32 / 5)
reg('P10', 'bound', R='S', f='x**4', f4='24+0*x', a=0, b=2, n=2, K=24.0, val=24 * 32 / (180 * 16))
reg('P10', 'bound', R='S', f='x**4', f4='24+0*x', a=0, b=2, n=4, K=24.0, val=24 * 32 / (180 * 256))
st = [r'Exact value: $\displaystyle\int_0^2x^4\,dx=\Big[\dfrac{x^5}{5}\Big]_0^2=\dfrac{32}{5}=6.4$.', r'**(a) Simpson with $n=2$.**'] + stA + [
 T(r'Error: $S_2-\dfrac{32}{5}=\dfrac{20}{3}-\dfrac{32}{5}=\dfrac{100-96}{15}=\dfrac{4}{15}=@e@$. The rule is **not** exact here because $x^4$ has degree $4>3$.', e=fm(4 / 15)),
 r'Error bound: $f^{(4)}(x)=24$ is constant, so $M=24$ and $$E_S\leq\dfrac{24\cdot2^5}{180\cdot2^4}=\dfrac{768}{2880}=\dfrac{4}{15}=0.266667.$$ The actual error **equals** the bound, so the bound cannot be improved in general.',
 r'**(b) Simpson with $n=4$.**'] + stB + [
 T(r'Error: $S_4-6.4=@a@-6.4=@e@$ (as a fraction, $\dfrac{1}{60}$). The bound is $\dfrac{24\cdot2^5}{180\cdot4^4}=\dfrac{768}{46080}=\dfrac{1}{60}=0.016667$, again equal to the actual error.', a=fm(v4_), e=fm(v4_ - 6.4, 4)),
 T(r'Ratio of the errors: $\dfrac{4/15}{1/60}=\dfrac{4\cdot60}{15}=16$, exactly the factor $2^4=16$ predicted by the $n^4$ in the denominator when $n$ doubles from $2$ to $4$.')]
P(SB, r"Let $f(x)=x^4$ on $[0,2]$. (a) Compute $S_2$ and its exact error. (b) Compute $S_4$ and its exact error. (c) Compare each error with the Simpson error bound and find the ratio of the two errors.",
  st, r'$S_2=\dfrac{20}{3}$ (error $\dfrac{4}{15}$), $S_4=\dfrac{77}{12}$ (error $\dfrac{1}{60}$); both errors equal their bounds, and the ratio is $16$.', 16)
