import math
from lib import *
from pr1 import *   # PR, P, section names, function objects

# ============================================================ C tables
tv = {0.0: 0, 2.0: 6.6, 4.0: 11.0, 6.0: 14.0, 8.0: 16.0, 10.0: 17.3, 12.0: 18.2}
fv_ = data_fn(tv, 'v')
V = [0, 6.6, 11.0, 14.0, 16.0, 17.3, 18.2]
stT, vt = rule('T', fv_, 0, 12, 6, override=V)
stS, vs = rule('S', fv_, 0, 12, 6, override=V)
stM, vm = rule('M', fv_, 0, 12, 3, override=[6.6, 14.0, 17.3], nm='M_{3}')
reg('P11', 'data', R='T', y=V, h=2, val=vt)
reg('P11', 'data', R='S', y=V, h=2, val=vs)
reg('P11', 'data', R='M', y=[6.6, 14.0, 17.3], h=4, val=vm)
model = lambda t: 20 * (1 - math.exp(-t / 5))
Imod = 20 * (12 - 5 * (1 - math.exp(-12 / 5)))
reg('P11', 'claimdata', model='20*(1-np.exp(-x/5))', T=vt, M=vm, S=vs, a=0, b=12)
st = ([r'The distance travelled is $s=\displaystyle\int_0^{12}v(t)\,dt$ (metres, with $t$ in seconds and $v$ in metres per second). The speeds are given at $t=0,2,\ldots,12$, spacing $2$ s, so $n=6$ subintervals.', r'**(a) Trapezoidal Rule $T_6$.**'] + stT +
      [r'**(b) Simpson’s Rule $S_6$** ($n=6$ is even).'] + stS +
      [r'**(c) Midpoint Rule.** Use subintervals of width $4$ ($n=3$: $[0,4],[4,8],[8,12]$), whose midpoints $2,6,10$ are in the table.'] + stM +
      [r'Concavity of the data: the successive increases of $v$ are $6.6,\ 4.4,\ 3.0,\ 2.0,\ 1.3,\ 0.9$, which are decreasing, so the graph of $v$ is concave down. For a concave-down function $T_n$ underestimates and $M_n$ overestimates, so the distance should lie between $T_6$ and $M_3$.',
       T(r'Summary: $T_6=@t@$ m, $S_6=@s@$ m, $M_3=@m@$ m, consistent with $T_6<S_6<M_3$; the best single estimate is $S_6\approx@s@$ m.', t=fm(vt, 6), s=fm(vs, 6), m=fm(vm, 6))])
P(SC, r'A car accelerates from rest and its speed $v(t)$ (m/s) is measured every $2$ seconds: \begin{center}\renewcommand{\arraystretch}{1.35}\setlength{\tabcolsep}{7pt}\begin{tabular}{|c|c|c|c|c|c|c|c|}\hline $t$ (s) & $0$ & $2$ & $4$ & $6$ & $8$ & $10$ & $12$ \\ \hline $v(t)$ & $0$ & $6.6$ & $11.0$ & $14.0$ & $16.0$ & $17.3$ & $18.2$ \\ \hline\end{tabular}\end{center} Estimate the distance travelled in the first $12$ seconds, $\displaystyle\int_0^{12}v(t)\,dt$, using (a) $T_6$, (b) $S_6$, (c) $M_3$ (with $n=3$ subintervals of width $4$ s).',
  st, T(r'$T_6=@t@$ m, $S_6=@s@$ m, $M_3=@m@$ m.', t=fm(vt, 6), s=fm(vs, 6), m=fm(vm, 6)), 16)

td = {0.0: 0, 10.0: 2.1, 20.0: 3.4, 30.0: 4.2, 40.0: 4.6, 50.0: 4.1, 60.0: 3.3, 70.0: 1.8, 80.0: 0}
fd_ = data_fn(td, 'd')
D = [0, 2.1, 3.4, 4.2, 4.6, 4.1, 3.3, 1.8, 0]
stT, vt = rule('T', fd_, 0, 80, 8, override=D)
stS, vs = rule('S', fd_, 0, 80, 8, override=D)
stM, vm = rule('M', fd_, 0, 80, 4, override=[2.1, 4.2, 4.1, 1.8], nm='M_{4}')
reg('P12', 'data', R='T', y=D, h=10, val=vt)
reg('P12', 'data', R='S', y=D, h=10, val=vs)
reg('P12', 'data', R='M', y=[2.1, 4.2, 4.1, 1.8], h=20, val=vm)
Q = vs * 0.8
reg('P12', 'plain', expr='S8*0.8', val=Q, S8=vs)
st = ([r'The cross-sectional area is $A=\displaystyle\int_0^{80}d(x)\,dx$ (square metres), with the depth $d$ measured every $10$ m, so $n=8$ subintervals of width $10$.', r'**(a) Trapezoidal Rule $T_8$.**'] + stT +
      [r'**(b) Simpson’s Rule $S_8$** ($n=8$ is even).'] + stS +
      [r'**(c) Midpoint Rule.** Use subintervals of width $20$ ($n=4$), whose midpoints $10,30,50,70$ are in the table.'] + stM +
      [T(r'**(d) Discharge.** Take $S_8$ as the best estimate of the area, $A\approx@s@\ \text{m}^2$. Discharge $=$ area $\times$ speed $=@s@\times0.8=@q@\ \text{m}^3/\text{s}$.', s=fm(vs, 6), q=fm(Q, 6))])
P(SC, r'The depth $d(x)$ (metres) of a river was measured every $10$ m across its width: \begin{center}\renewcommand{\arraystretch}{1.35}\setlength{\tabcolsep}{7pt}\begin{tabular}{|c|c|c|c|c|c|c|c|c|c|}\hline $x$ (m) & $0$ & $10$ & $20$ & $30$ & $40$ & $50$ & $60$ & $70$ & $80$ \\ \hline $d(x)$ & $0$ & $2.1$ & $3.4$ & $4.2$ & $4.6$ & $4.1$ & $3.3$ & $1.8$ & $0$ \\ \hline\end{tabular}\end{center} Using the table: (a) estimate the cross-sectional area $\displaystyle\int_0^{80}d(x)\,dx$ using $T_8$; (b) estimate it using $S_8$; (c) estimate it using $M_4$ (subintervals of width $20$ m); (d) if the water flows at an average speed of $0.8$ m/s, estimate the discharge (area $\times$ speed) using your Simpson area.',
  st, T(r'$T_8=@t@$ m$^2$, $S_8=@s@$ m$^2$, $M_4=@m@$ m$^2$; discharge $\approx@q@$ m$^3$/s.', t=fm(vt, 6), s=fm(vs, 6), m=fm(vm, 6), q=fm(Q, 5)), 18)

# ============================================================ D error bounds
# P13 source 5
Kb = math.e
Tb = 2.718 / 768
a_T8 = calc('T', math.exp, 0, 1, 8)
reg('P13', 'bound', R='T', f='np.exp(x)', f2='np.exp(x)', a=0, b=1, n=8, K=math.e, val=math.e / 768, tol=2e-3)
reg('P13', 'rule', R='T', f='np.exp(x)', a=0, b=1, n=8, val=a_T8)
st = [r'Identify: $f(x)=e^x$, $a=0$, $b=1$, $n=8$, and $E_T\leq\dfrac{K(b-a)^3}{12n^2}$ with $|f^{\prime\prime}(x)|\leq K$ on $[0,1]$.',
 r'Differentiate: $f^{\prime}(x)=e^x$ and $f^{\prime\prime}(x)=e^x$.',
 r'Maximise $|f^{\prime\prime}|$ on $[0,1]$: $e^x>0$, so $|f^{\prime\prime}(x)|=e^x$. The exponential is increasing, so the maximum is at the right endpoint: $$K=f^{\prime\prime}(1)=e\approx2.718.$$',
 r'Substitute $K=2.718$, $b-a=1$, $n=8$: $$E_T\leq\dfrac{2.718\cdot1^3}{12\cdot8^2}=\dfrac{2.718}{12\cdot64}=\dfrac{2.718}{768}.$$',
 T(r'Divide: $\dfrac{2.718}{768}=@b@$. So $\left|\displaystyle\int_0^1e^x\,dx-T_8\right|\leq0.00354$.', b=fm(Tb, 4)),
 T(r'Reference check: $T_8=@t@$ and $e-1=1.718282$, so the actual error is $@e@\leq0.00354$ (the bound holds).', t=fm(a_T8), e=fm(abs(a_T8 - (math.e - 1)), 3))]
P(SD, r'Find a bound on the error in approximating $\displaystyle\int_0^1 e^{x}\,dx$ using $T_8$.', st, r'$E_T\leq\dfrac{e}{12\cdot64}\approx0.00354$.', 8)

# P14 source 6
a_M6 = calc('M', math.log, 1, 3, 6)
Iln = 3 * math.log(3) - 2
reg('P14', 'bound', R='M', f='np.log(x)', f2='-1/x**2', a=1, b=3, n=6, K=1.0, val=8 / 864)
reg('P14', 'rule', R='M', f='np.log(x)', a=1, b=3, n=6, val=a_M6)
reg('P14', 'exact', f='np.log(x)', a=1, b=3, val=Iln)
st = [r'Identify: $f(x)=\ln x$, $a=1$, $b=3$, $n=6$, and $E_M\leq\dfrac{K(b-a)^3}{24n^2}$ with $|f^{\prime\prime}(x)|\leq K$ on $[1,3]$.',
 r'Differentiate: $f^{\prime}(x)=\dfrac{1}{x}$ and $f^{\prime\prime}(x)=-\dfrac{1}{x^2}$.',
 r'Maximise $|f^{\prime\prime}|$ on $[1,3]$: $|f^{\prime\prime}(x)|=\dfrac{1}{x^2}$, which is decreasing for $x>0$ (its derivative is $-\dfrac{2}{x^3}<0$). The maximum is at $x=1$: $$K=\left|-\dfrac{1}{1^2}\right|=1.$$',
 r'Substitute $K=1$, $b-a=3-1=2$, $n=6$: $$E_M\leq\dfrac{1\cdot2^3}{24\cdot6^2}=\dfrac{8}{24\cdot36}=\dfrac{8}{864}.$$',
 T(r'Simplify: $\dfrac{8}{864}=\dfrac{1}{108}=@b@$. So $\left|\displaystyle\int_1^3\ln x\,dx-M_6\right|\leq0.00926$.', b=fm(8 / 864, 4)),
 T(r'Reference check: $\displaystyle\int_1^3\ln x\,dx=\Big[x\ln x-x\Big]_1^3=3\ln3-2=@I@$ and $M_6=@m@$, so the actual error is $@e@\leq0.00926$.', I=fm(Iln), m=fm(a_M6), e=fm(abs(a_M6 - Iln), 3))]
P(SD, r'Find a bound on the error in approximating $\displaystyle\int_1^3 \ln x\,dx$ using $M_6$.', st, r'$E_M\leq\dfrac{1}{108}\approx0.00926$.', 8)

# P15 sqrt on [1,4] T_6
stT, vT = rule('T', sqrt, 1, 4, 6)
reg('P15', 'rule', R='T', f='np.sqrt(x)', a=1, b=4, n=6, val=vT)
reg('P15', 'exact', f='np.sqrt(x)', a=1, b=4, val=14 / 3)
reg('P15', 'bound', R='T', f='np.sqrt(x)', f2='-0.25*x**(-1.5)', a=1, b=4, n=6, K=0.25, val=0.25 * 27 / (12 * 36))
st = [r'**Part 1: the error bound.** $f(x)=\sqrt x=x^{1/2}$, $a=1$, $b=4$, $n=6$. Differentiate: $f^{\prime}(x)=\dfrac{1}{2}x^{-1/2}$ and $f^{\prime\prime}(x)=-\dfrac{1}{4}x^{-3/2}$.',
 r'Maximise $|f^{\prime\prime}|$ on $[1,4]$: $|f^{\prime\prime}(x)|=\dfrac{1}{4}x^{-3/2}=\dfrac{1}{4x^{3/2}}$, which decreases as $x$ increases, so the maximum is at $x=1$: $$K=\dfrac{1}{4\cdot1^{3/2}}=\dfrac{1}{4}.$$',
 r'Substitute into $E_T\leq\dfrac{K(b-a)^3}{12n^2}$ with $b-a=3$: $$E_T\leq\dfrac{\frac14\cdot3^3}{12\cdot6^2}=\dfrac{\frac{27}{4}}{432}=\dfrac{27}{1728}=\dfrac{1}{64}=0.015625.$$',
 r'**Part 2: compute $T_6$ and check the bound.**'] + stT + [
 r'Exact value: $\displaystyle\int_1^4\sqrt x\,dx=\Big[\dfrac{2}{3}x^{3/2}\Big]_1^4=\dfrac{2}{3}(8-1)=\dfrac{14}{3}=4.666667$.',
 T(r'Actual error: $\dfrac{14}{3}-T_6=4.666667-@t@=@e@$, which is positive ($T_6$ underestimates, since $f^{\prime\prime}<0$), and $@e@\leq0.015625$, so the bound is respected.', t=fm(vT), e=fm(14 / 3 - vT, 4))]
P(SD, r'Tasks: (a) find a bound on the error in approximating $\displaystyle\int_1^4\sqrt{x}\,dx$ using $T_6$; (b) compute $T_6$ and the exact value, and check that the actual error respects your bound.',
  st, T(r'$E_T\leq\dfrac{1}{64}=0.015625$; $T_6\approx@t@$, actual error $@e@$.', t=fm(vT, 5), e=fm(14 / 3 - vT, 3)), 14)

# P16 Simpson bound 1/x [1,2] n=4
reg('P16', 'bound', R='S', f='1/x', f4='24/x**5', a=1, b=2, n=4, K=24.0, val=24 / (180 * 256))
B16 = 24 / (180 * 256)
st = [r'Identify: $f(x)=\dfrac{1}{x}=x^{-1}$, $a=1$, $b=2$, $n=4$, and $E_S\leq\dfrac{M(b-a)^5}{180n^4}$ with $|f^{(4)}(x)|\leq M$ on $[1,2]$.',
 r'Differentiate four times: $f^{\prime}(x)=-x^{-2}$, $f^{\prime\prime}(x)=2x^{-3}$, $f^{(3)}(x)=-6x^{-4}$, $f^{(4)}(x)=24x^{-5}=\dfrac{24}{x^5}$.',
 r'Maximise $|f^{(4)}|$ on $[1,2]$: $\dfrac{24}{x^5}$ is positive and decreasing for $x>0$, so the maximum is at $x=1$: $$M=\dfrac{24}{1^5}=24.$$',
 T(r'Substitute $M=24$, $b-a=1$, $n=4$: $$E_S\leq\dfrac{24\cdot1^5}{180\cdot4^4}=\dfrac{24}{180\cdot256}=\dfrac{24}{46080}=\dfrac{1}{1920}=@b@.$$', b=fm(B16, 4)),
 T(r'Compare with Problem 8: the actual error of $S_4$ there was $|\ln2-S_4|=@e@$, which is below $@b@$. Compare also with the Trapezoidal bound for $n=4$ on the same integral: with $K=2$, $\dfrac{2\cdot1}{12\cdot16}=0.010417$, about $20$ times larger.', e=fm(abs(calc('S', lambda x: 1 / x, 1, 2, 4) - math.log(2)), 3), b=fm(B16, 4))]
P(SD, r"Find a bound on the error in approximating $\displaystyle\int_1^2\dfrac{1}{x}\,dx$ using $S_4$, and compare it with the actual error found in Problem 8.", st, r'$E_S\leq\dfrac{1}{1920}\approx5.21\times10^{-4}$.', 8)

# ============================================================ E choosing n
def nmin_text(Kdesc, expr_text, need, ngt, nres, checks):
    return None

# P17 source 7
reg('P17', 'nmin', R='T', K=math.e, a=0, b=1, tol=1e-3, even=False, val=16)
st = [r'Setup: $f(x)=e^x$ on $[0,1]$ with $f^{\prime\prime}(x)=e^x$, and we need $E_T\leq\dfrac{K(b-a)^3}{12n^2}<0.001$.',
 r'The maximum of $|f^{\prime\prime}(x)|=e^x$ on $[0,1]$ is at $x=1$ (increasing function), so $K=e\approx2.718282$.',
 r'Write the requirement: $$\dfrac{2.718282\cdot1^3}{12n^2}<0.001.$$',
 r'Multiply by $12n^2>0$ and divide by $0.001$: $$n^2>\dfrac{2.718282}{12\times0.001}=\dfrac{2.718282}{0.012}=226.5235.$$',
 r'Take the positive square root: $$n>\sqrt{226.5235}\approx15.0507.$$ (Check: $15^2=225<226.5235$ and $16^2=256>226.5235$.)',
 r'The Trapezoidal Rule has no parity requirement, and $n$ must be an integer strictly greater than $15.0507$, so the smallest choice is $n=16$.',
 r'Verify: $n=16$ gives $\dfrac{2.718282}{12\cdot256}=\dfrac{2.718282}{3072}=8.848\times10^{-4}<0.001$ (holds). $n=15$ gives $\dfrac{2.718282}{12\cdot225}=\dfrac{2.718282}{2700}=1.0068\times10^{-3}>0.001$ (fails).']
P(SE, r'How large must $n$ be so that $T_n$ approximates $\displaystyle\int_0^1 e^{x}\,dx$ with error less than $0.001$?', st, r'$n=16$.', 8)

# P18 source 8
reg('P18', 'nmin', R='S', K=24.0, a=0, b=2, tol=1e-2, even=True, val=6)
st = [r'Setup: $f(x)=x^4$ on $[0,2]$, and we need $E_S\leq\dfrac{M(b-a)^5}{180n^4}<0.01$ with $n$ even.',
 r'Differentiate four times: $f^{\prime}(x)=4x^3$, $f^{\prime\prime}(x)=12x^2$, $f^{(3)}(x)=24x$, $f^{(4)}(x)=24$. The fourth derivative is the constant $24$, so $M=24$.',
 r'Write the requirement with $b-a=2$: $$\dfrac{24\cdot2^5}{180n^4}<0.01\ \Longrightarrow\ \dfrac{768}{180n^4}<0.01.$$',
 r'Multiply by $n^4>0$ and divide by $0.01$: $$n^4>\dfrac{768}{180\times0.01}=\dfrac{768}{1.8}=426.667.$$',
 r'Fourth root: $\sqrt{426.667}\approx20.656$, then $\sqrt{20.656}\approx4.545$, so $$n>4.545.$$',
 r'The smallest **even** integer greater than $4.545$ is $n=6$ (the next even integer after $4$).',
 r'Verify: $n=6$ gives $\dfrac{768}{180\cdot1296}=\dfrac{768}{233280}=0.003292<0.01$ (holds). $n=4$ gives $\dfrac{768}{180\cdot256}=\dfrac{768}{46080}=0.016667>0.01$ (fails).']
P(SE, r'How large must (even) $n$ be so that $S_n$ approximates $\displaystyle\int_0^2 x^4\,dx$ with error less than $0.01$?', st, r'$n=6$.', 8)

# P19 M_n for e^{-x^2} on [0,2]
reg('P19', 'Kmax', f='np.exp(-x**2)', fd='(4*x**2-2)*np.exp(-x**2)', a=0, b=2, K=2.0)
reg('P19', 'nmin', R='M', K=2.0, a=0, b=2, tol=1e-4, even=False, val=82)
st = [r'Setup: $f(x)=e^{-x^2}$ on $[0,2]$, and we need $E_M\leq\dfrac{K(b-a)^3}{24n^2}<10^{-4}$ with $|f^{\prime\prime}(x)|\leq K$ on $[0,2]$.',
 r'First derivative (chain rule): $f^{\prime}(x)=-2xe^{-x^2}$. Second derivative (product rule): $$f^{\prime\prime}(x)=-2e^{-x^2}+(-2x)(-2xe^{-x^2})=(4x^2-2)e^{-x^2}.$$',
 r'To maximise $|f^{\prime\prime}|$ on $[0,2]$, find the critical points of $f^{\prime\prime}$ using $f^{(3)}$: $$f^{(3)}(x)=8xe^{-x^2}+(4x^2-2)(-2x)e^{-x^2}=(12x-8x^3)e^{-x^2}=4x(3-2x^2)e^{-x^2}.$$ It vanishes at $x=0$ and $x=\sqrt{1.5}\approx1.2247$ (in $[0,2]$).',
 r'Evaluate $f^{\prime\prime}$ at the critical points and the endpoints: $$f^{\prime\prime}(0)=-2,\quad f^{\prime\prime}(1.2247)=(6-2)e^{-1.5}=4(0.223130)=0.892521,\quad f^{\prime\prime}(2)=14e^{-4}=14(0.018316)=0.256423.$$ The largest absolute value is $|f^{\prime\prime}(0)|=2$, so $K=2$.',
 r'Write the requirement with $b-a=2$: $$\dfrac{2\cdot2^3}{24n^2}=\dfrac{16}{24n^2}=\dfrac{2}{3n^2}<10^{-4}.$$',
 r'Solve: $$n^2>\dfrac{2}{3\times10^{-4}}=6666.67\ \Longrightarrow\ n>\sqrt{6666.67}\approx81.65.$$ (Check: $81^2=6561<6666.67<6724=82^2$.)',
 r'The smallest integer greater than $81.65$ is $n=82$. Verify: $n=82$: $\dfrac{2}{3\cdot6724}=9.915\times10^{-5}<10^{-4}$ (holds); $n=81$: $\dfrac{2}{3\cdot6561}=1.0161\times10^{-4}>10^{-4}$ (fails).']
P(SE, r'How large must $n$ be so that $M_n$ approximates $\displaystyle\int_0^2 e^{-x^2}\,dx$ with error less than $10^{-4}$? (Find $K$ by maximising $|f^{\prime\prime}|$ on $[0,2]$.)', st, r'$K=2$, $n=82$.', 14)

# P20 S_n for ln on [1,3] tol 1e-6
reg('P20', 'Kmax', f='np.log(x)', fd='-6/x**4', a=1, b=3, K=6.0, order=4)
reg('P20', 'nmin', R='S', K=6.0, a=1, b=3, tol=1e-6, even=True, val=34)
st = [r'Setup: $f(x)=\ln x$ on $[1,3]$, and we need $E_S\leq\dfrac{M(b-a)^5}{180n^4}<10^{-6}$ with $n$ even.',
 r'Differentiate four times: $f^{\prime}(x)=x^{-1}$, $f^{\prime\prime}(x)=-x^{-2}$, $f^{(3)}(x)=2x^{-3}$, $f^{(4)}(x)=-6x^{-4}=-\dfrac{6}{x^4}$.',
 r'Maximise $|f^{(4)}|$ on $[1,3]$: $|f^{(4)}(x)|=\dfrac{6}{x^4}$ is decreasing for $x>0$, so the maximum is at $x=1$: $M=6$.',
 r'Write the requirement with $b-a=2$: $$\dfrac{6\cdot2^5}{180n^4}=\dfrac{192}{180n^4}=\dfrac{16}{15n^4}<10^{-6}.$$',
 r'Solve: $$n^4>\dfrac{16}{15\times10^{-6}}=1\,066\,667\ \Longrightarrow\ n>(1\,066\,667)^{1/4}.$$ Since $\sqrt{1\,066\,667}\approx1032.8$ and $\sqrt{1032.8}\approx32.14$, we get $n>32.14$.',
 r'The smallest **even** integer greater than $32.14$ is $n=34$. Verify: $34^4=1\,336\,336$, so $\dfrac{16}{15\cdot1\,336\,336}=7.98\times10^{-7}<10^{-6}$ (holds). For $n=32$: $32^4=1\,048\,576$ and $\dfrac{16}{15\cdot1\,048\,576}=1.0173\times10^{-6}>10^{-6}$ (fails, just barely).']
P(SE, r"How large must (even) $n$ be so that Simpson’s Rule $S_n$ approximates $\displaystyle\int_1^3\ln x\,dx$ with error less than $10^{-6}$?", st, r'$M=6$, $n=34$.', 11)

# P21 compare T vs S cost
reg('P21', 'nmin', R='T', K=math.e, a=0, b=1, tol=1e-6, even=False, val=476)
reg('P21', 'nmin', R='S', K=math.e, a=0, b=1, tol=1e-6, even=True, val=12)
st = [r'For $f(x)=e^x$ on $[0,1]$, every derivative is $e^x$, which is increasing, so $K=M=e\approx2.718282$ for both the second and the fourth derivative.',
 r'**Trapezoidal Rule.** Require $\dfrac{e\cdot1^3}{12n^2}<10^{-6}$: $$n^2>\dfrac{2.718282}{12\times10^{-6}}=226\,523.5\ \Longrightarrow\ n>\sqrt{226\,523.5}\approx475.9.$$ (Check: $475^2=225\,625<226\,523.5<226\,576=476^2$.) So $n=476$.',
 r"**Simpson’s Rule.** Require $\dfrac{e\cdot1^5}{180n^4}<10^{-6}$: $$n^4>\dfrac{2.718282}{180\times10^{-6}}=15\,101.6\ \Longrightarrow\ n>(15\,101.6)^{1/4}\approx11.09.$$ (Check: $11^4=14\,641<15\,101.6<20\,736=12^4$.) The smallest even integer above $11.09$ is $n=12$.",
 r'Count function evaluations: a rule with $n$ subintervals uses $n+1$ grid values for $T_n$ and $S_n$. $$T_{476}:\ 477\ \text{values},\qquad S_{12}:\ 13\ \text{values}.$$',
 r'Ratio: $\dfrac{477}{13}\approx36.7$, so Simpson’s Rule needs about $37$ times fewer function evaluations for the same guaranteed accuracy, because its error bound decreases like $n^{-4}$ instead of $n^{-2}$.']
P(SE, r"For $\displaystyle\int_0^1e^x\,dx$, find the smallest $n$ that guarantees an error below $10^{-6}$ for (a) the Trapezoidal Rule $T_n$ and (b) Simpson’s Rule $S_n$ (even $n$). Compare the number of function evaluations ($n+1$ in each case).", st, r'$T_{476}$ (477 values) versus $S_{12}$ (13 values); about $37$ times fewer evaluations for Simpson.', 11)
