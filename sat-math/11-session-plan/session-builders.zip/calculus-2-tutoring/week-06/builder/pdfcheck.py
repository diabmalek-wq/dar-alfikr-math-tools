import re, json, subprocess, sys
import numpy as np
from scipy import integrate
txt = subprocess.run(['pdftotext','-layout','/home/claude/c2w6/Week-06-solutions.pdf','-'],capture_output=True,text=True).stdout
txt = txt.replace('−','-')
parts = re.split(r'Answer\.', txt)
# part[k] = text leading up to k-th Answer (k=1..39); segment k covers its solution
segs = parts[:40]
print('answer markers:', len(parts)-1)
REG = json.load(open('/home/claude/c2w6/reg.json'))
def ev(s): return float(eval(str(s),{'np':np})) if isinstance(s,str) else float(s)
F=lambda e:(lambda x: eval(e,{'np':np,'x':np.asarray(x,float)})+0*np.asarray(x,float))
def rn(R,f,a,b,m):
    x=np.linspace(a,b,m+1)
    if R=='T': return float(np.trapezoid(f(x),x))
    if R=='M': return float((b-a)/m*f((x[:-1]+x[1:])/2).sum())
    return float(integrate.simpson(f(x),x=x))
def idx(pid):
    if pid.startswith('E'): return int(pid[1:])
    n=int(re.match(r'P(\d+)',pid).group(1)); return 8+n
nums=lambda s:[float(t) for t in re.findall(r'-?\d+\.?\d*',s)]
bad=0; ok=0; skipped=0
for r in REG:
    if r['kind'] not in ('rule','data'): continue
    if r['kind']=='rule':
        v=rn(r['R'],F(r['f']),ev(r['a']),ev(r['b']),int(r['n']))
    else:
        y=np.array(r['y'],float);h=float(r['h'])
        v=float(np.trapezoid(y,dx=h)) if r['R']=='T' else (float(integrate.simpson(y,dx=h)) if r['R']=='S' else float(h*y.sum()))
    k=idx(r['pid']); seg=parts[k-1]+parts[k][:300]
    tol=max(float(r.get('tol') or 0),1e-4)*max(1,abs(v))
    if any(abs(t-v)<=tol for t in nums(seg)): ok+=1
    else:
        # value may be only displayed as a fraction / not at all in the PDF
        skipped+=1; print('not found in PDF text:',r['pid'],r['kind'],r.get('R'),r.get('n'),v)
print('found',ok,'not displayed',skipped)
