"""Verifies every Desmos box in Session 8: every typed [[expr]]: it returns v, every tapped intersection, every regression claim, and every final answer."""
import re,sys,json,math
sys.path.insert(0,'.')
import numpy as np
from dsteps import S,V,CLAIMS,REGS,ev,n,N
import io,contextlib
with contextlib.redirect_stdout(io.StringIO()):
    from solve import tex2f
items={o['id']:o for o in json.load(open('s8_items.json'))};K=json.load(open('s8_keys.json'))
bad=0;cnt=0;boxes=0;withbox=0
for iid,st in S.items():
    t=' '.join(st);b=re.findall(r"\[\[((?:(?!\]\]).)+)\]\]",t);boxes+=len(b);withbox+=1 if b else 0
    for expr in b:
        if expr.startswith('y_1~') : continue
        e=expr[2:] if expr.startswith('y=') else expr
        try: ev(e,x=1.37) if 'x' in e else ev(e)
        except Exception as ex: print('SYNTAX',iid,expr,ex);bad+=1
    for m in re.finditer(r"\[\[((?:(?!\]\]).)+)\]\]: it returns \$([^$]+)\$",t):
        cnt+=1;want=float(m.group(2));got=ev(m.group(1))
        if abs(got-want)>6e-5*max(1,abs(want)): print('MISMATCH',iid,m.group(1),got,want);bad+=1
tp=0
for iid,F,G,x,y in CLAIMS:
    tp+=1
    if abs(ev(F,x=x)-ev(G,x=x))>1e-6*max(1,abs(y)) or abs(ev(F,x=x)-y)>1e-9: print('BAD point',iid,F,G);bad+=1
    if not any(q in ' '.join(S[iid]).replace('\\,',',') for q in (n(x),n(x,2),n(x,1))): print('point text?',iid,F,n(x));bad+=1
for iid,xs,ys,m,b_,r2 in REGS:
    co=np.polyfit(xs,ys,1);rr=np.corrcoef(xs,ys)[0,1]**2
    if abs(co[0]-m)>1e-9 or abs(rr-r2)>1e-9: bad+=1;print('REG',iid)
    if not any(q in ' '.join(S[iid]) for q in (n(m),n(m,2),'r^2=%s'%n(r2))): print('reg text',iid,m);bad+=1
# final answers
fa=0
for iid,val in V.items():
    if val is None: continue
    kind,k=K[iid]
    want=k if kind=='val' else tex2f(items[iid]['opts'][int(k)])
    fa+=1
    if abs(want-val)>1e-6: print('ANSWER MISMATCH',iid,val,want);bad+=1
# per-problem step counts and Desmos boxes
for iid,st in S.items():
    if not 3<=len(st)<=4 or '[[' not in ' '.join(st): print('STEPS',iid,len(st));bad+=1
print('problems',len(S),'with >=1 Desmos box',withbox,'boxes',boxes,'returns checked',cnt,'tapped points',tp,'regressions',len(REGS),'final answers cross-checked',fa,'BAD',bad)
sys.exit(1 if bad else 0)
