import json,re,sys,subprocess,os,math
HERE=os.path.dirname(os.path.abspath(__file__)); os.chdir(HERE); sys.path.insert(0,HERE)
from lib import *
import figs
from dsteps import S,N,T
items=json.load(open('s8_items.json')); KEYS=json.load(open('s8_keys.json'))
ESC={'\\':r'\textbackslash{}','{':r'\{','}':r'\}','^':r'\textasciicircum{}','_':r'\_','~':r'\textasciitilde{}','#':r'\#','%':r'\%','&':r'\&','$':r'\$'}
def code(m):
    c=m.group(1).replace('\\{','{').replace('\\}','}')
    return r"\dzc{"+"".join(ESC.get(ch,ch) for ch in c)+"}"
def conv(s): return re.sub(r"\[\[(.+?)\]\]",code,s)
SESSION=8; NN='08'; TITLE='Data Models, Angles and Triangles'; FILET='Data-Models-Angles-and-Triangles'
LINES_FILE='lines.json'
LINES=json.load(open(LINES_FILE)) if os.path.exists(LINES_FILE) else {}
def fmtval(x):
    return str(int(round(x))) if abs(x-round(x))<1e-9 else ('%.4f'%x).rstrip('0').rstrip('.')
order=[o for o in items if o['part']=='In class']+[o for o in items if o['part']!='In class']
nA=sum(1 for o in items if o['part']=='In class')
P=[]
for o in order:
    i=o['id'];kind,val=KEYS[i]
    p=dict(id=i,lv='M' if o['d']=='Medium' else 'H',tool=T.get(i,'N' if i in N else 'D'),q=o['q'])
    if i in figs.FIG: p['fig']=figs.FIG[i]()
    if o['fmt']=='MCQ':
        assert len(o['opts'])==4 and len(set(o['opts']))==4,i
        p['opts']=list(o['opts']);p['correct']=int(val);p['norot']=False;p['chk']=lambda c=int(val):('idx',c)
    else:
        p['val']=float(val);p['ans']=fmtval(float(val));p['chk']=lambda x=float(val):x
    p['steps']=[conv(x) for x in S[i]]
    p['lines']=LINES.get(i,{'M':5,'H':6}[p['lv']])
    P.append(p)
P=prep(P)
for p in P: p['steps']=[x.replace('@@L@@',"ABCD"[p['correct']] if p.get('opts') else '?') for x in p['steps']]
for p in P: assert '@@' not in ''.join(p['steps']) and not (not p.get('opts') and '(?)' in ''.join(p['steps'])),p['id']
json.dump({p['id']:(["ABCD"[p['correct']]] if p.get('opts') else [p['ans']]) for p in P},open('final_key.json','w'))
meta=dict(title=TITLE,code='SAT-M \\textperiodcentered\\ Session %d'%SESSION,headfull='Session %d \\textemdash\\ %s'%(SESSION,TITLE),
 time='3 hours: Part A in class (about 2 hours of solving), then Part B, the self-assessment, done independently (about 45 minutes), and a short error log.',
 topics='scatterplots and lines of best fit: predicted versus actual, slope and intercept in context, linear versus exponential models \\textperiodcentered\\ parallel lines and transversals \\textperiodcentered\\ angle sums and exterior angles \\textperiodcentered\\ isosceles triangles and regular polygons \\textperiodcentered\\ similar triangles and proportional segments \\textperiodcentered\\ triangle inequality, midsegments and angle bisectors \\textperiodcentered\\ right-triangle trigonometry and special right triangles \\textperiodcentered\\ Law of Cosines')
KEYSPACE=r"""
\newcounter{kp}
\renewcommand{\keyspace}[2]{\par\nopagebreak\stepcounter{kp}
 \setbox0\vbox{\hsize\linewidth\color{SOLGREEN}\small #2\par}%
 \setbox1\vbox{\foreach \i in {1,...,#1}{\par\vspace{0.74cm}{\color{LINE}\hrule height 0.4pt}}}%
 \typeout{KP \thekp: ht0=\the\ht0 ht1=\the\ht1 lines=#1}%
 \ifdim\ht0>\ht1 \dimen2=\ht0 \else \dimen2=\ht1 \fi
 \vbox to \dimen2{\nointerlineskip\vbox to 0pt{\box1\vss}\nointerlineskip\box0\vss}\par\vspace{4pt}}
"""
def build_s(mode,out):
    key=(mode=='key')
    L=[PRE.replace("@@CODE@@",meta['code']).replace("@@HEAD@@",meta['headfull']).replace("\\begin{document}",EXTRA+KEYSPACE+r"\setmonofont[Scale=0.9]{DejaVu Sans Mono}\newcommand{\dzc}[1]{\colorbox{black!8}{\texttt{\small\textcolor{black}{#1}}}}"+"\n\\begin{document}")]
    L.append(r"""
\begin{tcolorbox}[enhanced,colback=NAVY!4,colframe=NAVY,boxrule=0.8pt,arc=3pt]
{\Large\bfseries\color{NAVY} SAT Math Mastery \textperiodcentered\ Session %d}\\[2pt]
{\large\bfseries %s}\\[3pt]
\begin{tabular}{@{}p{0.2\linewidth}p{0.75\linewidth}@{}}
\textbf{Time} & %s\\
\textbf{Topics} & %s\\
\textbf{Name / Date} & \rule{5.5cm}{0.3pt}\ \ \rule{3cm}{0.3pt}\\
\end{tabular}
\end{tcolorbox}
"""%(SESSION,meta['title'],meta['time'],meta['topics']))
    L.append(r"\banner{Part A \textperiodcentered\ In class \textemdash\ %d problems}"%nA)
    L.append(r"\small Each problem states its tool. Write your work in the space below. Multiple choice: one correct option. Student-produced response (SPR): enter an exact value (fraction or decimal)."+(r" Grey boxes show exactly what to type in Desmos, one expression per line; tap a grey dot to read an intersection, intercept or vertex. A letter such as $a$, $c$ or $k$ becomes a slider when you accept Desmos's offer to add one." if key else "")+r"\normalsize\par\vspace{4pt}")
    for i,p in enumerate(P,1):
        if i==nA+1: L.append(r"\par\needspace{9cm}\banner{Part B \textperiodcentered\ Self-assessment \textemdash\ %d problems}"%(len(P)-nA))
        L.append(problem_tex(i,p,mode))
    L.append(r"\end{document}")
    open(out,'w').write("\n".join(L))
def compile_(out):
    for _ in range(2): subprocess.run(['xelatex','-interaction=nonstopmode',out],capture_output=True,text=True)
    log=open(out[:-4]+'.log').read();return log
if __name__=='__main__':
    for it in range(6):
        build_s('key','S8_key.tex');log=compile_('S8_key.tex')
        grow={}
        for m in re.finditer(r'KP (\d+): ht0=([\d.]+)pt ht1=([\d.]+)pt lines=(\d+)',log):
            k,h0,h1,ln=int(m.group(1)),float(m.group(2)),float(m.group(3)),int(m.group(4))
            if h0>h1: grow[P[k-1]['id']]=math.ceil(ln*h0/h1)
        if not grow: break
        for i,l in grow.items(): LINES[i]=l
        for p in P:
            if p['id'] in grow: p['lines']=LINES[p['id']]
        json.dump(LINES,open(LINES_FILE,'w'))
        print('raising lines',grow)
    build_s('ws','S8_ws.tex');log2=compile_('S8_ws.tex')
    for out in ('S8_ws.log','S8_key.log'):
        lg=open(out).read();print(out,'overfull',lg.count('Overfull'),'err',len(re.findall(r'^!',lg,re.M)))
