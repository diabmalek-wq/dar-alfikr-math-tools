"""Session 8: Desmos solution steps for EVERY problem.  Every typed [[expr]] 'returns' value and every tapped point is computed here
(ev / inter / reg) and re-evaluated independently by verify_steps.py."""
import math, re, statistics
import numpy as np
from scipy.optimize import brentq
DEG=math.pi/180
def _nCr(a,b): return math.comb(int(a),int(b))
def n(v,d=4):
    s=('%.*f'%(d,v)).rstrip('0').rstrip('.'); return '0' if s in ('-0','') else s
def ev(expr,**kw):
    e=expr.replace('^','**')
    e=re.sub(r'\[(\d+)\.\.\.(\d+)\]',lambda m:'list(range(%s,%s))'%(m.group(1),int(m.group(2))+1),e)
    e=re.sub(r'(\d+(?:\.\d+)?|\))\s*deg\b',r'\1*DEG',e)
    e=re.sub(r'(\d|\))\s*(\(|[a-zA-Z])',r'\1*\2',e)
    env=dict(sqrt=math.sqrt,abs=abs,ln=math.log,sin=math.sin,cos=math.cos,tan=math.tan,arcsin=math.asin,arccos=math.acos,arctan=math.atan,
             pi=math.pi,round=round,mean=lambda L:sum(L)/len(L),total=sum,median=statistics.median,stdev=statistics.stdev,length=len,list=list,range=range,nCr=_nCr,DEG=DEG)
    env.update(kw);return eval(e,{'__builtins__':{}},env)
def c(e): return '[[%s]]'%e
def v(x,d=4): return '$%s$'%n(x,d)
def ret(e,d=4,**kw): return "Type %s: it returns %s"%(c(e),v(ev(e,**kw),d))
def rets(*es): return ', '.join(ret(e) for e in es)
def pt(x,y,d=4): return "$(%s,\\,%s)$"%(n(x,d),n(y,d))
def sub(e,xv): return re.sub(r'(?<![A-Za-z_])x(?![A-Za-z_])','(%s)'%n(xv),e)
CLAIMS=[];REGS=[];V={};S={};N=set();T={}
def inter(i,F,G,lo,hi):
    f=lambda x:ev(F,x=x)-ev(G,x=x); xs=brentq(f,lo,hi,xtol=1e-13); y=ev(F,x=xs); CLAIMS.append((i,F,G,xs,y)); return xs,y
def tap(i,F,G,lo=-1000,hi=1000,d=4,what="Tap the intersection"):
    xs,y=inter(i,F,G,lo,hi)
    return xs,y,"Type %s and %s. %s: %s."%(c('y='+F),c('y='+G),what,pt(xs,y,d))
def lin(i,F,G,lo=-1000,hi=1000):
    xs,y,t=tap(i,F,G,lo,hi); return xs,y,t+" Its first coordinate is the unknown $x=%s$."%n(xs)
def reg(i,xs,ys,deg=1):
    co=np.polyfit(xs,ys,1);r2=float(np.corrcoef(xs,ys)[0,1]**2);REGS.append((i,list(xs),list(ys),float(co[0]),float(co[1]),r2));return float(co[0]),float(co[1]),r2
def tbl(xs,ys): return "Open a table and enter $x_1=%s$ and $y_1=%s$."%(','.join(map(str,xs)),','.join(map(str,ys)))
# ============ Problem Solving and Data Analysis ============
i='PS-038'
S[i]=["Type the model %s and the recorded day %s. The point sits above the line."%(c('y=12x+20'),c('(10,155)')),
 "The predicted value at $x=10$: "+ret('12*10+20')+" liters.",
 "The positive difference is actual minus predicted: "+ret('155-(12*10+20)')+".", ]
V[i]=ev('155-(12*10+20)')
i='PS-039'
S[i]=["Type the two points %s and %s."%(c('(2,340)'),c('(10,60)')),
 "Slope = rise over run: "+ret('(60-340)/(10-2)')+".",
 "Check by drawing the line through both points: type %s. At $x=2$ "%c('y=-35(x-2)+340')+ret('-35*(2-2)+340')+" and at $x=10$ "+ret('-35*(10-2)+340')+", so the line passes through both points.",
 "The slope is $-35$ (the count falls as distance grows), option (@@L@@)."]
V[i]=ev('(60-340)/(10-2)')
i='PS-040'
S[i]=["Type the model %s (letting $x$ be the years since $2015$)."%c('y=45.2x+12.5'),
 "Evaluate it at $x=8.4$: "+ret('45.2*8.4+12.5')+".",
 "Round to one decimal place: "+ret('round(45.2*8.4+12.5,1)')+".",
 "That is option (@@L@@)."]
V[i]=ev('round(45.2*8.4+12.5,1)')
i='PS-041'
xs_=[0,1,2,3];y1=[1000-85*k for k in xs_];y2=[round(1000*0.9**k,1) for k in xs_]
m1,b1,r1=reg(i,xs_,y1);m2,b2,r2=reg(i,xs_,y2)
S[i]=[tbl(xs_,y1)+" (a tank draining $85$ liters per hour). Type %s: Desmos returns $m=%s$, $b=%s$, $r^2=%s$, a perfect line with negative slope."%(c('y_1~mx_1+b'),n(m1),n(b1),n(r1)),
 "Compare a decay that removes $10$ percent each hour: "+tbl(xs_,y2)+" Type %s: Desmos returns $r^2=%s$ and the points curve away from the line (the drops %s, %s, %s are not constant)."%(c('y_1~mx_1+b'),n(r2),n(y2[0]-y2[1],1),n(y2[1]-y2[2],1),n(y2[2]-y2[3],1)),
 "A constant rate of drainage gives constant drops, so the model is linear with a negative slope, option (@@L@@). (Verbal reasoning step: the table and regression are only a model of the idea.)"]
i='PS-042'
S[i]=["The difference is actual minus predicted: "+ret('96-89')+".",
 "Check by adding back: "+ret('89+7')+", the actual score.",
 "The point is $7$ above the line, option (@@L@@)."]
V[i]=ev('96-89')
i='PS-043'
xs_=[1,2,3,4,5];ys_=[3.5,6.0,8.6,11.0,13.4];m,b,r2_=reg(i,xs_,ys_)
S[i]=[tbl(xs_,ys_),
 "Type %s: Desmos returns $m=%s$ and $b=%s$ (about $2.5$ and $1$)."%(c('y_1~mx_1+b'),n(m,2),n(b,2)),
 "Test option (@@L@@) at $x=5$: "+ret('2.5*5+1')+" against the data value $13.4$.",
 "The others miss badly at $x=5$: "+rets('-2.5*5+1','5+2.5','2.5*5-1')+"."]
V[i]=None
i='PS-044'
tabs=[[5,9,13,17],[2,4,6,8],[5,10,15,20],[3,6,12,24]]
rr=[reg(i,[1,2,3,4],t) for t in tabs]
S[i]=["Linear means constant change. Enter each table and run %s. For the first three tables $r^2=%s$, $%s$, $%s$ (perfect lines, with slopes $%s$, $%s$, $%s$)."%(c('y_1~mx_1+b'),n(rr[0][2]),n(rr[1][2]),n(rr[2][2]),n(rr[0][0]),n(rr[1][0]),n(rr[2][0])),
 "For the fourth table (%s) the fit is not perfect: Desmos returns $r^2=%s<1$."%(tbl([1,2,3,4],tabs[3])[0:0]+'$y_1=3,6,12,24$',n(rr[3][2])),
 "Differences confirm it: "+rets('6-3','12-6','24-12')+" are not equal (each $y$-value doubles).",
 "The nonlinear relationship is the fourth table, option (@@L@@)."]
i='PS-045'
S[i]=["Type the model %s (here $x$ is years since $2018$)."%c('y=-18.6x+340'),
 "Evaluate at $x=0$ and $x=1$: "+rets('-18.6*0+340','-18.6*1+340')+".",
 "The change per year is "+ret('(-18.6*1+340)-(-18.6*0+340)')+" dollars, a decrease. (Verbal reasoning step: the number $340$ is the starting value, not a rate.) That is option (@@L@@)."]
V[i]=None
i='PS-046'
fA='800*1.05^x';fB='1500+40*x'
xc,yc,t=tap(i,fA,fB,5,60,2,"Zoom out and tap the right-hand intersection")
S[i]=[t[:t.index(' Zoom')] if False else "Type %s and %s."%(c('y='+fA),c('y='+fB)),
 "Zoom out and tap the intersection with $x>0$: %s (about $%s$ years). The other intersection has a negative $x$, so ignore it."%(pt(xc,yc,2),n(xc,1)),
 "At the start: "+rets('800*1.05^0','1500+40*0')+", so A begins lower.",
 "Far out: "+rets('800*1.05^30','1500+40*30')+", so A has overtaken B. That is option (@@L@@)."]
CLAIMS_NEG=[]
# ============ Geometry: lines, angles, triangles ============
i='GT-011'
x,y,t=lin(i,'3x+10','5x-30')
S[i]=[t,"Check both sides at $x=%s$: "%n(x)+rets(sub('3x+10',x),sub('5x-30',x))+".","Corresponding angles are equal, so $x=%s$ (option (@@L@@))."%n(x)];V[i]=x
i='GT-012'
x,y,t=tap(i,'x/(x+4)','15/25',0.01,200)
S[i]=["$ST\\parallel QR$ gives $\\dfrac{x}{x+4}=\\dfrac{15}{25}$. "+t,"The first coordinate is $x=%s$."%n(x),"Check: "+rets(sub('x/(x+4)',x),'15/25')+", equal."];V[i]=x
i='GT-013'
x,y,t=lin(i,'5x-10','(2x+15)+(x+25)')
S[i]=["Exterior angle = sum of the remote interior angles. "+t,"Angle $Y=2x+15$: "+ret(sub('2x+15',x))+" degrees.","Check the exterior angle: "+rets(sub('5x-10',x),sub('(2x+15)+(x+25)',x))+"."];V[i]=ev(sub('2x+15',x))
i='GT-020'
x,y,t=lin(i,'2x+x+(x+24)','180')
S[i]=["With $B=x$, $A=2x$, $C=x+24$ the angle sum is $180$. "+t,"Angle $A=2x$: "+ret(sub('2x',x))+" degrees.","Check the sum: "+ret(sub('2x+x+(x+24)',x))+". That is option (@@L@@)."];V[i]=ev(sub('2x',x))
i='GT-024'
x,y,t=tap(i,'360/x','24',1,200)
S[i]=["The exterior angles sum to $360^\\circ$, so each is $\\dfrac{360}{n}$. "+t,"The number of sides is the first coordinate $n=%s$."%n(x),"Check: "+ret('360/15')+" degrees each. That is option (@@L@@)."];V[i]=x
i='GT-031'
S[i]=["The diagonal of the right triangle $ABC$: "+ret('sqrt(9^2+12^2)')+".",
 "Area of $ABC$: "+ret('1/2*9*12')+".","Area of $ACD$ (legs $AC=15$ and $AD=8$): "+ret('1/2*15*8')+".","Total: "+ret('1/2*9*12+1/2*15*8')+", option (@@L@@)."];V[i]=ev('1/2*9*12+1/2*15*8')
i='GT-033'
x,y,t=lin(i,'3x+x+68','180')
S[i]=["$b=180-112$: "+ret('180-112')+".","With $c=x$, $a=3x$: "+t,"So $c=%s$, $a=3c$: "%n(x)+ret(sub('3x',x))+".","$a+b$: "+ret(sub('3x',x)+'+68')+", option (@@L@@)."];V[i]=ev(sub('3x',x)+'+68')
i='GT-034'
S[i]=["Octagon exterior angle: "+ret('360/8')+".","Decagon exterior angle: "+ret('360/10')+".","Positive difference: "+ret('360/8-360/10')+"."];V[i]=ev('360/8-360/10')
i='GT-035'
S[i]=["Top vertex angle: "+ret('180-40-40')+" degrees.","Bottom vertex angle $b$: "+ret('100/2')+" degrees.","Each bottom base angle: "+ret('(180-50)/2')+" degrees.","Angle $a$ is supplementary to a base angle: "+ret('180-65')+"."];V[i]=ev('180-65')
i='GT-048'
S[i]=["Similar triangles: height over shadow is constant. "+ret('6/4')+" for the flagpole.","Building: "+ret('6/4*30')+" meters.","Check the ratio: "+ret('45/30')+", equal to $6/4$."];V[i]=ev('6/4*30')
i='GT-049'
S[i]=["Similar triangles have equal corresponding angles, so $H=E=63^\\circ$ (option (@@L@@)).","Angle $F$: "+ret('180-48-63')+".","Angle sum check for $GHI$: "+ret('48+63+69')+"."];V[i]=63
i='GT-050'
S[i]=["Interior angle at $C$: "+ret('180-130')+".","Angle $B$ from the exterior angle theorem: "+ret('130-55')+".","Check the angle sum: "+ret('55+75+50')+"."];V[i]=ev('130-55')
i='GT-051'
S[i]=["Same-side interior angles must add to $180^\\circ$. First two pairs: "+rets('100+80','95+85')+".","Third and fourth pairs: "+rets('112+68','95+84')+".","The pair summing to $179$ cannot be same-side interior angles, option (@@L@@)."]
i='GT-062'
x,y,t=lin(i,'x+2x+(3x-30)','180')
S[i]=[t,"Largest angle: "+ret(sub('3x-30',x))+" degrees.","Check the sum: "+ret(sub('x+2x+(3x-30)',x))+". That is option (@@L@@)."];V[i]=x
i='GT-063'
x,y,t=lin(i,'4x+5','6x-21')
S[i]=[t,"Check both angles: "+rets(sub('4x+5',x),sub('6x-21',x))+".","So $x=%s$, option (@@L@@)."%n(x)];V[i]=x
i='GT-064'
x,y,t=lin(i,'7x-12','(3x+8)+(2x+16)')
S[i]=[t,"Exterior angle: "+ret(sub('7x-12',x))+" degrees.","Remote angles: "+ret(sub('(3x+8)+(2x+16)',x))+", the same."];V[i]=x
i='GT-065'
S[i]=["Height per meter of shadow from the pole: "+ret('2.4/3.2')+".","Tower height: "+ret('2.4/3.2*52')+" meters.","(Flipping the ratio would give "+ret('3.2/2.4*52',2)+", not an option.) That is option (@@L@@)."];V[i]=ev('2.4/3.2*52')
i='GT-081'
x,y,t=lin(i,'5x+10','3x+30')
S[i]=[t,"Check: "+rets(sub('5x+10',x),sub('3x+30',x))+".","So $x=%s$, option (@@L@@)."%n(x)];V[i]=x
i='GT-082'
S[i]=["Triangle inequality: $x<9+14$. "+ret('9+14')+".","The greatest integer below $23$: "+ret('23-1')+".","Check the other inequalities for $x=22$: "+rets('9+22','14+9')+" (need $31>14$ and $23>22$). That is option (@@L@@)."];V[i]=ev('23-1')
i='GT-083'
x,y,t=lin(i,'(x+30)+x+x','180')
S[i]=["Let each base angle be $x$ (since $AB=AC$) and $A=x+30$. "+t,"Angle $C=x=%s$; angle $A$: "%n(x)+ret(sub('x+30',x))+".","Check the sum: "+ret('80+50+50')+"."];V[i]=x
i='GT-084'
x,y,t=lin(i,'3x-4','(5x+2)/2')
S[i]=["Midsegment: $MN=\\frac12BC$. "+t,"$BC$: "+ret(sub('5x+2',x))+".","Check $MN$: "+ret(sub('3x-4',x))+", half of $BC$. That is option (@@L@@)."];V[i]=ev(sub('5x+2',x))
i='GT-089'
S[i]=["Triangle inequality: $|a-b|<c<a+b$. Smallest $|a-b|$ is near "+ret('abs(6-9)')+".","Largest $a+b$ is near "+ret('6+11')+".","Test values just inside the ranges: "+rets('abs(5.999-9.001)','5.999+10.999')+" (never reaching $3$ or $17$). So $3<c<17$, option (@@L@@)."]
i='GT-094'
S[i]=["Scale factor $DEF$ to $ABC$ sides: "+ret('8/12')+".","Area ratio is the square: "+ret('(8/12)^2')+".","Compare with the option $\\frac49$: "+ret('4/9')+", the same. Option (@@L@@)."];V[i]=ev('(8/12)^2')
i='GT-098'
S[i]=["Angle $ACB$ (supplementary to $DCA$): "+ret('180-112')+".","Angle $A$ (isosceles, $B=ACB$): "+ret('180-68-68')+".","Check the sum: "+ret('44+68+68')+"."];V[i]=ev('180-68-68')
i='GT-124'
x,y,t=lin(i,'(5x+5)+(3x+15)','180')
S[i]=["Same-side interior angles $B$ and $C$ add to $180$. "+t,"Angles: "+rets(sub('6x',x),sub('5x+5',x),sub('3x+15',x),sub('7x-10',x))+".","A pentagon's angles total "+ret('(5-2)*180')+".","$E$: "+ret('540-(120+105+75+130)')+", option (@@L@@)."];V[i]=ev('540-(120+105+75+130)')
i='GT-126'
S[i]=["$AB\\parallel DC$: "+rets('180-108','180-94')+" for $A$ and $B$.","Half-angles: "+rets('72/2','86/2')+".","Angle $APB$: "+ret('180-72/2-86/2')+" (obtuse).","The obtuse angle is $101^\\circ$, option (@@L@@). (The other angle at $P$ is "+ret('180-101')+".)"];V[i]=ev('180-72/2-86/2')
i='GT-129'
L=[25,25,65,65,25,25,65,65]
S[i]=["Angles are $50$ and $130$; bisected: "+rets('50/2','(180-50)/2')+".","The eight small angles add to a full turn: "+ret('total([25,25,65,65,25,25,65,65])')+" (a full turn).","Spans of two or three: "+rets('25+25','25+65','65+65','25+25+65','25+65+65')+".","The values $130$, $155$ and $115$ occur; $140$ does not. Option (@@L@@)."]
i='GT-141'
S[i]=["Coordinates $A=(2,2\\sqrt3)$, $C=(4,0)$, $D=(1,0)$. Cross product of $\\vec{AC}=(2,-2\\sqrt3)$ and $\\vec{AD}=(-1,-2\\sqrt3)$: "+ret('abs(2*(-2*sqrt(3))-(-2*sqrt(3))*(-1))')+".",
 "Dot product: "+ret('2*(-1)+(-2*sqrt(3))*(-2*sqrt(3))')+".","Tangent: "+ret('abs(2*(-2*sqrt(3))-(-2*sqrt(3))*(-1))/(2*(-1)+(-2*sqrt(3))*(-2*sqrt(3)))')+".","Match to the options: "+ret('3*sqrt(3)/5')+" (option (@@L@@)); the others give "+rets('5*sqrt(3)/9','3*sqrt(3)/7','sqrt(3)/7')+"."];V[i]=ev('3*sqrt(3)/5')
i='GT-147'
x,y,t=lin(i,'4x-10','2x+30')
S[i]=["Corresponding angles: $\\angle ADE=\\angle ABC$. "+t,"Angles $B$ and $C$: "+rets(sub('2x+30',x),sub('x+25',x))+".","$\\angle BAC$: "+ret('180-70-45')+", option (@@L@@)."];V[i]=ev('180-70-45')
i='GT-152'
x,y,t=tap(i,'1800/x-15','180-540/x',1,100)
S[i]=["With $x+3=\\dfrac{180}{n}$ and $10x+15=180-\\dfrac{540}{n}$, eliminating $x$ gives $\\dfrac{1800}{n}-15=180-\\dfrac{540}{n}$. "+t,"So $n=%s$."%n(x),"Check the angles: "+rets('180/12','180-540/12','10*(180/12-3)+15')+" (the last two agree). Option (@@L@@)."];V[i]=x
i='GT-160'
xa,ya=inter(i,'(x/2)*(2*120+(x-1)*5)','180*(x-2)',5,12);xb,yb=inter(i,'(x/2)*(2*120+(x-1)*5)','180*(x-2)',12,30)
S[i]=["Sum of the angles: $\\frac n2(2\\cdot120+(n-1)5)$; the polygon sum is $180(n-2)$. Type %s and %s."%(c('y=(x/2)(2*120+(x-1)*5)'),c('y=180(x-2)')),
 "Tap both intersections: %s and %s, so $n=%s$ or $n=%s$."%(pt(xa,ya),pt(xb,yb),n(xa),n(xb)),
 "Largest angle for each: "+rets('120+5*(16-1)','120+5*(9-1)')+".","Convex needs every angle under $180$, so reject $16$ and keep $n=9$, option (@@L@@)."];V[i]=xa
i='GT-161'
x,y,t=lin(i,'(2x+4)+(3(2x+4)+4)','180')
S[i]=[t,"Acute and obtuse angles: "+rets(sub('2x+4',x),'3*44+4')+".","Sums of two angles: "+rets('44+44','44+136','136+136')+".","$224$ is not among them, so it cannot be a sum, option (@@L@@)."];V[i]=224
i='GT-162'
x,y,t=lin(i,'(3x+11)+(2x+4)+30','180')
S[i]=[t,"Angles $A$ and $B$: "+rets(sub('3x+11',x),sub('2x+4',x))+".","The two factors: "+rets('sin(92 deg)*cos(58 deg)+cos(92 deg)*sin(58 deg)','cos(92 deg)*cos(58 deg)-sin(92 deg)*sin(58 deg)')+", and their product is "+ret('0.5*(-sqrt(3)/2)')+".","Compare with option (@@L@@): "+ret('-sqrt(3)/4')+"."];V[i]=ev('-sqrt(3)/4')
i='GT-213'
x,y,t=lin(i,'6x-8','4x+12')
S[i]=["Alternate interior angles are equal. "+t,"Each angle: "+ret(sub('6x-8',x))+" degrees.","Check: "+ret(sub('4x+12',x))+"."];V[i]=ev(sub('6x-8',x))
i='GT-214'
x,y,t=lin(i,'8x-6','(3x+14)+(2x+19)')
S[i]=["Exterior angle = sum of remote interior angles. "+t,"Exterior angle: "+ret(sub('8x-6',x))+" degrees.","Check the remote sum: "+ret(sub('(3x+14)+(2x+19)',x))+"."];V[i]=ev(sub('8x-6',x))
i='GT-215'
x,y,t=lin(i,'(4x-10)+2(x+20)','180')
S[i]=[t,"Vertex angle: "+ret(sub('4x-10',x))+" degrees.","Base angle and sum check: "+rets(sub('x+20',x),'90+45+45')+"."];V[i]=ev(sub('4x-10',x))
i='GT-216'
x,y,t=tap(i,'10/16*x','15',1,200)
S[i]=["$AB=AD+DB$: "+ret('10+6')+". With $DE\\parallel BC$, $\\dfrac{AD}{AB}=\\dfrac{AE}{AC}$, so $AE=\\frac{10}{16}AC$.","Type the ratio and $AE=15$: "+t[:t.index('Tap')]+"Tap the intersection: %s, so $AC=%s$."%(pt(x,y),n(x)),"$EC=AC-AE$: "+ret('24-15')+"."];V[i]=ev('24-15')
i='GT-217'
x,y,t=lin(i,'2x+3x','20')
S[i]=["Angle bisector theorem: $BD:DC=12:18=2:3$, so $BD=2k$, $DC=3k$ with $5k=20$. "+t,"$BD$ and $DC$: "+rets(sub('2x',x),sub('3x',x))+".","The longer segment is $12$."];V[i]=ev(sub('3x',x))
i='GT-218'
x,y,t=tap(i,'180(x-2)/x','140',3,200)
S[i]=["Each interior angle of a regular $n$-gon is $\\dfrac{180(n-2)}{n}$. "+t,"The number of sides is $n=%s$."%n(x),"Check via exterior angles: "+rets('180-140','360/40')+"."];V[i]=x
i='GT-219'
S[i]=["The midsegment is the average of the bases: "+ret('mean([10,24])')+".","Check: "+rets('10+24','(10+24)/2')+".","Option (@@L@@)."];V[i]=ev('mean([10,24])')
i='GT-220'
S[i]=["Triangle inequality bounds: "+rets('12-7','12+7')+", so $5<t<19$.","Count the integers $6$ to $18$: "+ret('18-6+1')+".","Let Desmos count them: "+ret('length([6...18])')+"."];V[i]=13
i='GT-221'
x,y,t=lin(i,'1/2*8*x','20')
S[i]=["Area $=\\frac12(8)(k)$ with the $x$-coordinate $3$ not mattering. "+t,"So $k=%s$."%n(x),"Check the area: "+ret('1/2*8*5')+"."];V[i]=x
i='GT-222'
S[i]=["Base angles of $ABC$: "+ret('(180-40)/2')+".","In triangle $BCD$ ($BD=BC$): angle $CBD$ is "+ret('180-2*70')+".","$\\angle ABD$: "+ret('70-40')+"."];V[i]=ev('70-40')
# ============ Right triangles and trigonometry ============
i='GT-001'
S[i]=["Angle $A$ in degrees: "+ret('arcsin(3/5)*180/pi')+".","Angle $B$ (complementary): "+ret('90-36.8699')+".","$\\cos B$: "+ret('cos(53.1301 deg)')+".","This equals "+ret('3/5')+", so $\\cos B=\\sin A$. Option (@@L@@)."];V[i]=ev('3/5')
i='GT-002'
xx,yy,t=tap(i,'x*tan(60 deg)','(x+50)*tan(30 deg)',1,500)
S[i]=["Let $x$ be the distance to the base and $y$ the height. Type the two sight lines. "+t[t.index('Type'):] ,
 "Read the tapped point: distance $%s$ and height $%s$."%(n(xx),n(yy)),"Check with an exact value: "+ret('25*sqrt(3)')+".","Round to the nearest tenth: "+ret('round(25*sqrt(3),1)')+"."];V[i]=ev('round(25*sqrt(3),1)')
i='GT-003'
S[i]=["Law of Cosines: "+ret('7^2+8^2-2*7*8*cos(120 deg)')+" for $c^2$.","Take the square root: "+ret('sqrt(7^2+8^2-2*7*8*cos(120 deg))')+".","Option (@@L@@)."];V[i]=ev('sqrt(7^2+8^2-2*7*8*cos(120 deg))')
i='GT-014'
S[i]=["Angle $D$: "+ret('arctan(8/15)*180/pi')+" degrees.","Angle $E=90-D$: "+ret('90-28.0725')+".","$\\tan E$: "+ret('tan(61.9275 deg)')+".","Compare with "+ret('15/8')+". Option (@@L@@)."];V[i]=ev('15/8')
i='GT-017'
S[i]=["Missing leg: "+ret('sqrt(25^2-7^2)')+".","$\\sin J$: "+ret('24/25')+".","Identity check: "+ret('(24/25)^2+(7/25)^2')+". Option (@@L@@)."];V[i]=ev('24/25')
i='GT-023'
S[i]=["Adjacent side: "+ret('sqrt(13^2-5^2)')+".","$\\tan\\theta$: "+ret('5/12')+".","Direct check: "+ret('tan(arcsin(5/13))')+". Option (@@L@@)."];V[i]=ev('5/12')
i='GT-025'
S[i]=["The hypotenuse is twice the short side: "+ret('2*7')+".","Check with sine: "+ret('7/sin(30 deg)')+".","Long leg check: "+ret('sqrt(14^2-7^2)')+" equals "+ret('7*sqrt(3)')+". Option (@@L@@)."];V[i]=14
i='GT-030'
S[i]=["Evaluate each term: "+rets('cos(60 deg)','sin(30 deg)')+".","Add them: "+ret('cos(60 deg)+sin(30 deg)')+".","Option (@@L@@)."];V[i]=1
i='GT-042'
S[i]=["$DC=\\cos C\\cdot AC$: "+ret('0.75*48')+".","$BC=\\cos C\\cdot DC$: "+ret('0.75*36')+".","Check with the angle: "+ret('arccos(0.75)*180/pi')+" degrees for $C$, then "+ret('36*cos(41.4096 deg)')+"."];V[i]=ev('0.75*36')
N|={'PS-041','PS-042','PS-045','GT-025','GT-030','GT-049'}
