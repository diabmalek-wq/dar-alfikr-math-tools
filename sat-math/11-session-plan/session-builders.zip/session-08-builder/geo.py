"""Geometry helpers shared by figs.py and solve.py. Coordinates are built from the numbers in the stems."""
import math, numpy as np
def P(*a): return np.array(a,float)
def ang(v): return math.degrees(math.atan2(v[1],v[0]))
def angle_at(V,A,B):
    """unsigned angle AVB in degrees"""
    a=np.array(A,float)-V; b=np.array(B,float)-V
    return math.degrees(math.acos(np.clip(a@b/np.linalg.norm(a)/np.linalg.norm(b),-1,1)))
def dist(A,B): return float(np.linalg.norm(np.array(A,float)-np.array(B,float)))
def shoelace(pts):
    s=0
    for i in range(len(pts)):
        x1,y1=pts[i];x2,y2=pts[(i+1)%len(pts)];s+=x1*y2-x2*y1
    return abs(s)/2
def polar(deg,r=1.0): return np.array([r*math.cos(math.radians(deg)),r*math.sin(math.radians(deg))])
def interior_angles(pts):
    n=len(pts);return [angle_at(np.array(pts[i],float),pts[i-1],pts[(i+1)%n]) for i in range(n)]
def line_isect(p,d,q,e):
    """intersection of p+t d and q+s e"""
    M=np.array([d,-np.array(e)]).T; t,s=np.linalg.solve(M,np.array(q)-np.array(p)); return np.array(p)+t*np.array(d)

# ---- GT-124 pentagon: interior angles A=6x, B=5x+5, C=3x+15, D=7x-10 with x=20; AB parallel to DC
def g124(x=20):
    A,B,C,D=6*x,5*x+5,3*x+15,7*x-10; E=540-(A+B+C+D)
    d=[0.0]; # direction of each side, turning left by the exterior angle
    dirs=[0.0]
    for ia in (B,C,D,E): dirs.append(dirs[-1]+180-ia)
    # sides AB=6 (given scale), BC=8, CD=5; solve DE and EA lengths for closure
    L=[6.0,8.0,5.0,None,None]
    known=sum(L[i]*polar(dirs[i]) for i in range(3))
    M=np.array([polar(dirs[3]),polar(dirs[4])]).T
    L[3],L[4]=np.linalg.solve(M,-known)
    pts=[P(0,0)]
    for i in range(4): pts.append(pts[-1]+L[i]*polar(dirs[i]))
    return pts,(A,B,C,D,E)
# ---- GT-126 trapezoid: AB || DC, D=108, C=94; AB=9, height 5.6
def g126(Dd=108,Cd=94,AB=9.0,h=5.6):
    A=P(0,0);B=P(AB,0)
    angA=180-Dd; angB=180-Cd
    D=A+polar(angA,h/math.sin(math.radians(angA))); C=B+polar(180-angB,h/math.sin(math.radians(angB)))
    PP=line_isect(A,polar(angA/2),B,polar(180-angB/2))
    return A,B,C,D,PP,angA,angB
