"""Parse the 61 Session-8 items from the bank + CSV, apply context cleaning and the recorded fixes/edits, write s8_items.json."""
import re,csv,json
BANK='/home/claude/repo-check2/sat-bank/verified-item-bank/SAT_Bank_Verified_Item_Bank.md'
CSV='/home/claude/cb/session_plan_11.csv'
txt=open(BANK).read()
B={}
for b in re.split(r'\n(?=### )',txt):
    m=re.match(r'### (\S+)',b)
    if m: B[m.group(1)]=b
rows=[r for r in csv.DictReader(open(CSV)) if r['session']=='8']
def parse(b):
    fmt='MCQ' if re.search(r'Multiple Choice',b) else 'SPR'
    q=re.search(r'\*\*Question:\*\*\s*(.*?)(?=\n\*\*(?:Figure|Correct Answer|Tool)|\Z)',b,re.S).group(1).strip()
    a=re.search(r'\*\*Correct Answer:\*\*\s*(.+)',b).group(1).strip()
    lines=q.split('\n');stem=[];opts=[]
    for ln in lines:
        m=re.match(r'^\(?([A-D])\)\s*(.*)$',ln.strip())
        if m and (opts or m.group(1)=='A'): opts.append(m.group(2).strip())
        elif opts and ln.strip()=='': continue
        elif opts: opts[-1]+=' '+ln.strip()
        else: stem.append(ln)
    if not opts and fmt=='MCQ':
        pre=b.split('**Correct Answer:**')[0]
        for ln in pre.split('\n'):
            m=re.match(r'^\(([A-D])\)\s*(.*)$',ln.strip())
            if m: opts.append(m.group(2).strip())
    stem='\n'.join(stem).strip()
    stem=re.sub(r'^\[Figure:.*?\]\s*','',stem,flags=re.S)   # figures are redrawn in TikZ
    stem=stem.replace('°','^\\circ')
    return fmt,stem,opts,a
items=[]
for r in rows:
    fmt,stem,opts,a=parse(B[r['id']])
    items.append(dict(id=r['id'],part=r['part'],d=r['difficulty'],fmt=fmt,q=stem,opts=opts if fmt=='MCQ' else None,bank_ans=a))
J={o['id']:o for o in items}
def rep(i,a,b,cnt=1):
    assert J[i]['q'].count(a)==cnt,(i,a,J[i]['q'])
    J[i]['q']=J[i]['q'].replace(a,b)
def setq(i,q): J[i]['q']=q
def setopts(i,o): J[i]['opts']=o
# ---------- context cleaning (math unchanged) ----------
rep('PS-038','A household water-conservation study in Riyadh recorded','A household water-conservation study recorded')
rep('PS-039','the distance in kilometers from the Jeddah Corniche','the distance in kilometers from a city\'s central waterfront')
rep('PS-040','at a NEOM pilot site','at a pilot site')
rep('PS-041','A desalination plant\'s storage tank','A water-treatment plant\'s storage tank')
rep('PS-042','A scatterplot shows GAT preparation hours','A scatterplot shows exam-preparation hours')
rep('PS-045','in SAR, provided to households in a Vision 2030 efficiency pilot program','in dollars, provided to households in an energy-efficiency pilot program')
setopts('PS-045',['The estimated subsidy increases by $\\$18.6$ each year.','The estimated subsidy decreases by $\\$18.6$ each year.','The estimated subsidy decreases by $\\$340$ each year.','The estimated initial subsidy was $\\$18.6$.'])
setq('PS-046','Sam deposits $\\$800$ into Account A, which earns $5\\%$ interest compounded annually. Sam also deposits $\\$1{,}500$ into Account B, whose balance increases by a fixed $\\$40$ each year. Based on these growth patterns, which of the following best describes the long-term behavior of the balances of Account A and Account B?')
setq('GT-048','At a certain time of day, a $6$-meter flagpole casts a shadow that is $4$ meters long. At the same time, a nearby building casts a shadow that is $30$ meters long. What is the height, in meters, of the building?')
rep('GT-002','Engineers surveying a proposed tower near King Abdullah Financial District measure','Engineers surveying a proposed tower measure')
rep('GT-003','A triangular plot of land has','A triangular plot of land has')
# ---------- stems whose bank text said "In a figure" without a description: fully specify the figure ----------
setq('GT-033','In the figure shown, $a$, $b$ and $c$ are the three interior angles of a triangle, with $a=3c$. Side $PQ$ of the triangle is extended through $Q$, and the angle $d$ that this extension makes with the side at $Q$ measures $112^\\circ$, so $b$ and $d$ together form a straight line. What is the value of $a+b$?')
setq('GT-035','In the figure shown, two isosceles triangles share the vertex $R$. In the top triangle, the vertex angle is $c$ and each of its two equal base angles measures $40^\\circ$. In the bottom triangle, the vertex angle $b$ is at $R$ and equals half of $c$. Angle $a$ is formed by extending the base of the bottom triangle, so $a$ is supplementary to one of the bottom triangle\'s two equal base angles. What is the value of $a$, in degrees?')
# ---------- near-duplicate / flawed-item edits (recorded as FIXES / CHANGES in the report) ----------
# GT-042: bank says B on segment AD with a right angle at B, which is impossible (CB and CD would both be perpendicular to AD). B must lie on the hypotenuse AC.
setq('GT-042','In the figure shown, right triangle $ACD$ has a right angle at $D$, and right triangle $BCD$, with $B$ on segment $AC$, has a right angle at $B$. Both triangles share angle $C$. If $\\cos C = 0.75$ and $AC = 48$, what is the length of $BC$?')
# near-duplicates inside the session (numbers changed, item kept, answer re-derived and re-verified in solve.py)
setq('GT-063','Line $\\ell$ is parallel to line $m$, and a transversal crosses both lines. One angle formed at line $\\ell$ measures $(4x + 5)^\\circ$, and the corresponding angle formed at line $m$ measures $(6x - 21)^\\circ$. What is the value of $x$?')
setopts('GT-063',['$11$','$13$','$15$','$18$'])
setq('GT-213','Two parallel lines are cut by a transversal. A pair of alternate interior angles measure $(6x-8)^\\circ$ and $(4x+12)^\\circ$. What is the measure, in degrees, of each of these angles?')
setq('GT-064','In triangle $ABC$, the exterior angle at vertex $C$ measures $(7x - 12)^\\circ$. This exterior angle equals the sum of the two non-adjacent interior angles, which measure $(3x + 8)^\\circ$ and $(2x + 16)^\\circ$. What is the value of $x$?')
setq('GT-214','An exterior angle of a triangle measures $(8x-6)^\\circ$. The two remote interior angles measure $(3x+14)^\\circ$ and $(2x+19)^\\circ$. What is the measure, in degrees, of the exterior angle?')
setq('GT-020','In triangle $ABC$, the measure of angle $A$ is twice the measure of angle $B$, and the measure of angle $C$ is $24^\\circ$ more than the measure of angle $B$. What is the measure of angle $A$, in degrees?')
setopts('GT-020',['$39$','$52$','$78$','$87$'])
setq('GT-082','A triangle has side lengths of $9$, $14$, and $x$, where $x$ is an integer. What is the greatest possible value of $x$?')
setopts('GT-082',['$21$','$22$','$23$','$24$'])
setq('GT-216','In triangle $ABC$, point $D$ lies on $\\overline{AB}$ and point $E$ lies on $\\overline{AC}$ such that $\\overline{DE}$ is parallel to $\\overline{BC}$. If $AD=10$, $DB=6$ and $AE=15$, what is the length of $\\overline{EC}$?')
setq('GT-098','In triangle $ABC$, sides $AC$ and $AB$ are congruent. Points $D$, $C$, and $B$ are collinear, with $C$ between $D$ and $B$. If the measure of angle $DCA$ is $112^\\circ$, what is the measure, in degrees, of angle $A$?')
# PS-044: options are tables
def tb(ys): return '{\\renewcommand{\\arraystretch}{1.15}\\begin{tabular}{|c|c|c|c|c|}\\hline $x$ & $1$ & $2$ & $3$ & $4$ \\\\ \\hline $y$ & '+' & '.join('$%d$'%y for y in ys)+' \\\\ \\hline\\end{tabular}}'
setq('PS-044','In which of the following tables is the relationship between the values of $x$ and their corresponding $y$-values nonlinear?')
setopts('PS-044',[tb([5,9,13,17]),tb([2,4,6,8]),tb([5,10,15,20]),tb([3,6,12,24])])
# PS-043: table in stem
setq('PS-043','The table shows the age $x$, in years, and the efficiency loss $y$, in percent, for a sample of rooftop solar panels.\n\n'+'\\begin{center}\\renewcommand{\\arraystretch}{1.5}\\begin{tabular}{|c|c|c|c|c|c|}\\hline $x$ & $1$ & $2$ & $3$ & $4$ & $5$ \\\\ \\hline $y$ & $3.5$ & $6.0$ & $8.6$ & $11.0$ & $13.4$ \\\\ \\hline\\end{tabular}\\end{center}\n\nWhich of the following equations could be the line of best fit for the data?')
# GT-089/-051 etc keep bank text. Clean leftover bank-style tex in options
for o in items:
    if o['opts']:
        o['opts']=[re.sub(r'^\$\{(\d+)\}\^\{\\circ\}\$',r'$\1^\\circ$',x).replace('{48}','48').replace('{63}','63').replace('{69}','69').replace('{117}','117') for x in o['opts']]
        o['opts']=[x.replace('${','$').replace('^{\\circ}','^\\circ') if False else x for x in o['opts']]
for i in ('GT-049','GT-050','GT-051'):
    if J[i]['q']: J[i]['q']=re.sub(r'\$?\{(\d+)\}\^\{\\circ\}\$?',r'$\1^\\circ$',J[i]['q'])
    if J[i]['opts']: J[i]['opts']=[re.sub(r'\{(\d+)\}\^\{\\circ\}',r'\1^\\circ',x) for x in J[i]['opts']]
json.dump(items,open('s8_items.json','w'),indent=1)
for o in items: print(o['id'],o['part'][:2],o['d'][0],o['fmt'],'|',o['q'][:90].replace('\n',' '),'|',o['opts'] and [x[:25] for x in o['opts']],'|',o['bank_ans'][:30])
