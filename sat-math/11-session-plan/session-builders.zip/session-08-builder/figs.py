"""TikZ figures for Session 8.  Every figure is drawn from the same numbers as the stem (coordinates from geo.py)."""
import math, numpy as np
from figlib import FIGSTYLE
from geo import *
def f_(v): return "%.3f"%v
def pt_(p): return "(%s,%s)"%(f_(p[0]),f_(p[1]))
def wrap(body,u=1.0): return r"\begin{center}\begin{tikzpicture}[x=%scm,y=%scm]"%(u,u)+FIGSTYLE+body+r"\end{tikzpicture}\end{center}"
POLY="BLUE,very thick,line join=round"
def poly(pts,style=POLY): return r"\draw[%s] "%style+" -- ".join(pt_(p) for p in pts)+" -- cycle;\n"
def seg(p,q,style="BLUE,very thick"): return r"\draw[%s] %s -- %s;"%(style,pt_(p),pt_(q))+"\n"
def node(p,t,anchor="center",font=r"\small",extra=""): return r"\node[%s,anchor=%s,font=%s%s] at %s {%s};"%("inner sep=1pt",anchor,font,extra,pt_(p),t)+"\n"
def vlab(p,name,cen,d=0.38): 
    u=np.array(p,float)-np.array(cen,float);u=u/np.linalg.norm(u);return node(np.array(p)+d*u,"$%s$"%name)
def arc(O,a0,a1,r,style="ORANGE,thick"):
    O=np.array(O,float);s=O+r*polar(a0);return r"\draw[%s] %s arc (%s:%s:%s);"%(style,pt_(s),f_(a0),f_(a1),f_(r))+"\n"
def rt(V,u,v,s=0.3):
    V=np.array(V,float);u=np.array(u,float)/np.linalg.norm(u);v=np.array(v,float)/np.linalg.norm(v)
    return r"\draw[INK,thin] %s -- %s -- %s;"%(pt_(V+s*u),pt_(V+s*(u+v)),pt_(V+s*v))+"\n"
def tick(p,q,n=1,s=0.12):
    p=np.array(p,float);q=np.array(q,float);m=(p+q)/2;d=(q-p)/np.linalg.norm(q-p);nrm=np.array([-d[1],d[0]]);o=""
    for k in range(n):
        c=m+(k-(n-1)/2)*0.12*d;o+=r"\draw[INK,thin] %s -- %s;"%(pt_(c-s*nrm),pt_(c+s*nrm))+"\n"
    return o
def para(p,q,n=1,s=0.12):
    p=np.array(p,float);q=np.array(q,float);d=(q-p)/np.linalg.norm(q-p);nrm=np.array([-d[1],d[0]]);m=(p+q)/2;o=""
    for k in range(n):
        c=m+(k-(n-1)/2)*0.2*d;o+=r"\draw[INK,thin] %s -- %s -- %s;"%(pt_(c-s*d+s*nrm),pt_(c+s*d*0.0),pt_(c-s*d-s*nrm))+"\n"
    return o
def mid(p,q,t=0.5): return np.array(p,float)*(1-t)+np.array(q,float)*t
def outside(p,q,cen,d=0.3):
    m=mid(p,q);dd=np.array(q,float)-np.array(p,float);nrm=np.array([-dd[1],dd[0]]);nrm/=np.linalg.norm(nrm)
    if nrm@(m-np.array(cen,float))<0: nrm=-nrm
    return m+d*nrm

def arcb(O,A,B,r,style="ORANGE,thick"):
    """arc at O between rays toward A and B (the smaller angle); returns (tikz, mid-direction in degrees)"""
    O=np.array(O,float);a=ang(np.array(A,float)-O);b=ang(np.array(B,float)-O);d=(b-a+180)%360-180
    return arc(O,a,a+d,r,style),a+d/2
def arcd(O,a,b,r,style="ORANGE,thick"):
    d=(b-a+180)%360-180;return arc(O,a,a+d,r,style),a+d/2

def F_GT011():
    t=70;yl=2.2;x0=-0.4;Xm=P(x0,0);Xl=P(x0+yl/math.tan(math.radians(t)),yl)
    b=seg(P(-3,0),P(3.6,0))+seg(P(-3,yl),P(3.6,yl))
    b+=seg(Xm-1.0*polar(t),Xl+1.0*polar(t),"INK,thick")
    b+=node(P(3.9,0),"$m$")+node(P(3.9,yl),r"$\ell$")+node(Xl+1.25*polar(t),"$t$")
    for X,lab in ((Xl,r"$(3x+10)^\circ$"),(Xm,r"$(5x-30)^\circ$")):
        b+=arc(X,0,t,0.55)+node(X+1.0*polar(t/2-12),lab,"west")
    b+=para(P(1.2,0),P(1.8,0))+para(P(1.2,yl),P(1.8,yl))
    return wrap(b,0.85)
def F_GT012():
    Q=P(0,0);Rr=P(36,0);cp=(16**2+36**2-40**2)/(2*16*36);Pp=Q+16*polar(math.degrees(math.acos(cp)))
    s=0.17;Q,Rr,Pp=Q*s,Rr*s,Pp*s
    S=Pp+(Q-Pp)*6/16;T=Pp+(Rr-Pp)*15/40;cen=(Q+Rr+Pp)/3
    b=poly([Pp,Q,Rr])+seg(S,T,"ORANGE,very thick")
    b+=para(S,T)+para(Q,Rr)
    for p,n in ((Pp,"P"),(Q,"Q"),(Rr,"R"),(S,"S"),(T,"T")): b+=vlab(p,n,cen,0.33)
    b+=node(outside(Pp,S,cen,0.38),"$x$")+node(outside(S,Q,cen,0.55),"$x+4$")+node(outside(Pp,T,cen,0.32),"$15$")+node(outside(T,Rr,cen,0.32),"$25$")
    return wrap(b)
def F_GT013():
    Zv=P(0,0);Yv=P(8,0);X=8*polar(50);ext=X+3.0*polar(50);cen=(Zv+Yv+X)/3
    b=poly([Zv,Yv,X])+seg(X,ext,"BLUE,very thick")
    for p,n in ((Zv,"Z"),(Yv,"Y")): b+=vlab(p,n,cen)
    b+=node(X+0.45*polar(130),"$X$")
    b+=arc(Zv,0,50,0.9)+node(Zv+P(-0.15,0.85),r"$(x+25)^\circ$","east")
    b+=arc(Yv,115,180,0.9)+node(Yv+P(0.25,0.75),r"$(2x+15)^\circ$","west")
    b+=arc(X,-65,50,0.8)+node(X+1.15*polar(-8),r"$(5x-10)^\circ$","west")
    return wrap(b,0.62)
def F_GT031():
    A=P(0,0);C=P(15,0);B=P(5.4,-7.2);D=P(0,8);cen=(A+B+C+D)/4
    b=poly([A,B,C,D])+seg(A,C,"BLUE,dashed,thick")
    b+=rt(B,A-B,C-B,1.0)+rt(A,C-A,D-A,1.0)
    for p,n in ((B,"B"),(C,"C"),(D,"D")): b+=vlab(p,n,cen,1.3)
    b+=node(A+P(-1.5,-0.9),"$A$")+node(outside(A,B,cen,1.3),"$9$")+node(outside(B,C,cen,1.3),"$12$")+node(outside(A,D,cen,1.3),"$8$")
    return wrap(b,0.3)
def F_GT033():
    Rv=P(0,0);Pv=P(8,0);RQ=8*math.sin(math.radians(28))/math.sin(math.radians(68));Q=Rv+RQ*polar(84)
    u=(Q-Pv)/np.linalg.norm(Q-Pv);ext=Q+3.2*u;cen=(Rv+Pv+Q)/3
    b=poly([Rv,Pv,Q])+seg(Q,ext,"BLUE,very thick")
    for p,n in ((Rv,"R"),(Pv,"P")): b+=vlab(p,n,cen,0.4)
    b+=node(Q+0.42*polar(80),"$Q$")
    t,m=arcb(Rv,Pv,Q,0.9);b+=t+node(Rv+1.4*polar(m),"$a$")
    t,m=arcb(Pv,Rv,Q,1.5);b+=t+node(Pv+2.0*polar(m),"$c$")
    t,m=arcb(Q,Rv,Pv,0.8);b+=t+node(Q+1.25*polar(m),"$b$")
    t,m=arcb(Q,Rv,ext,0.8);b+=t+node(Q+1.3*polar(m),"$d$")
    return wrap(b,0.62)
def F_GT035():
    Rv=P(0,0);Lv=P(-7,0);T=P(-3.5,3.5*math.tan(math.radians(40)));bd=50
    U=Rv+4*polar(270-bd/2);V=Rv+4*polar(270+bd/2);ext=V+2.2*(V-U)/np.linalg.norm(V-U)
    cen1=(Lv+Rv+T)/3;cen2=(Rv+U+V)/3
    b=poly([Lv,Rv,T])+poly([Rv,U,V])+seg(V,ext)
    b+=tick(T,Lv)+tick(T,Rv)+tick(Rv,U,2)+tick(Rv,V,2)
    b+=vlab(T,"",cen1,0.1)+node(T+P(0,0.35),"$T$")+vlab(Lv,"L",cen1,0.38)+node(Rv+P(0.4,0.3),"$R$")+vlab(U,"U",cen2,0.38)+vlab(V,"V",cen2,0.38)
    t,m=arcb(T,Lv,Rv,0.75);b+=t+node(T+1.2*polar(m),"$c$")
    t,m=arcb(Lv,Rv,T,1.0);b+=t+node(Lv+P(1.55,0.28),r"$40^\circ$")
    t,m=arcb(Rv,Lv,T,0.9);b+=t+node(Rv+P(-1.65,0.35),r"$40^\circ$")
    t,m=arcb(Rv,U,V,0.8);b+=t+node(Rv+1.2*polar(m),"$b$")
    t,m=arcb(V,Rv,ext,0.8);b+=t+node(V+1.25*polar(m),"$a$")
    return wrap(b,0.62)
def F_GT042():
    s=7/48;C=P(0,0);A=P(48*s,0);Cd=math.acos(0.75);D=C+36*s*polar(math.degrees(Cd));B=P(D[0],0);cen=(A+C+D)/3
    b=poly([C,A,D])+seg(D,B,"BLUE,very thick")
    b+=rt(D,C-D,A-D,0.3)+rt(B,D-B,A-B,0.3)
    for p,n in ((A,"A"),(C,"C"),(D,"D")): b+=vlab(p,n,cen,0.4)
    b+=node(B+P(0,-0.4),"$B$")+node(mid(B,A)+P(0,-0.4),"$48$")
    return wrap(b,1.0)
def F_GT124():
    pts,_=g124(20);cen=sum(pts)/5
    b=poly(pts)+para(pts[0],pts[1])+para(pts[3],pts[2],1)
    for p,n in zip(pts,"ABCDE"): b+=vlab(p,n,cen,0.4)
    return wrap(b,0.5)
def F_GT126():
    A,B,C,D,PP,angA,angB=g126();cen=(A+B+C+D)/4
    b=poly([A,B,C,D])+seg(A,PP,"ORANGE,thick")+seg(B,PP,"ORANGE,thick")+para(A,B)+para(D,C)
    for p,n in ((A,"A"),(B,"B"),(C,"C"),(D,"D")): b+=vlab(p,n,cen,0.4)
    b+=node(PP+P(0,0.3),"$P$")
    return wrap(b,0.55)
def _rtri(Rp,Ap,Bp,names,u):
    cen=(Rp+Ap+Bp)/3
    b=poly([Rp,Ap,Bp])+rt(Rp,Ap-Rp,Bp-Rp,0.3)
    for p,n in zip((Rp,Ap,Bp),names): b+=vlab(p,n,cen,0.4)
    return wrap(b,u)
def F_GT001(): return _rtri(P(4,0),P(0,0),P(4,3),"CAB",0.8)
def F_GT014(): return _rtri(P(4.5,0),P(0,0),P(4.5,2.4),"FDE",0.9)
def F_GT017(): return _rtri(P(1.12,0),P(0,0),P(1.12,3.84),"LJK",0.8)
def F_GT002():
    s=0.1;d=25;h=d*math.sqrt(3);Fp=P(-(d+50)*s,0);Np=P(-d*s,0);Tp=P(0,h*s);Bp=P(0,0)
    b=seg(P(-8.0,0),P(0.9,0),"INK,thick")+seg(Bp,Tp,"BLUE,very thick")
    b+=seg(Fp,Tp,"ORANGE,thick")+seg(Np,Tp,"ORANGE,thick")+rt(Bp,P(-1,0),P(0,1),0.25)
    for p in (Fp,Np): b+=r"\node[pt] at %s {};"%pt_(p)+"\n"
    b+=node(Tp+P(0.35,0.0),"top")+node(Bp+P(0.3,-0.3),"base")
    t,m=arcb(Fp,Tp,Np,1.2);b+=t+node(Fp+P(1.55,0.28),r"$30^\circ$")
    t,m=arcb(Np,Tp,Bp,0.9);b+=t+node(Np+1.4*polar(m),r"$60^\circ$")
    b+=r"\draw[<->,thick,INK] %s -- %s;"%(pt_(Fp+P(0,-0.45)),pt_(Np+P(0,-0.45)))+"\n"+node(mid(Fp,Np)+P(0,-0.8),"$50$ m")
    b+=node(P(0.35,h*s/2),"$h$","west")
    return wrap(b,1.0)
def F_GT003():
    V0=P(0,0);A_=polar(0,8)*0.5;B_=polar(120,7)*0.5;cen=(V0+A_+B_)/3
    b=poly([V0,A_,B_])+arc(V0,0,120,0.7)+node(V0+1.15*polar(60),r"$120^\circ$")
    b+=node(outside(V0,A_,cen,0.38),"$8$ km")+node(outside(V0,B_,cen,0.62),"$7$ km")
    return wrap(b,1.0)
FIG={'GT-011':F_GT011,'GT-012':F_GT012,'GT-013':F_GT013,'GT-031':F_GT031,'GT-033':F_GT033,'GT-035':F_GT035,'GT-042':F_GT042,
     'GT-124':F_GT124,'GT-126':F_GT126,'GT-001':F_GT001,'GT-014':F_GT014,'GT-017':F_GT017,'GT-002':F_GT002,'GT-003':F_GT003}
