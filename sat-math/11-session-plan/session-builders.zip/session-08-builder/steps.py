"""Worked-solution steps for Session 8.  Every number quoted is computed here (or by ev()) from the stem numbers."""
import math, re
from fractions import Fraction as Fr
import numpy as np
from scipy.optimize import brentq
from geo import *
def n(v,d=4):
    s=('%.*f'%(d,v)).rstrip('0').rstrip('.'); return '0' if s in ('-0','') else s
def ev(expr,**kw):
    e=expr.replace('^','**'); e=re.sub(r'(\d|\))\s*(\(|[a-zA-Z])',r'\1*\2',e)
    return eval(e,{'__builtins__':{}},dict(sqrt=math.sqrt,abs=abs,ln=math.log,**kw))
def c(e): return '[[%s]]'%e
def v(x,d=4): return '$%s$'%n(x,d)
def ret(e,d=4,**kw): return "Type %s: it returns %s"%(c(e),v(ev(e,**kw),d))
def pt(x,y,d=4): return "$(%s,\\,%s)$"%(n(x,d),n(y,d))
def fr(f):
    f=Fr(f); return str(f.numerator) if f.denominator==1 else ('-' if f<0 else '')+'\\dfrac{%d}{%d}'%(abs(f.numerator),f.denominator)
def m(*a): return '$'+''.join(a)+'$'
S={};N=set();T={}   # steps, no-calculator ids, tool overrides ('C'/'D')
def deg(x): return '%s^\\circ'%n(x)
# ================= Problem Solving and Data Analysis =================
pred=12*10+20; act=155
S['PS-038']=["The line of best fit gives the predicted value. Substitute the given $x=10$ into $y=12x+20$.",
 "$y=12(10)+20=%d+%d=%d$ liters is the predicted water use."%(12*10,20,pred),
 "The actual water use was $%d$ liters. The positive difference is $%d-%d=%d$."%(act,act,pred,abs(act-pred))]
sl=(60-340)/(10-2)
S['PS-039']=["The slope is rise over run between the two points: $\\dfrac{y_2-y_1}{x_2-x_1}=\\dfrac{60-340}{10-2}$.",
 "The numerator is $%d$ and the denominator is $%d$, so the slope is $\\dfrac{%d}{%d}=%d$."%(60-340,10-2,60-340,10-2,sl),
 "The slope is negative because the visitor count falls as the distance grows. That is option (@@L@@); option $35$ drops the sign and $-28$ or $28$ come from a slip in the division."]
p40=45.2*8.4+12.5
S['PS-040']=["Substitute $x=8.4$ into $y=45.2x+12.5$. Multiply first, then add.",
 "$45.2\\times8.4=%s$. Then $%s+12.5=%s$."%(n(45.2*8.4,2),n(45.2*8.4,2),n(p40,2)),
 "Rounded to one decimal place, $%s\\approx%s$. That is option (@@L@@)."%(n(p40,2),n(round(p40,1),1))]
T['PS-040']='C'
d1=[1000-85*k for k in range(4)]; d2=[round(1000*0.9**k,1) for k in range(4)]
S['PS-041']=["A constant rate means the same amount leaves the tank every unit of time. Example: a $1000$-liter tank draining $85$ liters per hour holds $%s$ liters after $0,1,2,3$ hours. The drops are $%s$ each time (constant)."%(','.join(map(str,d1)),n(d1[0]-d1[1])),
 "Constant drops mean a linear model, and because the volume is going down the slope is negative.",
 "Exponential decay removes the same percent each time, so the drops get smaller: $10\\%%$ decay gives $%s$ liters with drops $%s$, $%s$, $%s$ (not constant)."%(','.join(n(x,1) for x in d2),n(d2[0]-d2[1],1),n(d2[1]-d2[2],1),n(d2[2]-d2[3],1)),
 "So the model is linear with a negative slope, option (@@L@@)."]
S['PS-042']=["The difference between the actual score and the predicted score is the actual value minus the predicted value (the vertical gap between the point and the line).",
 "The actual score is $%d$ and the predicted score is $%d$."%(96,89),
 "$%d-%d=%d$, so the point sits $%d$ points above the line. That is option (@@L@@)."%(96,89,96-89,96-89)]
xs=np.array([1,2,3,4,5.]);ys=np.array([3.5,6.0,8.6,11.0,13.4]);mm,bb=np.polyfit(xs,ys,1)
S['PS-043']=["Open a table and enter $x_1=1,2,3,4,5$ and $y_1=3.5,6,8.6,11,13.4$.",
 "Type %s: Desmos returns $m=%s$ and $b=%s$ (the line of best fit)."%(c('y_1~mx_1+b'),n(mm,2),n(bb,2)),
 "The slope is about $%s\\approx2.5$ and the intercept is about $%s\\approx1$, so the line is $y\\approx2.5x+1$, option (@@L@@)."%(n(mm,2),n(bb,2)),
 "Check the others: option $y=x+2.5$ has slope $1$, option $y=-2.5x+1$ slopes downward and option $y=2.5x-1$ has intercept $-1$, far from $%s$."%n(bb,2)]
tabs=[[5,9,13,17],[2,4,6,8],[5,10,15,20],[3,6,12,24]]
dif=[list(np.diff(t)) for t in tabs]
S['PS-044']=["A table is linear when $y$ changes by the same amount for every $1$-unit step in $x$. So check the differences between consecutive $y$-values.",
 "The first table gives $%s$, the second $%s$ and the third $%s$. Each is constant ($%d$, $%d$ and $%d$), so all three are linear."%(', '.join(map(str,dif[0])),', '.join(map(str,dif[1])),', '.join(map(str,dif[2])),dif[0][0],dif[1][0],dif[2][0]),
 "The fourth table gives $%s$, which are not equal (each $y$-value is double the one before: a constant ratio, not a constant difference), so it is nonlinear. That is option (@@L@@)."%', '.join(map(str,dif[3]))]
s1=[0,1,2,3]
S['PS-045']=["In $y=mx+b$ the slope $m$ is the change in $y$ for each $1$-unit increase in $x$. Here $x$ is years since $2018$ and $y$ is the subsidy in dollars.",
 "The slope is $m=-18.6$: from $x=0$ to $x=1$ the model goes from $%s$ to $%s$, a change of $%s$ dollars per year."%(n(-18.6*0+340),n(-18.6*1+340),n(-18.6)),
 "A negative change means the subsidy decreases by $\\$18.6$ each year. The number $340$ is the intercept: the estimated subsidy at $x=0$ (the year $2018$), not a rate. That is option (@@L@@)."]
N|={'PS-038','PS-039','PS-041','PS-042','PS-044','PS-045'}
ts=np.arange(0,400,0.001);gap=lambda t:800*1.05**t-(1500+40*t)
tcross=brentq(gap,5,60); tneg=brentq(gap,-80,-5)
S['PS-046']=["Let $x$ be the number of years. Account A is exponential: type %s. Account B is linear: type %s."%(c('y=800(1.05)^x'),c('y=1500+40x')),
 "Zoom out and tap the intersection with $x>0$: %s. (The other intersection has $x=%s<0$, which is not a time after the deposits.)"%(pt(tcross,800*1.05**tcross,2),n(tneg,1)),
 "At $x=0$ the values are $800$ and $1500$, so A starts lower. After about $%s$ years the exponential curve is above the line and stays above it, because exponential growth eventually outpaces any linear growth. That is option (@@L@@)."%n(tcross,1)]
T['PS-046']='D'
# ================= Geometry: lines, angles, triangles =================
x11=(-30-10)/(3-5)
S['GT-011']=["Corresponding angles formed by a transversal across parallel lines are equal, so $3x+10=5x-30$.",
 "Subtract $3x$ and add $30$ to both sides: $%d+%d=%dx-%dx$, so $%d=2x$."%(10,30,5,3,10+30),
 "Divide by $2$: $x=%s$."%n(x11),
 "Check: $3(%s)+10=%s$ and $5(%s)-30=%s$, equal as required. That is option (@@L@@)."%(n(x11),n(3*x11+10),n(x11),n(5*x11-30))]
x12=[x for x in range(1,100) if Fr(x,x+4)==Fr(15,25)][0]
S['GT-012']=["$ST\\parallel QR$, so triangle $PST$ is similar to triangle $PQR$ and the sides are proportional: $\\dfrac{PS}{SQ}=\\dfrac{PT}{TR}$.",
 "Substitute: $\\dfrac{x}{x+4}=\\dfrac{15}{25}=%s$."%fr(Fr(15,25)),
 "Cross-multiply: $5x=3(x+4)=3x+12$, so $2x=12$.",
 "$x=%d$. Check: $PS=%d$ and $SQ=%d$, and $\\dfrac{%d}{%d}=%s$."%(x12,x12,x12+4,x12,x12+4,fr(Fr(x12,x12+4)))]
x13=(40+10)/(5-3)
S['GT-013']=["The exterior angle equals the sum of the two remote interior angles: $5x-10=(2x+15)+(x+25)$.",
 "Combine: $5x-10=3x+40$, so $2x=%d$ and $x=%s$."%(40+10,n(x13)),
 "Angle $Y=2(%s)+15=%s^\\circ$."%(n(x13),n(2*x13+15)),
 "Check: the exterior angle is $5(%s)-10=%s^\\circ$ and $%s+%s=%s$."%(n(x13),n(5*x13-10),n(2*x13+15),n(x13+25),n(3*x13+40))]
x20=(180-24)/4
S['GT-020']=["Let angle $B=x$. Then angle $A=2x$ and angle $C=x+24$.",
 "The angles of a triangle add to $180^\\circ$: $2x+x+(x+24)=180$, so $4x+24=180$.",
 "$4x=%d$, so $x=%s$ and angle $A=2(%s)=%s^\\circ$."%(180-24,n(x20),n(x20),n(2*x20)),
 "Check: $%s+%s+%s=%s$. That is option (@@L@@); the value $%s$ is angle $B$, the other options come from answering for the wrong angle or an arithmetic slip."%(n(2*x20),n(x20),n(x20+24),n(2*x20+x20+x20+24),n(x20))]
S['GT-024']=["The exterior angles of any convex polygon add up to $360^\\circ$.",
 "In a regular polygon they are all equal, so the number of sides is $\\dfrac{360}{24}$.",
 "$\\dfrac{360}{24}=%d$ sides. That is option (@@L@@)."%(360//24)]
AC31=math.hypot(9,12)
S['GT-031']=["Triangle $ABC$ has a right angle at $B$ with legs $9$ and $12$, so $AC=\\sqrt{9^2+12^2}=\\sqrt{%d}=%s$."%(81+144,n(AC31)),
 "Its area is $\\dfrac12(9)(12)=%s$."%n(0.5*9*12),
 "Triangle $ACD$ has a right angle at $A$, so its legs are $AC=%s$ and $AD=8$, and its area is $\\dfrac12(%s)(8)=%s$."%(n(AC31),n(AC31),n(0.5*AC31*8)),
 "Add the two areas: $%s+%s=%s$. That is option (@@L@@)."%(n(0.5*9*12),n(0.5*AC31*8),n(0.5*9*12+0.5*AC31*8))]
b33=180-112;c33=(180-b33)/4;a33=3*c33
S['GT-033']=["Angles $b$ and $d$ form a straight line, so $b=180^\\circ-112^\\circ=%s^\\circ$."%n(b33),
 "The interior angles add to $180^\\circ$: $a+b+c=180$ with $a=3c$ and $b=%s$, so $3c+%s+c=180$ and $4c=%s$."%(n(b33),n(b33),n(180-b33)),
 "$c=%s^\\circ$ and $a=3(%s)=%s^\\circ$."%(n(c33),n(c33),n(a33)),
 "$a+b=%s+%s=%s$. That is option (@@L@@)."%(n(a33),n(b33),n(a33+b33))]
S['GT-034']=["Every exterior angle of a regular $n$-gon is $\\dfrac{360^\\circ}{n}$ (the exterior angles of a polygon sum to $360^\\circ$).",
 "Octagon: $\\dfrac{360}{8}=%s^\\circ$. Decagon: $\\dfrac{360}{10}=%s^\\circ$."%(n(360/8),n(360/10)),
 "The positive difference is $%s-%s=%s$."%(n(360/8),n(360/10),n(360/8-360/10))]
c35=180-40-40;b35=c35/2;base35=(180-b35)/2
S['GT-035']=["Top triangle: its base angles are $40^\\circ$, so $c=180-40-40=%s^\\circ$."%n(c35),
 "The bottom vertex angle is half of $c$: $b=\\dfrac{%s}{2}=%s^\\circ$."%(n(c35),n(b35)),
 "The bottom triangle is isosceles, so each base angle is $\\dfrac{180-%s}{2}=%s^\\circ$."%(n(b35),n(base35)),
 "Angle $a$ is supplementary to a base angle: $a=180-%s=%s^\\circ$."%(n(base35),n(180-base35))]
S['GT-048']=["The flagpole with its shadow and the building with its shadow form similar right triangles, so height over shadow is the same: $\\dfrac{6}{4}=\\dfrac{h}{30}$.",
 "Multiply both sides by $30$: $h=\\dfrac{6}{4}\\times30=%s\\times30$."%n(6/4,1),
 "$h=%s$ meters. Check: $\\dfrac{%s}{30}=%s=\\dfrac{6}{4}$."%(n(6/4*30),n(6/4*30),n(45/30,1))]
F49=180-48-63
S['GT-049']=["Similar triangles have equal corresponding angles, whatever the scale factor.",
 "$D\\leftrightarrow G$, $E\\leftrightarrow H$ and $F\\leftrightarrow I$, so angle $H$ equals angle $E=63^\\circ$.",
 "Check: angle $F=180-48-63=%s^\\circ$, so triangle $GHI$ has angles $48^\\circ$, $63^\\circ$ and $%s^\\circ$. That is option (@@L@@). (The value $%s^\\circ$ is angle $F$ and $%s^\\circ$ is $180-63$.)"%(n(F49),n(F49),n(F49),n(180-63))]
Cint50=180-130
S['GT-050']=["The exterior angle at $C$ equals the sum of the two remote interior angles: $130=\\angle A+\\angle B$.",
 "Substitute $\\angle A=55^\\circ$: $\\angle B=130-55=%s^\\circ$."%n(130-55),
 "Check with the angle sum: the interior angle at $C$ is $180-130=%s$, and $%s+%s+%s=%s$."%(n(Cint50),n(55),n(130-55),n(Cint50),n(55+130-55+Cint50))]
sums51=[(100,80),(95,85),(112,68),(95,84)]
S['GT-051']=["Same-side interior angles between parallel lines are supplementary: they must add to $180^\\circ$.",
 "Add each pair: $%s$, $%s$, $%s$ and $%s$."%tuple(('%d+%d=%d'%(p,q,p+q)) for p,q in sums51),
 "Only one sum differs from $180$: $95+84=%d$. That pair could NOT be same-side interior angles, option (@@L@@)."%(95+84)]
x62=(180+30)/6
S['GT-062']=["The three angles of a triangle add to $180^\\circ$: $x+2x+(3x-30)=180$.",
 "Combine like terms: $6x-30=180$, so $6x=%s$."%n(180+30),
 "$x=%s$. Check: the angles are $%s^\\circ$, $%s^\\circ$ and $%s^\\circ$, which add to $%s$. That is option (@@L@@)."%(n(x62),n(x62),n(2*x62),n(3*x62-30),n(x62+2*x62+3*x62-30))]
x63=(5+21)/(6-4)
S['GT-063']=["Corresponding angles across parallel lines are equal: $4x+5=6x-21$.",
 "Move the $x$ terms to one side and the numbers to the other: $5+21=6x-4x$, so $%s=2x$."%n(5+21),
 "$x=%s$. Check: $4(%s)+5=%s$ and $6(%s)-21=%s$. That is option (@@L@@)."%(n(x63),n(x63),n(4*x63+5),n(x63),n(6*x63-21))]
x64=(24+12)/(7-5)
S['GT-064']=["The exterior angle equals the sum of the two remote interior angles: $7x-12=(3x+8)+(2x+16)$.",
 "Combine on the right: $7x-12=5x+24$.",
 "$2x=%s$, so $x=%s$."%(n(24+12),n(x64)),
 "Check: the exterior angle is $7(%s)-12=%s^\\circ$ and the remote angles are $%s^\\circ$ and $%s^\\circ$, which add to $%s$."%(n(x64),n(7*x64-12),n(3*x64+8),n(2*x64+16),n(5*x64+24))]
r65=Fr(24,32)
S['GT-065']=["The pole with its shadow and the tower with its shadow form similar triangles, so height over shadow is constant. For the pole: $\\dfrac{2.4}{3.2}=%s$."%n(2.4/3.2,2),
 "Tower height $=%s\\times52$ (the tower's shadow)."%n(2.4/3.2,2),
 "$%s\\times52=%s$ meters. That is option (@@L@@)."%(n(2.4/3.2,2),n(2.4/3.2*52,1))]
T['GT-065']='C'
x81=(30-10)/(5-3)
S['GT-081']=["Vertical angles are equal: $5x+10=3x+30$.",
 "Subtract $3x$ and $10$: $2x=%s$."%n(30-10),
 "$x=%s$. Check: $5(%s)+10=%s$ and $3(%s)+30=%s$. That is option (@@L@@)."%(n(x81),n(x81),n(5*x81+10),n(x81),n(3*x81+30))]
S['GT-082']=["The triangle inequality says the third side must be less than the sum of the other two: $x<9+14=%d$."%(9+14),
 "$x$ is an integer and $x<%d$ (it cannot equal $%d$), so the greatest possible value is $%d$."%(9+14,9+14,9+14-1),
 "Check the other two inequalities: $9+%d=%d>14$ and $14+%d=%d>%d$. Option (@@L@@). (The value $%d$ is the sum, which would make a flat triangle.)"%(22,9+22,9,14+9,22,23)]
b83=(180-30)/3
S['GT-083']=["$AB=AC$, so the angles opposite them are equal: angle $B=$ angle $C$. Call each $b$.",
 "Angle $A=b+30$, and the three angles add to $180$: $(b+30)+b+b=180$.",
 "$3b=%s$, so $b=%s$ and angle $C=%s^\\circ$."%(n(150),n(b83),n(b83)),
 "Check: $A=%s^\\circ$ and $%s+%s+%s=%s$."%(n(b83+30),n(b83+30),n(b83),n(b83),n(b83+30+2*b83))]
x84=(8+2)/(6-5)
S['GT-084']=["The segment joining the midpoints of two sides is parallel to the third side and half as long: $MN=\\dfrac12BC$.",
 "$3x-4=\\dfrac12(5x+2)$. Multiply by $2$: $6x-8=5x+2$.",
 "$x=%s$, so $BC=5(%s)+2=%s$."%(n(x84),n(x84),n(5*x84+2)),
 "Check: $MN=3(%s)-4=%s$, which is half of $%s$. That is option (@@L@@)."%(n(x84),n(3*x84-4),n(5*x84+2))]
S['GT-089']=["The triangle inequality: $|a-b|<c<a+b$.",
 "For the smallest possible lower bound, make $|a-b|$ as small as it can be: $a$ as large as possible and $b$ as small as possible, so $|a-b|$ gets close to $|%d-%d|=%d$ (but never reaches it)."%(6,9,abs(6-9)),
 "For the largest upper bound, make $a+b$ as large as possible: it gets close to $%d+%d=%d$ (never reaching it)."%(6,11,17),
 "So $%d<c<%d$, option (@@L@@). The bounds $5$ and $15$ come from using other combinations of the end values."%(3,17)]
S['GT-094']=["The scale factor from $ABC$ to $DEF$ is the ratio of corresponding sides: $\\dfrac{DE}{AB}=\\dfrac{8}{12}=%s$."%fr(Fr(8,12)),
 "Areas of similar figures scale by the square of the scale factor: $\\left(%s\\right)^2=%s$."%(fr(Fr(8,12)),fr(Fr(8,12)**2)),
 "So area of $DEF=%s\\,(\\text{area of }ABC)$, option (@@L@@). Since $DEF$ is the smaller triangle the ratio must be less than $1$, which rules out the two fractions above $1$."%fr(Fr(8,12)**2)]
ACB98=180-112
S['GT-098']=["$D$, $C$, $B$ lie on a line, so angles $DCA$ and $ACB$ are supplementary: $\\angle ACB=180-112=%s^\\circ$."%n(ACB98),
 "$AC=AB$, so the angles opposite them are equal: $\\angle B=\\angle ACB=%s^\\circ$."%n(ACB98),
 "$\\angle A=180-%s-%s=%s^\\circ$."%(n(ACB98),n(ACB98),n(180-2*ACB98))]
pts124,(A24,B24,C24,D24,E24)=g124(20)
S['GT-124']=["Sides $AB$ and $DC$ are parallel and $BC$ is a transversal, so the same-side interior angles $B$ and $C$ add to $180^\\circ$: $(5x+5)+(3x+15)=180$.",
 "$8x+20=180$, so $8x=%s$ and $x=%s$."%(n(160),n(20)),
 "Then $\\angle A=%s^\\circ$, $\\angle B=%s^\\circ$, $\\angle C=%s^\\circ$, $\\angle D=%s^\\circ$."%(n(A24),n(B24),n(C24),n(D24)),
 "A pentagon's angles add to $(5-2)\\cdot180=%s$, so $\\angle E=%s-(%s+%s+%s+%s)=%s^\\circ$. Option (@@L@@)."%(n(540),n(540),n(A24),n(B24),n(C24),n(D24),n(E24))]
A1,B1,C1,D1,P1,angA,angB=g126()
S['GT-126']=["$AB\\parallel DC$, so angles on the same side add to $180^\\circ$: $\\angle A=180-108=%s^\\circ$ and $\\angle B=180-94=%s^\\circ$."%(n(angA),n(angB)),
 "The bisectors cut these in half: $\\angle PAB=%s^\\circ$ and $\\angle PBA=%s^\\circ$."%(n(angA/2),n(angB/2)),
 "In triangle $APB$: $\\angle APB=180-%s-%s=%s^\\circ$, which is obtuse."%(n(angA/2),n(angB/2),n(180-angA/2-angB/2)),
 "The other angle at $P$ is $180-%s=%s^\\circ$ (acute), so the obtuse angle is $%s^\\circ$, option (@@L@@)."%(n(180-angA/2-angB/2),n(angA/2+angB/2),n(180-angA/2-angB/2))]
gaps=[25,25,65,65,25,25,65,65]
spans=sorted({sum(gaps[(i+j)%8] for j in range(k)) for i in range(8) for k in (1,2,3)})
S['GT-129']=["The lines make angles of $50^\\circ$ and $180-50=%s^\\circ$. Each bisecting ray halves one of these, giving small angles of $\\dfrac{50}{2}=%s^\\circ$ and $\\dfrac{130}{2}=%s^\\circ$."%(n(130),n(25),n(65)),
 "Going around $O$ the eight small angles are $%s$ degrees (they add to $%s$)."%(','.join(map(str,gaps)),n(sum(gaps))),
 "Spans of $1$ small angle: $25$, $65$. Of $2$: $25+25=%s$, $25+65=%s$, $65+65=%s$. Of $3$: $25+25+65=%s$, $25+65+65=%s$."%(n(50),n(90),n(130),n(115),n(155)),
 "The possible spans are $%s$. The values $130$, $155$ and $115$ appear but $140$ does not, so the answer is option (@@L@@)."%', '.join(map(str,spans))]
Bz=P(0,0);Cz=P(4,0);Az=P(2,2*math.sqrt(3));Dz=P(1,0);v1=Cz-Az;v2=Dz-Az
cr=abs(v1[0]*v2[1]-v1[1]*v2[0]);dt=v1@v2
S['GT-141']=["Put the triangle on coordinates: $B=(0,0)$, $C=(4,0)$ and $A=(2,2\\sqrt3)$ (side $4$, so $BD=\\frac14\\cdot4=%d$ and $D=(%d,0)$)."%(1,1),
 "The vectors from $A$ are $\\vec{AC}=(%d,-2\\sqrt3)$ and $\\vec{AD}=(%d,-2\\sqrt3)$."%(2,-1),
 "The tangent of the angle between two vectors is $\\dfrac{|\\text{cross}|}{\\text{dot}}$. Cross: $%s\\sqrt3$. Dot: $%s$."%(n(cr/math.sqrt(3)),n(dt)),
 "$\\tan\\angle DAC=\\dfrac{%s\\sqrt3}{%s}=\\dfrac{%s\\sqrt3}{%s}$, option (@@L@@)."%(n(cr/math.sqrt(3)),n(dt),n(cr/math.sqrt(3)/2),n(dt/2))]
x147=(30+10)/(4-2)
S['GT-147']=["$DE\\parallel BC$, so the corresponding angles $\\angle ADE$ and $\\angle ABC$ are equal: $4x-10=2x+30$.",
 "$2x=%s$, so $x=%s$."%(n(40),n(x147)),
 "$\\angle ABC=2(%s)+30=%s^\\circ$ and $\\angle ACB=%s+25=%s^\\circ$."%(n(x147),n(2*x147+30),n(x147),n(x147+25)),
 "$\\angle BAC=180-%s-%s=%s^\\circ$, option (@@L@@)."%(n(2*x147+30),n(x147+25),n(180-2*x147-30-x147-25))]
n152=12;ba=180/n152;x152=ba-3;acd=180-540/n152
S['GT-152']=["In a regular $n$-gon, triangle $ABC$ is isosceles with apex angle equal to the interior angle $180-\\dfrac{360}{n}$, so $\\angle BAC=\\dfrac{180}{n}$ and $\\angle ACD=180-\\dfrac{540}{n}$ (the interior angle at $C$ minus $\\angle BCA$).",
 "Set $x+3=\\dfrac{180}{n}$ and $10x+15=180-\\dfrac{540}{n}$. Substitute $x=\\dfrac{180}{n}-3$: $\\dfrac{1800}{n}-15=180-\\dfrac{540}{n}$.",
 "$\\dfrac{2340}{n}=%d$, so $n=%d$."%(180+15,2340//195),
 "Check: $\\angle BAC=\\dfrac{180}{%d}=%s^\\circ$ gives $x=%s$, and $10(%s)+15=%s=180-\\dfrac{540}{%d}$. Option (@@L@@)."%(n152,n(ba),n(x152),n(x152),n(10*x152+15),n152)]
roots=np.roots([1,-25,144])
S['GT-160']=["The angles are $120,125,130,\\dots$, an arithmetic sequence, so their sum is $\\dfrac n2\\bigl(2\\cdot120+(n-1)\\cdot5\\bigr)=\\dfrac n2(235+5n)$. An $n$-gon's angles add to $180(n-2)$.",
 "$n(235+5n)=360(n-2)$ gives $5n^2-125n+720=0$, so $n^2-25n+144=0$.",
 "$(n-%d)(n-%d)=0$, so $n=%d$ or $n=%d$."%(round(min(roots)),round(max(roots)),round(min(roots)),round(max(roots))),
 "Convex means every angle is under $180^\\circ$. The largest angle is $120+5(n-1)$: for $n=%d$ it is $%d^\\circ$ (too big), for $n=%d$ it is $%d^\\circ$ (fine). So $n=%d$, option (@@L@@)."%(round(max(roots)),120+5*(round(max(roots))-1),round(min(roots)),120+5*(round(min(roots))-1),round(min(roots)))]
k161=(180-20)/8;ac=2*k161+4;ob=3*ac+4
S['GT-161']=["An acute angle and an obtuse angle at an intersection are supplementary: $(2k+4)+\\bigl[3(2k+4)+4\\bigr]=180$.",
 "$4(2k+4)+4=180$, so $8k+20=180$ and $k=%s$. The acute angles are $2(%s)+4=%s^\\circ$ and the obtuse angles are $3(%s)+4=%s^\\circ$."%(n(k161),n(k161),n(ac),n(ac),n(ob)),
 "Sums of two of the four angles: acute plus acute $=%s$, acute plus obtuse $=%s$, obtuse plus obtuse $=%s$."%(n(ac+ac),n(ac+ob),n(ob+ob)),
 "The value $224$ is not among these, so it CANNOT be a sum: option (@@L@@)."]
x162=(150-15)/5
S['GT-162']=["The angles of a triangle add to $180^\\circ$, so $A+B=180-30=%s^\\circ$. (The value of $x$ is not needed.)"%n(150),
 "The first factor is $\\sin A\\cos B+\\cos A\\sin B=\\sin(A+B)=\\sin%s^\\circ=%s$."%(n(150),fr(Fr(1,2))),
 "The second factor is $\\cos A\\cos B-\\sin A\\sin B=\\cos(A+B)=\\cos%s^\\circ=-\\dfrac{\\sqrt3}{2}$."%n(150),
 "Product: $\\dfrac12\\cdot\\left(-\\dfrac{\\sqrt3}{2}\\right)=-\\dfrac{\\sqrt3}{4}$ (about $%s$), option (@@L@@)."%n(math.sin(math.radians(150))*math.cos(math.radians(150)),4)]
x213=(12+8)/(6-4)
S['GT-213']=["Alternate interior angles between parallel lines are equal: $6x-8=4x+12$.",
 "$2x=%s$, so $x=%s$."%(n(12+8),n(x213)),
 "Each angle is $6(%s)-8=%s^\\circ$. Check: $4(%s)+12=%s$."%(n(x213),n(6*x213-8),n(x213),n(4*x213+12))]
x214=(33+6)/(8-5)
S['GT-214']=["The exterior angle equals the sum of the remote interior angles: $8x-6=(3x+14)+(2x+19)=5x+33$.",
 "$3x=%s$, so $x=%s$."%(n(33+6),n(x214)),
 "The exterior angle is $8(%s)-6=%s^\\circ$. Check: $%s+%s=%s$."%(n(x214),n(8*x214-6),n(3*x214+14),n(2*x214+19),n(5*x214+33))]
x215=(180+10-40)/6
S['GT-215']=["The three angles add to $180$: $(4x-10)+2(x+20)=180$.",
 "$6x+30=180$, so $6x=%s$ and $x=%s$."%(n(150),n(x215)),
 "The vertex angle is $4(%s)-10=%s^\\circ$. Check: the base angles are $%s^\\circ$ each and $%s+%s+%s=%s$."%(n(x215),n(4*x215-10),n(x215+20),n(4*x215-10),n(x215+20),n(x215+20),n(4*x215-10+2*(x215+20)))]
AC216=15*(10+6)/10
S['GT-216']=["$DE\\parallel BC$, so the sides are proportional: $\\dfrac{AD}{AB}=\\dfrac{AE}{AC}$. Here $AB=AD+DB=10+6=%d$."%(10+6),
 "$\\dfrac{10}{16}=\\dfrac{15}{AC}$, so $AC=\\dfrac{15\\cdot16}{10}=%s$."%n(AC216),
 "$EC=AC-AE=%s-15=%s$."%(n(AC216),n(AC216-15))]
bd=Fr(12,12+18)*20
S['GT-217']=["The angle bisector theorem: $\\dfrac{BD}{DC}=\\dfrac{AB}{AC}=\\dfrac{12}{18}=%s$."%fr(Fr(12,18)),
 "So $BD=2k$ and $DC=3k$ with $2k+3k=BC=20$, giving $k=%s$."%n(20/5),
 "$BD=%s$ and $DC=%s$. The longer segment is $%s$."%(n(2*20/5),n(3*20/5),n(3*20/5))]
S['GT-218']=["Each exterior angle is $180-140=%s^\\circ$ (interior plus exterior make a straight angle)."%n(40),
 "The exterior angles of a polygon add to $360^\\circ$, and in a regular polygon they are all equal, so the number of sides is $\\dfrac{360}{%s}$."%n(40),
 "$\\dfrac{360}{%s}=%s$ sides. Check: $\\dfrac{180(%s-2)}{%s}=%s^\\circ$."%(n(40),n(360/40),n(9),n(9),n(180*7/9))]
S['GT-219']=["The segment joining the midpoints of the non-parallel sides (the midsegment) is parallel to the bases and has length equal to their average.",
 "Add the bases: $10+24=%d$."%(34),
 "Divide by $2$: $\\dfrac{%d}{2}=%d$. Option (@@L@@). (The value $%d$ is the sum of the bases, not their average.)"%(34,17,34)]
S['GT-220']=["The third side $t$ must satisfy $12-7<t<12+7$, that is $%d<t<%d$."%(5,19),
 "The integers in that range are $%d,%d,\\dots,%d$."%(6,7,18),
 "Count them: $%d-%d+1=%d$."%(18,6,18-6+1)]
S['GT-221']=["The base on the $x$-axis is from $(0,0)$ to $(8,0)$, so the base is $8$. The height is the $y$-coordinate $k$ of the third vertex (the $x$-coordinate $3$ does not matter).",
 "Area $=\\dfrac12(8)(k)=4k$, so $4k=20$.",
 "$k=%s$."%n(20/4)]
S['GT-222']=["Since $AB=AC$ and $\\angle A=40^\\circ$, the base angles are $\\dfrac{180-40}{2}=%s^\\circ$ each, so $\\angle ABC=\\angle C=%s^\\circ$."%(n(70),n(70)),
 "In triangle $BCD$, $BD=BC$ so $\\angle BDC=\\angle C=%s^\\circ$, and $\\angle CBD=180-2(%s)=%s^\\circ$."%(n(70),n(70),n(180-140)),
 "$\\angle ABD=\\angle ABC-\\angle CBD=%s-%s=%s^\\circ$."%(n(70),n(40),n(30))]
# ================= Right triangles and trigonometry =================
S['GT-001']=["In a right triangle the two acute angles are complementary: $A+B=90^\\circ$.",
 "Use a $3$-$4$-$5$ triangle with $\\sin A=\\dfrac35$: the side opposite $A$ is $3$, the hypotenuse is $5$, and the other leg is $4$.",
 "$\\cos B=\\dfrac{\\text{side adjacent to }B}{\\text{hypotenuse}}$. The side adjacent to $B$ is the same side that is opposite $A$, namely $3$, so $\\cos B=\\dfrac35$. That is option (@@L@@): $\\sin A=\\cos(90^\\circ-A)$."]
c3=math.sqrt(7**2+8**2+7*8)
S['GT-003']=["The third side is opposite the $120^\\circ$ angle, so use the Law of Cosines: $c^2=7^2+8^2-2(7)(8)\\cos120^\\circ$.",
 "$\\cos120^\\circ=-\\dfrac12$, so $c^2=%d+%d-%d\\left(-\\dfrac12\\right)=%d+%d$."%(49,64,112,49+64,56),
 "$c^2=%d$, so $c=\\sqrt{%d}=%d$ kilometers. That is option (@@L@@)."%(169,169,13)]
S['GT-014']=["In a right triangle $DEF$ with the right angle at $F$, angles $D$ and $E$ are complementary, and the two legs swap roles: the leg opposite $D$ is adjacent to $E$.",
 "$\\tan D=\\dfrac{\\text{opposite }D}{\\text{adjacent }D}=\\dfrac{8}{15}$, so $EF=8$ and $DF=15$ (and $DE=\\sqrt{8^2+15^2}=%d$)."%17,
 "For angle $E$: the opposite side is $DF=15$ and the adjacent side is $EF=8$, so $\\tan E=\\dfrac{15}{8}$ (the reciprocal of $\\tan D$). Option (@@L@@)."]
S['GT-017']=["$\\cos J=\\dfrac{7}{25}$ means the side adjacent to $J$ is $7$ and the hypotenuse is $25$ (scaled).",
 "The other leg is $\\sqrt{25^2-7^2}=\\sqrt{%d}=%d$."%(625-49,24),
 "$\\sin J=\\dfrac{\\text{opposite}}{\\text{hypotenuse}}=\\dfrac{24}{25}$. Option (@@L@@). (Check by the identity: $\\sin^2J+\\cos^2J=\\dfrac{%d}{625}+\\dfrac{%d}{625}=1$.)"%(576,49)]
S['GT-023']=["$\\sin\\theta=\\dfrac{5}{13}$ means the opposite side is $5$ and the hypotenuse is $13$.",
 "The adjacent side is $\\sqrt{13^2-5^2}=\\sqrt{%d}=%d$ (a $5$-$12$-$13$ triangle)."%(169-25,12),
 "$\\tan\\theta=\\dfrac{\\text{opposite}}{\\text{adjacent}}=\\dfrac{5}{12}$. Option (@@L@@)."]
S['GT-025']=["In a $30^\\circ$-$60^\\circ$-$90^\\circ$ triangle the sides are in the ratio $x:x\\sqrt3:2x$, where $x$ is opposite the $30^\\circ$ angle.",
 "Here $x=7$.",
 "The hypotenuse is $2x=2(7)=%d$. Option (@@L@@)."%14]
S['GT-030']=["Use the special-angle values: $\\cos60^\\circ=\\dfrac12$ and $\\sin30^\\circ=\\dfrac12$ (these are equal because $60+30=90$).",
 "Add: $\\dfrac12+\\dfrac12=%d$."%(1),
 "The sum is $%d$, option (@@L@@)."%(1)]
d2=25;h2=d2*math.sqrt(3)
S['GT-002']=["Let $d$ be the distance from the nearer point to the base. Then $h=d\\tan60^\\circ$ and $h=(d+50)\\tan30^\\circ$.",
 "Set them equal: $d\\sqrt3=\\dfrac{d+50}{\\sqrt3}$. Multiply by $\\sqrt3$: $3d=d+50$, so $2d=50$ and $d=%d$."%d2,
 "$h=25\\tan60^\\circ=25\\sqrt3$. On a calculator, $25\\times%s=%s$, so $h\\approx%s$ meters."%(n(math.sqrt(3),4),n(h2,4),n(h2,1))]
T['GT-002']='C'
S['GT-042']=["Triangle $ACD$ has a right angle at $D$, so $\\cos C=\\dfrac{DC}{AC}$ and $DC=0.75\\times48=%d$."%36,
 "Triangle $BCD$ has a right angle at $B$ ($B$ is the foot of the perpendicular from $D$ to $AC$), and it shares angle $C$: $\\cos C=\\dfrac{BC}{DC}$.",
 "$BC=0.75\\times%d=%d$."%(36,27)]
N|={k for k in S if k.startswith('GT') and k not in ('GT-065','GT-002')}
