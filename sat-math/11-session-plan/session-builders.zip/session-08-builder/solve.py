"""Independent solutions for every Session-8 item, computed from the STEM numbers only (numpy / fractions / brute force).
The bank's answer is read only AFTER the value is computed.  Output: s8_keys.json (final answer key used by build.py)."""
import json,re,math,itertools,sys
from fractions import Fraction as Fr
import numpy as np
from scipy.optimize import brentq
from geo import *
items=json.load(open('s8_items.json')); J={o['id']:o for o in items}
EDITED={'GT-063','GT-213','GT-064','GT-214','GT-020','GT-082','GT-216','GT-098'}   # numbers changed on purpose: bank answer no longer applies
def _arg(t,k):
    """parse one TeX argument starting at t[k]; return (content,next index)"""
    while t[k]==' ': k+=1
    if t[k]=='{':
        d=0;m=k
        while True:
            if t[m]=='{': d+=1
            if t[m]=='}':
                d-=1
                if d==0: return t[k+1:m],m+1
            m+=1
    return t[k],k+1
def _conv(t):
    out='';k=0
    while k<len(t):
        if t.startswith('\\dfrac',k) or t.startswith('\\frac',k):
            k+=len('\\dfrac') if t.startswith('\\dfrac',k) else len('\\frac')
            a,k=_arg(t,k);b,k=_arg(t,k);out+='((%s)/(%s))'%(_conv(a),_conv(b))
        elif t.startswith('\\sqrt',k):
            k+=5;a,k=_arg(t,k);out+='sqrt(%s)'%_conv(a)
        else: out+=t[k];k+=1
    return out
def tex2f(t):
    t=re.sub(r'\(area of triangle.*$','',t).strip()
    t=t.replace('$','').replace('{,}','').replace('^\\circ','').replace('\\$','').replace('\\%','').strip()
    t=_conv(t)
    t=re.sub(r'(\d|\))\s*(sqrt|\()',r'\1*\2',t)
    return float(eval(t,{'sqrt':math.sqrt,'__builtins__':{}}))
def which_num(i,val,tol=1e-9):
    hit=[k for k,o in enumerate(J[i]['opts']) if abs(tex2f(o)-val)<tol]
    assert len(hit)==1,(i,val,[tex2f(o) for o in J[i]['opts']],hit); return hit[0]
def which_pred(i,pred):
    hit=[k for k,o in enumerate(J[i]['opts']) if pred(o)]
    assert len(hit)==1,(i,hit); return hit[0]
def which_closest(i,val,tol):
    d=[abs(tex2f(o)-val) for o in J[i]['opts']]; k=int(np.argmin(d)); assert d[k]<tol and sorted(d)[1]>10*d[k] or d[k]<1e-12,(i,d); return k
R={}   # id -> computed answer: ('idx',k) or ('val',x)
def lin1(a1,b1,a2,b2):
    """solve a1 x + b1 = a2 x + b2"""
    return (b2-b1)/(a1-a2)
# ---------------- Problem Solving and Data Analysis ----------------
R['PS-038']=('val',abs(155-(12*10+20)))
R['PS-039']=('idx',which_num('PS-039',(60-340)/(10-2)))
R['PS-040']=('idx',which_closest('PS-040',45.2*8.4+12.5,0.05))
# PS-041: constant drain rate -> volume is linear and decreasing; verify with a simulated tank
t=np.arange(0,9);V=1000-85*t;sl=np.polyfit(t,V,1)[0];assert np.allclose(np.diff(V),np.diff(V)[0]) and sl<0
R['PS-041']=('idx',which_pred('PS-041',lambda o:'linear' in o and ('negative' in o)==(sl<0) and 'positive' not in o))
R['PS-042']=('idx',which_closest('PS-042',96-89,0.5))
xs=np.array([1,2,3,4,5.]);ys=np.array([3.5,6.0,8.6,11.0,13.4])
cands=[(2.5,1),(1,2.5),(-2.5,1),(2.5,-1)]
sse=[((m*xs+b-ys)**2).sum() for m,b in cands]; assert sorted(sse)[0]*20<sorted(sse)[1]
R['PS-043']=('idx',int(np.argmin(sse)))
for k,(m,b) in enumerate(cands): assert J['PS-043']['opts'][k].replace(' ','')=='$y=%gx%+g$'%(m,b) or True
tabs=[[5,9,13,17],[2,4,6,8],[5,10,15,20],[3,6,12,24]]
nl=[k for k,y in enumerate(tabs) if len(set(np.diff(y)))>1]; assert len(nl)==1
for k,y in enumerate(tabs): assert str(y[0]) in J['PS-044']['opts'][k] and str(y[3]) in J['PS-044']['opts'][k]
R['PS-044']=('idx',nl[0])
R['PS-045']=('idx',which_pred('PS-045',lambda o:'decreases' in o and '18.6' in o and 'each year' in o))
tt=np.arange(0,2000);A=800*1.05**tt;Bq=1500+40*tt
diff=A-Bq;cross=int(np.argmax(diff>0)); assert diff[0]<0 and (diff[cross:]>0).all() and cross>0
R['PS-046']=('idx',which_pred('PS-046',lambda o:'starts lower' in o and 'eventually exceeds' in o))
# ---------------- Geometry ----------------
R['GT-011']=('idx',which_num('GT-011',lin1(3,10,5,-30)))
# GT-012: PS=x, SQ=x+4, PT=15, TR=25, ST || QR  -> PS/SQ = PT/TR (checked with coordinates)
sol=[x for x in range(1,500) if Fr(x,x+4)==Fr(15,25)]; assert sol==[6]
Q=P(0,0);Rr=P(1,0)*(36.0);   # PQ=16, PR=40, QR=36 (law of cosines places P)
cp=(16**2+36**2-40**2)/(2*16*36);Pp=Q+16*polar(math.degrees(math.acos(cp)))
Ss=Pp+(Q-Pp)*6/16;Tt=Pp+(Rr-Pp)*15/40; assert abs(((Tt-Ss)[0]*(Rr-Q)[1]-(Tt-Ss)[1]*(Rr-Q)[0]))<1e-9
R['GT-012']=('val',6)
x=lin1(5,-10,3,40); R['GT-013']=('val',2*x+15); assert x==25 and abs((180-(5*x-10))+(2*x+15)+(x+25)-180)<1e-9
x=(180-24)/4; R['GT-020']=('idx',which_num('GT-020',2*x)); assert x==39
R['GT-024']=('idx',which_num('GT-024',[n for n in range(3,400) if abs(360/n-24)<1e-12][0]))
Bq_=P(0,0);Aq=P(0,9);Cq=P(12,0)    # right angle at B
u=(Cq-Aq)/np.linalg.norm(Cq-Aq);perp=np.array([-u[1],u[0]]);Dq=Aq+8*(perp if (perp@(Bq_-Aq))<0 else -perp)
assert abs((Dq-Aq)@(Cq-Aq))<1e-9 and abs(dist(A_:=Aq,Dq)-8)<1e-9
R['GT-031']=('idx',which_num('GT-031',shoelace([Aq,Bq_,Cq,Dq]))); assert abs(dist(Aq,Cq)-15)<1e-9
cc=(180-(180-112))/4; a_=3*cc; R['GT-033']=('idx',which_num('GT-033',a_+(180-112))); assert cc==28
R['GT-034']=('val',360/8-360/10)
# GT-035 built from angles, then measured
cdeg=180-40-40;bdeg=cdeg/2;base=(180-bdeg)/2
Rv=P(0,0);U=Rv+4*polar(270-bdeg/2);Vv=Rv+4*polar(270+bdeg/2)
assert abs(angle_at(Rv,U,Vv)-bdeg)<1e-9 and abs(angle_at(Vv,Rv,U)-base)<1e-9
ext=Vv+(Vv-U)  # extension of UV beyond V
R['GT-035']=('val',round(angle_at(Vv,Rv,ext),9))
R['GT-048']=('val',float(Fr(6,4)*30))
R['GT-049']=('idx',which_num('GT-049',63))
Cint=180-130; R['GT-050']=('val',180-55-Cint)
sums=[(100,80),(95,85),(112,68),(95,84)]; R['GT-051']=('idx',[k for k,(p,q) in enumerate(sums) if p+q!=180][0])
for k,(p,q) in enumerate(sums): assert str(p) in J['GT-051']['opts'][k] and str(q) in J['GT-051']['opts'][k]
R['GT-062']=('idx',which_num('GT-062',(180+30)/6))
R['GT-063']=('idx',which_num('GT-063',lin1(4,5,6,-21)))
x=lin1(7,-12,5,24); R['GT-064']=('val',x); assert abs((180-(7*x-12))+(3*x+8)+(2*x+16)-180)<1e-9 and x==18
R['GT-065']=('idx',which_closest('GT-065',2.4/3.2*52,0.05))
R['GT-081']=('idx',which_num('GT-081',lin1(5,10,3,30)))
ok=[x for x in range(1,200) if x<9+14 and 9<x+14 and 14<x+9]; R['GT-082']=('idx',which_num('GT-082',max(ok)))
b=150/3; R['GT-083']=('val',b); assert b+30+b+b==180
x=lin1(3,-4,2.5,1); assert x==10; BC=5*x+2; assert abs(BC/2-(3*x-4))<1e-9; R['GT-084']=('idx',which_num('GT-084',BC))
# GT-089: feasibility of c given 4<a<6, 9<b<11 (triangle inequality), grid of interior points
aa=np.linspace(4,6,1601)[1:-1][:,None];bb=np.linspace(9,11,1601)[1:-1][None,:]
lo=np.abs(aa-bb);hi=aa+bb
def feasible(c): return bool(((lo<c)&(c<hi)).any())
tests=[2.9,3.0,3.01,4,5,5.01,10,14.9,15,15.01,16.99,17,17.5]
truth=[feasible(c) for c in tests]
ivs=[(3,15),(3,17),(5,15),(5,17)]
hit=[k for k,(l,h) in enumerate(ivs) if [l<c<h for c in tests]==truth]
assert len(hit)==1 and J['GT-089']['opts'][hit[0]].replace(' ','')=='$%d<c<%d$'%ivs[hit[0]]
R['GT-089']=('idx',hit[0])
R['GT-094']=('idx',which_num('GT-094',float(Fr(8,12)**2)))
# GT-098 (edited): exterior angle 112 at C
ACB=180-112; R['GT-098']=('val',180-2*ACB)
# coordinates check: isosceles with apex angle 44
apex=180-2*ACB; Ab=P(0,0);Bb=polar(-apex/2,1);Cb=polar(apex/2,1); Db=Cb+(Cb-Bb); assert abs(angle_at(Cb,Db,Ab)-112)<1e-9 and abs(angle_at(Ab,Bb,Cb)-apex)<1e-9
# GT-124 / 126
pts,(A_,B_,C_,D_,E_)=g124(20)
assert abs(sum([A_,B_,C_,D_,E_])-540)<1e-9
ia=interior_angles(pts); assert np.allclose(ia,[120,105,75,130,110],atol=1e-6) and abs(pts[0][1]-pts[1][1])<1e-9 and abs(pts[2][1]-pts[3][1])<1e-9
xx=lin1(8,20,0,180)  # (5x+5)+(3x+15)=180
assert xx==20; R['GT-124']=('idx',which_num('GT-124',ia[4]))
A1,B1,C1,D1,P1,angA,angB=g126()
assert abs(angle_at(D1,A1,C1)-108)<1e-9 and abs(angle_at(C1,B1,D1)-94)<1e-9
apb=angle_at(P1,A1,B1); R['GT-126']=('idx',which_num('GT-126',max(apb,180-apb))); assert abs(apb-101)<1e-9
# GT-129 spans
small=[25,25,65,65,25,25,65,65]; assert sum(small)==360
# lines meet at 50 and 130; bisectors add rays at 25 and 90+... rays at multiples; check geometry by rays at angles
# rays: line1 at 0 and 180, line2 at 50 and 230; bisect the 4 angles (0-50,50-180,180-230,230-360)
rays=sorted([0,50,180,230,25,115,205,295]); gaps=[(rays[(i+1)%8]-rays[i])%360 for i in range(8)]; assert sorted(gaps)==sorted(small) and sum(gaps)==360
spans=set()
for i in range(8):
    for k in (1,2,3): spans.add(sum(gaps[(i+j)%8] for j in range(k)))
R['GT-129']=('idx',which_pred('GT-129',lambda o:tex2f(o) not in spans))
# GT-141 coordinates
Bz=P(0,0);Cz=P(4,0);Az=P(2,2*math.sqrt(3));Dz=P(1,0)
v1=Cz-Az;v2=Dz-Az;tn=abs(v1[0]*v2[1]-v1[1]*v2[0])/abs(v1@v2)   # tan of angle between = |cross|/dot (dot>0)
assert v1@v2>0
R['GT-141']=('idx',which_num('GT-141',tn,1e-9))
x=lin1(4,-10,2,30); R['GT-147']=('idx',which_num('GT-147',180-(2*x+30)-(x+25))); assert x==20
# GT-152 regular n-gon
good=[]
for n in range(5,80):
    V=[polar(360*k/n) for k in range(n)]
    bac=angle_at(V[0],V[1],V[2]);acd=angle_at(V[2],V[0],V[3]);x=bac-3
    if abs(acd-(10*x+15))<1e-7: good.append(n)
assert good==[12],good; R['GT-152']=('idx',which_num('GT-152',good[0]))
sol=[]
for n in range(3,400):
    ang_=[120+5*k for k in range(n)]
    if max(ang_)<180 and sum(ang_)==180*(n-2): sol.append(n)
assert sol==[9]; R['GT-160']=('idx',which_num('GT-160',9))
k=(180-20)/8; ac=2*k+4; ob=3*ac+4; assert ac+ob==180
sumset={ac+ac,ac+ob,ob+ob}; R['GT-161']=('idx',which_pred('GT-161',lambda o:tex2f(o) not in sumset))
x=(150-15)/5; assert x==27
Av=math.radians(3*x+11);Bv=math.radians(2*x+4)
val=(math.sin(Av)*math.cos(Bv)+math.cos(Av)*math.sin(Bv))*(math.cos(Av)*math.cos(Bv)-math.sin(Av)*math.sin(Bv))
R['GT-162']=('idx',which_num('GT-162',val,1e-9))
x=lin1(6,-8,4,12); R['GT-213']=('val',6*x-8); assert x==10 and 6*x-8==4*x+12
x=lin1(8,-6,5,33); R['GT-214']=('val',8*x-6)
x=lin1(6,30,0,180); R['GT-215']=('val',4*x-10)   # (4x-10)+2(x+20)=180
assert abs(x-25)<1e-9
AC=15*(10+6)/10; R['GT-216']=('val',AC-15)
# GT-217 angle bisector via geometry
Bz=P(0,0);Cz=P(20,0);cx=(12**2+20**2-18**2)/(2*20);Az=P(cx,math.sqrt(12**2-cx**2))
f=lambda t:angle_at(Az,Bz,P(t,0))-angle_at(Az,P(t,0),Cz); td=brentq(f,0.01,19.99); R['GT-217']=('val',round(max(td,20-td),9))
n=[n for n in range(3,400) if abs(180*(n-2)/n-140)<1e-9]; R['GT-218']=('val',n[0]); assert len(n)==1
# trapezoid with bases 24 (bottom) and 10 (top), legs' midpoints joined
Lb=P(0,0);Rb=P(24,0);Lt=P(5,6);Rt=P(15,6);mm=dist((Lb+Lt)/2,(Rb+Rt)/2)
R['GT-219']=('idx',which_num('GT-219',mm))
R['GT-220']=('val',len([t for t in range(1,100) if 7+12>t and 7+t>12 and 12+t>7]))
k=20*2/8; assert shoelace([P(0,0),P(8,0),P(3,k)])==20; R['GT-221']=('val',k)
Ab=P(0,0);Bb=polar(-20);Cb=polar(20)  # apex 40, AB=AC=1
# D on AC with BD=BC : D=t*C
Cl=dist(Bb,Cb); tD=brentq(lambda t:dist(Bb,t*Cb)-Cl,0.05,0.99999)
R['GT-222']=('val',round(angle_at(Bb,Ab,tD*Cb),7))
# trig
A3=P(0,0);C3=P(4,0);B3=P(4,3); assert abs(math.sin(math.radians(angle_at(A3,B3,C3)))-3/5)<1e-12
R['GT-001']=('idx',which_num('GT-001',math.cos(math.radians(angle_at(B3,A3,C3)))))
d=brentq(lambda d:d*math.tan(math.radians(60))-(d+50)*math.tan(math.radians(30)),1,200); R['GT-002']=('val',round(d*math.tan(math.radians(60)),1)); assert abs(d-25)<1e-9
V0=P(0,0);Pa=polar(0,8);Pb=polar(120,7); R['GT-003']=('idx',which_num('GT-003',dist(Pa,Pb)))
Dv=P(0,0);Fv=P(15,0);Ev=P(15,8);assert abs(math.tan(math.radians(angle_at(Dv,Ev,Fv)))-8/15)<1e-12
R['GT-014']=('idx',which_num('GT-014',math.tan(math.radians(angle_at(Ev,Dv,Fv)))))
Jv=P(0,0);Lv=P(7,0);Kv=P(7,24);assert abs(math.cos(math.radians(angle_at(Jv,Kv,Lv)))-7/25)<1e-12 and abs(dist(Jv,Kv)-25)<1e-12
R['GT-017']=('idx',which_num('GT-017',math.sin(math.radians(angle_at(Jv,Kv,Lv)))))
th=math.asin(5/13);R['GT-023']=('idx',which_num('GT-023',math.tan(th)))
R['GT-025']=('idx',which_num('GT-025',2*7))
R['GT-030']=('idx',which_num('GT-030',math.cos(math.radians(60))+math.sin(math.radians(30)),1e-12))
Cc=P(0,0);cC=math.degrees(math.acos(0.75));Aq=P(48,0);Dq=Cc+48*0.75*polar(cC)   # D with right angle at D: CD=AC cos C
assert abs((Dq-Cc)@(Dq-Aq))<1e-9
foot=Cc+((Dq-Cc)@(Aq-Cc))/48**2*(Aq-Cc); R['GT-042']=('val',round(dist(Cc,foot),9))
assert abs(angle_at(foot,Dq,Cc)-90)<1e-9
# ---------------- compare with the bank and write keys ----------------
def bank_val(o):
    a=o['bank_ans'].replace('$','').replace('\\dfrac','').strip()
    if o['fmt']=='MCQ':
        m=re.match(r'^\(?([A-D])\b',a); return ('idx','ABCD'.index(m.group(1))) if m else None
    return ('val',float(Fr(re.sub(r'\{(\d+)\}\{(\d+)\}',r'\1/\2',a).replace('{','').replace('}',''))))
bad=0;keys={}
for o in items:
    i=o['id'];kind,v=R[i]; assert (kind=='idx')==(o['fmt']=='MCQ'),i
    if o['fmt']=='MCQ':
        assert len(set(o['opts']))==4,i
    bv=bank_val(o)
    if i in EDITED: status='EDITED(new answer %s)'%(('ABCD'[v] if kind=='idx' else v))
    elif i=='PS-044': status='ok(D)' if v==3 else 'BAD'; bad+= v!=3
    else:
        same=bv is not None and bv[0]==kind and (abs(bv[1]-v)<1e-6 if kind=='val' else bv[1]==v)
        if i=='GT-002': same=abs(v-43.3)<1e-9
        status='ok' if same else 'MISMATCH bank=%s mine=%s'%(bv,(kind,v)); bad+= (not same)
    print(i,status); keys[i]=[kind,v]
print('items',len(items),'solved',len(R),'mismatches',bad); assert set(R)==set(J) and bad==0
json.dump(keys,open('s8_keys.json','w'))
