"""Independent solutions for every Session-5 item. Computed from the question text (numpy / fractions / brute force).
The bank's Correct Answer is only read in the final comparison block at the bottom."""
import json,math,re,itertools,sys
from fractions import Fraction as Fr
import numpy as np
from scipy.optimize import brentq
items={d['id']:d for d in json.load(open('s5_items.json'))}
ANS={}   # id -> ('mc',idx) or ('val',float)
def close(a,b,t=1e-9): return abs(a-b)<=t*max(1,abs(b))
def mc(iid,preds,keys=None):
    """preds: 4 booleans, one per option, in the item's option order; keys: substrings that must appear in each option"""
    it=items[iid]; assert len(preds)==4
    if keys:
        for i,k in enumerate(keys): assert k in it['opts'][i].replace(' ','').replace('\\left','').replace('\\right','').replace('$',''),(iid,i,k,it['opts'][i])
    assert len(set(it['opts']))==4,iid
    assert sum(preds)==1,(iid,preds)
    ANS[iid]=('mc',preds.index(True))
def val(iid,v): ANS[iid]=('val',float(v))
rng=np.random.default_rng(5)
# ---------------- Equivalent expressions ----------------
ks={Fr(6)**(2*x+3)/Fr(2)**(2*x-1)/Fr(9)**x for x in (0,1,2,3,4)}; assert len(ks)==1
val('AM-193',ks.pop())
# 194: real p,q roots of x^2+bx+c, integers b,c
T=[True,True,True]
for b in range(-8,9):
  for c in range(-20,21):
    D=b*b-4*c
    if D<0: continue
    p=(-b+math.sqrt(D))/2;q=(-b-math.sqrt(D))/2
    s=[abs((p+q)-round(p+q))<1e-9,abs((p*p+q*q)-round(p*p+q*q))<1e-9,abs((p*p+q*q)/2-round((p*p+q*q)/2))<1e-9]
    T=[t and x for t,x in zip(T,s)]
assert T==[True,True,False]
mc('AM-194',[T==[1,0,0],T==[1,1,0],T==[0,1,1],T==[1,1,1]],['Ionly','IandIIonly','IIandIIIonly','I,II,andIII'])
# 195: a(x^2+x+1)-(bx+c)(x-1)=3x^2+8x+4 -> linear system from 3 x-values
xs=[0,2,3];A=np.array([[x*x+x+1,-x*(x-1),-(x-1)] for x in xs],float);rhs=np.array([3*x*x+8*x+4 for x in xs],float)
a_,b_,c_=np.linalg.solve(A,rhs)
for x in (1.5,2.5,7,-0.3):   # check original equation (x^3-1 form)
    assert close(a_/(x-1)-(b_*x+c_)/(x*x+x+1),(3*x*x+8*x+4)/(x**3-1))
assert close(a_,5) and close(b_,2); val('AM-195',c_)
# 197
us=lambda y:1/y
f=lambda y:((1/y**3)-27)/((1/y)-3)
cand=[lambda u:u*u-3*u+9,lambda u:u*u+9,lambda u:u*u+6*u+9,lambda u:u*u+3*u+9]
ys=[0.7,-0.4,2.3,5.1,-1.9]
mc('AM-197',[all(close(f(y),g(1/y)) for y in ys) for g in cand],['-\\dfrac3y','\\dfrac1{y^2}+9','+\\dfrac6y','+\\dfrac3y'])
# 198: brute force
sols=set()
for n in range(1,1000):
  for k in range(1,5000):
    if n**3-9*n*n+k*n-12==0: sols.add(k)
val('AM-198',sum(sols)); assert sols=={20,22,23}
# 203
cands=[lambda P,a:(P/a)**(2/5),lambda P,a:(a/P)**(5/2),lambda P,a:(P/a)**(5/2),lambda P,a:(a/P)**(2/5)]
ok=[True]*4
for _ in range(20):
    a=rng.uniform(.5,9);w=rng.uniform(.3,12);P=a/(w**2)**(1/5)
    ok=[o and close(g(P,a),w,1e-9) for o,g in zip(ok,cands)]
mc('AM-203',ok,['(\\dfrac{P}{a})^{2/5}','(\\dfrac{a}{P})^{5/2}','(\\dfrac{P}{a})^{5/2}','(\\dfrac{a}{P})^{2/5}'])
# 207
b=8*4**(1/3)*math.sqrt(2)
for x in (1.7,-2.2,3.0): assert close(8**x*4**(x/3)*math.sqrt(2)**x,b**x)
mc('AM-207',[close(b**25,2),close(b**(-6/25),2),close(b**(6/25),2),close(b**(25/6),2)],['b^{25}','b^{-6/25}','b^{6/25}','b^{25/6}'])
# 212
ok=[True]*4
for _ in range(20):
    a=rng.uniform(.5,6);b=rng.uniform(.5,6);c=5/(2/a-3/b)
    g=[3*a*c/(5*a-2*c),(2*c-5*a)/(3*a*c),3*a*c/(2*c+5*a),3*a*c/(2*c-5*a)]
    ok=[o and close(x,b,1e-9) for o,x in zip(ok,g)]
mc('AM-212',ok,['5a-2c','2c-5a}{3ac','2c+5a','2c-5a'])
# 217
best=None
for a in range(-24,25):
  for b in range(-24,25):
    if a*b==24:
      k=2*b+3*a; best=k if best is None else max(best,k)
val('AM-217',best)
# 218
F=lambda a:1/(1-a)+1/(1+a)+2/(1+a*a)+4/(1+a**4)
roots=[]
grid=np.concatenate([np.linspace(-0.9999,-0.0001,4000),np.linspace(0.0001,0.9999,4000)])
for lo,hi in zip(grid[:-1],grid[1:]):
    if abs(hi-lo)>0.01: continue
    if (F(lo)-10)*(F(hi)-10)<0: roots.append(brentq(lambda a:F(a)-10,lo,hi))
big=np.concatenate([np.linspace(1.0001,60,200000),np.linspace(-60,-1.0001,200000)])
for lo,hi in zip(big[:-1],big[1:]):
    if abs(hi-lo)<0.01 and (F(lo)-10)*(F(hi)-10)<0: roots.append(brentq(lambda a:F(a)-10,lo,hi))
a8={round(r**8,6) for r in roots}; assert a8=={0.2},a8
mc('AM-218',[close(0.2,1.25,1e-6),close(0.2,1.8,1e-6),close(0.2,0.2,1e-6),close(0.2,0.8,1e-6)],['\\dfrac54','\\dfrac95','\\dfrac15','\\dfrac45'])
# 224
for _ in range(10):
    b=rng.uniform(-9,9);a=math.sqrt(36+b*b)*rng.choice([-1,1])
    assert close((3*a+b)**2-(a+3*b)**2,288,1e-9)
val('AM-224',288)
# 225
ok=[True]*4
for _ in range(20):
    x=rng.uniform(-6,6);y=(8-2*x)/3;lhs=2*x*x+3*x*y-4*x-6*y
    g=[8*x-4*y,8*x-16,8*x-8,16-8*x]; ok=[o and close(lhs,v,1e-9) for o,v in zip(ok,g)]
mc('AM-225',ok,['8x-4y','8x-16','8x-8','16-8x'])
# 226
t=3.7
h=lambda p,t:(t**(2/3))**p*(math.sqrt(t))**3/t**(1/6)-t**5
p=brentq(lambda p:h(p,t),-20,20); assert close(brentq(lambda p:h(p,2.9),-20,20),p,1e-9); val('AM-226',p)
# 229
Pl=np.polynomial.Polynomial
poly=((Pl([-3,2])**4)*Pl([2,1])-7)/5
sv=poly.coef.sum(); assert len(poly.coef)==6
mc('AM-229',[close(sv,31),close(sv,-4/5),close(sv,3/5),close(sv,-4)],['31','-\\dfrac45','\\dfrac35','-4'])
# 235
best=None
for a in range(1,13):
  if 12%a: continue
  c=12//a
  for b in range(-150,151):
    for d in range(-150,151):
      if b*d==144 and a*d+b*c==-84:
        s=a+b+c+d; best=s if best is None else min(best,s)
mc('AM-235',[best==-27,best==-22,best==-18,best==-38],['-27','-22','-18','-38'])
# 237
f=lambda x:6**(x+1)*4**x/3**(x-2)
a0=f(1);b0=f(2)/f(1)
for x in (0,0.5,3,-1.3): assert close(f(x),a0*b0**(x-1),1e-12)
mc('AM-237',[close(a0+b0,62),close(a0+b0,440),close(a0+b0,456),close(a0+b0,3456)],['62','440','456','3456'])
# 239: m from ab=128, then ab^2
m=brentq(lambda m:m**(1/3)*m**(1/4)-128,1,1e6)
val('AM-239',m**(1/3)*(m**(1/4))**2)
# 243
g=lambda x:9**(x+2)*10**(x+1)/6**(x-1)
r={g(x)/15**(x+1) for x in (0,1,2)}; ks=[g(x)/15**(x+1) for x in (0,0.5,1,2,3.3)]; assert all(close(k,ks[0],1e-12) for k in ks); val('AM-243',ks[0])
# 248
bb=7.31;aa=bb**(2/3);assert close(aa**3,bb**2);kk=math.log(aa**9/bb**(1/3))/math.log(bb)
mc('AM-248',[close(kk,17/3),close(kk,6),close(kk,19/3),close(kk,17/2)],['\\dfrac{17}{3}','6','\\dfrac{19}{3}','\\dfrac{17}{2}'])
# 250
rr=np.roots([1,-15,36]); x,y=rr; assert close(x+y,15) and close(x*y,36)
ex=(1/x-1/y)/(1/x**2-1/y**2)
mc('AM-250',[close(ex,1),close(ex,4),close(ex,12/5),close(ex,5/12)],['1','4','\\dfrac{12}{5}','\\dfrac{5}{12}'])
# ---------------- Nonlinear equations ----------------
sol=[x for x in np.linspace(-7,60,6700001) if abs(math.sqrt(x+7)-(x-5))<1e-4] if False else None
xs_=np.linspace(-7,60,2_000_001); fv=np.sqrt(xs_+7)-(xs_-5)
roots=[brentq(lambda x:math.sqrt(x+7)-(x-5),lo,hi) for lo,hi in zip(xs_[:-1],xs_[1:]) if fv[list(xs_).index(lo)] is None] if False else []
idx=np.where(np.sign(fv[:-1])*np.sign(fv[1:])<=0)[0]; roots=sorted({round(brentq(lambda x:math.sqrt(x+7)-(x-5),xs_[i],xs_[i+1]),6) for i in idx})
assert roots==[9.0],roots
mc('AM-008',[roots==[2.0],roots==[9.0],roots==[2.0,9.0],roots==[]],['x=2only','x=9only','x=2andx=9','Thereisnosolution'])
val('AM-069',brentq(lambda x:math.sqrt(2*x+7)-5,-3,100))
ra=brentq(lambda a:a+1-13-math.sqrt(a),1,1000); g_=np.linspace(0,1e5,2000001); vv=g_+1-13-np.sqrt(g_); assert (((vv[:-1]<0)&(vv[1:]>=0))|((vv[:-1]>0)&(vv[1:]<=0))).sum()==1
val('AM-091',ra)
val('AM-096',sum(1 for m in range(-200,200) if m%2==0 and m+11>=0 and math.sqrt(m+11)<=4))
# 166: log2 equations
sol=np.linalg.solve(np.array([[1/3,2],[4,-2/3]]),np.array([8,22.]));xx,yy=sol
assert close((2**xx)**(1/3)*4**yy,256) and close(16**xx/(4**yy)**(1/3),2**22)
val('AM-166',xx*yy)
# 206
rts=np.roots([2,-4,-22]);sx=[r for r in rts if r>0][0];sy=sx-2;assert sy>0 and close(sx*sx+sy*sy,26)
val('AM-206',sx*sx*sy*sy)
# ---------------- Nonlinear functions ----------------
def rad_zero(r,k):  # -sqrt(z^2+pz+q) through (r,0),(0,-sqrt k): q=k, r^2+pr+q=0
    q=k;p=-(r*r+q)/r;rts=np.roots([1,p,q]);return p,q,sorted(rts.real)
p,q,rt=rad_zero(6,252);assert all(abs(z*z+p*z+q)<1e-6 for z in rt);val('AM-145',max(rt))
p,q,rt=rad_zero(2,314);assert abs(sum(rt)+p)<1e-9;val('AM-148',abs(rt[1]-rt[0]))
pf=np.polymul([3,1-math.sqrt(5)],[3,1+math.sqrt(5)])*2; val('AM-227',(pf[1]+pf[2])/pf[0])
# 233
p_=lambda x:-(x+3)**2*(x-1)**3*(x-4)**2
I=all(p_(x)>=0 for x in np.linspace(-60,0.999,100001))
II=p_(3.999)*p_(4.001)<0
III=p_(-1e3)>0 and p_(-1e4)>p_(-1e3)>p_(-100)
assert (I,II,III)==(True,False,True)
mc('AM-233',[(I,II,III)==(1,0,0),(I,II,III)==(1,1,0),(I,II,III)==(1,0,1),(I,II,III)==(0,1,1)],['Ionly','IandIIonly','IandIIIonly','IIandIIIonly'])
# 257: domain of g(x)=h(x+5)
dom=[x for x in np.linspace(-20,20,400001) if x+5-2>=0];lo=min(dom)
mc('AM-257',[close(lo,-3),close(lo,2),close(lo,7),close(lo,-5)],['x\\ge-3','x\\ge2','x\\ge7','x\\ge-5'])
# 002
v=1.15**5
mc('AM-002',[abs(v-1.15)<.005,abs(v-1.75)<.005,abs(v-2.01)<.005,abs(v-2.99)<.005],['1.15','1.75','2.01','2.99'])
v=120000*.88**4
mc('AM-004',[round(v,-3)==61000,round(v,-3)==72000,round(v,-3)==84000,round(v,-3)==94000],['61{,}000','72{,}000','84{,}000','94{,}000'])
E=lambda t:1450*1.08**t
mc('AM-045',[close(E(15),1450),close(E(0),1450),close(8,1450),close(math.log(2)/math.log(1.08),1450)],['15','opened','percent','double'])
# 035
a=5
for _ in range(3): a=2*a-3
val('AM-035',a)
v=300*1.5**3; mc('AM-061',[close(v,675),close(v,900),close(v,1012.5),close(v,1350)],['675','900','1{,}012.5','1{,}350'])
true_=lambda t:250*(1-.12)**t
fs=[lambda t:250*.12**t,lambda t:250*.88**t,lambda t:250*1.12**t,lambda t:250-12*t]
mc('AM-063',[all(close(f(t),true_(t)) for t in (0,1,2,3.5)) for f in fs],['0.12','0.88','1.12','-12t'])
v=500*1.2**5; opt=[1000,1100,1244,1500]; mc('AM-065',[min(opt,key=lambda o:abs(o-v))==o for o in opt],['1{,}000','1{,}100','1{,}244','1{,}500'])
v=200*.85**6; opt=[65.5,75.5,85.5,95.5]; mc('AM-072',[min(opt,key=lambda o:abs(o-v))==o for o in opt],['65.5','75.5','85.5','95.5'])
tru=lambda t:60*1.024**t
fs=[lambda t:60*1.024**t,lambda t:60*2.4**t,lambda t:1.024*t+60,lambda t:2.4*t+60]
mc('AM-080',[all(close(f(t),tru(t)) for t in (0,1,2,3)) for f in fs],['60(1.024)','60(2.4)','1.024t+60','2.4t+60'])
# 088 (edited): a1=-4, a_{n+1}=3a_n-2
a=-4;n=1
while abs(a)<=150: a=3*a-2;n+=1
mc('AM-088',[n==3,n==4,n==5,n==6],['3','4','5','6'])
t0,t1=3,18;ratio=18/3
nth=3*6**8
mc('AM-105',[close(nth,648*9),close(nth,3**9),close(nth,3*6**8),close(nth,6*3**8)],['648\\times9','3^9','3\\times6^8','6\\times3^8'])
r=round((54/2)**(1/3));assert r**3==27;val('AM-121',sum(2*r**k for k in range(5)))
b3=(486/18)**(1/3);a3=18/b3**2;assert close(a3*b3**5,486);val('AM-160',a3*b3**4)
V=lambda t:500*2**(t/2)*4**(t/3)*16**(-t/12);cs=[V(t+6)/V(t) for t in (0,1.7,5)];assert all(close(c,cs[0]) for c in cs);val('AM-173',cs[0])
# 200
P=lambda t:120/(1+5*.8**t);ts=np.linspace(0,10,100001)
I=bool((np.diff(P(ts))>0).all());II=P(0)<60<P(10);III=P(0)<=80<=P(10)
assert (I,II,III)==(True,True,False)
mc('AM-200',[(I,II,III)==(1,0,0),(I,II,III)==(1,1,0),(I,II,III)==(0,1,1),(I,II,III)==(1,1,1)],['Ionly','IandIIonly','IIandIIIonly','I,II,andIII'])
Vv=lambda t:2400*.64**(t/2.5)
fall25=1-Vv(2.5)/Vv(0);fall5=1-Vv(5)/Vv(0);fally=1-Vv(1)/Vv(0)
mc('AM-205',[close(fall25,.36),close(fall5,.36),close(fall25,.64),close(fally,.025)],['36\\%$everyone','36\\%$every$5','64\\%','2.5\\%'] if False else None)
At=lambda t:300*4**(t/3)
ok=[]
for f in [lambda m:300*2**(m/18),lambda m:1200*2**(m/36),lambda m:900*2**(m/18),lambda m:1200*2**(m/18)]:
    ok.append(all(close(f(m),At(3+m/12)) for m in (0,5,12,30,77)))
mc('AM-219',ok,['300\\cdot2^{m/18}','1200\\cdot2^{m/36}','900\\cdot2^{m/18}','1200\\cdot2^{m/18}'])
T_=lambda t:24+66*.85**t
mc('AM-242',[close(1-T_(1)/T_(0),.15),all(close((T_(t+1)-24)/(T_(t)-24),.85) for t in (0,2,5)),close(T_(1),.85*T_(0)),close(24,.85*T_(0))],['TFalls','gap','T(1)','levels'] if False else None)
# ---------------- Percentages ----------------
val('PS-001',9020000/(1.25*.88))
mc('PS-002',[close(o*.7*1.05,44.10) for o in (42.00,58.80,60.00,63.00)],['42.00','58.80','60.00','63.00'])
mc('PS-014',[close(o*.85,1020) for o in (950,1000,1050,1200)],['950','1{,}000','1{,}050','1{,}200'])
w1=8400/(1.4*.75);val('PS-016',1.4*w1-8400)
ok=[all(close(f(y),y*(1-.12)) for y in (50,200,3.3)) for f in (lambda y:.88*y,lambda y:.12*y,lambda y:y-12,lambda y:y-.12)]
mc('PS-023',ok,['0.88y','0.12y','y-12','y-0.12'])
# ---- AM-205 / AM-242 key words (option-text checks done separately) ----
assert 'every $2.5$ years' in items['AM-205']['opts'][0] and '36' in items['AM-205']['opts'][0]
assert items['AM-242']['opts'][1].startswith('the gap')
# ================= compare with the bank (read only now) =================
assert set(ANS)==set(items),set(items)-set(ANS)
def bank_letter(s): m=re.match(r'^\(?([A-D])(?:\)|$|\s)',s.strip()); return 'ABCD'.index(m.group(1))
def bank_val(s):
    s=s.replace('$','').replace('{,}','').replace(',','').strip()
    s=re.sub(r'\\dfrac\{(-?\d+)\}\{(\d+)\}',r'\1/\2',s)
    return float(Fr(s))
FIXES=[];bad=0
for iid,(kind,v) in ANS.items():
    it=items[iid]
    if it['bank_ans'] is None: print('NEW   ',iid,'(edited item, no bank answer)',kind,v);continue
    if kind=='mc': bv=bank_letter(it['bank_ans']);ok=(bv==v)
    else: bv=bank_val(it['bank_ans']);ok=close(bv,v,1e-9)
    if not ok: bad+=1;print('MISMATCH',iid,'mine',v,'bank',bv)
print('items',len(ANS),'bank mismatches',bad)
json.dump({k:v for k,v in ANS.items()},open('solved.json','w'))
