"""Desmos solutions for EVERY Session-5 problem (3-4 numbered steps, grey boxes via [[expr]]).
All quoted values come from ev() on the typed expressions; tapped points are asserted by substitution."""
import math, re
from fractions import Fraction as Fr
from steps import n, fm, ev, c, v, pt, lc, fr, KEY as KEY0
from scipy.optimize import brentq
S = {}; RES = {}; SEL = {}; CLAIMS = []; FUN = {}
def claim(desc, ok): CLAIMS.append((desc, bool(ok))); assert ok, desc
def begin(): FUN.clear()
def df(defn):
    m = re.match(r'^([A-Za-z])\(([a-z])\)=(.+)$', defn); assert m, defn
    name, var, body = m.groups()
    FUN[name] = lambda t, body=body, var=var: ev(body, **{**FUN, var: t})
    return c(defn)
def dv(defn, d=4):
    m = re.match(r'^([A-Za-z])=(.+)$', defn); assert m and m.group(1) != 'y', defn
    FUN[m.group(1)] = ev(m.group(2), **FUN)
    return "%s (so $%s=%s$)" % (c(defn), m.group(1), fm(FUN[m.group(1)], d))
def val(expr): return ev(expr, **FUN)
def R(expr, d=4): return "Type %s: it returns %s" % (c(expr), v(val(expr), d))
def RR(exprs, d=4):
    out = [R(e, d) for e in exprs]
    return "; ".join([out[0]] + [lc(o) for o in out[1:]])
def tap(x, y, *fs, tol=1e-6):
    for f in fs: claim('tap %s,%s' % (x, y), abs(f(x) - y) < tol * max(1, abs(y)))
    return pt(x, y)
def pick(iid, cands, target):
    """cands: {label: value}; exactly the label whose value equals target (relative tol) is selected"""
    hit = [k for k, x in cands.items() if abs(x - target) <= 1e-6 * max(1, abs(target))]
    assert len(hit) == 1, (iid, hit, cands); SEL[iid] = hit[0]; assert hit[0] == KEY0[iid], (iid, hit[0], KEY0[iid]); return hit[0]
L = "(@@L@@)"

# ---------------- Equivalent expressions
begin()
S['AM-193'] = [
 "Move $k$ to one side and type %s. The $x$ terms cancel, so Desmos draws a flat line and $k$ is its height." % df('g(x)=6^(2x+3)/(2^(2x-1)*9^x)'),
 "Tap the line where it crosses the $y$-axis: %s, so $k=%s$." % (pt(0, val('g(0)')), fm(val('g(0)'))),
 "Check a second point on the same line. " + R('g(2)') + ": the same height."]
RES['AM-193'] = val('g(0)'); assert abs(val('g(2)') - val('g(0)')) < 1e-9

begin()
_dp = dv('p=(3+sqrt(3^2-4*2))/2'); _dq = dv('q=(3-sqrt(3^2-4*2))/2')
S['AM-194'] = [
 "Test one case with integers $b=3$, $c=2$: type %s and %s." % (_dp, _dq),
 R('p+q') + " and " + lc(R('p^2+q^2')) + ": both integers, matching statements I and II (algebra shows they always are, since $b=p+q$ and $p^2+q^2=b^2-2c$).",
 R('(p^2+q^2)/2') + ": not an integer, so statement III does not have to be true.",
 "Only I and II: option (@@L@@)."]
assert val('p+q') == 3 and val('p^2+q^2') == 5 and val('(p^2+q^2)/2') == 2.5

begin()
S['AM-195'] = [
 "Multiply by $x^3-1$, then put $x=1$ so that the $c$ and $b$ terms vanish: " + R('(3*1^2+8*1+4)/(1^2+1+1)') + ", so $a=5$.",
 "Put $a=5$ back and isolate $bx+c$: type %s. Desmos draws a straight line (with a hole at $x=1$)." % df('g(x)=(3x^2+8x+4-5(x^2+x+1))/(-(x-1))'),
 "Tap the $y$-intercept: " + R('g(0)') + ", so $c=%s$." % fm(val('g(0)')),
 "The line also passes through $(2,%s)$: " % fm(val('g(2)')) + R('g(2)') + ", so the slope is $b=%s$." % fm((val('g(2)') - val('g(0)')) / 2)]
RES['AM-195'] = val('g(0)'); assert val('g(2)') == 3

begin()
S['AM-197'] = [
 "Type the original expression: %s. At $y=0.5$: " % df('f(x)=(1/x^3-27)/(1/x-3)') + R('f(0.5)') + ".",
 "Now try each option at $y=0.5$: " + RR(['1/0.5^2-3/0.5+9', '1/0.5^2+9', '1/0.5^2+6/0.5+9', '1/0.5^2+3/0.5+9']) + ".",
 "Only %s matches $19$; graphing it on top of $f$ gives the same curve. Option (@@L@@)." % c('y=1/x^2+3/x+9')]
pick('AM-197', {'\\dfrac1{y^2}+\\dfrac3y+9': val('1/0.5^2+3/0.5+9'), 'A': val('1/0.5^2-3/0.5+9'), 'B': val('1/0.5^2+9'), 'C': val('1/0.5^2+6/0.5+9')}, val('f(0.5)'))

begin()
S['AM-198'] = [
 "A factor $x-n$ means $p(n)=0$, so $k=\\dfrac{12}{n}+9n-n^2$, and $n$ must divide $12$. Type %s." % df('k(n)=12/n+9n-n^2'),
 "Try the divisors: " + RR(['k(1)', 'k(2)', 'k(3)', 'k(4)'], 0) + ".",
 "Continue: " + RR(['k(6)', 'k(12)'], 0) + ". Reject $n=12$ (negative).",
 "The distinct positive values are $20$, $22$, $23$ (count $20$ once): " + R('20+22+23', 0) + "."]
assert [val('k(%d)' % i) for i in (1, 2, 3, 4, 6, 12)] == [20, 20, 22, 23, 20, -35]
RES['AM-198'] = val('20+22+23')

begin()
S['AM-203'] = [
 "Test with $a=2$ and $w=5$: " + dv('P=2/(5^2)^(1/5)') + ".",
 "Evaluate two options: " + RR(['(2/P)^(5/2)', '(P/2)^(2/5)']) + ".",
 "And the other two: " + RR(['(P/2)^(5/2)', '(2/P)^(2/5)']) + ".",
 "Only $\\left(\\dfrac aP\\right)^{5/2}$ returns $w=5$: option (@@L@@)."]
pick('AM-203', {'(\\dfrac{a}{P})^{5/2}': val('(2/P)^(5/2)'), 'x1': val('(P/2)^(2/5)'), 'x2': val('(P/2)^(5/2)'), 'x3': val('(2/P)^(2/5)')}, 5)

begin()
S['AM-207'] = [
 "Add the exponents of $2$: " + R('3+2/3+1/2') + ", which is $\\dfrac{25}{6}$. So $b=2^{25/6}$.",
 "Check: " + RR(['8*4^(1/3)*sqrt(2)', '2^(25/6)']) + " (the same number, $b$).",
 dv('b=2^(25/6)') + ". " + RR(['b^(6/25)', 'b^(-6/25)']) + ".",
 "Only $b^{6/25}$ equals $2$: option (@@L@@)."]
pick('AM-207', {'b^{6/25}': val('b^(6/25)'), 'b^{-6/25}': val('b^(-6/25)'), 'b^{25/6}': val('b^(25/6)')}, 2)

begin()
S['AM-212'] = [
 "Choose $a=1$ and $b=2$ and find the $c$ that fits: " + R('5/(2/1-3/2)') + ", so $c=10$.",
 "Now test the options with $a=1$, $c=10$ (they should return $b=2$): " + RR(['3*1*10/(2*10-5*1)', '3*1*10/(5*1-2*10)']) + ".",
 RR(['(2*10-5*1)/(3*1*10)', '3*1*10/(2*10+5*1)']) + ".",
 "Only $\\dfrac{3ac}{2c-5a}$ returns $2$: option (@@L@@)."]
pick('AM-212', {'3ac}{2c-5a': val('3*1*10/(2*10-5*1)'), 'x1': val('3*1*10/(5*1-2*10)'), 'x2': val('(2*10-5*1)/(3*1*10)'), 'x3': val('3*1*10/(2*10+5*1)')}, 2)

begin()
S['AM-217'] = [
 "Expanding gives $ab=24$ and $k=2b+3a$. Type %s." % df('k(a)=2(24/a)+3a'),
 "Try the divisors of $24$: " + RR(['k(1)', 'k(2)', 'k(3)', 'k(4)'], 0) + ".",
 "Continue: " + RR(['k(6)', 'k(8)', 'k(12)', 'k(24)'], 0) + ". Negative pairs give negative $k$.",
 "The greatest value is the last one: $k=%s$." % fm(val('k(24)'))]
RES['AM-217'] = max(val('k(%d)' % a) for a in (1, 2, 3, 4, 6, 8, 12, 24))

begin()
a8 = (1/5) ** (1/8)
S['AM-218'] = [
 "Type the left side %s and the line %s." % (c('y=1/(1-x)+1/(1+x)+2/(1+x^2)+4/(1+x^4)'), c('y=10')),
 "Tap the intersection (zoom in near $x=0.8$): " + tap(round(a8, 5), 10, lambda x: 1/(1-x)+1/(1+x)+2/(1+x**2)+4/(1+x**4), tol=1e-3) + ", so $a\\approx%s$." % n(a8, 5),
 R('%s^8' % n(a8, 5), 3) + ", so $a^8=\\dfrac15$: option (@@L@@)."]
SEL['AM-218'] = '\\dfrac15'; assert abs(val('%s^8' % n(a8, 5)) - 0.2) < 1e-3

begin()
S['AM-224'] = [
 "Pick numbers with $a^2-b^2=36$, e.g. $a=10$, $b=8$: " + R('(3*10+8)^2-(10+3*8)^2', 0) + ".",
 "Another pair, $a=6$, $b=0$: " + R('(3*6+0)^2-(6+3*0)^2', 0) + " (same value).",
 "Algebra explains it: the expression is $8(a^2-b^2)$. " + R('8*36', 0) + "."]
RES['AM-224'] = val('8*36'); assert val('(3*10+8)^2-(10+3*8)^2') == 288 == val('(3*6+0)^2-(6+3*0)^2')

begin()
S['AM-225'] = [
 "If $2x+3y=8$, then $(x,y)=(1,2)$ works. The original expression there: " + R('2*1^2+3*1*2-4*1-6*2', 0) + ".",
 "Test the options at $(1,2)$: " + RR(['8*1-4*2', '8*1-16', '8*1-8', '16-8*1'], 0) + ".",
 "Only $8x-16$ matches. Check with $(x,y)=(4,0)$: " + RR(['2*4^2+3*4*0-4*4-6*0', '8*4-16'], 0) + ". Option (@@L@@)."]
pick('AM-225', {'8x-16': val('8*1-16'), 'x1': val('8*1-4*2'), 'x2': val('8*1-8'), 'x3': val('16-8*1')}, -8)

begin()
S['AM-226'] = [
 "Test with $t=2$: type %s and %s (letting $x$ stand for $p$)." % (c('y=(2^(2/3))^x*(sqrt(2))^3/2^(1/6)'), c('y=2^5')),
 "Tap the intersection: " + tap(5.5, 32, lambda x: (2**(2/3))**x*(math.sqrt(2))**3/2**(1/6), lambda x: 2**5) + ", so $p=5.5$.",
 "Check: " + R('2^(2*5.5/3+3/2-1/6)', 0) + ", which is $2^5$.",
 "As a fraction, $5.5=\\dfrac{11}{2}$."]
RES['AM-226'] = 5.5

begin()
S['AM-227'] = [
 "Type %s. Then $f(0)=c$: " % df('f(x)=2(3x+1-sqrt(5))(3x+1+sqrt(5))') + R('f(0)', 0) + ".",
 "Evaluate $f(1)=a+b+c$ and $f(-1)=a-b+c$: " + RR(['f(1)', 'f(-1)'], 0) + ".",
 "Then $a=\\dfrac{f(1)+f(-1)}2-c$ and $b=\\dfrac{f(1)-f(-1)}2$: " + RR(['(22+(-2))/2-(-8)', '(22-(-2))/2'], 0) + ".",
 "Finally " + R('(12+(-8))/18') + ", which is $\\dfrac29$."]
assert round(val('f(1)')) == 22 and round(val('f(-1)')) == -2 and round(val('f(0)')) == -8
RES['AM-227'] = val('(12+(-8))/18')

begin()
S['AM-229'] = [
 "The sum of the coefficients is the value at $x=1$. Type %s." % df('f(x)=((2x-3)^4(x+2)-7)/5'),
 R('f(1)') + ", which is $-\\dfrac45$.",
 "Compare with the options: " + RR(['-4/5', '3/5', '-4']) + ". Only the first matches: option (@@L@@)."]
pick('AM-229', {'-\\dfrac45': val('-4/5'), 'x1': 31, 'x2': val('3/5'), 'x3': -4}, val('f(1)'))

begin()
S['AM-235'] = [
 "Check the factoring at $x=1$: " + RR(['12*1^4-84*1^2+144', '(1^2-3)*(12*1^2-48)'], 0) + ". So $(x^2-3)(12x^2-48)$ works, i.e. $12(x^2-3)(x^2-4)$ split as $(ax^2-3a)(cx^2-4c)$, $ac=12$.",
 "The sum is $-2a-3c$ with $c=\\dfrac{12}{a}$. Type %s and evaluate: " % df('s(a)=-2a-3(12/a)') + RR(['s(1)', 's(2)', 's(3)', 's(4)'], 0) + ".",
 RR(['s(6)', 's(12)'], 0) + ". Swapping the factors, type %s and " % df('t(a)=-3a-2(12/a)') + lc(R('t(12)', 0)) + ".",
 "The least value is $%s$: option (@@L@@)." % fm(min(val('s(%d)' % a) for a in (1, 2, 3, 4, 6, 12)))]
pick('AM-235', {'-38': min(val('s(%d)' % a) for a in (1, 2, 3, 4, 6, 12)), 'x1': -27, 'x2': -22, 'x3': -18}, -38)

begin()
S['AM-237'] = [
 "In the form $a\\cdot b^{x-1}$, $a=f(1)$. Type %s and " % df('f(x)=6^(x+1)*4^x/3^(x-2)') + lc(R('f(1)', 0)) + ".",
 "The ratio of consecutive values is $b$: " + R('f(2)/f(1)', 0) + ".",
 "So $a+b=$ " + lc(R('432+8', 0)) + ": option (@@L@@)."]
assert round(val('f(1)')) == 432 and round(val('f(2)/f(1)')) == 8
SEL['AM-237'] = '440'

begin()
S['AM-239'] = [
 "Type %s and %s (letting $x$ stand for $m$)." % (c('y=x^(1/3)*x^(1/4)'), c('y=128')),
 "Tap the intersection: " + tap(4096, 128, lambda x: x**(1/3)*x**(1/4), lambda x: 128) + ", so $m=4096$.",
 "Now $ab^2$ with $a=m^{1/3}$, $b=m^{1/4}$: " + R('4096^(1/3)*(4096^(1/4))^2', 0) + "."]
RES['AM-239'] = val('4096^(1/3)*(4096^(1/4))^2')

begin()
S['AM-243'] = [
 "Divide $g$ by $15^{x+1}$ and graph: %s and " % df('g(x)=9^(x+2)*10^(x+1)/6^(x-1)') + c('h(x)=g(x)/15^(x+1)') + ". Desmos draws a flat line, so $k$ is its height.",
 "Tap the line at the $y$-axis: " + R('g(0)/15^(0+1)', 0) + ", so $k=324$.",
 "Check at $x=3$: " + R('g(3)/15^(3+1)', 0) + "."]
RES['AM-243'] = val('g(0)/15^(0+1)'); assert abs(val('g(3)/15^(3+1)') - 324) < 1e-6

begin()
S['AM-248'] = [
 "Pick $b=8$. Then $a^3=64$, so " + R('8^(2/3)', 0) + " gives $a=4$.",
 "Evaluate the left side: " + R('4^9/8^(1/3)', 0) + ".",
 "Solve $8^k=131072$: " + R('ln(131072)/ln(8)') + ", which is $\\dfrac{17}{3}$: " + lc(R('17/3')) + ". Option (@@L@@)."]
pick('AM-248', {'\\dfrac{17}{3}': val('ln(131072)/ln(8)'), 'x1': 6, 'x2': 19/3, 'x3': 17/2}, val('17/3'))

begin()
S['AM-250'] = [
 "Type %s (from $t^2-15t+36$)." % c('y=x^2-15x+36'),
 "Tap the zeros: " + tap(3, 0, lambda x: x*x-15*x+36) + " and " + tap(12, 0, lambda x: x*x-15*x+36) + ", so $\\{x,y\\}=\\{3,12\\}$.",
 "Evaluate: " + R('(1/12-1/3)/(1/12^2-1/3^2)') + ", which is " + lc(R('12/5')) + ". Option (@@L@@)."]
pick('AM-250', {'\\dfrac{12}{5}': val('(1/12-1/3)/(1/12^2-1/3^2)'), 'x1': 1, 'x2': 4, 'x3': 5/12}, val('12/5'))

# ---------------- Nonlinear equations
begin()
S['AM-008'] = [
 "Graph each side: type %s and %s." % (c('y=sqrt(x+7)'), c('y=x-5')),
 "Tap the intersection: " + tap(9, 4, lambda x: math.sqrt(x+7), lambda x: x-5) + ". The line and curve meet only once, so $x=9$.",
 R('sqrt(9+7)') + "; " + lc(R('9-5')) + ". Both sides agree at $x=9$.",
 "Squaring also produces $x=2$, but there the line is at $%s$ and the curve at $%s$: extraneous. Option (@@L@@)." % (fm(val('2-5')), fm(val('sqrt(2+7)')))]
SEL['AM-008'] = 'x=9only'

begin()
S['AM-069'] = [
 "Type %s and %s." % (c('y=sqrt(2x+7)'), c('y=5')),
 "Tap the intersection: " + tap(9, 5, lambda x: math.sqrt(2*x+7), lambda x: 5) + ", so $x=9$.",
 "Check: " + R('sqrt(2*9+7)', 0) + "."]
RES['AM-069'] = 9

begin()
S['AM-091'] = [
 "Consecutive integers: $b=a+1$, so $a+1=13+\\sqrt a$. Type %s and %s (letting $x$ stand for $a$)." % (c('y=x+1'), c('y=13+sqrt(x)')),
 "Tap the intersection: " + tap(16, 17, lambda x: x+1, lambda x: 13+math.sqrt(x)) + ", so $a=16$ (the curves cross once).",
 "Check: " + R('13+sqrt(16)', 0) + ", which equals $16+1$."]
RES['AM-091'] = 16

begin()
S['AM-096'] = [
 "Type %s and %s (letting $x$ stand for $m$)." % (c('y=sqrt(x+11)'), c('y=4')),
 "The curve starts at " + tap(-11, 0, lambda x: math.sqrt(x+11)) + " and meets the line at " + tap(5, 4, lambda x: math.sqrt(x+11), lambda x: 4) + ". It is at or below the line for $-11\\le m\\le5$.",
 "The even integers there run from $-10$ to $4$: " + R('(4-(-10))/2+1', 0) + " values."]
RES['AM-096'] = val('(4-(-10))/2+1')

begin()
S['AM-166'] = [
 "Write both equations with base $2$ and type the exponent equations: %s and %s (letting $x$, $y$ be the unknowns)." % (c('x/3+2y=8'), c('4x-2y/3=22')),
 "Tap the intersection: " + tap(6, 3, lambda x: (8-x/3)/2, lambda x: (4*x-22)*3/2) + ", so $x=6$, $y=3$.",
 R('6*3', 0) + ".",
 "Check the originals: " + RR(['(2^6)^(1/3)*4^3', '16^6/(4^3)^(1/3)', '2^22'], 0) + "."]
RES['AM-166'] = 18

begin()
x206 = 13 + 4*math.sqrt(3); y206 = 13 - 4*math.sqrt(3)
S['AM-206'] = [
 "Type %s and %s (curves in the $xy$-plane)." % (c('sqrt(x)-sqrt(y)=2'), c('x+y=26')),
 "Tap the intersection: " + pt(round(x206, 4), round(y206, 4)) + ", i.e. $x\\approx%s$, $y\\approx%s$." % (n(x206, 4), n(y206, 4)),
 R('%s*%s' % (n(x206, 4), n(y206, 4)), 1) + ", so $xy=121$."]
claim('206 eq1', abs(math.sqrt(x206)-math.sqrt(y206)-2) < 1e-9); claim('206 eq2', abs(x206+y206-26) < 1e-9)
RES['AM-206'] = round(x206*y206)

# ---------------- Nonlinear functions
begin()
S['AM-145'] = [
 "The point $(0,-\\sqrt{252})$ gives $q=252$. The point $(6,0)$ gives $36+6p+252=0$: " + R('-(36+252)/6', 0) + ", so $p=-48$.",
 "Zeros of $m$ are zeros of $z^2-48z+252$: type %s." % c('y=x^2-48x+252'),
 "Tap the zeros: " + tap(6, 0, lambda x: x*x-48*x+252) + " and " + tap(42, 0, lambda x: x*x-48*x+252) + ". The greatest is $42$.",
 "Check the product: " + R('6*42', 0) + "."]
RES['AM-145'] = 42

begin()
S['AM-148'] = [
 "The point $(0,-\\sqrt{314})$ gives $c=314$. The point $(2,0)$ gives $4+2b+314=0$: " + R('-(4+314)/2', 0) + ", so $b=-159$.",
 "Type %s." % c('y=x^2-159x+314'),
 "Tap the two zeros: " + tap(2, 0, lambda x: x*x-159*x+314) + " and " + tap(157, 0, lambda x: x*x-159*x+314) + ".",
 "The distance between the intercepts: " + R('157-2', 0) + "."]
RES['AM-148'] = 155

begin()
p233 = lambda x: -(x+3)**2*(x-1)**3*(x-4)**2
claim('233 zeros', all(p233(z) == 0 for z in (-3, 1, 4)))
S['AM-233'] = [
 "Type %s and zoom out. Tap the zeros: " % df('p(x)=-(x+3)^2(x-1)^3(x-4)^2') + tap(-3, 0, p233) + ", " + tap(1, 0, p233) + ", " + tap(4, 0, p233) + ". For $x<1$ the graph is on or above the axis: statement I is true.",
 "Check near $x=4$: " + RR(['p(3.9)', 'p(4.1)']) + ". Both are negative, so the graph touches the axis at $x=4$ and does not cross: statement II is false.",
 "Far to the left: " + RR(['p(-10)', 'p(-20)'], 0) + ". The values are positive and growing, so $p(x)\\to\\infty$: statement III is true.",
 "So I and III only: option (@@L@@)."]
assert val('p(3.9)') < 0 and val('p(4.1)') < 0 and val('p(-10)') > 0 and val('p(-20)') > val('p(-10)')
SEL['AM-233'] = '=IandIIIonly'

begin()
S['AM-257'] = [
 "Type %s and %s." % (df('h(x)=sqrt(x-2)+1'), df('g(x)=h(x+5)')),
 "Tap the starting point of $g$: " + tap(-3, 2 if False else 1, lambda x: val('g(%s)' % x)) + ". The graph exists only for $x\\ge-3$.",
 "Check: " + RR(['g(-3)', 'g(-2)'], 0) + ". (Typing $g(-4)$ gives no value.)",
 "The domain is $x\\ge-3$: option (@@L@@)."]
SEL['AM-257'] = 'x\\ge-3'

begin()
S['AM-035'] = [
 "Type the rule as a function: %s." % df('f(x)=2x-3'),
 "Start with $a_1=5$: " + RR(['f(5)', 'f(f(5))'], 0) + " (these are $a_2$ and $a_3$).",
 "Then " + R('f(f(f(5)))', 0) + ", which is $a_4$."]
RES['AM-035'] = val('f(f(f(5)))')

begin()
S['AM-063'] = [
 "After one hour a $12\\%$ decrease leaves " + R('250*(1-0.12)', 0) + ".",
 "Test each option at $t=1$: " + RR(['250*0.12^1', '250*0.88^1', '250*1.12^1', '250-12*1'], 0) + ".",
 "Only $250(0.88)^t$ gives $220$. Check $t=2$: " + RR(['220*0.88', '250*0.88^2']) + ". Option (@@L@@)."]
pick('AM-063', {'0.88': val('250*0.88^1'), 'x1': val('250*0.12^1'), 'x2': val('250*1.12^1'), 'x3': val('250-12*1')}, val('250*(1-0.12)'))

begin()
S['AM-088'] = [
 "Type the rule: %s." % df('f(x)=3x-2'),
 "Starting from $a_1=-4$: " + RR(['f(-4)', 'f(f(-4))'], 0) + " ($a_2$ and $a_3$).",
 RR(['f(f(f(-4)))', 'f(f(f(f(-4))))'], 0) + " ($a_4$ and $a_5$).",
 "$|a_4|=134<150$ but $|a_5|=404>150$, so the $5$th term: option (@@L@@)."]
assert val('f(f(f(-4)))') == -134 and val('f(f(f(f(-4))))') == -404
SEL['AM-088'] = '5'

begin()
S['AM-160'] = [
 "Divide: $b^3=\\dfrac{486}{18}$. " + R('(486/18)^(1/3)', 0) + ", so $b=3$.",
 "Then $a\\cdot3^2=18$: " + R('18/3^2', 0) + ", so $a=2$.",
 "Check $f(5)$: " + R('2*3^5', 0) + ".",
 "Finally " + R('2*3^4', 0) + "."]
RES['AM-160'] = val('2*3^4')

begin()
S['AM-173'] = [
 "Type %s." % df('V(t)=500*2^(t/2)*4^(t/3)*16^(-t/12)'),
 "Compare $V$ six hours apart: " + R('V(6)/V(0)', 0) + ".",
 "Try a different start: " + R('V(10)/V(4)', 0) + ". The factor is constant, $c=32$."]
RES['AM-173'] = val('V(6)/V(0)'); assert abs(val('V(10)/V(4)') - 32) < 1e-6

# ---------------- Part B
begin()
S['AM-002'] = [
 "Type %s." % df('P(t)=5000*1.15^t'),
 "Compare five years apart: " + R('P(5)/P(0)') + ".",
 "Try another start: " + R('P(12)/P(7)') + ": the same factor, so it is $1.15^5\\approx2.01$. Option (@@L@@)."]
assert abs(val('P(5)/P(0)') - val('P(12)/P(7)')) < 1e-9; SEL['AM-002'] = '2.01'

begin()
S['AM-004'] = [
 "Type %s." % df('V(t)=120000*0.88^t'),
 R('V(4)', 0) + ", which rounds to $72{,}000$ dollars: option (@@L@@).",
 "Trap check (simple $12\\%$ a year): " + R('120000*(1-0.12*4)', 0) + ", which is not an option."]
SEL['AM-004'] = '72{,}000'

begin()
S['AM-045'] = [
 "Type %s." % df('E(t)=1450*1.08^t'),
 "The start of the model is $t=0$: " + R('E(0)', 0) + ". So $1450$ is the capacity when the facility opened.",
 "The other readings fail: " + RR(['E(15)', 'ln(2)/ln(1.08)']) + " (the capacity at $t=15$ and the doubling time), neither is $1450$. Option (@@L@@)."]
SEL['AM-045'] = 'whenthefacilityopened'

begin()
S['AM-061'] = [
 "Type %s." % df('P(t)=300*1.5^t'),
 R('P(3)') + ".",
 "Trap check (linear growth): " + R('300*1.5*3') + ". The answer is option (@@L@@)."]
SEL['AM-061'] = '1{,}012.5'

begin()
S['AM-065'] = [
 "Type %s." % df('N(t)=500*1.2^t'),
 R('N(5)') + ".",
 "The closest option is $1{,}244$ (linear trap: " + lc(R('500*1.2*5', 0)) + "). Option (@@L@@)."]
SEL['AM-065'] = '1{,}244'

begin()
S['AM-072'] = [
 "Type %s." % df('M(t)=200*0.85^t'),
 R('M(6)') + ".",
 "The closest option is $75.5$ (linear trap: " + lc(R('200*0.85*6', 0)) + "). Option (@@L@@)."]
SEL['AM-072'] = '75.5'

begin()
S['AM-080'] = [
 "One year of $2.4\\%$ growth on $60$ thousand: " + R('60*(1+2.4/100)') + ".",
 "Test each option at $t=1$: " + RR(['60*1.024^1', '60*2.4^1', '1.024*1+60', '2.4*1+60']) + ".",
 "Only $60(1.024)^t$ gives $61.44$. Check $t=2$: " + RR(['61.44*1.024', '60*1.024^2']) + ". Option (@@L@@)."]
SEL['AM-080'] = '60(1.024)'

begin()
S['AM-105'] = [
 "Type the rule: %s." % df('a(n)=3*6^(n-1)'),
 "Check against the list: " + RR(['a(2)', 'a(4)'], 0) + ".",
 "The $9$th term: " + R('a(9)', 0) + ". Compare the options: " + RR(['3*6^8', '648*9', '3^9', '6*3^8'], 0) + ".",
 "Only $3\\times6^8$ matches: option (@@L@@)."]
assert val('a(9)') == val('3*6^8'); SEL['AM-105'] = '3\\times6^8'

begin()
S['AM-121'] = [
 "The fourth term is $2r^3=54$: " + R('(54/2)^(1/3)', 0) + ", so $r=3$.",
 "Check: " + R('2*3^3', 0) + ".",
 "Sum of five terms: " + R('2*(3^5-1)/(3-1)', 0) + "."]
RES['AM-121'] = val('2*(3^5-1)/(3-1)')

begin()
P200 = lambda t: 120/(1+5*0.8**t); t60 = brentq(lambda t: P200(t)-60, 0, 10)
S['AM-200'] = [
 "Type %s (letting $x$ stand for $t$). The curve rises from %s to %s, so statement I is true." % (c('y=120/(1+5*0.8^x)\\{0<=x<=10\\}'), tap(0, 20, P200), tap(10, P200(10), P200, tol=1e-6)),
 "Add %s and tap the intersection: %s. It lies inside the interval: statement II is true." % (c('y=60'), tap(round(t60, 4), 60, P200, tol=1e-3)),
 "Add %s: it never meets the graph for $0\\le t\\le10$, because the highest point is " % c('y=80') + R('120/(1+5*0.8^10)', 2) + ". Statement III is false.",
 "So I and II only: option (@@L@@)."]
SEL['AM-200'] = '=IandIIonly'

begin()
S['AM-205'] = [
 "Type %s." % df('V(t)=2400*0.64^(t/2.5)'),
 "Ratio over $2.5$ years: " + R('V(2.5)/V(0)') + ", a fall of " + lc(R('(1-V(2.5)/V(0))*100', 0)) + " percent.",
 "Ratio over $5$ years: " + R('V(5)/V(0)') + ", a fall of " + lc(R('(1-V(5)/V(0))*100', 1)) + " percent, not $36$; each year: " + lc(R('(1-V(1)/V(0))*100', 1)) + " percent, not $2.5$.",
 "So it falls $36\\%$ every $2.5$ years: option (@@L@@)."]
SEL['AM-205'] = '36\\%$every$2.5'

begin()
S['AM-219'] = [
 "Type %s and the shifted version %s ($m$ months after January 1, 2023 is $t=3+\\frac m{12}$)." % (df('A(t)=300*4^(t/3)'), df('B(m)=A(3+m/12)')),
 "At $m=0$ and $m=12$: " + RR(['B(0)', 'B(12)'], 1) + ".",
 "Test each option at $m=12$: " + RR(['300*2^(12/18)', '1200*2^(12/36)', '900*2^(12/18)', '1200*2^(12/18)'], 1) + ".",
 "Only $1200\\cdot2^{m/18}$ matches: option (@@L@@)."]
pick('AM-219', {'1200\\cdot2^{m/18}': val('1200*2^(12/18)'), 'x1': val('300*2^(12/18)'), 'x2': val('1200*2^(12/36)'), 'x3': val('900*2^(12/18)')}, val('B(12)'))

begin()
S['AM-242'] = [
 "Type %s. " % df('T(t)=24+66*0.85^t') + RR(['T(0)', 'T(1)']) + ".",
 "The gap above $24$: " + RR(['T(0)-24', 'T(1)-24', '0.85*(T(0)-24)']) + ". The gap shrinks by the factor $0.85$ each minute.",
 "But " + R('0.85*T(0)') + " is not $T(1)$, so $T$ itself does not fall by $15\\%$. Option (@@L@@)."]
SEL['AM-242'] = 'thegapT-24falls'

begin()
S['PS-001'] = [
 "Successive changes multiply: " + R('1.25*0.88') + ", so $1.1x=9{,}020{,}000$.",
 "Solve: " + R('9020000/1.1', 0) + ".",
 "Check forward: " + R('8200000*1.25*0.88', 0) + "."]
RES['PS-001'] = val('9020000/1.1')

begin()
S['PS-002'] = [
 "Discount then tax multiply: " + R('0.7*1.05', 3) + ", so $0.735x=44.10$.",
 "Solve: " + R('44.10/0.735', 2) + ".",
 "Check forward: " + R('60*0.7*1.05', 2) + ". Option (@@L@@)."]
SEL['PS-002'] = '60.00'

begin()
S['PS-014'] = [
 "The final price is $85\\%$ of the price at the end of the promotion: " + R('1020/0.85', 0) + ".",
 "Check: " + R('1200*0.85', 0) + ".",
 "The original price (the trap in $1{,}000$): " + R('1200/1.2', 0) + ". The answer is option (@@L@@)."]
SEL['PS-014'] = '1{,}200'

begin()
S['PS-016'] = [
 "Week 3 is $75\\%$ of Week 2: " + R('8400/0.75', 0) + " families in Week 2.",
 "The difference: " + R('8400/0.75-8400', 0) + ".",
 "Check with Week 1: " + R('8400/(1.4*0.75)', 0) + "; " + lc(R('1.4*8000', 0)) + " in Week 2."]
RES['PS-016'] = val('8400/0.75-8400')

begin()
S['PS-023'] = [
 "Take $y=50$. A $12\\%$ decrease: " + R('50*(1-0.12)', 0) + ".",
 "Test the options at $y=50$: " + RR(['0.88*50', '0.12*50', '50-12', '50-0.12'], 2) + ".",
 "Only $0.88y$ gives $44$. Check $y=200$: " + RR(['200*(1-0.12)', '0.88*200'], 0) + ". Option (@@L@@)."]
SEL['PS-023'] = '0.88y'
SEL['AM-194'] = '=IandIIonly'   # statements I and II verified by the p, q test above; III refuted by its counterexample
