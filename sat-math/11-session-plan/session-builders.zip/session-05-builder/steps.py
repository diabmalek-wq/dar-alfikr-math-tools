"""Tutor solution steps for Session 5.
Every number quoted in a step is computed here from the item data; every typed Desmos/calculator
expression that 'returns' a value goes through ret() (evaluated by ev()); verify_steps.py re-checks
all of them from the final text with an independent evaluator."""
import math, re
from fractions import Fraction as Fr
from scipy.optimize import brentq

def n(v, d=4):
    s = ('%.*f' % (d, v)).rstrip('0').rstrip('.')
    return '0' if s in ('-0', '') else s
def fm(v, d=4):
    """number with {,} thousands grouping for the text"""
    if isinstance(v, Fr): v = float(v)
    if abs(v - round(v)) < 1e-9:
        s = '{:,}'.format(int(round(v))); return s.replace(',', '{,}')
    s = n(v, d)
    ip, _, fp = s.partition('.')
    ip = '{:,}'.format(int(ip)).replace(',', '{,}') if abs(int(ip)) >= 1000 else ip
    return ip + ('.' + fp if fp else '')
def ev(expr, **kw):
    e = expr.replace('^', '**')
    e = re.sub(r'(\d|\))\s*(\(|[a-zA-Z])', r'\1*\2', e)
    env = dict(sqrt=math.sqrt, abs=abs, ln=math.log, **kw)
    return eval(e, {'__builtins__': {}}, env)
def c(e): return '[[%s]]' % e
def v(x, d=4): return '$%s$' % fm(x, d)
def ret(e, d=4, **kw): return "Type %s: it returns %s" % (c(e), v(ev(e, **kw), d))
def lc(t): return t[0].lower()+t[1:]
def pt(x, y, d=4): return "$(%s,\\,%s)$" % (fm(x, d), fm(y, d))
def fr(F):
    F = Fr(F)
    if F.denominator == 1: return str(F.numerator)
    return ("-" if F < 0 else "") + "\\dfrac{%d}{%d}" % (abs(F.numerator), F.denominator)

S = {}      # id -> list of step strings (@@L@@ = letter of the correct option, filled in by build.py)
KEY = {}    # id -> text that the correct option must contain (MCQ) -- cross-check against the option text
RES = {}    # id -> value derived inside the steps (SPR / numeric MCQ), cross-checked against solve.py
CLAIMS = [] # (description, bool) tapped points etc.; asserted in verify_steps.py
def claim(desc, ok): CLAIMS.append((desc, bool(ok))); assert ok, desc

# ------------------------------------------------------------------ Equivalent expressions
# AM-193
d2 = 3 - (-1); k193 = 2**d2 * 3**3
S['AM-193'] = [
 "Split the base: $6^{2x+3}=2^{2x+3}\\cdot3^{2x+3}$.",
 "The powers of $2$ cancel down: $\\dfrac{2^{2x+3}}{2^{2x-1}}=2^{(2x+3)-(2x-1)}=2^{%d}=%d$." % (d2, 2**d2),
 "The powers of $3$: $3^{2x+3}=3^{3}\\cdot(3^{2})^{x}=%d\\cdot9^{x}$." % 3**3,
 "So the left side is $%d\\cdot%d\\cdot9^{x}=%d\\cdot9^{x}$ and $k=%d$." % (2**d2, 3**3, k193, k193)]
RES['AM-193'] = k193

# AM-194
b_, c_ = 3, 2; p_, q_ = 1, 2
assert p_ + q_ == b_ and p_ * q_ == c_
S['AM-194'] = [
 "Expand: $(x+p)(x+q)=x^2+(p+q)x+pq$, so $b=p+q$ and $c=pq$, both integers. Statement I is true.",
 "$p^2+q^2=(p+q)^2-2pq=b^2-2c$, an integer, so statement II is true.",
 "Statement III needs $\\dfrac{b^2-2c}{2}$ to be an integer, which fails when $b$ is odd. Try $p=%d$, $q=%d$ ($b=%d$, $c=%d$): $p^2+q^2=%d$, and $\\dfrac{%d}{2}$ is not an integer." % (p_, q_, b_, c_, p_**2 + q_**2, p_**2 + q_**2),
 "Only I and II must be true: option (@@L@@)."]
KEY['AM-194'] = '=IandIIonly'

# AM-195
a195 = Fr(3 + 8 + 4, 3); c195 = 4 - a195; b195 = a195 - 3
assert a195 == 5 and b195 == 2 and a195 + b195 - c195 == 8 and a195 + c195 == 4
S['AM-195'] = [
 "Multiply both sides by $x^3-1=(x-1)(x^2+x+1)$: $a(x^2+x+1)-(bx+c)(x-1)=3x^2+8x+4$.",
 "Put $x=1$ so that the second term vanishes: $3a=3+8+4=%d$, so $a=%d$." % (3+8+4, a195),
 "Put $x=0$: $a+c=4$, so $c=4-%d=%s$." % (a195, c195),
 "Check with the $x^2$ and $x$ coefficients: $%d-b=3$ gives $b=%d$, and $%d+b-c=%d+%d+%d=8$ as required." % (a195, b195, a195, a195, b195, -c195)]
RES['AM-195'] = c195

# AM-197
S['AM-197'] = [
 "Let $u=\\dfrac1y$. The expression becomes $\\dfrac{u^3-27}{u-3}$.",
 "Difference of cubes: $u^3-27=(u-3)(u^2+3u+9)$ (the middle sign is $+$). Check: $(u-3)(u^2+3u+9)=u^3+3u^2+9u-3u^2-9u-27=u^3-27$.",
 "Cancel $u-3$ (not zero because $y\\neq\\tfrac13$): $u^2+3u+9=\\dfrac1{y^2}+\\dfrac3y+9$, option (@@L@@)."]
KEY['AM-197'] = '\\dfrac1{y^2}+\\dfrac3y+9'

# AM-198
rows = []
ks198 = []
for nn in (1, 2, 3, 4, 6, 12):
    kk = Fr(12, nn) + 9*nn - nn*nn; assert kk.denominator == 1
    rows.append((nn, int(kk)))
good = sorted({k for _, k in rows if k > 0})
S['AM-198'] = [
 "If $x-n$ is a factor then $p(n)=0$: $n^3-9n^2+kn-12=0$, so $k=\\dfrac{12}{n}+9n-n^2$. For $k$ to be an integer, $n$ must divide $12$: $n\\in\\{1,2,3,4,6,12\\}$.",
 "Compute $k$ for each: " + "; ".join("$n=%d$: $k=%s$" % (a, fm(b)) for a, b in rows) + ".",
 "Keep only positive $k$ and count each value once: $k\\in\\{%s\\}$ ($n=12$ gives a negative $k$)." % ",".join(map(str, good)),
 "The sum is $%s=%d$." % ("+".join(map(str, good)), sum(good))]
RES['AM-198'] = sum(good)

# AM-203
S['AM-203'] = [
 "Rewrite the radical as a power: $\\sqrt[5]{w^{2}}=w^{2/5}$, so $P=\\dfrac{a}{w^{2/5}}$.",
 "Multiply by $w^{2/5}$ and divide by $P$: $w^{2/5}=\\dfrac{a}{P}$ (the $a$ stays on top).",
 "Raise both sides to the reciprocal power $\\dfrac52$: $w=\\left(\\dfrac aP\\right)^{5/2}$, option (@@L@@). Options with the exponent $\\dfrac25$ forgot to flip it."]
KEY['AM-203'] = '(\\dfrac{a}{P})^{5/2}'

# AM-207
s207 = Fr(3) + Fr(2, 3) + Fr(1, 2)
S['AM-207'] = [
 "Write every base as a power of $2$: $8^{x}=2^{3x}$, $4^{x/3}=2^{2x/3}$, $(\\sqrt2)^{x}=2^{x/2}$.",
 "Add the exponents: $3+\\dfrac23+\\dfrac12=%s$, so $b^{x}=2^{%sx}$ and $b=2^{%s}$." % (fr(s207), fr(s207), fr(s207)),
 "Raise $b$ to the reciprocal power $%s$: $b^{%s}=2$, option (@@L@@)." % (fr(1/s207), fr(1/s207))]
KEY['AM-207'] = 'b^{%s}' % ('6/25')
assert 1/s207 == Fr(6, 25)

# AM-212
S['AM-212'] = [
 "Get the $b$ term alone: $\\dfrac3b=\\dfrac2a-\\dfrac5c$.",
 "Common denominator $ac$: $\\dfrac3b=\\dfrac{2c-5a}{ac}$.",
 "Take the reciprocal of both sides and multiply by $3$: $b=\\dfrac{3ac}{2c-5a}$, option (@@L@@). The condition $2c\\neq5a$ is what keeps this denominator nonzero."]
KEY['AM-212'] = '3ac}{2c-5a'

# AM-217
pairs = [(a, 24//a) for a in (1, 2, 3, 4, 6, 8, 12, 24)]
ks217 = [(a, b, 2*b + 3*a) for a, b in pairs]
S['AM-217'] = [
 "Expand: $(2x^2+a)(3x^2+b)=6x^4+(2b+3a)x^2+ab$, so $ab=24$ and $k=2b+3a$.",
 "List the positive pairs with $ab=24$ (negative pairs give negative $k$): " + "; ".join("$(%d,%d)\\to k=%d$" % t for t in ks217) + ".",
 "The greatest value is $k=%d$ (from $a=24$, $b=1$)." % max(t[2] for t in ks217)]
RES['AM-217'] = max(t[2] for t in ks217)

# AM-218
a8 = Fr(1) - Fr(8, 10)
S['AM-218'] = [
 "Add the first two fractions: $\\dfrac1{1-a}+\\dfrac1{1+a}=\\dfrac{2}{1-a^2}$.",
 "Add $\\dfrac{2}{1+a^2}$: $\\dfrac{2(1+a^2)+2(1-a^2)}{1-a^4}=\\dfrac{4}{1-a^4}$. Add $\\dfrac4{1+a^4}$ the same way: $\\dfrac{8}{1-a^8}$.",
 "Solve $\\dfrac{8}{1-a^8}=10$: $1-a^8=\\dfrac{8}{10}$, so $a^8=1-\\dfrac45=%s$, option (@@L@@)." % fr(a8)]
KEY['AM-218'] = '\\dfrac15'; assert a8 == Fr(1, 5)

# AM-224
S['AM-224'] = [
 "Expand: $(3a+b)^2=9a^2+6ab+b^2$ and $(a+3b)^2=a^2+6ab+9b^2$.",
 "Subtract: the $6ab$ terms cancel, leaving $8a^2-8b^2=8(a^2-b^2)$.",
 "Substitute $a^2-b^2=36$: $8\\cdot36=%d$." % (8*36)]
RES['AM-224'] = 8*36

# AM-225
x_t = 1; y_t = Fr(8 - 2*x_t, 3)
chk225 = 2*x_t**2 + 3*x_t*y_t - 4*x_t - 6*y_t
assert chk225 == 8*x_t - 16
S['AM-225'] = [
 "Factor by grouping: $2x^2+3xy-4x-6y=x(2x+3y)-2(2x+3y)=(x-2)(2x+3y)$.",
 "Substitute $2x+3y=8$: $8(x-2)=8x-16$, option (@@L@@).",
 "Quick check: $x=%d$ gives $y=%s$, and the original expression is $%s$, while $8x-16=%d$." % (x_t, fr(y_t), fr(chk225), 8*x_t-16)]
KEY['AM-225'] = '8x-16'

# AM-226
e_l = Fr(3, 2) - Fr(1, 6)   # n^3 / t^(1/6)
rhs = 5 - e_l
p226 = rhs / Fr(2, 3)
S['AM-226'] = [
 "Write everything as powers of $t$: $m=t^{2/3}$ and $n=t^{1/2}$, so $m^p=t^{2p/3}$ and $n^3=t^{3/2}$.",
 "Combine the exponents on the left: $\\dfrac{2p}{3}+\\dfrac32-\\dfrac16=\\dfrac{2p}{3}+%s$." % fr(e_l),
 "Equate exponents ($t\\neq1$): $\\dfrac{2p}{3}+%s=5$, so $\\dfrac{2p}{3}=%s$ and $p=%s$ (which is $%s$ as a decimal)." % (fr(e_l), fr(rhs), fr(p226), n(float(p226)))]
RES['AM-226'] = p226

# AM-229
f229 = lambda x: ((2*x - 3)**4 * (x + 2) - 7) / 5
inner = (2 - 3)**4 * (1 + 2)
S['AM-229'] = [
 "The sum $a+b+c+d+e+f$ is the value of the polynomial at $x=1$ (every power of $1$ is $1$), so no expanding is needed.",
 "At $x=1$: $(2-3)^4(1+2)=%d\\cdot%d=%d$." % ((2-3)**4, 1+2, inner),
 "Then $\\dfrac{%d-7}{5}=%s$, option (@@L@@)." % (inner, fr(Fr(inner - 7, 5)))]
KEY['AM-229'] = '-\\dfrac45'; assert Fr(inner-7, 5) == Fr(-4, 5)

# AM-235
cands = []
for a in (1, 2, 3, 4, 6, 12):
    cc = 12 // a
    cands.append((a, cc, -2*a - 3*cc, -3*a - 2*cc))
best235 = min(min(t[2], t[3]) for t in cands)
S['AM-235'] = [
 "Factor out $12$ and then the quadratic in $x^2$: $12x^4-84x^2+144=12(x^2-3)(x^2-4)$.",
 "Split the $12$ as $ac$: $(ax^2-3a)(cx^2-4c)$ with $ac=12$. Then $a+b+c+d=a+c-3a-4c=-2a-3c$. (Swapping the roles of the two factors gives $-3a-2c$.)",
 "To make this as small as possible, put the big coefficient on the larger multiplier: $a=1$, $c=12$ gives $-2(1)-3(12)=%d$, from $(x^2-3)(12x^2-48)$ with $1-3+12-48=%d$." % (-2*1-3*12, 1-3+12-48),
 "The other splits give sums such as %s (these are the other options), all larger, so the least value is $%d$, option (@@L@@)." % (", ".join("$%d$" % t for t in sorted({x for t in cands for x in t[2:]})[1:4]), best235)]
KEY['AM-235'] = '-38'; assert best235 == -38

# AM-237
a237 = 2 * 27 * 8; b237 = 8
S['AM-237'] = [
 "Write the bases with primes: $6^{x+1}=2^{x+1}3^{x+1}$ and $4^{x}=2^{2x}$.",
 "Divide by $3^{x-2}$: the powers of $3$ give $3^{(x+1)-(x-2)}=3^{3}=%d$; the powers of $2$ give $2^{3x+1}=2\\cdot8^{x}$. So $f(x)=%d\\cdot8^{x}$." % (27, 2*27),
 "Match the form $a\\cdot b^{x-1}$: $b=8$ and $%d\\cdot8^{x}=%d\\cdot8\\cdot8^{x-1}=%d\\cdot8^{x-1}$, so $a=%d$." % (54, 54, a237, a237),
 "Then $a+b=%d+%d=%d$, option (@@L@@)." % (a237, b237, a237 + b237)]
RES['AM-237'] = a237 + b237; KEY['AM-237'] = '440'

# AM-239
s_ab = Fr(1, 3) + Fr(1, 4); s_ab2 = Fr(1, 3) + Fr(2, 4); e_m = Fr(7) / s_ab
r239 = 2**int(e_m * s_ab2)
S['AM-239'] = [
 "$ab=m^{1/3}\\cdot m^{1/4}=m^{%s}$." % fr(s_ab),
 "Since $128=2^{7}$: $m^{%s}=2^{7}$, so $m=2^{7\\cdot%s}=2^{%d}$." % (fr(s_ab), fr(1/s_ab), e_m),
 "Now $ab^{2}=m^{1/3}\\cdot m^{2/4}=m^{%s}=2^{%d\\cdot%s}=2^{%d}=%d$." % (fr(s_ab2), e_m, fr(s_ab2), e_m*s_ab2, r239)]
RES['AM-239'] = r239

# AM-243
k243 = 2**2 * 3**4
S['AM-243'] = [
 "Use prime bases: $9^{x+2}=3^{2x+4}$, $10^{x+1}=2^{x+1}5^{x+1}$, $6^{x-1}=2^{x-1}3^{x-1}$.",
 "Divide: powers of $2$ give $2^{(x+1)-(x-1)}=2^{2}=%d$; powers of $3$ give $3^{(2x+4)-(x-1)}=3^{x+5}$; and $5^{x+1}$ stays." % 4,
 "Pull out $3^{4}$ so the other $3$ and $5$ pair up into $15$: $3^{x+5}\\cdot5^{x+1}=3^{4}\\cdot(3\\cdot5)^{x+1}=%d\\cdot15^{x+1}$." % 3**4,
 "So $g(x)=%d\\cdot%d\\cdot15^{x+1}$ and $k=%d$." % (4, 3**4, k243)]
RES['AM-243'] = k243

# AM-248
e248 = 6 - Fr(1, 3)
S['AM-248'] = [
 "From $a^{3}=b^{2}$ we get $a=b^{2/3}$.",
 "Then $a^{9}=b^{\\frac23\\cdot9}=b^{%d}$." % 6,
 "Divide by $\\sqrt[3]{b}=b^{1/3}$: $b^{6-1/3}=b^{%s}$, so $k=%s$, option (@@L@@)." % (fr(e248), fr(e248))]
KEY['AM-248'] = '\\dfrac{17}{3}'; assert e248 == Fr(17, 3)

# AM-250
val250 = Fr(36, 15)
S['AM-250'] = [
 "Factor the bottom as a difference of squares: $\\dfrac1{x^2}-\\dfrac1{y^2}=\\left(\\dfrac1x-\\dfrac1y\\right)\\left(\\dfrac1x+\\dfrac1y\\right)$.",
 "Cancel $\\dfrac1x-\\dfrac1y$ (not zero since $x\\neq y$): the expression is $\\dfrac{1}{\\frac1x+\\frac1y}=\\dfrac{xy}{x+y}$.",
 "Substitute: $\\dfrac{36}{15}=%s$, option (@@L@@)." % fr(val250)]
KEY['AM-250'] = '\\dfrac{12}{5}'

# ------------------------------------------------------------------ Nonlinear equations (D = Desmos)
# AM-008
claim('008 intersection', math.isclose(math.sqrt(9+7), 9-5) and math.sqrt(2+7) > 2-5)
S['AM-008'] = [
 "Graph each side: type %s and %s." % (c('y=sqrt(x+7)'), c('y=x-5')),
 "Tap the intersection: %s. The line and the curve meet only once, so there is exactly one solution, $x=9$." % pt(9, 4),
 ret('sqrt(9+7)') + "; " + lc(ret('9-5')) + ". Both sides agree at $x=9$.",
 "Squaring also produces $x=2$, but at $x=2$ the line is at $-3$ while the curve is at $3$: extraneous. The answer is option (@@L@@)."]
KEY['AM-008'] = 'x=9only'

# AM-069
S['AM-069'] = [
 "Square both sides: $2x+7=25$.",
 "Subtract $7$: $2x=%d$, so $x=%d$." % (25-7, (25-7)//2),
 "Check in the original equation: $\\sqrt{2(%d)+7}=\\sqrt{%d}=%d$." % (9, 2*9+7, 5)]
RES['AM-069'] = (25 - 7) // 2

# AM-091
claim('091 intersection', 16 + 1 == 13 + math.sqrt(16))
S['AM-091'] = [
 "Consecutive integers with $b>a$ means $b=a+1$, so $a+1=13+\\sqrt a$. Type %s and %s (letting $x$ stand for $a$)." % (c('y=x+1'), c('y=13+sqrt(x)')),
 "Tap the intersection: %s, so $a=16$ (the curves cross only once)." % pt(16, 17),
 ret('13+sqrt(16)') + ", which equals $16+1$: confirmed, with $b=17$."]
RES['AM-091'] = 16

# AM-096
ms = [m for m in range(-30, 30) if m % 2 == 0 and m + 11 >= 0 and math.sqrt(m + 11) <= 4]
S['AM-096'] = [
 "The square root needs $m+11\\ge0$, so $m\\ge-11$.",
 "Square both sides of $\\sqrt{m+11}\\le4$ (both sides are non-negative): $m+11\\le%d$, so $m\\le%d$." % (16, 16-11),
 "The even integers from $-11$ to $%d$ are $%s$, a total of $%d$ values." % (5, ",".join(map(str, ms)), len(ms))]
RES['AM-096'] = len(ms)

# AM-166
A = Fr(3)  # solve x/3+2y=8 and 4x-2y/3=22  ->  x+6y=24, 6x-y=33
xs166 = Fr(24 + 6*33, 1 + 36); ys166 = 6*xs166 - 33
assert xs166 + 6*ys166 == 24 and 12*xs166 - 2*ys166 == 66
S['AM-166'] = [
 "Use base $2$: $\\sqrt[3]{2^{x}}\\cdot4^{y}=2^{x/3+2y}=2^{8}$, so $\\dfrac x3+2y=8$, i.e. $x+6y=24$.",
 "Second equation: $\\dfrac{16^{x}}{\\sqrt[3]{4^{y}}}=2^{4x-2y/3}=2^{22}$, so $4x-\\dfrac{2y}{3}=22$, i.e. $12x-2y=66$, i.e. $6x-y=33$.",
 "From $6x-y=33$: $y=6x-33$. Substitute: $x+6(6x-33)=24$, so $37x=%d$ and $x=%d$, $y=%d$." % (24 + 198, xs166, ys166),
 "Then $xy=%d\\cdot%d=%d$." % (xs166, ys166, xs166*ys166)]
RES['AM-166'] = xs166 * ys166

# AM-206
S['AM-206'] = [
 "Square the first equation: $x-2\\sqrt{xy}+y=4$.",
 "Substitute $x+y=26$: $26-2\\sqrt{xy}=4$, so $\\sqrt{xy}=%d$." % ((26-4)//2),
 "Square again: $xy=%d^2=%d$." % ((26-4)//2, ((26-4)//2)**2)]
RES['AM-206'] = ((26-4)//2)**2

# ------------------------------------------------------------------ Nonlinear functions
# AM-145
q145 = 252; p145 = -(36 + q145) // 6
assert 36 + 6*p145 + q145 == 0
S['AM-145'] = [
 "A zero of $m$ is a zero of $z^2+pz+q$. The point $(0,-\\sqrt{252})$ gives $q=%d$." % q145,
 "The point $(6,0)$ gives $36+6p+%d=0$, so $p=%d$." % (q145, p145),
 "Solve $z^2-%dz+%d=0$: $(z-6)(z-42)=0$ since $6\\cdot42=%d$ and $6+42=%d$. The zeros are $6$ and $42$, so the greatest is $42$." % (-p145, q145, 6*42, 6+42)]
RES['AM-145'] = 42; assert 6*42 == q145 and 6+42 == -p145

# AM-148 (edited item)
q148 = 314; b148 = -(4 + q148) // 2
assert 4 + 2*b148 + q148 == 0
S['AM-148'] = [
 "The point $(0,-\\sqrt{314})$ gives $c=%d$. The point $(2,0)$ gives $4+2b+%d=0$, so $b=%d$." % (q148, q148, b148),
 "The $x$-intercepts are the zeros of $x^2-%dx+%d$, which factors as $(x-2)(x-157)$ because $2\\cdot157=%d$ and $2+157=%d$." % (-b148, q148, 2*157, 2+157),
 "The intercepts are $x=2$ and $x=157$, so the distance between them is $157-2=%d$." % (157-2)]
RES['AM-148'] = 157 - 2; assert 2*157 == q148 and 2+157 == -b148

# AM-227
a227, b227, c227 = 2*9, 2*6, 2*(1-5)
S['AM-227'] = [
 "Spot the difference of squares with $u=3x+1$: $(u-\\sqrt5)(u+\\sqrt5)=u^2-5$.",
 "So $f(x)=2\\left((3x+1)^2-5\\right)=2(9x^2+6x-4)=%dx^2+%dx%s$." % (a227, b227, ("-%d" % -c227) if c227 < 0 else "+%d" % c227),
 "Read off $a=%d$, $b=%d$, $c=%d$: $\\dfrac{b+c}{a}=\\dfrac{%d}{%d}=%s$." % (a227, b227, c227, b227 + c227, a227, fr(Fr(b227 + c227, a227)))]
RES['AM-227'] = Fr(b227 + c227, a227)

# AM-233
p233 = lambda x: -(x + 3)**2 * (x - 1)**3 * (x - 4)**2
claim('233 zeros', all(p233(z) == 0 for z in (-3, 1, 4)))
claim('233 left end up', p233(-10) > 0 and p233(-50) > p233(-10))
S['AM-233'] = [
 "Type %s and zoom out. The graph meets the $x$-axis at $x=-3$, $x=1$ and $x=4$ (tap them to see)." % c('y=-(x+3)^2(x-1)^3(x-4)^2'),
 "Statement I: to the left of $x=1$ the graph stays on or above the $x$-axis (it only touches it at $x=-3$). True.",
 "Statement II: at $x=4$ the graph touches the axis and turns back (even power), it does not cross. False.",
 "Statement III: far to the left the graph rises (odd degree, negative leading coefficient). True. So I and III only: option (@@L@@)."]
KEY['AM-233'] = '=IandIIIonly'

# AM-257
S['AM-257'] = [
 "Substitute into $h$: $g(x)=h(x+5)=\\sqrt{(x+5)-2}+1=\\sqrt{x+3}+1$.",
 "The radicand must be non-negative: $x+3\\ge0$, so $x\\ge%d$." % (-3),
 "Shortcut: replacing $x$ by $x+5$ shifts the graph $5$ units left, so the domain edge moves from $2$ to $2-5=%d$, option (@@L@@)." % (2-5)]
KEY['AM-257'] = 'x\\ge-3'

# AM-035
a_ = [5]
for _ in range(3): a_.append(2*a_[-1] - 3)
S['AM-035'] = [
 "Apply the rule to the previous term each time, starting from $a_1=5$.",
 "$a_2=2(%d)-3=%d$ and $a_3=2(%d)-3=%d$." % (a_[0], a_[1], a_[1], a_[2]),
 "$a_4=2(%d)-3=%d$." % (a_[2], a_[3])]
RES['AM-035'] = a_[3]

# AM-063
S['AM-063'] = [
 "A $12\\%$ decrease each hour leaves $100\\%-12\\%=88\\%$, so the hourly factor is $0.88$.",
 "That gives $C(t)=250(0.88)^t$, option (@@L@@).",
 "Check at $t=1$: $250(0.88)=%s$, which is $250-12\\%%$ of $250=250-%s$." % (fm(250*0.88), fm(250*0.12))]
KEY['AM-063'] = '0.88'

# AM-088 (edited item)
seq = [-4]
while abs(seq[-1]) <= 150: seq.append(3*seq[-1] - 2)
S['AM-088'] = [
 "``Two less than triple the preceding term'' means $a_{n+1}=3a_n-2$, starting from $a_1=%d$." % -4,
 "Build the terms: " + ", ".join("$a_{%d}=%d$" % (i+1, t) for i, t in enumerate(seq)) + ".",
 "$|a_{%d}|=%d$ is still below $150$, and $|a_{%d}|=%d$ is the first to exceed it: option (@@L@@)." % (len(seq)-1, abs(seq[-2]), len(seq), abs(seq[-1]))]
KEY['AM-088'] = str(len(seq)); assert len(seq) == 5

# AM-160
b160 = round((486/18) ** (1/3)); a160 = 18 // b160**2
S['AM-160'] = [
 "Divide the two conditions: $\\dfrac{f(5)}{f(2)}=b^{3}=\\dfrac{486}{18}=%d$, so $b=%d$." % (486//18, b160),
 "Then $a\\cdot%d^{2}=18$, so $a=%d$." % (b160, a160),
 "$f(4)=%d\\cdot%d^{4}=%d$." % (a160, b160, a160*b160**4)]
RES['AM-160'] = a160 * b160**4; assert b160**3 == 27 and a160*b160**5 == 486

# AM-173
e173 = Fr(1, 2) + Fr(2, 3) - Fr(1, 3)
S['AM-173'] = [
 "Use base $2$: $4^{t/3}=2^{2t/3}$ and $16^{-t/12}=2^{-4t/12}=2^{-t/3}$.",
 "Add the exponents: $\\dfrac t2+\\dfrac{2t}{3}-\\dfrac t3=%st$, so $V(t)=500\\cdot2^{%st}$." % (fr(e173), fr(e173)),
 "Six hours later: $\\dfrac{V(t+6)}{V(t)}=2^{%s\\cdot6}=2^{%d}=%d$." % (fr(e173), e173*6, 2**int(e173*6))]
RES['AM-173'] = 2**int(e173*6)

# ------------------------------------------------------------------ Part B
# AM-002
f002 = 1.15**5
S['AM-002'] = [
 "$P(t+5)=5000(1.15)^{t+5}=P(t)\\cdot(1.15)^{5}$, so the factor per $5$ years is $1.15^{5}$ (the $5000$ and $t$ cancel).",
 ret('1.15^5') + ".",
 "The closest option is $2.01$: option (@@L@@). The value $1.75$ comes from wrongly using $1+0.15\\cdot5$."]
KEY['AM-002'] = '2.01'; assert abs(f002 - 2.01) < 0.005

# AM-004
S['AM-004'] = [
 "Substitute $t=4$ into $V(t)=120000(0.88)^{t}$.",
 ret('120000*0.88^4', 0) + " dollars.",
 "To the nearest thousand dollars this is $%s$: option (@@L@@)." % fm(round(120000*0.88**4, -3))]
KEY['AM-004'] = '72{,}000'

# AM-045
S['AM-045'] = [
 "In $E(t)=1450(1.08)^{t}$, the time $t=0$ is the moment the facility opened.",
 "At $t=0$: $E(0)=1450(1.08)^{0}=1450\\cdot1=%d$." % 1450,
 "So $1450$ megawatt-hours is the capacity when the facility opened: option (@@L@@). The growth rate is the $8\\%$ hidden in $1.08$, not the $1450$."]
KEY['AM-045'] = 'whenthefacilityopened'

# AM-061
S['AM-061'] = [
 "Substitute $t=3$: $P(3)=300(1.5)^{3}$.",
 ret('300*1.5^3') + ".",
 "That is option (@@L@@). Do not compute $300\\cdot1.5\\cdot3=%s$: that treats the growth as linear." % fm(300*1.5*3)]
KEY['AM-061'] = '1{,}012.5'

# AM-065
S['AM-065'] = [
 "Substitute $t=5$: $N(5)=500(1.2)^{5}$.",
 ret('500*1.2^5') + ".",
 "The closest option is $1{,}244$: option (@@L@@)."]
KEY['AM-065'] = '1{,}244'

# AM-072
S['AM-072'] = [
 "Substitute $t=6$: $M(6)=200(0.85)^{6}$.",
 ret('200*0.85^6') + ".",
 "The closest option is $75.5$: option (@@L@@)."]
KEY['AM-072'] = '75.5'

# AM-080
S['AM-080'] = [
 "A growth of $2.4\\%$ per year multiplies the population by $1+0.024=1.024$ each year.",
 "The starting population is $60$ thousand, so $P(t)=60(1.024)^{t}$, option (@@L@@).",
 "Check: after one year $P(1)=60(1.024)=%s$ thousand, which is $60+%s$ (that is $2.4\\%%$ of $60$)." % (n(60*1.024), n(0.024*60))]
KEY['AM-080'] = '60(1.024)'

# AM-105
t9 = 3 * 6**8
S['AM-105'] = [
 "Multiplying by $6$ each time makes this a geometric sequence with first term $3$ and ratio $6$: the $n$th term is $3\\cdot6^{n-1}$.",
 "Check the 4th term: $3\\cdot6^{3}=%d$, matching the list." % (3*6**3),
 "The 9th term is $3\\cdot6^{8}$, option (@@L@@)."]
KEY['AM-105'] = '3\\times6^8'; assert 3*6**3 == 648

# AM-121
r121 = round((54/2)**(1/3)); terms = [2*r121**k for k in range(5)]
S['AM-121'] = [
 "The fourth term is $2r^{3}=54$, so $r^{3}=%d$ and $r=%d$." % (54//2, r121),
 "The first five terms are $%s$." % ",".join(map(str, terms)),
 "Their sum is $%s=%d$." % ("+".join(map(str, terms)), sum(terms))]
RES['AM-121'] = sum(terms); assert r121**3 == 27

# AM-200
P200 = lambda t: 120 / (1 + 5 * 0.8**t)
t60 = brentq(lambda t: P200(t) - 60, 0, 10)
claim('200 t60', abs(P200(t60) - 60) < 1e-9 and 0 < t60 < 10)
claim('200 below 80', all(P200(t) < 80 for t in [i/100 for i in range(1001)]))
claim('200 increasing', all(P200((i+1)/100) > P200(i/100) for i in range(1000)))
S['AM-200'] = [
 "Type %s (letting $x$ stand for $t$)." % c('y=120/(1+5*0.8^x)\\{0<=x<=10\\}') + " The curve rises from %s to %s, so $P$ is increasing: statement I is true." % (pt(0, P200(0)), pt(10, P200(10))),
 "Add the line %s and tap the intersection: %s. It lies inside the interval, so statement II is true." % (c('y=60'), pt(t60, 60)),
 "Add the line %s: it never meets the graph for $0\\le t\\le10$, because the highest point is $P(10)\\approx%s$. Statement III is false." % (c('y=80'), n(P200(10), 2)),
 ret('120/(1+5*0.8^10)', 2) + ", which confirms the highest value. So I and II only: option (@@L@@)."]
KEY['AM-200'] = '=IandIIonly'

# AM-205
f25 = 0.64; f5 = 0.64**2
S['AM-205'] = [
 "Increasing $t$ by $2.5$ adds $1$ to the exponent $\\dfrac{t}{2.5}$, so $V$ is multiplied by $%s$ every $2.5$ years." % n(f25),
 "A factor of $%s$ means a fall of $1-%s=%s$, that is $%s\\%%$, every $2.5$ years." % (n(f25), n(f25), n(1-f25), n((1-f25)*100)),
 "Check the other options: every $5$ years the factor is $%s^2=%s$, a fall of about $%s\\%%$, not $%s\\%%$. The correct choice is (@@L@@)." % (n(f25), n(f5, 4), n((1-f5)*100, 2), n((1-f25)*100))]
KEY['AM-205'] = '36\\%$every$2.5'

# AM-219
S['AM-219'] = [
 "January 1, 2023 is $3$ years after January 1, 2020, and $m$ more months is $\\dfrac{m}{12}$ more years, so $t=3+\\dfrac{m}{12}$.",
 "$A=300\\cdot4^{(3+m/12)/3}=300\\cdot4^{1+m/36}=%d\\cdot4^{m/36}$." % (300*4),
 "Convert the base: $4^{m/36}=2^{2m/36}=2^{m/18}$, so $A=%d\\cdot2^{m/18}$, option (@@L@@)." % (300*4),
 "Check $m=0$: $%d\\cdot2^{0}=%d$, which equals $A(3)=300\\cdot4=%d$." % (1200, 1200, 300*4)]
KEY['AM-219'] = '1200\\cdot2^{m/18}'

# AM-242
T0 = 24 + 66; T1 = 24 + 66*0.85
S['AM-242'] = [
 "Subtract the constant: $T(t)-24=66(0.85)^{t}$. This is the gap between the tea and the room temperature.",
 "Each extra minute multiplies the gap by $0.85$, so the gap falls by $15\\%$ per minute: option (@@L@@).",
 "Why not (C): $T(0)=%d$ and $T(1)=%s$, but $0.85\\cdot T(0)=%s\\neq T(1)$. The gap goes from $%d$ to $%s=0.85\\cdot%d$." % (T0, n(T1), n(0.85*T0), T0-24, n(T1-24), T0-24)]
KEY['AM-242'] = 'thegapT-24falls'

# PS-001
S['PS-001'] = [
 "Let $x$ be the 2022 number. Successive changes multiply: $x\\cdot1.25\\cdot0.88$.",
 "Calculate the combined factor. " + ret('1.25*0.88') + ", so $1.1x=%s$." % fm(9020000),
 "Solve. " + ret('9020000/1.1', 0) + "."]
RES['PS-001'] = 9020000 / 1.1

# PS-002
S['PS-002'] = [
 "Let $x$ be the original price. After a $30\\%$ discount the price is $0.7x$; the tax is applied to that: $0.7x\\cdot1.05$.",
 "Combined factor: " + ret('0.7*1.05', 3) + ", so $0.735x=44.10$.",
 "Solve: " + ret('44.10/0.735', 2) + " dollars, option (@@L@@)."]
KEY['PS-002'] = '60.00'

# PS-014 (edited item)
S['PS-014'] = [
 "The final price comes after the $15\\%$ decrease, so it is $85\\%$ of the price at the end of the promotion: $0.85p=1{,}020$.",
 "Solve: " + ret('1020/0.85', 0) + " dollars, option (@@L@@).",
 "Check: " + ret('1200*0.85', 0) + ". The original price (the trap in option $1{,}000$) is found by " + lc(ret('1200/1.2', 0)) + " dollars."]
KEY['PS-014'] = '1{,}200'

# PS-016 (edited item)
w1 = 8400 / (1.4*0.75); w2 = 1.4 * w1
S['PS-016'] = [
 "Work backwards from Week 3 to Week 2. Week 3 is $75\\%$ of Week 2. " + ret('8400/0.75', 0) + " families in Week 2.",
 "The question asks for the difference. " + ret('8400/0.75-8400', 0) + ".",
 "Check with Week 1. " + ret('8400/(1.4*0.75)', 0) + "; " + lc(ret('1.4*8000', 0)) + " in Week 2, and $%s-%s=%s$." % (fm(11200), fm(8400), fm(11200-8400))]
RES['PS-016'] = 11200 - 8400

# PS-023
S['PS-023'] = [
 "Decreasing by $12\\%$ removes $0.12y$: $y-0.12y$.",
 "Factor out $y$: $(1-0.12)y=0.88y$, option (@@L@@).",
 "Check with $y=50$: a $12\\%%$ decrease is $%s$, so $50-%s=%s$ and $0.88(50)=%s$." % (n(50*0.12), n(50*0.12), n(50-50*0.12), n(0.88*50))]
KEY['PS-023'] = '0.88y'

for _k in ('AM-173','AM-207','AM-239'):
    S[_k] = [x.replace('\\dfrac','\\frac') for x in S[_k]]
