import re,json,csv
txt=open('/home/claude/repo-check2/sat-bank/verified-item-bank/SAT_Bank_Verified_Item_Bank.md').read()
blocks=re.split(r'^### ',txt,flags=re.M)[1:]
B={}
for b in blocks:
    iid=b.split('\n',1)[0].strip()
    def g(label,nxt):
        m=re.search(r'\*\*%s:\*\*\s*(.*?)(?=\n\*\*(?:%s):\*\*|\n---|\Z)'%(label,nxt),b,re.S)
        return m.group(1).strip() if m else None
    B[iid]=dict(id=iid,skill=g('Skill','Difficulty'),diff=g('Difficulty','Format'),fmt=g('Format','Tool|Source|Question'),
      tool=g('Tool','Source|Question'),q=g('Question','Correct Answer'),ans=g('Correct Answer','Rationale[^*]*'),rat=b.split('(worked solution):**',1)[1].strip() if 'worked solution' in b else None)
rows=[r for r in csv.DictReader(open('/home/claude/cb/session_plan_11.csv')) if r['session']=='5']
out=[]
for r in rows:
    o=B[r['id']]; o=dict(o); o['part']=r['part']; o['csvdiff']=r['difficulty']; out.append(o)
json.dump(out,open('raw_items.json','w'),indent=1)
print(len(out),sum(o['part']=='In class' for o in out))
