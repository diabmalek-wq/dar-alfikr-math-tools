"""Independent verification of the Desmos steps. A Desmos-syntax-aware evaluator (its own tokenizer / parser:
implicit multiplication, ^, sqrt, ln, abs, user functions f(x)=..., variables p=...) re-evaluates EVERY typed
[[expr]] from the FINAL step text: definitions are registered in order per problem, every 'it returns' value is
re-computed, tapped points / implicit curves are re-checked, and every final answer is compared with solve.py."""
import re, math, json
import steps_d
from steps_d import S, CLAIMS, RES, SEL
TOK = re.compile(r'\s*(\d+\.\d+|\d+|sqrt|ln|abs|[A-Za-z]|[-+*/^()])')
BUILTIN = {'sqrt': math.sqrt, 'ln': math.log, 'abs': abs}
def evaluate(expr, funcs, vars_):
    t = []; i = 0; expr = expr.strip()
    while i < len(expr):
        m = TOK.match(expr, i); assert m, (expr, i); t.append(m.group(1)); i = m.end()
    pos = [0]
    peek = lambda: t[pos[0]] if pos[0] < len(t) else None
    def eat(): pos[0] += 1; return t[pos[0]-1]
    def starts_atom(x): return x is not None and (x == '(' or re.match(r'^(\d|[A-Za-z]|sqrt|ln|abs)', x) is not None)
    def atom(env):
        x = eat()
        if x == '(': v = add(env); assert eat() == ')'; return v
        if x == '-': return -power(env)
        if re.match(r'^\d', x): return float(x)
        if x in BUILTIN or (x in funcs and peek() == '('):
            assert eat() == '('; a = add(env); assert eat() == ')'
            return BUILTIN[x](a) if x in BUILTIN else funcs[x](a)
        if x in env: return env[x]
        if x in vars_: return vars_[x]
        raise KeyError(x)
    def power(env):
        b = atom(env)
        if peek() == '^': eat(); return b ** power(env)
        return b
    def mul(env):
        v = power(env)
        while peek() in ('*', '/') or starts_atom(peek()):
            if peek() == '*': eat(); v *= power(env)
            elif peek() == '/': eat(); v /= power(env)
            else: v *= power(env)
        return v
    def add(env):
        v = mul(env)
        while peek() in ('+', '-'):
            o = eat(); w = mul(env); v = v + w if o == '+' else v - w
        return v
    r = add({}); assert pos[0] == len(t), (expr, t, pos); return r
def fdef(funcs, vars_, name, var, body):
    def f(a):
        # evaluate body with var bound: substitute via env by re-parsing with temporary variable
        saved = vars_.get(var); vars_[var] = a
        try: return evaluate(body, funcs, vars_)
        finally:
            if saved is None: vars_.pop(var, None)
            else: vars_[var] = saved
    funcs[name] = f
bad = 0; cnt = 0; boxes = 0; with_box = 0; defs = 0
for iid, steps in S.items():
    funcs = {}; vars_ = {}; nb = 0
    for st in steps:
        for m in re.finditer(r'\[\[(.+?)\]\]', st):
            e = m.group(1).replace('\\{', '{').replace('\\}', '}'); nb += 1
            mf = re.match(r'^([A-Za-z])\(([a-z])\)=(.+)$', e)
            mv = re.match(r'^([A-Za-z])=(.+)$', e)
            if mf: fdef(funcs, vars_, *mf.groups()); defs += 1
            elif mv and mv.group(1) != 'y':
                vars_[mv.group(1)] = evaluate(mv.group(2), funcs, vars_); defs += 1
                mm = re.search(re.escape(m.group(0)) + r' \(so \$[A-Za-z]=([^$]+)\$\)', st)
                if mm:
                    want = float(mm.group(1).replace('{,}', '')); dec = len(mm.group(1).split('.')[1]) if '.' in mm.group(1) else 0
                    cnt += 1
                    if abs(vars_[mv.group(1)] - want) > 0.5*10**(-dec) + 1e-12: print('MISMATCH var', iid, e); bad += 1
        for m in re.finditer(r"\[\[([^\]]+?)\]\]: it returns \$([^$]+)\$", st):
            e, vt = m.group(1), m.group(2).replace('{,}', '')
            got = evaluate(e, funcs, vars_); want = float(vt); dec = len(vt.split('.')[1]) if '.' in vt else 0; cnt += 1
            if abs(got - want) > 0.5*10**(-dec) + 1e-12: print('MISMATCH', iid, e, got, want); bad += 1
    boxes += nb; with_box += nb > 0
    assert 3 <= len(steps) <= 4 and nb >= 1, (iid, len(steps), nb)
print('problems', len(S), 'with >=1 Desmos box', with_box, 'total boxes', boxes, 'returns/values re-evaluated', cnt, 'definitions', defs, 'mismatches', bad)
print('tap/curve claims', len(CLAIMS), 'all true', all(c[1] for c in CLAIMS))
# final answers vs solve.py (independent), and option selection
solved = json.load(open('solved.json')); items = {d['id']: d for d in json.load(open('s5_items.json'))}
x = 0
for iid, (k, sv) in solved.items():
    if k == 'val': assert abs(float(RES[iid]) - sv) < 1e-9, (iid, RES[iid], sv); x += 1
    else: assert iid in SEL; x += 1
print('final answers cross-checked against solve.py:', x, 'of', len(solved))
print('TOTAL BAD', bad)
