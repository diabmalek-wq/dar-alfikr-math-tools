# Builds s5_items.json from raw_items.json (bank text) + context/duplicate overrides (EDITS).
import json,re
raw=json.load(open('raw_items.json'))
def split_opts(q):
    stem=[];opts=[]
    for ln in q.split('\n'):
        m=re.match(r'^\(?([A-D])\)\s*(.*)$',ln.strip())
        if m and (opts or m.group(1)=='A'): opts.append(m.group(2).strip())
        elif opts and ln.strip()=='': continue
        elif opts: opts[-1]+=' '+ln.strip()
        else: stem.append(ln)
    return '\n'.join(stem).strip(),(opts if len(opts)==4 else None)
D='$'
EDITS={ # id -> (stem, opts or None, note)
'AM-194':(r"""$$(x+p)(x+q)=x^{2}+bx+c$$
In the equation above, $p$ and $q$ are real constants and $b$ and $c$ are integers. Which of the following must be true?

I.\ $p+q$ is an integer

II.\ $p^{2}+q^{2}$ is an integer

III.\ $\dfrac{p^{2}+q^{2}}{2}$ is an integer""",None,'layout only'),
'AM-233':(r"""The polynomial function $p$ is defined by $p(x)=-(x+3)^2(x-1)^3(x-4)^2$. Consider the following statements.

I.\ $p(x)\ge0$ for all $x<1$.

II.\ The graph of $y=p(x)$ crosses the $x$-axis at $x=4$.

III.\ $p(x)\to\infty$ as $x\to-\infty$.

Which of the statements must be true?""",None,'layout only'),
'AM-200':(r"""The function $P(t)=\dfrac{120}{1+5(0.8)^{t}}$ models the number of active users of an app, in thousands, $t$ weeks after launch, for $0\le t\le10$. Consider the following statements.

I.\ $P$ is increasing on the interval $0\le t\le10$.

II.\ There is a time $t$ in the interval at which $P(t)=60$.

III.\ There is a time $t$ in the interval at which $P(t)=80$.

Which of the statements must be true?""",None,'layout only'),
'AM-002':(r"""The estimated population of a new coastal town $t$ years after 2024 is modeled by
$$P(t) = 5000\left(1.15\right)^{t}.$$
According to the model, by approximately what factor does the population increase every $5$ years?""",None,'context: place/Vision 2030 removed'),
'AM-004':(r"""A car is purchased for $\$120{,}000$. Its value depreciates according to
$$V(t) = 120000\left(0.88\right)^{t},$$
where $t$ is the number of years since purchase. To the nearest thousand dollars, what is the value of the car after $4$ years?""",[r"$\$61{,}000$",r"$\$72{,}000$",r"$\$84{,}000$",r"$\$94{,}000$"],'context: Riyadh/SAR -> US dollars'),
'AM-045':(r"""The storage capacity of a battery facility is modeled by
$$E(t) = 1450\left(1.08\right)^{t},$$
where $E(t)$ is the capacity, in megawatt-hours, and $t$ is the number of years after the facility opened, for $0 \leq t \leq 15$. Which is the best interpretation of $1450$ in this context?""",None,'context: NEOM removed'),
'AM-080':(r"""The population of a small town has grown at an average rate of $2.4\%$ per year since $2010$. There were approximately $60{,}000$ residents in $2010$. Which of the following functions best models the town's population $P$, in thousands of residents, $t$ years after $2010$?""",None,'context: Yanbu removed'),
'AM-088':(r"""In a sequence, the first term is $-4$. Each term after the first is two less than triple the preceding term. Which term is the first one whose absolute value is greater than $150$?""",None,'DUPLICATE FIX: recurrence was identical to AM-035 (2a-3); now 3a-2, answer re-derived'),
'AM-148':(r"""The function $h(x)=-\sqrt{x^2+bx+c}$ has a graph passing through $(2,0)$ and $\left(0,-\sqrt{314}\right)$, where $b$ and $c$ are constants. What is the distance between the two $x$-intercepts of the graph?""",None,'DUPLICATE FIX: same template as AM-145; now asks for the distance between the intercepts, answer re-derived'),
'PS-001':(r"""The number of visitors to a national park increased by $25\%$ from 2022 to 2023. From 2023 to 2024, the number of visitors decreased by $12\%$. If the number of visitors in 2024 was $9{,}020{,}000$, what was the number of visitors in 2022?""",None,'context: Umrah/Makkah removed'),
'PS-014':(r"""A laptop's price increased by $20\%$ during a promotional period, then decreased by $15\%$ after the promotion ended. If the final price is $\$1{,}020$, what was the price at the end of the promotional period, before the decrease?""",[r"$\$950$",r"$\$1{,}000$",r"$\$1{,}050$",r"$\$1{,}200$"],'DUPLICATE FIX + context: SAR removed; asks for the peak price (one-step reversal) instead of the original price, so it no longer repeats PS-001/PS-016; answer re-derived'),
'PS-016':(r"""The number of families visiting a city festival's family zone increased by $40\%$ from Week 1 to Week 2, then decreased by $25\%$ from Week 2 to Week 3. If Week 3 attendance was $8{,}400$ families, how many more families attended in Week 2 than in Week 3?""",None,'DUPLICATE FIX + context: Riyadh Season removed; asks for the Week 2 minus Week 3 difference instead of Week 1; answer re-derived'),
}
out=[]
for o in raw:
    q=o['q']; stem,opts=split_opts(q)
    d=dict(id=o['id'],part=o['part'],lv='M' if o['csvdiff']=='Medium' else 'H',
           fmt='MC' if opts else 'SPR',bank_ans=o['ans'],edit=None)
    if o['id'] in EDITS:
        s,op,note=EDITS[o['id']]; d['edit']=note
        stem=s; opts=op if op is not None else opts
        if o['id'] in ('AM-088','AM-148','PS-014','PS-016'): d['bank_ans']=None  # bank answer no longer applies
    d['stem']=stem; d['opts']=opts
    if d['fmt']=='SPR' or o['id'] in ('AM-148','PS-016'):
        d['fmt']='SPR'; assert not opts or o['id']=='x'
    out.append(d)
for d in out:
    if d['fmt']=='MC': assert d['opts'] and len(d['opts'])==4,d['id']
json.dump(out,open('s5_items.json','w'),indent=1)
print(len(out),[d['id'] for d in out if d['fmt']=='MC'].__len__(),'MC')
