"""Re-evaluates every typed Desmos box of the Answers PDF with a Desmos-syntax evaluator, checks every quoted return value,
tapped point, regression and final answer against solve.py's independent answers."""
import re,math,json
import numpy as np
from scipy.optimize import brentq,minimize_scalar
import steps
from steps import S,ev,TAPS,VERT,REG,FINAL
items={o['id']:o for o in json.load(open('s7_items.json'))}; solved=json.load(open('solved.json'))
bad=0
def chk(name,ok):
    global bad
    if not ok: print('BAD',name); bad+=1
nbox=0;nret=0;nlist=0;withbox=0;verbal=[]
BOX=re.compile(r"\[\[(.+?)\]\](?!\])(: it returns \$([^$]+)\$)?")
for iid,st in S.items():
    env={}; cnt=0
    assert 3<=len(st)<=4,(iid,len(st))
    for step in st:
        for m in BOX.finditer(step):
            expr,ret,val=m.group(1),m.group(2),m.group(3); nbox+=1; cnt+=1
            dm=re.fullmatch(r'([A-Za-z]\w*)=(\[.*\])',expr)
            if dm:
                env[dm.group(1)]=ev(dm.group(2)); nlist+=1; continue
            if expr.startswith('y=') or expr.startswith('y_1~'):
                if expr.startswith('y='): ev(expr[2:],x=1.0,**env)   # syntax check
                continue
            got=ev(expr,**env)
            if ret:
                want=float(val.replace('{,}','')); nret+=1
                chk((iid,expr,got,want),abs(got-want)<=6e-5*max(1,abs(want)))
    if cnt: withbox+=1
    else: verbal.append(iid)
norm=lambda t:t.replace('*','').replace(' ','')
def alltext(i): return norm(''.join(S[i]))
for iid,f,g,xq,yq in TAPS:
    h=lambda x:ev(f,x=x)-ev(g,x=x)
    xs=np.linspace(xq-40.1234,xq+40.4567,8001); vals=[h(x) for x in xs]
    roots=[brentq(h,xs[k],xs[k+1]) for k in range(len(xs)-1) if vals[k]*vals[k+1]<0]
    chk((iid,'tap root',roots,xq),any(abs(r-xq)<1e-6 for r in roots))
    chk((iid,'tap y'),abs(ev(f,x=xq)-yq)<1e-9)
    chk((iid,'typed f'),norm('y='+f) in alltext(iid)) if iid!='PS-021' else None
    chk((iid,'printed point'),steps.pt(xq,yq).replace(' ','') in ''.join(S[iid]).replace(' ','') or iid=='PS-116' or iid=='PS-113')
    if iid in('PS-116','PS-113'): chk((iid,'printed'),steps.pt(xq,yq).replace(' ','') in ''.join(S[iid]).replace(' ',''))
for iid,f,xq,yq,kind in VERT:
    g=(lambda x:ev(f,x=x)) if kind=='min' else (lambda x:-ev(f,x=x))
    r=minimize_scalar(g,bounds=(xq-30,xq+30),method='bounded',options={'xatol':1e-10})
    chk((iid,'vertex'),abs(r.x-xq)<1e-3 and abs(ev(f,x=xq)-yq)<1e-9)
    chk((iid,'typed'),norm('y='+f) in alltext(iid)) 
for iid,xs,ys in REG:
    m,b=np.polyfit(xs,ys,1); txt=''.join(S[iid])
    chk((iid,'reg'),('m=%s'%steps.n(m)) in txt and ('b=%s'%steps.n(b)) in txt)
# final answers vs the independent solver
optval=lambda t:float(t.replace('\\%','').replace('$','').replace('{,}','').replace(',','').replace('{','').replace('}',''))
for iid,fv in FINAL.items():
    o=items[iid]; kind,val=solved[iid]
    if isinstance(fv,tuple):
        chk((iid,'final opt'),kind=='opt' and fv[1] in o['opts'][val])
    elif o['opts']:
        vs=[optval(t) for t in o['opts']]; k=min(range(4),key=lambda i:abs(vs[i]-fv))
        chk((iid,'final mcq'),kind=='opt' and k==val)
    else: chk((iid,'final spr'),kind=='val' and abs(float(val)-fv)<1e-9)
chk('every item has a final',set(FINAL)==set(items))
print('problems',len(S),'with >=1 box',withbox,'total boxes',nbox,'list-definition boxes',nlist,'returns checked',nret)
print('verbal exceptions (no typed box):',verbal)
print('total bad',bad); assert bad==0
