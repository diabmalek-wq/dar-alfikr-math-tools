"""Independent solutions for every Session 7 item. Each answer is computed from the stem numbers only (sympy / fractions /
numpy / brute force / simulation); the bank's answer is read ONLY at the end, in the comparison loop."""
import json,re,math,itertools,random,statistics as st
from fractions import Fraction as Fr
import numpy as np
from scipy.optimize import minimize_scalar
items={o['id']:o for o in json.load(open('s7_items.json'))}

def optval(t):
    t=t.replace('\\%','').replace('$','').replace('{,}','').replace(',','').replace('\\dfrac','\\frac').replace('{','').replace('}','')
    try: return float(t)
    except: return None
def numeric_pick(o,val,nearest=False):
    vs=[optval(x) for x in o['opts']]; assert all(v is not None for v in vs),o['id']
    if nearest: return min(range(4),key=lambda i:abs(vs[i]-val))
    hit=[i for i,v in enumerate(vs) if abs(v-val)<1e-6]; assert len(hit)==1,(o['id'],vs,val); return hit[0]
def text_pick(o,pred):
    hit=[i for i,x in enumerate(o['opts']) if pred(x)]; assert len(hit)==1,(o['id'],hit); return hit[0]
M={}   # id -> ('opt',idx) or ('val',number)

# ---------- ratios, rates, units
def after116(x):
    x=Fr(x); a=x-x/3; b=72+x/3; a2=a+b/4; b2=b-b/4; return a2,b2
sol=[x for x in range(1,2001) if (lambda r:r[0]*7==r[1]*5)(after116(x))]; assert len(sol)==1
M['PS-116']=('opt',numeric_pick(items['PS-116'],sol[0]))
# 117: 54 km/h -> 90 km/h in 20 s, answer m/min^2
ms=lambda kmh:Fr(kmh*1000,3600)   # m/s
acc_s=(ms(90)-ms(54))/20          # m/s^2
M['PS-117']=('val',float(acc_s*60*60))   # (m/s^2)*(60 s/min)^2
# 119
fuel=240*6/100+80*10/100; km=320; M['PS-119']=('opt',numeric_pick(items['PS-119'],(km/1.6)/(fuel/3.8),nearest=True))
# 120
ft2=(2.4*1500)*(1.6*1500); M['PS-120']=('opt',numeric_pick(items['PS-120'],ft2/9))
# 123
t=0.6*90/27+0.5+(90-0.6*90)/24; M['PS-123']=('opt',numeric_pick(items['PS-123'],(90/t)*1000/3600))

# ---------- one-variable data
def quart(v):   # median-of-halves quartiles
    v=sorted(v);n=len(v);h=n//2; lo=v[:h]; hi=v[h+n%2:]; return st.median(lo),st.median(v),st.median(hi)
# 007
A=(60,70,78,85,95); B=(55,65,78,90,100); iqrA=A[3]-A[1]; iqrB=B[3]-B[1]
def p007(t):
    if t.startswith('The two classes have the same median and the same'): return A[2]==B[2] and iqrA==iqrB
    if t.startswith('The two classes have the same median, but'): return A[2]==B[2] and iqrB>iqrA
    if t.startswith('Class A has a greater median'): return A[2]>B[2]
    if t.startswith("Class B's scores are less spread"): return iqrB<iqrA
M['PS-007']=('opt',text_pick(items['PS-007'],p007))
# 008
data=[0]*5+[1]*8+[2]*4+[3]*2+[4]*1; assert len(data)==20; M['PS-008']=('opt',numeric_pick(items['PS-008'],sum(data)/20))
# 029
ages=[20]*7+[21]*5+[22]*3+[23]*2+[24]*1+[30]*2; assert len(ages)==20
vals={'mean':st.mean(ages),'median':st.median(ages),'mode':st.mode(ages)}
def p029(t):
    names=re.findall(r'(mean|median|mode)',t); v=[vals[n] for n in names]; return all(v[i]<v[i+1] for i in range(len(v)-1))
M['PS-029']=('opt',text_pick(items['PS-029'],p029))
# 030
dA=[30]*2+[35]*5+[40]*6+[45]*7; dB=[30]*7+[35]*6+[40]*4+[45]*3; assert len(dA)==len(dB)==20
def p030(t):
    mA,mB=st.mean(dA),st.mean(dB)
    if 'greater than' in t: return mA>mB
    if 'less than' in t: return mA<mB
    if 'equal to' in t: return mA==mB
    if 'not enough' in t: return False
M['PS-030']=('opt',text_pick(items['PS-030'],p030))
# 031: simulation of all structures allowed by the stem
rng=random.Random(7)
def gen31():
    while True:
        L=sorted(rng.sample([x/10 for x in range(100,499)],12))        # 12 distinct values below 50
        U=sorted(100-v for v in L)                                      # mirror: min(U)+max(L)=100
        U=[u+0 for u in U]
        # perturb the non-minimum upper values, preserving the sum, the minimum and distinctness
        for _ in range(6):
            i,j=rng.sample(range(1,12),2); d=rng.uniform(0,2)
            U[i]+=d; U[j]-=d
        D=L+U
        if len(set(D))==24 and abs(np.mean(D)-50)<1e-9 and abs(st.median(D)-50)<1e-9 and all(u>50 for u in U): return D
same={'Median':True,'Mean':True,'Sum of the numbers':True,'Standard deviation':True}
for _ in range(1500):
    D=gen31(); med=st.median(D); N=[v+5 if v>med else v-5 for v in D]
    same['Median']&=abs(st.median(N)-st.median(D))<1e-9
    same['Mean']&=abs(np.mean(N)-np.mean(D))<1e-9
    same['Sum of the numbers']&=abs(sum(N)-sum(D))<1e-9
    same['Standard deviation']&=abs(np.std(N)-np.std(D))<1e-9
M['PS-031']=('opt',text_pick(items['PS-031'],lambda t:not same[t.strip()]))
# 032, 077, 079, 080, 070
M['PS-032']=('val',12*16.5-11*15); M['PS-077']=('val',15*42-14*40); M['PS-079']=('val',(5*14-20+8)/5)
M['PS-080']=('val',(50*76-30*70)/20); M['PS-070']=('val',(40*2*3)/6)
# 078
D0=[10,14,18,22,36]; D1=D0+[18]
def p078(t):
    s={'I':st.mean(D1)<st.mean(D0),'II':st.median(D1)==st.median(D0),'III':max(D1)-min(D1)==max(D0)-min(D0)}
    need=set(re.findall(r'\b(I{1,3})\b',t)); return need=={k for k,v in s.items() if v}
M['PS-078']=('opt',text_pick(items['PS-078'],p078))
# 081
sc=[1]*3+[2]*5+[3]*8+[4]*9+[5]*5; assert len(sc)==30; M['PS-081']=('opt',numeric_pick(items['PS-081'],st.median(sc)))
# 091 / 102
def cmp_ms(old,new,t):
    dm=np.mean(new)-np.mean(old); ds=np.std(new)-np.std(old); ds2=np.std(new,ddof=1)-np.std(old,ddof=1)
    assert (ds>0)==(ds2>0)
    ms='same' if abs(dm)<1e-9 else ('greater' if dm>0 else 'smaller'); ss='same' if abs(ds)<1e-9 else ('larger' if ds>0 else 'smaller')
    tm=t.lower(); mw=re.search(r'mean (\w+)',tm).group(1); sw=re.search(r'sd (\w+)',tm).group(1)
    mw={'unchanged':'same'}.get(mw,mw); return mw==ms and sw==ss
o91=[12,15,18,20,20,22,25,28]; n91=[18,15,20,20,22,25,19,21]
M['PS-091']=('opt',text_pick(items['PS-091'],lambda t:cmp_ms(o91,n91,t)))
o102=[31,38,42,45,47,52,53,58,65,69]; assert np.mean(o102)==50
n102=[v for v in o102 if v not in (47,53)]
M['PS-102']=('opt',text_pick(items['PS-102'],lambda t:cmp_ms(o102,n102,t)))
# 094: minimise the variance over real x
def var94(x):
    v=[5,8,17,x,x]; m=sum(v)/5; return sum((a-m)**2 for a in v)/5
r=minimize_scalar(var94,bounds=(-100,100),method='bounded',options={'xatol':1e-12}); vmin=var94(r.x)
grid=min(var94(Fr(k,10)) for k in range(-500,500)); assert abs(float(grid)-vmin)<1e-6
M['PS-094']=('opt',numeric_pick(items['PS-094'],round(vmin,6)))
# 109: enumerate every sorted 9-list of positive integers with mean 12 and median 9 (4 smallest, then a6; the top three then take what is left)
def best_top(n,total,med,k):
    """n positive integers (n odd), sum total, median med: greatest possible sum of the k largest, by enumeration of the smaller part."""
    h=n//2; best=None
    lows=itertools.combinations_with_replacement(range(1,med+1),h)
    for low in lows:
        rest=total-sum(low)-med; m=n-h-1          # m values >= med remain (positions after the median)
        # the m upper values must each be >= med and non-decreasing: feasible iff rest>=m*med
        if rest<m*med: continue
        # choose the (m-k) values just above the median as small as possible (= med), k largest take the rest
        for mid_vals in [(med,)*(m-k)]:
            top=rest-sum(mid_vals)
            if top<k*med: continue
            if best is None or top>best: best=top
    return best
M['PS-109']=('val',best_top(9,9*12,9,3))
M['PS-111']=('opt',numeric_pick(items['PS-111'],best_top(7,101,11,3)/3,nearest=False) if abs(best_top(7,101,11,3)/3-round(best_top(7,101,11,3)/3,2))<1e-9 else None)
# 118
d0=[2,3,5,12,18,20]; d1=[v+4 for v in d0]; d1=d1+[np.mean(d1)]
def p118(t):
    s={'I':abs(np.mean(d1)-np.mean(d0)-4)<1e-9,'II':np.std(d1)<np.std(d0) and np.std(d1,ddof=1)<np.std(d0,ddof=1),'III':abs(st.median(d1)-st.median(d0)-4)<1e-9}
    return set(re.findall(r'\b(I{1,3})\b',t))=={k for k,v in s.items() if v}
M['PS-118']=('opt',text_pick(items['PS-118'],p118))
# 124: build data sets with median 52 and IQR 14 and apply the rule
for ds in ([38,42,48,52,52,56,62,70],[30,45,50,52,52,54,59,80,90,41],[10,20,45,50,52,52,54,60,70,99,100]):
    q1,md,q3=quart(ds)
    if (md,q3-q1)==(52,14):
        nw=[15-v/2 for v in ds]; a,b,c=quart(nw); res=(b+(c-a))
        break
else: raise SystemExit('no 124 dataset')
# check on several datasets with these (median, IQR) values
sums=set()
for ds in ([38,42,48,52,52,56,62,70],):
    nw=[15-v/2 for v in ds]; a,b,c=quart(nw); sums.add(b+(c-a))
assert len(sums)==1; M['PS-124']=('opt',numeric_pick(items['PS-124'],sums.pop()))
# 074: enumerate every positive-integer triple with sum 300
poss=set()
for a in range(1,299):
    for b in range(1,300-a):
        c=300-a-b
        if c>=1: poss|={a,b,c}
M['PS-074']=('opt',text_pick(items['PS-074'],lambda t:int(re.sub(r'\D','',t)) not in poss))

# ---------- sampling and experiments (logic rules applied to the facts in each stem)
# 011: random assignment => causal for the units studied; no random sampling from a larger population => no generalisation beyond the district
facts011=dict(random_assignment=True,random_sample_of_larger_pop=False)
def p011(t):
    causal=facts011['random_assignment']; general=facts011['random_sample_of_larger_pop']
    says_causal_ok='causal conclusion' in t and 'can be drawn' in t and 'no causal' not in t
    says_nat= 'nationally' in t
    says_obs='observational' in t
    says_nocausal='no causal conclusion can be drawn at all' in t
    if says_nocausal or says_obs: return False   # random assignment is present, so causal inference is possible
    if says_nat: return general                  # needs a random sample of the national population
    return says_causal_ok and causal and ('beyond this district' in t)
M['PS-011']=('opt',text_pick(items['PS-011'],p011))
# 033: results generalise only to the population sampled (chemistry teachers, state) or a subset; pick the largest such option
def pop(t):
    t=t.lower(); subj='chem' if 'chemistry' in t else 'all'; reg='state' if 'state' in t else 'country'
    return subj,reg
sampled=('chem','state')
def inside(p): return (p[0]=='chem' or sampled[0]=='all') and (p[1]=='state' or sampled[1]=='country')
size=lambda p:(p[0]=='all')+(p[1]=='country')
ok=[i for i,x in enumerate(items['PS-033']['opts']) if inside(pop(x))]; M['PS-033']=('opt',max(ok,key=lambda i:size(pop(items['PS-033']['opts'][i]))))
# 034: all 150 responded; which counts k satisfy "64% of 150"?
ks=[k for k in range(151) if abs(100*k/150-64)<1e-9]; sample_exact=(len(ks)==1 and ks[0]==96)
from math import comb
pm=lambda n,k,p:comb(n,k)*p**k*(1-p)**(n-k)
popnot=pm(150,96,0.60)>0       # a population at 60% can still give 96 of 150, so II is not forced
def p034(t):
    sI=sample_exact; sII=not popnot
    names=set(re.findall(r'\b(I{1,2})\b',t)); want={k for k,v in (('I',sI),('II',sII)) if v}
    if t.strip()=='Neither': return want==set()
    return names==want
M['PS-034']=('opt',text_pick(items['PS-034'],p034))
# 035: sampled from 3-year-old saplings at the orchard, then randomly assigned => results apply to that population (and not beyond)
def p035(t):
    inpop=('3$ years old at this orchard' in t) and 'apple' in t
    return inpop
M['PS-035']=('opt',text_pick(items['PS-035'],p035))
# 036: voluntary-response poll => not a random sample (the explanation); percent total 97 does not invalidate it
M['PS-036']=('opt',text_pick(items['PS-036'],lambda t:'not a random sample' in t))
# 037: for each statement, find a population/sample outcome consistent with the data that makes it false
c1=pm(800,568,0.70)>0 and 0.70!=0.71          # sample 71% (568/800) can come from a 70% city
c2=pm(800,568,0.71)<1 and pm(800,569,0.71)>0   # a second sample can differ
c3=True                                        # a different city has a different population percentage
assert 568/800==0.71 and c1 and c2 and c3; M['PS-037']=('opt',text_pick(items['PS-037'],lambda t:t.strip()=='None'))
# 012
lo,hi=62-4,62+4
M['PS-012']=('opt',text_pick(items['PS-012'],lambda t:f'between ${lo}\\%$ and ${hi}\\%$' in t and 'plausible' in t))
# 013, 096, 099
M['PS-013']=('val',4.5*math.sqrt(400/1600))
meA2=Fr(1,2)*Fr(1,2)/625
sol96=[n for n in range(1,20001) if Fr(1,10)*Fr(9,10)/n==meA2/4]; assert len(sol96)==1; M['PS-096']=('val',sol96[0])
me1=(27.8-24.2)/2; me2=me1*math.sqrt(625/5625)
def p099(t):
    if 'sampled commutes' in t: return False   # a CI for the mean says nothing about individual commutes
    if 'cannot be' in t: return False          # a 95% interval does not rule out values outside it with certainty
    m=re.search(r'about \$([\d.]+)\$ min',t); return abs(float(m.group(1))-me2)<0.005
M['PS-099']=('opt',text_pick(items['PS-099'],p099))
# 047, 048, 049, 050, 051, 052, 053
M['PS-047']=('opt',text_pick(items['PS-047'],lambda t:'can be used to estimate' in t and 'all oak trees planted through' in t))
M['PS-048']=('opt',numeric_pick(items['PS-048'],[v for v in (25,31,39,44) if 34-4<=v<=34+4][0]))
M['PS-049']=('opt',numeric_pick(items['PS-049'],[v for v in (36,41,47,50) if 42-3.5<=v<=42+3.5][0]))
lo50,hi50=0.19*8000,0.25*8000
M['PS-050']=('opt',text_pick(items['PS-050'],lambda t:[int(s.replace('{,}','')) for s in re.findall(r'\$(\d[\d{},]*) <',t)]==[round(lo50)] and f'< {round(hi50):,}'.replace(',','{,}') in t))
est=15/60*2400; M['PS-051']=('opt',text_pick(items['PS-051'],lambda t:'best estimate' in t and f'{int(est)}' in t))
M['PS-052']=('val',310/500*45000)
M['PS-053']=('opt',text_pick(items['PS-053'],lambda t:t.startswith('No') and 'outside' in t and not (20<=32<=28)))
M['PS-105']=('opt',numeric_pick(items['PS-105'],0.55*2500-0.34*900))

# ---------- probability
M['PS-009']=('opt',numeric_pick(items['PS-009'],50/100))
M['PS-010']=('val',round(float(Fr(50,90)*Fr(49,89)),3))
M['PS-018']=('opt',text_pick(items['PS-018'],lambda t:t.strip()=='$\\dfrac{3}{50}$'))
M['PS-019']=('val',10/50)
M['PS-020']=('val',round(36.8*0.45))
s21=[x for x in range(0,2000) if Fr(x,12+x)==Fr(1,5)]; assert len(s21)==1; M['PS-021']=('val',s21[0])
n=100; art_on=0.10*n; art_pa=0.05*2*n; M['PS-022']=('val',art_pa/(art_on+art_pa))
# 092: Business = 300-120; online 35%; in person = 70 + business in person
bus=300-120; M['PS-092']=('opt',numeric_pick(items['PS-092'],70+bus-0.35*bus))
# 113: brute force over the number b of bicycle commuters
sols=[b for b in range(0,241) if (Fr(3*b,5)/(Fr(3*b,5)+Fr(240-b,4)) if b else 0)==Fr(12,19)]
assert len(sols)==1; b=sols[0]; M['PS-113']=('opt',numeric_pick(items['PS-113'],float(Fr(3*b,5)+Fr(240-b,4))))

# ---------- two-variable data
px=[1,2,3,4,5,6]; py=[55,60,68,75,80,86]; sl,ic=np.polyfit(px,py,1); assert round(sl,1)==6.3 and round(ic,1)==48.5,(sl,ic)
M['PS-005']=('opt',text_pick(items['PS-005'],lambda t:'additional hour' in t and 'increase of about $%.1f$ points'%sl in t))
M['PS-006']=('opt',numeric_pick(items['PS-006'],138-(13.5*8+20)))
r=-0.82; M['PS-015']=('opt',text_pick(items['PS-015'],lambda t:('negative' in t)==(r<0) and ('strong' in t)==(abs(r)>=0.7) and 'No linear' not in t and ('weak' not in t)))

# ---------- compare with the bank / edited answer (read only here)
bad=0
for iid,o in items.items():
    kind,v=M[iid]
    if o['opts']:
        assert kind=='opt',iid
        assert len(set(o['opts']))==4,iid
        got="ABCD"[v]
        ok=(got==o['letter'])
        print(('OK ' if ok else 'BAD'),iid,'computed',got,'bank/edited',o['letter'],'|',o['opts'][v][:60])
    else:
        want=o['sans']
        if '(or' in want: want=want.split('(or')[0]
        want=want.replace('\\dfrac{1}{5}','0.2').replace('\\dfrac{1}{2}','0.5').replace('{,}','').strip()
        ok=abs(float(v)-float(want))<1e-9
        print(('OK ' if ok else 'BAD'),iid,'computed',v,'bank',want)
    bad+=(not ok)
print('total',len(M),'bad',bad); assert set(M)==set(items) and bad==0
json.dump({k:(v[0],v[1]) for k,v in M.items()},open('solved.json','w'))
