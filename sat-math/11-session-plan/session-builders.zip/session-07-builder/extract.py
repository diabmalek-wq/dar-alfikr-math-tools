import re,csv,json
B=open('/home/claude/repo-check2/sat-bank/verified-item-bank/SAT_Bank_Verified_Item_Bank.md').read()
blocks=re.split(r'\n(?=### )',B)
bank={}
for b in blocks:
    m=re.match(r'### (\S+)',b)
    if m: bank[m.group(1)]=b
rows=[r for r in csv.DictReader(open('/home/claude/cb/session_plan_11.csv')) if r['session']=='7']
out=[]
for r in rows:
    b=bank[r['id']]
    g=lambda k:(re.search(r'\*\*%s:\*\*\s*(.*?)(?=\n\n\*\*|\n---|\Z)'%k,b,re.S) or [None,None])[1]
    q=g('Question'); ans=g('Correct Answer'); rat=g('Rationale') or ''
    fm=re.search(r'\*\*Format:\*\* ([^\n|]+)',b).group(1).strip()
    d=re.search(r'\*\*Difficulty:\*\* (\w+)',b).group(1)
    assert d==r['difficulty'],(r['id'],d)
    out.append(dict(id=r['id'],part=r['part'],d=d,fmt=fm,skill=r['skill'],q=q.strip(),ans=ans.strip(),rat=rat.strip()))
json.dump(out,open('s7_raw.json','w'),indent=1)
print(len(out))
