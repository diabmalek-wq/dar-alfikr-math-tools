"""TikZ figures for Session 7, drawn from the same numbers as the stems."""
from figlib import FIGSTYLE, fig

def _scatter(pts, line, xr, yr, xt, yt, xl, yl, ux, uy, ybase, w_note=None):
    """pts list of (x,y); line (m,b); xr=(x0,x1); yr=(y0,y1) axis ranges; xt,yt tick lists.
    Plot coordinates are data coordinates scaled by ux, uy (cm per unit) with the axes starting at (xr[0], yr[0])."""
    X=lambda x:(x-xr[0])*ux; Y=lambda y:(y-yr[0])*uy
    s=[]
    for t in yt: s.append(r"\draw[gridl] (0,%g)--(%g,%g);" % (Y(t),X(xr[1]),Y(t)))
    for t in xt: s.append(r"\draw[gridl] (%g,0)--(%g,%g);" % (X(t),X(t),Y(yr[1])))
    s.append(r"\draw[axisline] (0,0)--(%g,0) node[right,font=\small]{$%s$};" % (X(xr[1])+0.3, xl))
    s.append(r"\draw[axisline] (0,0)--(0,%g) node[above,font=\small]{$%s$};" % (Y(yr[1])+0.3, yl))
    for t in xt: s.append(r"\draw (%g,0.07)--(%g,-0.07) node[below,font=\scriptsize]{$%g$};" % (X(t),X(t),t))
    for t in yt: s.append(r"\draw (0.07,%g)--(-0.07,%g) node[left,font=\scriptsize]{$%g$};" % (Y(t),Y(t),t))
    if line:
        m,b=line; x0=xr[0]; x1=xr[1]
        s.append(r"\begin{scope}\clip (0,0) rectangle (%g,%g);\draw[ln,thick] (%g,%g)--(%g,%g);\end{scope}" % (X(xr[1]),Y(yr[1]),X(x0),Y(m*x0+b),X(x1),Y(m*x1+b)))
    for (x,y) in pts: s.append(r"\node[pt] at (%g,%g){};" % (X(x),Y(y)))
    return "\n".join(s)

PTS5=[(1,55),(2,60),(3,68),(4,75),(5,80),(6,86)]
PTS6=[(0,30),(2,45),(4,68),(6,95),(8,138)]
def F005():
    return fig(_scatter(PTS5,(6.3,48.5),(0,7),(40,95),[1,2,3,4,5,6,7],[40,50,60,70,80,90],
        r"\text{hours studied}",r"\text{score}",1.5,0.11,40),xu=1,yu=1)
def F006():
    return fig(_scatter(PTS6,(13.5,20),(0,9),(0,150),[0,1,2,3,4,5,6,7,8,9],[0,25,50,75,100,125,150],
        r"\text{years since 2016}",r"\text{revenue}",1.35,0.032,0),xu=1,yu=1)

def boxplots(rows, lo, hi, step, unit):
    """rows: list of (label,(mn,q1,med,q3,mx)); horizontal box plots on one axis."""
    X=lambda v:(v-lo)*unit
    s=[r"\draw[gridl] (%g,0)--(%g,%g);"%(X(t),X(t),1.1*len(rows)+0.5) for t in range(lo,hi+1,step)]
    s.append(r"\draw[axisline] (0,0)--(%g,0);"%(X(hi)+0.4))
    for t in range(lo,hi+1,step): s.append(r"\draw (%g,0.07)--(%g,-0.07) node[below,font=\scriptsize]{$%d$};"%(X(t),X(t),t))
    s.append(r"\node[font=\small] at (%g,-0.75){exam score};"%(X((lo+hi)/2)))
    for i,(lab,(mn,q1,md,q3,mx)) in enumerate(rows):
        y=1.1*(len(rows)-i)-0.2; h=0.32
        s.append(r"\node[font=\small,left] at (-0.2,%g){%s};"%(y,lab))
        s.append(r"\draw[thick,BLUE] (%g,%g)--(%g,%g);\draw[thick,BLUE] (%g,%g)--(%g,%g);"%(X(mn),y,X(q1),y,X(q3),y,X(mx),y))
        s.append(r"\draw[thick,BLUE] (%g,%g)--(%g,%g);\draw[thick,BLUE] (%g,%g)--(%g,%g);"%(X(mn),y-h/2,X(mn),y+h/2,X(mx),y-h/2,X(mx),y+h/2))
        s.append(r"\draw[thick,BLUE,fill=BLUE!10] (%g,%g) rectangle (%g,%g);"%(X(q1),y-h,X(q3),y+h))
        s.append(r"\draw[very thick,ORANGE] (%g,%g)--(%g,%g);"%(X(md),y-h,X(md),y+h))
    return fig("\n".join(s),xu=1,yu=1)
BOX7=[("Class A",(60,70,78,85,95)),("Class B",(55,65,78,90,100))]
def F007(): return boxplots(BOX7,50,100,10,0.28)
FIG={'PS-005':F005,'PS-006':F006,'PS-007':F007}
