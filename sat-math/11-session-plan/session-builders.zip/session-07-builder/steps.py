"""Worked-solution steps for Session 7. Every number quoted in a step is computed here (not typed by hand);
every typed expression that 'returns' a value is evaluated by ev() and re-checked in verify_steps.py."""
import math, re, statistics as st
from fractions import Fraction as Fr
import numpy as np

def n(v, d=4):
    s = ('%.*f' % (d, v)).rstrip('0').rstrip('.')
    if s in ('-0', ''): s = '0'
    if re.fullmatch(r'-?\d{4,}', s):
        neg = s.startswith('-'); s = s.lstrip('-'); s = '{,}'.join([s[:len(s) % 3 or 3]] + [s[i:i+3] for i in range(len(s) % 3 or 3, len(s), 3)]) if False else s
        out = ''; r = s
        while len(r) > 3: out = '{,}' + r[-3:] + out; r = r[:-3]
        s = ('-' if neg else '') + r + out
    return s
def _L(x): return np.array(x, float)
def _total(a): return float(np.sum(a))
def _join(*a): return np.concatenate([np.atleast_1d(np.array(x, float)) for x in a])
def _ncr(n_, r_): return math.comb(int(n_), int(r_))
DESMOS_ENV = dict(sqrt=math.sqrt, abs=abs, pi=math.pi, mean=lambda a: float(np.mean(a)), median=lambda a: float(np.median(a)),
                  stdev=lambda a: float(np.std(a, ddof=1)), stdevp=lambda a: float(np.std(a)), total=_total, join=_join,
                  length=lambda a: len(a), nCr=_ncr, max=lambda a: float(np.max(a)), min=lambda a: float(np.min(a)), _L=_L)
def ev(expr, **kw):
    """Desmos-syntax evaluator: a^2, implicit multiplication, [list] literals, mean/median/stdev/stdevp/total/join/length/nCr/sqrt/abs."""
    e = expr.replace('^', '**')
    e = re.sub(r'\[([^\[\]]*)\]', r'_L([\1])', e)
    e = re.sub(r'(\d|\))\s*(\(|[a-zA-Z_])', r'\1*\2', e)
    env = dict(DESMOS_ENV); env.update(kw)
    return eval(e, {'__builtins__': {}}, env)
def rep(pairs): return ','.join(','.join([str(a)] * k) for a, k in pairs)
def c(e): return '[[%s]]' % e
def v(x, d=4): return '$%s$' % n(x, d)
def ret(e, d=4, **kw): return "Type %s: it returns %s" % (c(e), v(ev(e, **kw), d))
def pt(x, y, d=4): return "$(%s,\\,%s)$" % (n(x, d), n(y, d))
def L(_t, **kw): return re.sub(r"@(\w+)@", lambda m: str(kw[m.group(1)]), _t)

S = {}; T = {}; V = {}; CLAIMS = []
TAPS = []; VERT = []; REG = []; FINAL = {}
def TOOL(t, *ids):
    for i in ids: T[i] = t

# ---------------- 116 (Desmos)
def _a116(x): x = Fr(x); a = x - x/3; b = 72 + x/3; return a + b/4, b - b/4
x116 = 36; a116, b116 = _a116(x116)
S['PS-116'] = [
 "After the first move room A has $\\dfrac{2x}{3}$ students and room B has $72+\\dfrac{x}{3}$. After the second move room A has $\\dfrac{3x}{4}+18$ and room B has $54+\\dfrac{x}{4}$.",
 "A ratio of $5:7$ means $7A=5B$. Type %s and %s." % (c('y=7(3x/4+18)'), c('y=5(54+x/4)')),
 "Tap the intersection: %s. Its $x$-value is the original number in room A." % pt(x116, ev('7*(3*x/4+18)', x=x116)),
 L("Check with $x=@x@$: room A ends with $@a@$ and room B with $@b@$, and $@a@:@b@$ is $5:7$.", x=x116, a=n(float(a116)), b=n(float(b116)))]
V['PS-116'] = x116
# ---------------- 117 (N)
v1, v2 = Fr(54*1000, 3600), Fr(90*1000, 3600); acc = (v2 - v1)/20
S['PS-117'] = [
 L("Convert to meters per second: $54$ km/h $=\\dfrac{54\\,000}{3600}=@a@$ m/s and $90$ km/h $=@b@$ m/s.", a=n(float(v1)), b=n(float(v2))),
 L("The speed rises by $@d@$ m/s in $20$ s, so the acceleration is $\\dfrac{@d@}{20}=@acc@$ meters per second squared.", d=n(float(v2-v1)), acc=n(float(acc))),
 L("One minute is $60$ seconds, so one second squared is $\\dfrac{1}{3600}$ of a minute squared and the number is multiplied by $3600$: $@acc@\\times3600=@r@$.", acc=n(float(acc)), r=n(float(acc*3600)))]
V['PS-117'] = float(acc*3600)
# ---------------- 119 (C)
fuel = 240*6/100 + 80*10/100
S['PS-119'] = [
 "Fuel used: the highway part uses $240\\times\\dfrac{6.0}{100}$ liters and the city part uses $80\\times\\dfrac{10.0}{100}$ liters. " + ret('240*6/100+80*10/100') + " liters.",
 "Distance: $240+80=320$ kilometers. " + ret('(240+80)/1.6') + " miles. " + ret('22.4/3.8') + " gallons.",
 ret('200/(22.4/3.8)') + ", which is closest to $34$ miles per gallon."]
V['PS-119'] = (320/1.6)/(fuel/3.8)
# ---------------- 120 (C)
S['PS-120'] = [
 "Real lengths: " + ret('2.4*1500') + " feet and " + ret('1.6*1500') + " feet.",
 "Change to yards before multiplying: " + ret('3600/3') + " yards and " + ret('2400/3') + " yards.",
 ret('1200*800') + " square yards. (Multiplying in feet first gives square feet, $8{,}640{,}000$, which is not what was asked.)"]
V['PS-120'] = 1200*800
# ---------------- 123 (C)
S['PS-123'] = [
 "First part: " + ret('0.6*90') + " km at $27$ km/h, so " + ret('54/27') + " hours.",
 "Rest of the route: " + ret('90-54') + " km at $24$ km/h, so " + ret('36/24') + " hours. Total time with the rest: " + ret('2+1.5+0.5') + " hours.",
 "Average speed: " + ret('90/4') + " km/h. Convert to meters per second: " + ret('22.5*1000/3600') + "."]
V['PS-123'] = 22.5*1000/3600
# ---------------- 007 (N)
S['PS-007'] = [
 "The medians are both $78$, so the statement that Class A has the greater median is out, and so is any statement that treats the medians as different.",
 "The interquartile range is $Q3-Q1$: Class A has $85-70=15$ and Class B has $90-65=25$.",
 "The IQR measures the spread of the middle half of the scores, so Class B is more spread out. The statement with the same median and a greater IQR for Class B is the one the box plots support."]
# ---------------- 008 (C)
S['PS-008'] = [
 "Each number of siblings is counted as many times as there are students: $0\\cdot5+1\\cdot8+2\\cdot4+3\\cdot2+4\\cdot1$. " + ret('0*5+1*8+2*4+3*2+4*1') + ".",
 "Divide by the $20$ students. " + ret('26/20') + ".",
 "The mean is $1.3$ siblings."]
# ---------------- 029 (C)
S['PS-029'] = [
 "The mode is the most frequent age: $20$, which appears $7$ times.",
 "There are $20$ values, so the median is the average of the $10$th and $11$th. The running counts are $7$ (age $20$) and $12$ (through age $21$), so both are $21$ and the median is $21$.",
 "Mean: " + ret('(20*7+21*5+22*3+23*2+24*1+30*2)/20', 4) + ".",
 "The two ages of $30$ pull the mean above the median, so mode $<$ median $<$ mean."]
# ---------------- 030 (C)
S['PS-030'] = [
 "Data set A: " + ret('(30*2+35*5+40*6+45*7)/20') + ".",
 "Data set B: " + ret('(30*7+35*6+40*4+45*3)/20') + ".",
 "Since $39.5>35.75$, the mean of A is greater. The tables give every value, so there is enough information."]
# ---------------- 031 (N)
S['PS-031'] = [
 "The $24$ numbers are all different and the median is $50$, so exactly $12$ are below $50$ and $12$ are above $50$.",
 "Twelve numbers go up by $5$ and twelve go down by $5$: the sum changes by $12(5)-12(5)=0$. The sum and the mean ($50$) do not change.",
 "The two middle values move one up and one down by $5$, so their average, the median, is still $50$.",
 "Every value moves $5$ farther from the mean, so the numbers are more spread out: only the standard deviation changes."]
# ---------------- 032 (N)
S['PS-032'] = [
 L("Total of all $12$ scores: $12\\times16.5=@a@$.", a=n(12*16.5)),
 L("Total of the other $11$ scores: $11\\times15=@b@$.", b=n(11*15)),
 L("The highest score is the difference: $@a@-@b@=@r@$.", a=n(12*16.5), b=n(11*15), r=n(12*16.5-11*15))]
V['PS-032'] = 12*16.5-11*15
# ---------------- 077 (N)
S['PS-077'] = [
 L("Total of the $15$ readings: $15\\times42=@a@$.", a=n(15*42)),
 L("Total of the other $14$ readings: $14\\times40=@b@$.", b=n(14*40)),
 L("The removed reading is the difference: $@a@-@b@=@r@$ degrees.", a=n(15*42), b=n(14*40), r=n(15*42-14*40))]
V['PS-077'] = 15*42-14*40
# ---------------- 078 (N)
D0 = [10, 14, 18, 22, 36]; D1 = D0 + [18]
S['PS-078'] = [
 L("Original set: mean $=\\dfrac{@s0@}{5}=@m0@$, median $=18$, range $=36-10=@r0@$.", s0=n(sum(D0)), m0=n(st.mean(D0)), r0=n(max(D0)-min(D0))),
 L("New set $10,14,18,18,22,36$: the sum is $@s1@$, so the mean is $\\dfrac{@s1@}{6}\\approx@m1@$. This is less than $@m0@$, so I is true.", s1=n(sum(D1)), m1=n(st.mean(D1), 2), m0=n(st.mean(D0))),
 "The two middle values are $18$ and $18$, so the median is still $18$. II is true.",
 L("The smallest and largest values are unchanged, so the range is still $@r@$. III is true: all three statements hold.", r=n(max(D1)-min(D1)))]
# ---------------- 079 (N)
S['PS-079'] = [
 L("Original sum: $5\\times14=@a@$.", a=n(5*14)),
 L("Replacing $20$ with $8$ lowers the sum by $12$: $@a@-20+8=@b@$.", a=n(5*14), b=n(5*14-20+8)),
 L("New mean: $\\dfrac{@b@}{5}=@m@$.", b=n(5*14-20+8), m=n((5*14-20+8)/5))]
V['PS-079'] = (5*14-20+8)/5
# ---------------- 080 (N)
S['PS-080'] = [
 L("Total age of all $50$ people: $50\\times76=@a@$. Total age of the first group: $30\\times70=@b@$.", a=n(50*76), b=n(30*70)),
 L("The second group's total is $@a@-@b@=@c@$.", a=n(50*76), b=n(30*70), c=n(50*76-30*70)),
 L("Its mean is $\\dfrac{@c@}{20}=@m@$ years.", c=n(50*76-30*70), m=n((50*76-30*70)/20))]
V['PS-080'] = (50*76-30*70)/20
# ---------------- 081 (N)
S['PS-081'] = [
 "There are $30$ scores, so the median is the average of the $15$th and $16$th scores.",
 "Running totals of the frequencies: $3,\\ 8,\\ 16,\\ 25,\\ 30$. Scores $9$ to $16$ are all $3$, so the $15$th and the $16$th scores are both $3$.",
 "The median is $\\dfrac{3+3}{2}=3$."]
# ---------------- 091 (N)
o91 = [12, 15, 18, 20, 20, 22, 25, 28]; n91 = [18, 15, 20, 20, 22, 25, 19, 21]
S['PS-091'] = [
 L("The original sum is $@s@$, so the mean is $@m@$. The values removed add to $12+28=@r@$ and the values added are $19+21=@a@$, so the sum and the mean do not change.", s=n(sum(o91)), m=n(st.mean(o91)), r=n(12+28), a=n(19+21)),
 L("Distances from the mean $@m@$: the removed values were $8$ away on each side. The added values $19$ and $21$ are only $1$ away on each side.", m=n(st.mean(o91))),
 "The data are now closer to the mean, so the standard deviation gets smaller: mean the same, SD smaller."]
# ---------------- 094 (D)
def var94(x):
    vals = [5, 8, 17, x, x]; m = sum(vals)/5; return sum((a-m)**2 for a in vals)/5
S['PS-094'] = [
 "The mean is $\\dfrac{30+2x}{5}$, so the variance is the average of the five squared distances from it.",
 "Type %s." % c('y=((5-(30+2x)/5)^2+(8-(30+2x)/5)^2+(17-(30+2x)/5)^2+2(x-(30+2x)/5)^2)/5'),
 "Tap the lowest point of the curve: %s. The least possible variance is the $y$-value." % pt(10, var94(10)),
 "Check with $x=10$ (mean $10$): " + ret('((5-10)^2+(8-10)^2+(17-10)^2)/5') + "."]
V['PS-094'] = var94(10)
# ---------------- 102 (N)
o102 = [31, 38, 42, 45, 47, 52, 53, 58, 65, 69]; n102 = [a for a in o102 if a not in (47, 53)]
S['PS-102'] = [
 L("The sum of the original values is $@s@$. The two removed values add to $47+53=@r@$, so the new sum is $@t@$ and the new mean is $\\dfrac{@t@}{8}=@m@$: the mean is unchanged.", s=n(sum(o102)), r=n(47+53), t=n(sum(n102)), m=n(np.mean(n102))),
 "The removed values are $3$ below and $3$ above the mean, the two values closest to it.",
 L("The values left are farther from the mean on average. The sum of squared distances drops only from $@a@$ to $@b@$, but it is now shared among $8$ values instead of $10$: the variance goes from $@va@$ to $@vb@$, so the SD is larger.", a=n(sum((a-50)**2 for a in o102)), b=n(sum((a-50)**2 for a in n102)), va=n(np.var(o102), 1), vb=n(np.var(n102), 1))]
# ---------------- 109 (N)
S['PS-109'] = [
 L("The nine integers add to $9\\times12=@s@$. In order, the median is the fifth integer, so it is $9$.", s=n(9*12)),
 "To make the three largest as big as possible, make the others as small as possible: the four smallest are at least $1$ each, and the sixth integer must be at least the median, $9$.",
 L("Everything else adds to $4(1)+9+9=@o@$, so the three largest add to at most $@s@-@o@=@r@$.", s=n(108), o=n(4+9+9), r=n(108-22)),
 "This is reachable: $1,1,1,1,9,9,9,9,68$ has sum $108$ and median $9$."]
V['PS-109'] = 108-22
# ---------------- 111 (N)  (edited item)
S['PS-111'] = [
 "In order, the median of seven integers is the fourth one, so it is $11$.",
 L("To make the three largest as big as possible, make the others as small as possible: the three smallest are $1$ each, and the median is $11$, so they add to $3+11=@o@$.", o=n(14)),
 L("The three largest add to at most $101-@o@=@t@$. Their mean is $\\dfrac{@t@}{3}=@m@$.", o=n(14), t=n(87), m=n(29)),
 "This is reachable: $1,1,1,11,11,11,65$ has sum $101$ and median $11$."]
V['PS-111'] = 87/3
# ---------------- 118 (N)
d0 = [2, 3, 5, 12, 18, 20]; d1a = [a+4 for a in d0]; m1 = np.mean(d1a); d1 = d1a + [m1]
S['PS-118'] = [
 L("Original mean: $\\dfrac{@s@}{6}=@m0@$. Adding $4$ to every value raises the mean to $@m1@$, and a new value equal to that mean leaves it at $@m1@$. I is true.", s=n(sum(d0)), m0=n(np.mean(d0)), m1=n(m1)),
 "Adding $4$ to every value does not change the spread. The new value sits exactly at the mean, so it adds nothing to the sum of squared distances but increases the number of values. The standard deviation is smaller, so II is true.",
 L("Original median: $\\dfrac{5+12}{2}=@a@$. The new set in order is $6,7,9,@m@,16,22,24$, so its median is $@b@$, which is $@d@$ more, not $4$ more. III is false.", a=n(st.median(d0)), m=n(m1), b=n(st.median(d1)), d=n(st.median(d1)-st.median(d0)))]
# ---------------- 124 (N)
S['PS-124'] = [
 L("The rule $x\\to15-\\dfrac{x}{2}$ is a straight-line change, so the median goes through the same rule: $15-\\dfrac{52}{2}=@m@$.", m=n(15-52/2)),
 L("Adding $15$ does not change the spread, and multiplying by $-\\dfrac12$ halves it (the negative sign only flips the order). The IQR becomes $14\\times\\dfrac12=@q@$.", q=n(14/2)),
 L("Sum: $@m@+@q@=@t@$.", m=n(15-52/2), q=n(14/2), t=n(15-52/2+14/2))]
V['PS-124'] = 15-52/2+14/2
# ---------------- 074 (N)
S['PS-074'] = [
 L("The mean is $100$, so $a+b+c=3\\times100=@s@$.", s=n(300)),
 L("One integer is largest when the other two are smallest. Each of them is at least $1$, so the largest integer is at most $@s@-1-1=@m@$.", s=n(300), m=n(298)),
 "So $150$, $250$ and $298$ are all possible values. $299$ is not: it would force the other two to add to $1$, but they add to at least $2$."]
# ---------------- 070 (N)
S['PS-070'] = [
 "Each pair has mean $40$, so each pair adds to $2\\times40=80$.",
 L("The six numbers add to $3\\times80=@s@$.", s=n(240)),
 L("Their mean is $\\dfrac{@s@}{6}=@m@$.", s=n(240), m=n(40))]
V['PS-070'] = 40
# ---------------- 011 (N)
S['PS-011'] = [
 "The researcher assigned the sections to the two methods at random. Random assignment is what supports a cause-and-effect conclusion about the method for the sections studied.",
 "The statements that call it an observational study or say that no causal conclusion can be drawn at all are wrong: random assignment of sections is still random assignment.",
 "The sections come from this one district. Nothing was randomly selected from all districts in the country, so the results cannot be generalized nationally or beyond this district."]
# ---------------- 033 (N)
S['PS-033'] = [
 "Results of a random sample can be generalized only to the population the sample was drawn from.",
 "The sample was drawn from chemistry teachers in one state, so the population is all chemistry teachers in that state.",
 "Teachers of all subjects, or chemistry teachers in the whole country, were never available to be selected."]
# ---------------- 034 (N, edited)
S['PS-034'] = [
 L("All $150$ residents responded, so $64\\%$ of $150$ is a count of people in the sample: $0.64\\times150=@k@$ residents said they support the program. Statement I must be true.", k=n(0.64*150)),
 "Statement II is about all city residents. A sample percentage is only an estimate of the population percentage, so it does not have to equal it exactly.",
 "Only statement I must be true."]
# ---------------- 035 (N)
S['PS-035'] = [
 "The saplings were randomly selected from the $3$-year-old saplings at the orchard, so the results apply to that population.",
 "Random assignment to the two irrigation schedules supports a cause-and-effect conclusion for that population.",
 "The $5$-year-old saplings and the saplings elsewhere in the country were not part of the selection, and the $40$ saplings alone are a smaller group than the population. The largest group is all $3$-year-old apple saplings at this orchard."]
# ---------------- 036 (N)
S['PS-036'] = [
 "Listeners chose for themselves whether to text in. This is a voluntary-response sample.",
 "A voluntary-response sample is not a random sample of all students' families, so the results are likely biased.",
 "The percentages adding to $97\\%$ is not the problem (some listeners may not have answered the question), and the number of Yes and No answers or the time allowed does not make the sample representative."]
# ---------------- 037 (N)
S['PS-037'] = [
 "A sample percentage is only an estimate of the percentage for the whole city, so statement 1 does not have to be true.",
 "A new random sample will not give exactly $71\\%$ again, because samples vary. Statement 2 does not have to be true.",
 "Another city is a different population, so statement 3 does not have to be true either. None must be true."]
# ---------------- 012 (N)
S['PS-012'] = [
 L("The margin of error is $4$ percentage points, so the plausible values are $62-4=@a@$ to $62+4=@b@$ percent.", a=n(58), b=n(66)),
 "A survey gives an estimate with a range of plausible values, not the exact value, and it cannot prove anything beyond doubt.",
 "The $95\\%$ is the confidence level, not the percentage of residents who support the initiative."]
# ---------------- 013 (N)
S['PS-013'] = [
 "The margin of error is proportional to $\\dfrac{1}{\\sqrt{n}}$, so only the change in $n$ matters.",
 L("The sample size goes from $400$ to $1600$, which is $4$ times larger, and $\\sqrt{4}=@r@$.", r=n(2)),
 L("The margin of error is divided by $@r@$: $\\dfrac{4.5}{@r@}=@a@$ percent.", r=n(2), a=n(4.5/2))]
V['PS-013'] = 4.5/2
# ---------------- 047 (N)
S['PS-047'] = [
 "Results of a random sample apply to the population it was drawn from: here, the oak trees planted through this program.",
 "So the sample average can be used as an estimate for those trees, but it is only an estimate, not an exact value.",
 "It cannot speak for trees of every species in the country, and it is not exactly equal to the program's average. Only the statement about estimating the average for the program's oak trees is correct."]
# ---------------- 048 (N)
S['PS-048'] = [
 L("The plausible values run from $34-4=@a@$ to $34+4=@b@$ minutes.", a=n(30), b=n(38)),
 "Check each option: $25$ is below $30$, $39$ and $44$ are above $38$.",
 "Only $31$ lies in the range."]
# ---------------- 049 (N)
S['PS-049'] = [
 L("The plausible values run from $42-3.5=@a@$ to $42+3.5=@b@$ percent.", a=n(38.5), b=n(45.5)),
 "Check each option: $36\\%$ is below $38.5\\%$, and $47\\%$ and $50\\%$ are above $45.5\\%$.",
 "Only $41\\%$ lies in the range."]
# ---------------- 050 (C)
S['PS-050'] = [
 L("The margin of error is $3$ points, so the plausible percentages are $22-3=@a@$ to $22+3=@b@$ percent.", a=n(19), b=n(25)),
 "Lower end: " + ret('0.19*8000') + ". Upper end: " + ret('0.25*8000') + ".",
 "The plausible range is $1{,}520<n<2{,}000$."]
# ---------------- 051 (N)
S['PS-051'] = [
 L("The sample defect rate is $\\dfrac{15}{60}=@r@$, which is $25\\%$.", r=n(15/60)),
 L("Applying the rate to the shipment: $0.25\\times2400=@a@$.", a=n(0.25*2400)),
 "This came from a sample, so it is a best estimate, not an exact count, a minimum or a maximum."]
# ---------------- 052 (C)
S['PS-052'] = [
 "Sample proportion in favor: " + ret('310/500') + ".",
 "Apply it to all $45{,}000$ registered voters: " + ret('0.62*45000') + ".",
 "The expected number is $27{,}900$ voters."]
V['PS-052'] = 0.62*45000
# ---------------- 053 (N)
S['PS-053'] = [
 L("The plausible values are $24-4=@a@$ to $24+4=@b@$ percent.", a=n(20), b=n(28)),
 "The administrator's $32\\%$ is above $28\\%$, so it is outside that range.",
 "So the claim is not consistent with the survey. The sample size is not the reason."]
# ---------------- 096 (N)
meA = math.sqrt(0.5*0.5/625)
S['PS-096'] = [
 L("Poll A: $\\sqrt{\\dfrac{0.5(0.5)}{625}}=\\sqrt{0.0004}=@a@$.", a=n(meA)),
 L("Poll B has half of that: $@h@$. So $\\sqrt{\\dfrac{0.1(0.9)}{n}}=@h@$.", h=n(meA/2)),
 L("Square both sides: $\\dfrac{0.09}{n}=@s@$, so $n=\\dfrac{0.09}{@s@}=@r@$.", s=n((meA/2)**2, 6), r=n(900))]
V['PS-096'] = 900
# ---------------- 099 (N, edited)
S['PS-099'] = [
 L("The interval $24.2$ to $27.8$ is centered at $26$, so its margin of error is $\\dfrac{27.8-24.2}{2}=@m@$ minutes.", m=n((27.8-24.2)/2)),
 L("The new sample is $\\dfrac{5625}{625}=@k@$ times as large, and $\\sqrt{@k@}=@r@$, so the margin of error is divided by $@r@$: $\\dfrac{@m@}{@r@}=@a@$ minutes.", k=n(9), r=n(3), m=n((27.8-24.2)/2), a=n((27.8-24.2)/2/3)),
 "The interval describes the mean of all workers, not individual commutes, and a $95\\%$ interval does not rule out values outside it. The new margin is the statement that must be true."]
# ---------------- 105 (C)
S['PS-105'] = [
 "The most supporters in county P come from the top of its range: $52+3=55\\%$ of $2{,}500$. " + ret('0.55*2500') + ".",
 "The fewest supporters in county Q come from the bottom of its range: $38-4=34\\%$ of $900$. " + ret('0.34*900') + ".",
 "The greatest difference is " + ret('1375-306') + "."]
V['PS-105'] = 1375-306
# ---------------- 009 (N)
S['PS-009'] = [
 "Restrict to the condition: only the $100$ female students count.",
 "Of those, $50$ intend a STEM track.",
 L("$P=\\dfrac{50}{100}=@p@$.", p=n(0.5, 2))]
# ---------------- 010 (C)
S['PS-010'] = [
 "First selection: $\\dfrac{50}{90}$ chance of a female student. With no replacement, $49$ of the remaining $89$ students are female.",
 "Multiply the two probabilities: " + ret('50/90*49/89') + ".",
 "Rounded to the nearest thousandth: $0.306$."]
V['PS-010'] = 50/90*49/89
# ---------------- 018 (N)
S['PS-018'] = [
 "Read the row for Grade $11$ and the column for does not own a graphing calculator.",
 "That cell holds $3$ students, and the total number of students is $50$.",
 "$P=\\dfrac{3}{50}$."]
# ---------------- 019 (N)
S['PS-019'] = [
 "Read the row for not robotics club and the column for coding club.",
 "That cell holds $10$ students, and the total number of students is $50$.",
 "$P=\\dfrac{10}{50}=\\dfrac15=0.2$."]
# ---------------- 020 (C)
S['PS-020'] = [
 "The $2024$ figure is not needed. Use the total on January 1, 2025: $36.8$ million.",
 "Carrier A has $45\\%$ of them: " + ret('36.8*0.45') + ".",
 "To the nearest integer, $p=17$."]
V['PS-020'] = round(36.8*0.45)
# ---------------- 021 (N)
S['PS-021'] = [
 "The private-sector column has $12$ full-time and $x$ part-time employees, $12+x$ in all.",
 "The probability of part-time is $\\dfrac{x}{12+x}=\\dfrac15$.",
 L("Cross-multiply: $5x=12+x$, so $4x=12$ and $x=@x@$.", x=n(3))]
V['PS-021'] = 3
# ---------------- 022 (N)
S['PS-022'] = [
 "Pick numbers that fit: $100$ online responses and $200$ paper-form responses.",
 L("Art: $10\\%$ of $100$ is $@a@$ online, and $5\\%$ of $200$ is $@b@$ on paper.", a=n(10), b=n(10)),
 L("Of the $@t@$ Art responses, $@b@$ were on paper: $\\dfrac{@b@}{@t@}=\\dfrac12$.", t=n(20), b=n(10))]
V['PS-022'] = 0.5
# ---------------- 092 (N)
bus = 300-120
S['PS-092'] = [
 L("The Business track has $300-120=@b@$ participants.", b=n(bus)),
 L("Online Business: $0.35\\times@b@=@o@$, so in-person Business is $@b@-@o@=@i@$.", b=n(bus), o=n(0.35*bus), i=n(bus-0.35*bus)),
 L("In person in total: $70+@i@=@t@$.", i=n(bus-0.35*bus), t=n(70+bus-0.35*bus))]
V['PS-092'] = 70+bus-0.35*bus
# ---------------- 113 (D)
b113 = 100
S['PS-113'] = [
 "Let $b$ be the number who commute by bicycle. Helmet owners: $\\dfrac{3b}{5}$ among cyclists plus $\\dfrac{240-b}{4}$ among the others.",
 "The probability that a helmet owner is a cyclist is $\\dfrac{3b/5}{3b/5+(240-b)/4}=\\dfrac{12}{19}$. Type %s and %s (letting $x$ stand for $b$)." % (c('y=(3x/5)/(3x/5+(240-x)/4)'), c('y=12/19')),
 "Tap the intersection: %s, so $b=100$." % pt(100, 12/19),
 "Helmet owners in all: " + ret('3*100/5+(240-100)/4') + "."]
V['PS-113'] = 95
# ---------------- 005 (N)
S['PS-005'] = [
 "In $y=mx+b$ the slope $m$ is the change in $y$ for each increase of $1$ in $x$.",
 "Here $y$ is the exam score and $x$ is the hours studied, so $6.3$ is the predicted change in score for each extra hour.",
 "The $y$-intercept ($48.5$) is the predicted score at $0$ hours, and a best-fit line gives predictions, not exact changes for every student."]
# ---------------- 006 (N)
S['PS-006'] = [
 L("The line predicts, at $x=8$: $13.5(8)+20=@p@$.", p=n(13.5*8+20)),
 L("Residual $=$ actual $-$ predicted $=138-@p@=@r@$.", p=n(13.5*8+20), r=n(138-(13.5*8+20))),
 "The actual point is above the line, so the residual is positive. ($-10$ comes from subtracting in the wrong order.)"]
# ---------------- 015 (N)
S['PS-015'] = [
 "The sign of $r$ gives the direction: $r=-0.82$ is negative, so as study time goes up, sleep time tends to go down.",
 "The size of $r$ gives the strength: $0.82$ is close to $1$, so the relationship is strong.",
 "So it is a strong, negative linear relationship."]


# =====================================================================================
# v2: every problem carries a Desmos solution (boxes typed with [[ ]], values computed by ev())
def A_(vals): return np.array(vals, float)
def lst(name, vals): return c('%s=[%s]' % (name, ','.join(n(x) for x in vals)))
def fin(i, val): FINAL[i] = val
def opt_fin(i, frag): FINAL[i] = ('opt', frag)

# 116, 094, 113: graph + tap (kept), register taps
TAPS.append(('PS-116', '7*(3*x/4+18)', '5*(54+x/4)', 36, 315)); fin('PS-116', 36)
VERT.append(('PS-094', '((5-(30+2*x)/5)^2+(8-(30+2*x)/5)^2+(17-(30+2*x)/5)^2+2*(x-(30+2*x)/5)^2)/5', 10, 15.6, 'min')); fin('PS-094', 15.6)
TAPS.append(('PS-113', '(3*x/5)/(3*x/5+(240-x)/4)', '12/19', 100, 12/19)); fin('PS-113', 95)

S['PS-117'] = [
 "Speeds in meters per second: " + ret('54*1000/3600') + " and " + ret('90*1000/3600') + ".",
 "Acceleration (change in speed over time): " + ret('(25-15)/20') + " meters per second squared.",
 "One minute is $60$ seconds, so multiply by $60^2$: " + ret('0.5*60^2') + ".",
 "The acceleration is $1800$ meters per minute squared."]
fin('PS-117', 1800)
fin('PS-119', (320/1.6)/(fuel/3.8)); fin('PS-120', 960000); fin('PS-123', 6.25); fin('PS-008', 1.3)
S['PS-007'] = [
 "Class A: " + ret('85-70') + " is its IQR. Class B: " + ret('90-65') + " is its IQR.",
 "Difference of the medians: " + ret('78-78') + ", so the medians are equal.",
 "Compare the two IQRs: $25>15$, so Class B's middle $50\\%$ of scores is more spread out.",
 "The statement with the same median and a greater IQR for Class B is the one the box plots support."]
opt_fin('PS-007', 'Class B')
_A = [20]*7+[21]*5+[22]*3+[23]*2+[24]*1+[30]*2
S['PS-029'] = [
 "Type the $20$ ages as a list: " + lst('A', _A) + ".",
 ret('mean(A)', A=A_(_A)) + ". Then " + ret('median(A)', A=A_(_A)) + ".",
 "The mode is the most frequent age, $20$, which appears " + ret('7') .replace("Type", "(type") + ") times in the list (Desmos has no mode button, so count it).",
 "So mode $20<$ median $21<$ mean $22.05$."]
S['PS-029'][2] = "The mode is the most frequent age: $20$ appears $7$ times in the list, more than any other age (Desmos has no mode function, so count)."
opt_fin('PS-029', 'mode $<$ median $<$ mean')
_dA=[30]*2+[35]*5+[40]*6+[45]*7; _dB=[30]*7+[35]*6+[40]*4+[45]*3
S['PS-030'] = [
 "Type each data set as a list: " + lst('A', _dA) + " and " + lst('B', _dB) + ".",
 "Data set A: " + ret('mean(A)', A=A_(_dA)) + ".",
 "Data set B: " + ret('mean(B)', B=A_(_dB)) + ".",
 "Since $39.5>35.75$, the mean of A is greater."]
opt_fin('PS-030', 'greater than')
_c31 = [40, 48, 52, 60]; _n31 = [35, 43, 57, 65]
S['PS-031'] = [
 "Sum change: $12$ numbers gain $5$ and $12$ lose $5$. " + ret('12*5-12*5') + ", so the sum and the mean do not change.",
 "Try a small example with the same pattern: " + lst('L', _c31) + " has mean $50$ and median $50$. Add $5$ to the two numbers above $50$ and subtract $5$ from the two below: " + lst('M', _n31) + ".",
 "Mean and median: " + ret('mean(L)', L=A_(_c31)) + ", " + ret('mean(M)', M=A_(_n31)) + ", " + ret('median(L)', L=A_(_c31)) + ", " + ret('median(M)', M=A_(_n31)) + ".",
 "Standard deviation: " + ret('stdevp(L)', L=A_(_c31)) + " and " + ret('stdevp(M)', M=A_(_n31)) + ". It grew, so the standard deviation is the measure that changes."]
opt_fin('PS-031', 'Standard deviation')
S['PS-032'] = ["Total of all $12$ scores: " + ret('12*16.5') + ".", "Total of the other $11$ scores: " + ret('11*15') + ".", "The highest score is the difference: " + ret('198-165') + ".", "The highest score is $33$."]
fin('PS-032', 33)
S['PS-077'] = ["Total of the $15$ readings: " + ret('15*42') + ".", "Total of the other $14$ readings: " + ret('14*40') + ".", "The removed reading is the difference: " + ret('630-560') + ".", "The removed reading is $70$ degrees."]
fin('PS-077', 70)
_o78 = [10, 14, 18, 22, 36]; _n78 = [10, 14, 18, 18, 22, 36]
S['PS-078'] = [
 "Type the original set and the new set: " + lst('L', _o78) + " and " + lst('M', _n78) + ".",
 "Original: " + ret('mean(L)', L=A_(_o78)) + ", " + ret('median(L)', L=A_(_o78)) + ", " + ret('max(L)-min(L)', L=A_(_o78)) + " (range).",
 "New: " + ret('mean(M)', M=A_(_n78)) + ", " + ret('median(M)', M=A_(_n78)) + ", " + ret('max(M)-min(M)', M=A_(_n78)) + " (range).",
 "The mean is smaller ($19.6667<20$), the median is the same ($18$) and the range is the same ($26$): all three statements are true."]
opt_fin('PS-078', 'I, II and III')
S['PS-079'] = ["Original sum: " + ret('5*14') + ".", "Replace $20$ by $8$: " + ret('70-20+8') + ".", "New mean: " + ret('58/5') + ".", "The new mean is $11.6$."]
fin('PS-079', 11.6)
S['PS-080'] = ["Total age of all $50$ people: " + ret('50*76') + ". Total age of the first group: " + ret('30*70') + ".", "Second group total: " + ret('3800-2100') + ".", "Its mean age: " + ret('1700/20') + ".", "The mean age of the second group is $85$ years."]
fin('PS-080', 85)
_s81 = [1]*3+[2]*5+[3]*8+[4]*9+[5]*5; _a81 = _s81[:8]; _b81 = _s81[8:]
S['PS-081'] = [
 "Type the $30$ scores in two lists: " + lst('A', _a81) + " and " + lst('B', _b81) + ".",
 "Check the count: " + ret('length(join(A,B))', A=A_(_a81), B=A_(_b81)) + ".",
 "Median: " + ret('median(join(A,B))', A=A_(_a81), B=A_(_b81)) + ".",
 "The median score is $3$."]
fin('PS-081', 3)
_O91 = [12, 15, 18, 20, 20, 22, 25, 28]; _N91 = [15, 18, 19, 20, 20, 21, 22, 25]
S['PS-091'] = [
 "Type the original and the new data set: " + lst('L', _O91) + " and " + lst('M', _N91) + ".",
 "Means: " + ret('mean(L)', L=A_(_O91)) + " and " + ret('mean(M)', M=A_(_N91)) + ".",
 "Standard deviations: " + ret('stdevp(L)', L=A_(_O91)) + " and " + ret('stdevp(M)', M=A_(_N91)) + ".",
 "The mean is the same and the standard deviation is smaller."]
opt_fin('PS-091', 'Mean same, SD smaller')
S['PS-094'] = S['PS-094']
_O102 = o102; _N102 = n102
S['PS-102'] = [
 "Type the original and the new data set: " + lst('L', _O102) + " and " + lst('M', _N102) + ".",
 "Means: " + ret('mean(L)', L=A_(_O102)) + " and " + ret('mean(M)', M=A_(_N102)) + ".",
 "Standard deviations: " + ret('stdevp(L)', L=A_(_O102)) + " and " + ret('stdevp(M)', M=A_(_N102)) + ".",
 "The mean is unchanged and the standard deviation is larger."]
opt_fin('PS-102', 'Mean unchanged; SD larger')
_e109 = [1, 1, 1, 1, 9, 9, 9, 9, 68]
S['PS-109'] = [
 "Total of the nine integers: " + ret('9*12') + ".",
 "Make everything except the three largest as small as possible: four $1$s, the median $9$ and a sixth integer $9$. Then " + ret('108-4*1-9-9') + ".",
 "Check with an example: " + lst('L', _e109) + ". " + ret('mean(L)', L=A_(_e109)) + " and " + ret('median(L)', L=A_(_e109)) + ".",
 "The greatest possible sum of the three largest integers is $86$."]
fin('PS-109', 86)
_e111 = [1, 1, 1, 11, 11, 11, 65]
S['PS-111'] = [
 "Everything except the three largest is as small as possible: three $1$s and the median $11$. " + ret('101-3*1-11') + ".",
 "Mean of the three largest: " + ret('87/3') + ".",
 "Check with an example: " + lst('L', _e111) + ". " + ret('total(L)', L=A_(_e111)) + " and " + ret('median(L)', L=A_(_e111)) + ".",
 "The greatest possible mean is $29$."]
fin('PS-111', 29)
_L118 = d0; _M118 = sorted(d1a + [m1])
S['PS-118'] = [
 "Type the original data and the new data (each value plus $4$, with the mean $14$ added): " + lst('L', _L118) + " and " + lst('M', _M118) + ".",
 "Means: " + ret('mean(L)', L=A_(_L118)) + " and " + ret('mean(M)', M=A_(_M118)) + ". The mean is $4$ greater: I is true.",
 "Standard deviations: " + ret('stdevp(L)', L=A_(_L118)) + " and " + ret('stdevp(M)', M=A_(_M118)) + ". It is smaller: II is true.",
 "Medians: " + ret('median(L)', L=A_(_L118)) + " and " + ret('median(M)', M=A_(_M118)) + ". The median is $5.5$ greater, not $4$: III is false."]
opt_fin('PS-118', 'I and II only')
S['PS-124'] = ["Median of the new data: " + ret('15-52/2') + ".", "IQR of the new data (halved; the shift of $15$ does not matter): " + ret('14/2') + ".", "Sum: " + ret('-11+7') + ".", "The sum is $-4$."]
fin('PS-124', -4)
S['PS-074'] = ["The three integers add to " + ret('3*100') + ".", "The largest possible integer uses $1$ and $1$ for the other two: " + ret('300-1-1') + ".", "Test $299$: " + ret('299+1+1') + ", which is more than $300$, so it is impossible.", "The value that is not possible is $299$."]
fin('PS-074', 299)
S['PS-070'] = ["Each pair adds to " + ret('40*2') + ".", "Three pairs add to " + ret('3*80') + ".", "Mean of the six numbers: " + ret('240/6') + ".", "The average is $40$."]
fin('PS-070', 40)
# verbal items (no typed computation): 011, 033, 035, 047 keep their reasoning steps
for i in ('PS-011', 'PS-033', 'PS-035', 'PS-047'): pass
opt_fin('PS-011', 'randomly assigned'); opt_fin('PS-033', 'chemistry teachers in the state'); opt_fin('PS-035', '3$ years old at this orchard'); opt_fin('PS-047', 'estimate the average growth rate of all oak')
S['PS-034'] = [
 "All $150$ responded, so $64\\%$ of them is a count: " + ret('0.64*150') + " residents.",
 "Check: " + ret('96/150') + ", which is $64\\%$. So statement I must be true.",
 "Statement II is about all city residents. A sample percentage is only an estimate of that percentage, so it does not have to be exact.",
 "Only statement I must be true."]
opt_fin('PS-034', 'I only')
S['PS-036'] = [
 "Add the reported percentages: " + ret('62+35') + ".",
 "The missing part: " + ret('100-97') + " percent gave no answer or another answer. That does not make the poll invalid.",
 "Listeners chose for themselves whether to text in (a voluntary-response sample), so the sample is not random.",
 "The best explanation is that the respondents were not a random sample of all students' families."]
opt_fin('PS-036', 'not a random sample')
S['PS-037'] = [
 "The sample count: " + ret('0.71*800') + " satisfied adults out of $800$. Check: " + ret('568/800') + ".",
 "That is a percentage for this sample only, so statement 1 (the whole city) does not have to be true.",
 "A new random sample would give a different count, so statement 2 does not have to be true.",
 "Another city is a different population, so statement 3 does not have to be true. None must be true."]
opt_fin('PS-037', 'None')
S['PS-012'] = ["Lower end of the interval: " + ret('62-4') + ".", "Upper end: " + ret('62+4') + ".", "So it is plausible that between $58\\%$ and $66\\%$ of all residents support the initiative.", "The survey gives a plausible range, not an exact value or a proof."]
opt_fin('PS-012', 'between $58')
S['PS-013'] = ["The sample size is multiplied by " + ret('1600/400') + ".", "The margin of error is divided by the square root of that: " + ret('sqrt(1600/400)') + ".", "New margin of error: " + ret('4.5/2') + ".", "Check in one line: " + ret('4.5*sqrt(400/1600)') + " percent."]
fin('PS-013', 2.25)
S['PS-048'] = ["Lower end: " + ret('34-4') + ". Upper end: " + ret('34+4') + ".", "The plausible values are $30$ to $38$ minutes.", "Check the options: $25<30$; $39$ and $44$ are above $38$.", "Only $31$ lies in the range."]
fin('PS-048', 31)
S['PS-049'] = ["Lower end: " + ret('42-3.5') + ". Upper end: " + ret('42+3.5') + ".", "The plausible values are $38.5\\%$ to $45.5\\%$.", "Check the options: $36\\%$ is below the range; $47\\%$ and $50\\%$ are above it.", "Only $41\\%$ lies in the range."]
fin('PS-049', 41)
opt_fin('PS-050', '$1{,}520 < n < 2{,}000$')
S['PS-051'] = ["Sample defect rate: " + ret('15/60') + ".", "Apply the rate to the shipment: " + ret('0.25*2400') + ".", "This comes from a sample, so it is an estimate, not an exact count, a minimum or a maximum.", "The best conclusion is that about $600$ laptops are defective."]
opt_fin('PS-051', 'best estimate is that $600$'); fin('PS-052', 27900)
S['PS-053'] = ["Lower end: " + ret('24-4') + ". Upper end: " + ret('24+4') + ".", "The plausible range is $20\\%$ to $28\\%$.", "Compare: " + ret('32-28') + " percentage points above the top of the range.", "So $32\\%$ is outside the range, and the claim is not consistent with the survey."]
opt_fin('PS-053', 'outside the range')
S['PS-096'] = ["Poll A: " + ret('sqrt(0.5*0.5/625)') + ".", "Poll B has half of that: " + ret('0.02/2') + ".", "Solve $\\sqrt{\\dfrac{0.1(0.9)}{n}}=0.01$ for $n$: " + ret('0.1*0.9/0.01^2') + ".", "Poll B surveyed $900$ people."]
fin('PS-096', 900)
S['PS-099'] = ["Margin of error of the first interval: " + ret('(27.8-24.2)/2') + ".", "The sample is multiplied by " + ret('5625/625') + ".", "New margin of error: " + ret('1.8/sqrt(9)') + ".", "The interval is about the mean of all workers, not individual commutes, and a $95\\%$ interval does not rule out other values with certainty. So the new margin of about $0.6$ minutes is the true statement."]
opt_fin('PS-099', 'about $0.6$')
fin('PS-105', 1069)
S['PS-009'] = ["Number of female students: " + ret('50+50') + ".", "Probability of STEM given female: " + ret('50/100') + ".", "Only the female row counts, so the denominator is $100$, not $200$.", "The probability is $0.50$."]
fin('PS-009', 0.5)
fin('PS-010', 0.306)
S['PS-018'] = ["Check the total: " + ret('18+7+22+3') + ".", "Grade $11$ and no calculator: $3$ students. " + ret('3/50') + ".", "As a fraction that is $\\dfrac{3}{50}$.", "The probability is $\\dfrac{3}{50}$."]
opt_fin('PS-018', '\\dfrac{3}{50}')
S['PS-019'] = ["Check the total: " + ret('15+8+10+17') + ".", "Coding club but not robotics club: $10$ students. " + ret('10/50') + ".", "As a fraction that is $\\dfrac15$.", "The probability is $\\dfrac15$ (or $0.2$)."]
fin('PS-019', 0.2); fin('PS-020', 17)
TAPS.append(('PS-021', 'x/(12+x)', '1/5', 3, 0.2)); fin('PS-021', 3)
S['PS-021'] = ["The probability of part-time among the private-sector employees is $\\dfrac{x}{12+x}$.", "Type %s and %s." % (c('y=x/(12+x)'), c('y=1/5')), "Tap the intersection: %s. Its $x$-value is the answer." % pt(3, 0.2), "Check: " + ret('3/(12+3)') + ", which is $\\dfrac15$."]
S['PS-022'] = ["Use $100$ online responses and $200$ paper responses.", "Art online: " + ret('0.1*100') + ". Art on paper: " + ret('0.05*200') + ".", "Probability of paper given Art: " + ret('10/(10+10)') + ".", "The probability is $\\dfrac12$ (or $0.5$)."]
fin('PS-022', 0.5)
S['PS-092'] = ["Business track: " + ret('300-120') + ".", "Online Business: " + ret('0.35*180') + ".", "In-person Business: " + ret('180-63') + ".", "In person in total: " + ret('70+117') + "."]
fin('PS-092', 187)
REG.append(('PS-005', [1, 2, 3, 4, 5, 6], [55, 60, 68, 75, 80, 86]))
_m5, _b5 = np.polyfit([1, 2, 3, 4, 5, 6], [55, 60, 68, 75, 80, 86], 1)
S['PS-005'] = [
 "Open a table and enter $x_1=1,2,3,4,5,6$ and $y_1=55,60,68,75,80,86$.",
 "Type %s: Desmos returns $m=%s$ and $b=%s$." % (c('y_1~m*x_1+b'), n(_m5), n(_b5)),
 "The slope is about $6.3$: the predicted score rises by about $6.3$ points for each extra hour studied.",
 "The intercept $48.5$ is the predicted score at $0$ hours, and a best-fit line gives predictions, not exact changes for every student."]
opt_fin('PS-005', 'additional hour')
S['PS-006'] = ["Predicted value at $x=8$: " + ret('13.5*8+20') + ".", "Residual $=$ actual $-$ predicted: " + ret('138-128') + ".", "The point is above the line, so the residual is positive ($-10$ comes from subtracting in the wrong order).", "The residual is $10$."]
fin('PS-006', 10)
S['PS-015'] = ["The sign of $r$ is negative, so the relationship is negative.", "The size of $r$: " + ret('abs(-0.82)') + ". Check how far it is from $1$: " + ret('1-0.82') + ".", "It is close to $1$, so the relationship is strong.", "It is a strong, negative linear relationship."]
opt_fin('PS-015', 'strong, negative')

TOOL('D', *list(S))
TOOL('N', 'PS-011', 'PS-033', 'PS-035', 'PS-047')
