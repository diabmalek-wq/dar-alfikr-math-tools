"""Builds s7_items.json from the raw bank extract: neutral contexts, tables, option parsing, figures, and the few edited items."""
import json,re,sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import figs
raw=json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'s7_raw.json')))

def tab(md):
    rows=[r.strip().strip('|').split('|') for r in md.strip().split('\n') if r.strip().startswith('|') and not re.match(r'^\|\s*-',r.strip())]
    n=len(rows[0]);t=r"\begin{center}\renewcommand{\arraystretch}{2.1}\begin{tabular}{|"+"c|"*n+"}\hline "
    for r in rows: t+=" & ".join(c.strip() for c in r)+r" \\ \hline "
    return t+r"\end{tabular}\end{center}"

# ---- full replacement stems (text before the options) and options, where the bank text needs a context change or an edit
STEM={}; OPTS={}; NEWANS={}; CHANGED={}
STEM['PS-006']=("A company's annual online-sales revenue, in millions of dollars, is recorded for years since $2016$ ($x$). The approximate data points are $\\left(0, 30\\right)$, $\\left(2, 45\\right)$, $\\left(4, 68\\right)$, $\\left(6, 95\\right)$ and $\\left(8, 138\\right)$. The scatterplot shows the data and a line used to model it, $y = 13.5x + 20$.\n\n@@FIG@@\n\nWhat is the residual for the data point at $x = 8$?")
STEM['PS-007']="Box plots summarize final exam scores for two sections of a course.\n\nClass A: minimum $60$, $Q1 = 70$, median $= 78$, $Q3 = 85$, maximum $95$.\n\nClass B: minimum $55$, $Q1 = 65$, median $= 78$, $Q3 = 90$, maximum $100$.\n\n@@FIG@@\n\nWhich statement is best supported by these box plots?"
STEM['PS-005']="A teacher records hours studied ($x$) and exam score ($y$) for $6$ students.\n\n| Hours studied ($x$) | 1 | 2 | 3 | 4 | 5 | 6 |\n|---|---|---|---|---|---|---|\n| Exam score ($y$) | 55 | 60 | 68 | 75 | 80 | 86 |\n\n@@FIG@@\n\nThe line of best fit for this data is approximately $y = 6.3x + 48.5$. Which of the following is the best interpretation of the slope of this line?"
OPTS['PS-005']=["The predicted exam score for a student who studies $0$ hours is $6.3$.","Each additional hour studied is associated with a predicted increase of about $6.3$ points on the exam.","Each additional point on the exam is associated with a predicted increase of about $6.3$ hours studied.","The exam score increases by exactly $6.3$ points for every student, regardless of hours studied."]
CHANGED['PS-005']="stated line changed from $y=6.2x+48.7$ to $y=6.3x+48.5$ (the least-squares line of the table is $y\\approx6.34x+48.47$); answer unchanged"
CHANGED['PS-006']="'line of best fit' reworded to 'a line used to model' the data (the least-squares line of the five points is $y=13.3x+22$, not $13.5x+20$); numbers and answer unchanged"
STEM['PS-009']="In a career-interest study, $200$ Grade 11 students were surveyed on their intended career track.\n\n| | STEM track | Non-STEM track | Total |\n|---|---|---|---|\n| Male | 60 | 40 | 100 |\n| Female | 50 | 50 | 100 |\n| Total | 110 | 90 | 200 |\n\nIf a student is selected at random from those surveyed and the student is female, what is the probability that the student intends a STEM track?"
STEM['PS-010']="In a career-interest survey, $90$ Grade 11 students intend a non-STEM track: $40$ of them are male and $50$ are female. Two of these students are selected at random, one after another, without replacement. What is the probability that both selected students are female? (Round to the nearest thousandth.)"
STEM['PS-020']="On January 1, 2024, there were $34.1$ million mobile broadband subscriptions in a certain country. By January 1, 2025, the number of subscriptions had increased to $36.8$ million. If a subscriber on January 1, 2025, is selected at random, the probability that the subscriber uses Carrier A is $0.45$. There were $p$ million Carrier A subscribers on January 1, 2025. To the nearest integer, what is the value of $p$?"
STEM['PS-021']="The table below shows the distribution of employment type and sector for a group of employees at a company.\n\n| | Public sector | Private sector |\n|---|---|---|\n| Full-time | $45$ | $12$ |\n| Part-time | $9$ | $x$ |\n\nIf one of these employees who works in the private sector is chosen at random, the probability that the employee is part-time is $\\dfrac{1}{5}$. What is the value of $x$?"
STEM['PS-022']="| | Online | Paper form |\n|---|---|---|\n| Robotics | $60\\%$ | $80\\%$ |\n| Sports | $25\\%$ | $10\\%$ |\n| Art | $10\\%$ | $5\\%$ |\n| Music | $5\\%$ | $5\\%$ |\n\nA school activity survey asked each student to select the one activity they preferred for a school event. Some students responded online, and the others responded on a paper form. The table above shows the distribution of preferred activity, in percent, for each response type. For the survey, the number of paper-form responses was twice the number of online responses. If a student who preferred Art is selected at random, what is the probability that the student responded on the paper form? (Express your answer as a decimal or fraction, not as a percent.)"
STEM['PS-033']="A researcher surveyed a random sample of chemistry teachers selected from all chemistry teachers in a certain state. The teachers were asked to name the textbook publisher they currently use. What is the largest population to which the results of the survey can be generalized?"
OPTS['PS-033']=["All teachers in the country","All chemistry teachers in the country","All chemistry teachers in the state","All teachers in the state"]
STEM['PS-034']="A random sample of $150$ residents of a city was surveyed about whether they support a new recycling program. All $150$ responded, and $64\\%$ said they support it. Based on this information, which of the following statements must be true?\n\nI. Exactly $96$ of the $150$ residents surveyed said they support the recycling program.\n\nII. Of all city residents, exactly $64\\%$ support the recycling program."
OPTS['PS-034']=["Neither","I only","II only","I and II"]; NEWANS['PS-034']='B'
CHANGED['PS-034']="statement I changed to a true statement about the sample (64% of 150 = 96); answer is now (I only); the bank version had the same 'Neither' answer and trick as PS-037"
STEM['PS-035']="For a research orchard, a scientist randomly selected $40$ apple saplings from the saplings that were $3$ years old at the orchard and randomly assigned them to two groups. Each group received a different irrigation schedule for $2$ consecutive years to observe whether the schedule affects fruit yield. Based on the design of the study, what is the largest group to which these results can be applied?"
OPTS['PS-035']=["All $40$ saplings that were selected at this orchard","All apple saplings that were $3$ years old at this orchard","All apple saplings that were $3$ years old in the country","All apple saplings that were $5$ years old at this orchard"]
STEM['PS-036']="At the end of a radio program, the host invited listeners to text in and respond to a poll asking, \"Do you support extending school hours by $30$ minutes?\" By the end of the show, the host reported that $62\\%$ responded \"Yes\" and $35\\%$ responded \"No.\" Which of the following best explains why the results are unlikely to represent the sentiments of all students' families in the country?"
STEM['PS-037']="A polling agency surveyed $800$ adults selected at random from a large city and asked, \"Are you satisfied with the quality of public transportation in the city?\" Of those surveyed, $71\\%$ responded that they were satisfied. Based on the results of the survey, which of the following statements must be true?\n\n1. Of all adults in the city, $71\\%$ are satisfied with the quality of public transportation.\n\n2. If another $800$ adults selected at random from the city were surveyed, $71\\%$ of them would report they are satisfied.\n\n3. If $800$ adults selected at random from a different city were surveyed, $71\\%$ of them would report they are satisfied."
STEM['PS-012']="A random sample of $500$ residents in a county found that $62\\%$ support a proposed residential zoning initiative, with a margin of error of $4$ percentage points at the $95\\%$ confidence level. Which of the following is the most appropriate interpretation of this result?"
OPTS['PS-012']=["Exactly $62\\%$ of all residents in the county support the initiative.","It is plausible that between $58\\%$ and $66\\%$ of all residents in the county support the initiative.","Exactly $95\\%$ of residents in the county support the initiative.","The survey proves beyond doubt that a majority of residents support the initiative."]
STEM['PS-047']="Researchers studying a reforestation program selected a random sample of $250$ oak trees planted through the program and measured each tree's growth rate. Based on this sample, which of the following is the most appropriate conclusion?"
OPTS['PS-047']=["The average growth rate of the sampled trees can be used to estimate the average growth rate of all oak trees planted through the reforestation program.","The average growth rate of the sampled trees can be used to estimate the average growth rate of all trees, of any species, in the country.","The average growth rate of the sampled trees is exactly equal to the average growth rate of all oak trees planted through the reforestation program.","The average growth rate of the sampled trees cannot be used to estimate the average growth rate of any other trees."]
STEM['PS-049']="A poll of a random sample of residents in a city district estimates that $42\\%$ of all residents support a new public transit expansion, with a margin of error of $3.5$ percentage points. Which of the following is the most plausible value for the actual percentage of all residents in the district who support the expansion?"
STEM['PS-053']="Based on a random sample survey, a researcher estimates that $24\\%\\pm 4\\%$ of high school students in a district spend more than $2$ hours a day on e-reading apps. A school administrator claims that $32\\%$ of the district's high school students spend more than $2$ hours a day on such apps. Is the administrator's claim consistent with the survey's estimate?"
STEM['PS-077']="A weather station recorded the high temperature, in degrees Fahrenheit, on each of $15$ days. The mean of these $15$ readings was $42$. After the reading from one day was removed as a recording error, the mean of the remaining $14$ readings was $40$. What was the removed reading?"
NEWANS['PS-077']='70'; CHANGED['PS-077']="numbers and context changed ($10$ numbers, means $38\\to36$, answer $56$ became $15$ readings, means $42\\to40$, answer $70$) because it repeated PS-032's trick with near-identical numbers"
STEM['PS-092']="A conference has $300$ participants. Each participant attended either the Technical track or the Business track, and either in person or online. Some of the data are shown.\n\n| | Technical | Business | Total |\n|---|---|---|---|\n| In person | $70$ | | |\n| Online | $50$ | | |\n| Total | $120$ | | $300$ |\n\nOf the participants in the Business track, $35\\%$ attended online. How many of the $300$ participants attended in person?"
STEM['PS-099']="A researcher surveys a random sample of $625$ workers in a city and calculates a $95\\%$ confidence interval of $24.2$ to $27.8$ minutes for the mean one-way commute time of all workers in the city. Assume a second random sample of $5{,}625$ workers has similar variability and the same method is used. Which of the following statements must be true?"
OPTS['PS-099']=["About $95\\%$ of sampled commutes lie in the interval.","The new margin is about $0.2$ min.","The population mean cannot be $28.1$ min.","The new margin is about $0.6$ min."]; NEWANS['PS-099']='D'
CHANGED['PS-099']="second sample changed from $2{,}500$ to $5{,}625$ workers (new margin about $0.6$ min instead of $0.9$) because it repeated PS-013's quadrupling-the-sample trick"
STEM['PS-102']="A data set has $10$ values: $31,\\ 38,\\ 42,\\ 45,\\ 47,\\ 52,\\ 53,\\ 58,\\ 65,\\ 69$. The mean of the data set is $50$. The values $47$ and $53$ are removed, leaving $8$ values. Which of the following is true of the new data set compared with the original? (SD means standard deviation.)"
OPTS['PS-102']=["Mean greater; SD smaller","Mean unchanged; SD smaller","Mean unchanged; SD larger","Mean smaller; SD larger"]; NEWANS['PS-102']='C'
CHANGED['PS-102']="removed values changed from the least and greatest (47 and 53 instead of 31 and 69) so the answer is now (Mean unchanged; SD larger); the bank version repeated PS-091's remove-extremes trick"
STEM['PS-111']="Seven positive integers, not necessarily distinct, have a sum of $101$ and a median of $11$. What is the greatest possible value of the mean of the three largest of these integers?"
OPTS['PS-111']=["$29$","$31.67$","$32.33$","$33.67$"]; NEWANS['PS-111']='A'
CHANGED['PS-111']="changed from nine integers, sum $100$, median $9$, mean of four largest (answer $21.75$) to seven integers, sum $101$, median $11$, mean of three largest (answer $29$) because it repeated PS-109's trick with near-identical numbers"
STEM['PS-118']="A data set has six values: $2,\\ 3,\\ 5,\\ 12,\\ 18,\\ 20$. Every value is increased by $4$, and then a seventh value equal to the mean of the six increased values is added to the data set. Consider the following statements about the new data set of seven values compared with the original data set.\n\nI. The mean is $4$ greater.\n\nII. The standard deviation is smaller.\n\nIII. The median is $4$ greater.\n\nWhich of the statements must be true?"
STEM['PS-029']=None  # unchanged

def split(q):
    stem=[];opts=[]
    for ln in q.split('\n'):
        m=re.match(r'^\(?([A-D])\)\s*(.*)$',ln.strip())
        if m and (opts or m.group(1)=='A'): opts.append(m.group(2).strip())
        elif opts and ln.strip()=='': continue
        elif opts: opts[-1]+=' '+ln.strip()
        else: stem.append(ln)
    return '\n'.join(stem).strip(),opts

def render_stem(stem):
    lines=stem.split('\n'); out=[];i=0
    while i<len(lines):
        if lines[i].strip().startswith('|'):
            j=i
            while j<len(lines) and lines[j].strip().startswith('|'): j+=1
            out.append('\n\n'+tab('\n'.join(lines[i:j]))+'\n\n'); i=j
        else: out.append(lines[i]); i+=1
    s='\n'.join(out)
    s=re.sub(r'\n{3,}','\n\n',s).strip()
    return s

def make():
    items=[]
    for o in raw:
        stem,opts=split(o['q'])
        if STEM.get(o['id']): stem=STEM[o['id']]
        if o['id'] in OPTS: opts=OPTS[o['id']]
        fmt=o['fmt']
        if fmt.startswith('Multiple'):
            assert len(opts)==4,(o['id'],opts)
            assert len(set(opts))==4,o['id']
        else: opts=None
        if o['id'] in NEWANS: ans=NEWANS[o['id']]
        else: ans=o['ans']
        if opts:
            m=re.match(r'^\(?([A-D])(?:\)|$|\s)',ans.strip()); letter=m.group(1)
        else: letter=None
        rs=render_stem(stem)
        fig=figs.FIG[o['id']]() if o['id'] in figs.FIG else None
        if fig is not None:
            assert '@@FIG@@' in rs; rs=rs.replace('@@FIG@@',fig)  # figure sits inside the stem
        else: assert '@@FIG@@' not in rs
        # SPR answer
        sans=None if opts else ans.replace('$','').strip()
        items.append(dict(id=o['id'],part=o['part'],d=o['d'],skill=o['skill'],q=rs,stem_raw=stem,opts=opts,letter=letter,sans=sans,changed=CHANGED.get(o['id'])))
    return items
if __name__=='__main__':
    it=make(); json.dump(it,open('s7_items.json','w'),indent=1); print(len(it))
