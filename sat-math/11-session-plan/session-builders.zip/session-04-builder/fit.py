import subprocess,re,json,os,math
ov=json.load(open('lines_ovr.json')) if os.path.exists('lines_ovr.json') else {}
items=json.load(open('s4_items.json'))
order=[o for o in items if o['part']=='In class']+[o for o in items if o['part']!='In class']
for it in range(6):
    print(subprocess.run(['python3','build.py'],capture_output=True,text=True).stdout)
    log=open('S4_key.log').read()
    H=re.findall(r'KEYH ([\d.]+)pt ?([\d.]+)pt',log)
    # last pass only: the log holds one pass (second run overwrites)
    assert len(H)==57,len(H)
    changed=0
    for o,(h0,h1) in zip(order,H):
        h0,h1=float(h0),float(h1)
        cur=ov.get(o['id'],{'M':5,'H':6}['M' if o['d']=='Medium' else 'H'])
        if h0>h1+0.5:
            per=h1/cur if cur else 21.6
            new=math.ceil(h0/ (21.6)) 
            new=max(new,cur+1); ov[o['id']]=new; changed+=1; print('raise',o['id'],cur,'->',new)
    json.dump(ov,open('lines_ovr.json','w'))
    if not changed: break
