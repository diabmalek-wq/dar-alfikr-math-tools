# Re-evaluates every typed [[expr]] "it returns" value, every tapped-point claim, and every final answer (vs solve.py's independent answers).
import re,math,sys,json
sys.path.insert(0,'.')
import numpy as np
from steps import S,ev,n,ENV,CLAIMS
import steps_d
from steps_d import FIN
from lx import compile_tex, call
bad=0;cnt=0;boxes=0;probs_with=0
items={o['id']:o for o in json.load(open('s4_items.json'))}
COMP=json.load(open('computed.json'))
for iid,steps in S.items():
    nb=0
    for st in steps:
        nb+=len(re.findall(r"\[\[(.+?)\]\](?!\])",st))
        for m in re.finditer(r"\[\[([^\]]+)\]\]: it returns \$([^$]+)\$",st):
            expr,val=m.group(1),m.group(2).replace('{,}','')
            want=[float(x) for x in val.replace('\\,',' ').replace(',',' ').split()]
            got=np.atleast_1d(ev(expr,**ENV.get(iid,{}))).astype(float); cnt+=1
            if len(got)!=len(want) or any(abs(g-w)>6e-5*max(1,abs(w)) for g,w in zip(got,want)): print('MISMATCH',iid,expr,got,want); bad+=1
    boxes+=nb; probs_with+=(nb>=1)
    if not (3<=len(steps)<=4): print('STEP COUNT',iid,len(steps)); bad+=1
    if nb<1: print('NO DESMOS BOX',iid); bad+=1
print('returns checked',cnt,'mismatches',bad)
for name,f in CLAIMS:
    ok=f(); 
    if not ok: print('BAD',name); bad+=1
print('claims (tapped points / identities) checked',len(CLAIMS))
# final answers
def opts(i):
    o=[]
    for ln in items[i]['q'].split('\n'):
        m=re.match(r'^\(?([A-D])\)\s*(.*)$',ln.strip())
        if m: o.append(m.group(2).strip())
    return o
nf=0
for iid,o in items.items():
    fin=FIN[iid]; mc=o['fmt']=='Multiple Choice'; comp=COMP[iid]; nf+=1
    if not mc:
        if fin[0]!='val' or abs(fin[1]-comp)>1e-6*max(1,abs(comp)): print('FINAL BAD',iid,fin,comp); bad+=1
        continue
    txt=opts(iid)['ABCD'.index(comp)]
    if fin[0]=='text':
        norm=lambda s:s.replace(' ','').replace('$','')
        if norm(fin[1]) not in norm(txt): print('FINAL TEXT BAD',iid,fin[1],txt); bad+=1
    elif fin[0]=='val':
        try: tv=call(compile_tex(txt))
        except Exception as e: print('parse fail',iid,txt); bad+=1; continue
        if abs(tv-fin[1])>1e-6*max(1,abs(tv)): print('FINAL BAD',iid,fin[1],tv); bad+=1
    elif fin[0]=='fn':
        f=compile_tex(txt)
        for kw in fin[2]:
            if abs(call(f,**kw)-fin[1](**kw))>1e-7*max(1,abs(fin[1](**kw))): print('FINAL FN BAD',iid,kw); bad+=1; break
print('final answers checked',nf)
for iid,steps in S.items():
    for st in steps:
        for m in re.finditer(r"\[\[(.+?)\]\](?!\])",st):
            e=m.group(1)
            if e.count('(')!=e.count(')') or e.count('[')!=e.count(']'): print('UNBALANCED',iid,e); bad+=1
print('problems with >=1 Desmos box',probs_with,'of',len(S),'; total boxes',boxes)
print('tags:',{k:sum(1 for i in S if steps_d.T[i]==k) for k in set(steps_d.T.values())})
print('FINAL bad',bad)
