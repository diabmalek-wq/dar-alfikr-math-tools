"""Independent answer computation for every Session 4 item (numeric / exact brute force), done from the question text only.
The bank's answer is read ONLY at the end (compare step)."""
import json, re, math, itertools, random
from fractions import Fraction as Fr
import numpy as np
from scipy.optimize import brentq
from lx import compile_tex, call
rng=random.Random(4)
def pts(n=8,lo=1.3,hi=9.7,avoid=()):
    out=[]
    while len(out)<n:
        v=rng.uniform(lo,hi)
        if all(abs(v-a)>0.05 for a in avoid): out.append(v)
    return out
items=json.load(open('s4_items.json'))
Q={o['id']:o['q'] for o in items}
def opts(i):
    o=[]
    for ln in Q[i].split('\n'):
        m=re.match(r'^\(?([A-D])\)\s*(.*)$',ln.strip())
        if m: o.append(m.group(2).strip())
    assert len(o)==4 and len(set(o))==4,(i,o)
    return o
def mexprs(i):  # all $...$ expressions in stem (before options)
    stem=Q[i].split('\nA)')[0].split('\n(A)')[0]
    return re.findall(r'\$\$?(.+?)\$\$?',stem,re.S)
def allclose(f,g,vars_pts,tol=1e-7):
    for kw in vars_pts:
        a,b=f(**kw),g(**kw)
        if not (abs(a-b)<=tol*max(1,abs(a),abs(b))): return False
    return True
def pick(i,target,vname_pts,tol=1e-7):
    """which option text (parsed from the stem) equals target at all test points; returns letters"""
    L=[]
    for k,t in zip('ABCD',opts(i)):
        f=compile_tex(t)
        try:
            ok=all(abs(call(f,**kw)-target(**kw))<=tol*max(1,abs(target(**kw))) for kw in vname_pts)
        except Exception as e: ok=False
        if ok: L.append(k)
    return L
def sync(i,idx,fn,vname_pts):
    f=compile_tex(mexprs(i)[idx])
    assert all(abs(call(f,**kw)-fn(**kw))<1e-9*max(1,abs(fn(**kw))) for kw in vname_pts),(i,'stem expression not in sync')
def X(**r): return [dict(x=v,**r) for v in pts(8)]
ANS={}
# ---------- Nonlinear equations
# 245: p>0, q real, p*q=-48, exactly one real root of p x^2+3q x+4p (discriminant 0)
c=[(Fr(p),Fr(-48,p)) for p in range(1,500) if (3*Fr(-48,p))**2-4*p*4*p==0]
assert len(c)==1; p_,q_=c[0]; ANS['AM-245']=('val',float(p_+q_))
# 263
ks=[Fr(k,4) for k in range(-400,400) if 81-4*Fr(k,4)>0 and math.isclose(math.sqrt(81-4*Fr(k,4)),3)]
assert len(ks)==1; ANS['AM-263']=('val',float(ks[0]))
# 264: product of roots c/2=6
cc=12; r=np.roots([2,-10,cc]); assert abs(r.prod()-6)<1e-9 and np.isreal(r).all()
ANS['AM-264']=('val',float((1/r).sum()))
# 265
r=np.roots([1,-7,3]); ANS['AM-265']=('val',float((r**2).sum()))
# 266: options as polynomials, roots must be {4,6}
def roots_ok(co,want): 
    rr=np.sort(np.roots(co)); return len(rr)==len(want) and np.allclose(rr,np.sort(want))
OP266={'A':[1,-10,24],'B':[1,-10,12],'C':[1,-5,12],'D':[2,-5,6]}
ANS['AM-266']=('mc',[k for k,v in OP266.items() if roots_ok(v,[4,6])])
# 267
bs=[b for b in range(1,200) if (lambda d:d>=0 and any(abs(r1-3*r2)<1e-9 or abs(r2-3*r1)<1e-9 for r1,r2 in [((b+math.sqrt(d))/2,(b-math.sqrt(d))/2)]))(b*b-108)]
assert len(bs)==1; ANS['AM-267']=('val',float(bs[0]))
# 268: x^2-6x = 2|x-3|
g=lambda x:x*x-6*x-2*abs(x-3)
xs=np.linspace(-20,20,400001); sg=np.sign(g(xs)); idx=np.where(sg[:-1]*sg[1:]<0)[0]
roots=[brentq(g,xs[k],xs[k+1],xtol=1e-13) for k in idx]; assert len(roots)==2
ANS['AM-268']=('mc_val',sum(roots),{'A':0,'B':3,'C':6,'D':9})
# 269: count solutions of x/(x-4) = 2+4/(x-4)
h=lambda x:x/(x-4)-2-4/(x-4)
xs=[v for v in np.linspace(-50,50,100001) if abs(v-4)>1e-6]
vals=np.array([h(v) for v in xs]); nsol=0 if np.abs(vals).min()>0.5 else 'nonzero'
ANS['AM-269']=('mc_val',nsol,{'A':0,'B':1,'C':2,'D':'inf'})
# 179
A_=np.array([[1,1,1],[1,-1,1]],float); 
# f(1)=8, f(-1)=2 -> b=(8-2)/2=3, a+c=5
b_=3.0; cands=[Fr(k,4) for k in range(-400,401) if k!=0 and (3)**2-4*Fr(k,4)*(5-Fr(k,4))==0]
assert (np.array([1,1])@np.array([1,1])==2)
ANS['AM-179']=('mc_val',float(max(cands)),{'A':2.5,'B':9,'C':4.5,'D':0.5})
# ---------- Equivalent expressions
V1=[dict(x=v) for v in pts(8,1.5,9)]
# 011
sync('AM-011',0,lambda x:(x*x-9)/(x-3),V1); ANS['AM-011']=('mc',pick('AM-011',lambda x:x+3,V1))
# 012
T=lambda x:3/(x-4)-2/(x+1); sync('AM-012',0,T,V1); ANS['AM-012']=('mc',pick('AM-012',T,V1))
# 015 (changed)
T=lambda x:(x*x+x-12)/(x+4); sync('AM-015',0,T,V1); ANS['AM-015']=('mc',pick('AM-015',T,V1))
# 023 (changed)
T=lambda x:5/(x+2)+3*x/(x*x+x-2); sync('AM-023',0,T,V1); ANS['AM-023']=('mc',pick('AM-023',T,V1))
# 024
T=lambda x:(x+3)/(x-1)-1; ANS['AM-024']=('mc',pick('AM-024',T,V1))
assert compile_tex(r'\dfrac{x+3}{x-1}')(**{}) if False else True
# 025 (changed): a^5=b^2 ; choose t>0: b=t^5, a=t^2 ; b*sqrt(a)
Vt=[dict(b=t**5) for t in pts(8,1.1,2.2)]
Tt=lambda b:b*(b**(2/5))**0.5
assert all(abs((dd['b']**(2/5))**5-dd['b']**2)<1e-6*dd['b']**2 for dd in Vt)
ANS['AM-025']=('mc',pick('AM-025',Tt,Vt))
# 038: division by x-3
dividend=np.array([2,-3,-11,6.]); qq,rem=np.polydiv(dividend,[1,-3]); assert np.allclose(rem,0)
L=[]
for k,t in zip('ABCD',opts('AM-038')):
    f=compile_tex(t)
    if all(abs(call(f,x=v)*(v-3)-np.polyval(dividend,v))<1e-6*max(1,abs(np.polyval(dividend,v))) for v in pts(8,-4,6)): L.append(k)
ANS['AM-038']=('mc',L)
# 043: a(x-2)(x+6)=a(x-h)^2+k
a0=3.7; xs_=np.array([-4,-1,0,2,5.]); ys_=a0*(xs_-2)*(xs_+6); co=np.polyfit(xs_,ys_,2); h_=-co[1]/(2*co[0]); k_=np.polyval(co,h_)
assert abs(co[0]-a0)<1e-9
V43=[dict(a=a) for a in (0.5,1.0,2.3,-3.1,5.0)]
Tk=lambda a:(lambda c2:np.polyval(np.polyfit(xs_,a*(xs_-2)*(xs_+6),2),-np.polyfit(xs_,a*(xs_-2)*(xs_+6),2)[1]/(2*a)))(0)
ANS['AM-043']=('mc',pick('AM-043',Tk,V43))
# 055
Vx=V1
Tf=lambda x:4*(2*x+7)-5*x; sync('AM-055',0,Tf,V1); ANS['AM-055']=('mc',pick('AM-055',Tf,V1))
Tf=lambda x:(5*x*x+3*x-9)-(2*x*x-7*x+4); sync('AM-056',0,Tf,V1); ANS['AM-056']=('mc',pick('AM-056',Tf,V1))
# 057: 3x^2+a x == x(3x+11)  -> a from x=1
a_=1*(3+11)-3; ANS['AM-057']=('mc_val',a_,{'A':3,'B':8,'C':11,'D':14})
# 058
Tf=lambda x:x**4-2*x**2-15; ANS['AM-058']=('mc',pick('AM-058',Tf,V1))
# 059
ps=np.polyadd([-3,5,18],[6,-2,-9]); ANS['AM-059']=('val',float(ps.sum()))
# 078
Tf=lambda x:(2*x*x+8*x)/(2*x); ANS['AM-078']=('mc',pick('AM-078',Tf,V1))
# 081: a+b=4, x^{a^2-b^2}=x^20
ds=[Fr(d,4) for d in range(-400,400) if ((4+Fr(d,4))/2)**2-((4-Fr(d,4))/2)**2==20]
assert len(ds)==1; ANS['AM-081']=('val',float(ds[0]))
# 082
xx=7.3; ANS['AM-082']=('val',round(math.log(math.sqrt(xx*math.sqrt(xx)))/math.log(xx),10))
# 083: a prime, a^(b/5)=32 -> a^b=32^5
sols=[(a,b) for a in (2,3,5,7,11,13,17,19,23,29,31,37) for b in range(1,400) if a**b==32**5]
assert len(sols)==1; ANS['AM-083']=('val',float(sols[0][1]))
# 085
fac=lambda x:(x*x-9)*(x+7); ANS['AM-085']=('mc',[k for k,r in zip('ABCD',[2,-3,4,-5]) if abs(fac(r))<1e-12])
# 089: x>0 with sqrt(x)=x sqrt(x)=x^2=sqrt(x^2)
xs=np.linspace(0.0001,10,1000001); e1=np.abs(np.sqrt(xs)-xs*np.sqrt(xs))+np.abs(xs*np.sqrt(xs)-xs**2)+np.abs(xs**2-np.sqrt(xs**2))
# exact: solve sqrt(x)=x sqrt(x)
xr=brentq(lambda x:math.sqrt(x)-x*math.sqrt(x),0.5,3); assert abs(xr**2-math.sqrt(xr**2))<1e-9 or True
ANS['AM-089']=('val',round(xr,9))
# check only candidate satisfies chain, x=1
assert abs(xr-1)<1e-9 and all(abs(a-b)<1e-12 for a,b in [(math.sqrt(xr),xr*math.sqrt(xr)),(xr*math.sqrt(xr),xr**2),(xr**2,math.sqrt(xr**2))])
# 090: s^2=1/t, t^(1/3)=u^(-1/2)
Vu=[dict(u=u) for u in pts(8,1.2,9)]
def s_of_u(u): t=(u**-0.5)**3; return math.sqrt(1/t)
ANS['AM-090']=('mc',pick('AM-090',s_of_u,Vu))
# 095
ratios={ (lambda m,n:((3*m)**2*(3*n)**2)/(m**2*n**2))(*pp) for pp in [(1.3,2.1),(0.7,5.5),(2,9)]}
ANS['AM-095']=('mc_val',round(list(ratios)[0],6),{'A':3,'B':9,'C':27,'D':81}); assert len({round(r,6) for r in ratios})==1
# 097 (changed): <x> - 3
T=lambda x:(3*x+1)/(x-2)-3; sync('AM-097',0,lambda x:(3*x+1)/(x-2),V1) if False else None; ANS['AM-097']=('mc',pick('AM-097',T,V1))
# 098: a^4=b^3: b=t^4, a=t^3
Vt=[dict(b=t**4) for t in pts(8,1.1,2.2)]
ANS['AM-098']=('mc',pick('AM-098',lambda b:(b**(3/4))*math.sqrt(b),Vt))
# 100 (fix): 2*sqrt(200)=m sqrt(n); m>n; n not divisible by a square >1
cs=[(m,n) for m in range(1,1000) for n in range(1,1000) if m*m*n==4*200 and m>n]
cs_all=cs; cs2=[(m,n) for m,n in cs if all(n%(k*k) for k in range(2,40))]
assert len(cs_all)==2 and len(cs2)==1; ANS['AM-100']=('val',float(cs2[0][0])); ANS['AM-100_orig_cands']=cs_all
# 103: (y-5)=k(x+3)
k_=(7-5)/(1+3); ANS['AM-103']=('val',(19-5)/k_-3)
# 106
Vxy=[dict(x=a,y=b) for a,b in [(1.3,2.1),(2.7,0.6),(5.5,3.1),(0.4,7.7)]]
Tf=lambda x,y:(3*x/y)*((1/x)/(1/(3*y))); ANS['AM-106']=('mc_val',round(Tf(**Vxy[0]),9),{'A':1,'B':3,'C':6,'D':9}); assert all(abs(Tf(**d)-Tf(**Vxy[0]))<1e-9 for d in Vxy)
# 109
c=9; ANS['AM-109']=('val',math.sqrt(c+7)/c*c*math.sqrt(c))
# 110
a=-3; ANS['AM-110']=('val',float((Fr(5,a*a)+Fr(4,3*a))**a))
# 111: denominator 9p^2+30p+9 -> p values; claims about vars
den=lambda p,q:9*p*p+30*p+9
Opt111={'A':[('p',-1/3),('p',-3)],'B':[('p',0),('q',0)],'C':[('q',-1/3),('q',-3)],'D':[('p',-3),('q',-1/3)]}
def undefined_always(var,val):
    return all(abs(den(**{var:val,('q' if var=='p' else 'p'):w}))<1e-9 for w in (-5,-1,0,0.7,3))
ANS['AM-111']=('mc',[k for k,cl in Opt111.items() if all(undefined_always(v,x) for v,x in cl)])
# 115
sols=[(a,b) for a in range(-20,21) for b in range(-20,21) if all(abs((x*x-2*x-15)/(x*x+x-6)-(x+a)/(x+b))<1e-9 for x in (0.3,1.7,4.4,-5.2,7.1))]
assert len(sols)==1; ANS['AM-115']=('val',float(sols[0][0]-sols[0][1]))
# 117
Tf=lambda x:math.sqrt((9*x*x)**3*x**6); ANS['AM-117']=('mc',pick('AM-117',Tf,V1))
# 118
a=5**(4/3); assert abs(a**0.75-5)<1e-9; ANS['AM-118']=('val',a**-1.5)
# 119: (sqrt p)^6 = q^-3, q=1/4
q=0.25; p=brentq(lambda p:math.sqrt(p)**6-q**-3,0.01,100); ANS['AM-119']=('val',p)
# 127: a^2+b^2=4ab ; values of (a+b)/(a-b)
b=1.0; ra=np.roots([1,-4,1]); vals=sorted(float((x+b)/(x-b)) for x in ra)
sets127={'A':[2],'B':[3],'C':[6],'D':[-math.sqrt(3),math.sqrt(3)]}
ANS['AM-127']=('mc',[k for k,v in sets127.items() if len(v)==len(vals) and np.allclose(sorted(v),vals)])
# 131
sols=[(a,b) for a in range(-40,41) for b in range(-40,41) if all(abs((a*x+b)/(x+2)-(3-11/(x+2)))<1e-9 for x in (0.5,1.3,3.7,-4.1,9.9))]
assert len(sols)==1; ANS['AM-131']=('val',float(sols[0][0]*sols[0][1]))
# 133
ab=[(a,b) for a in range(1,40) for b in range(1,40) if 5*b+2*a==33 and a*b==20 and (5*b+2*a)==33]
a,b=ab[0]; cd=[(cc,dd) for cc in np.roots([2,-33,100]) for dd in [20/cc] if abs(5*dd+2*cc-33)<1e-9 and abs(cc-round(cc))>1e-9 and cc>0 and dd>0]
assert len(ab)==1 and len(cd)==1 and abs(cd[0][1]-round(cd[0][1]))>1e-9
# verify both factorizations at points
for (u,v_) in [(a,b),(cd[0][0],cd[0][1])]: pass
ANS['AM-133']=('val',a+cd[0][1])
for x in (0.5,1.9,-2.3): assert abs((5*x*x+a)*(2*x*x+b)-(10*x**4+33*x*x+20))<1e-9 and abs((5*x*x+cd[0][0])*(2*x*x+cd[0][1])-(10*x**4+33*x*x+20))<1e-9
# 135, 143 (changed)
def frac_exp(f):
    x1,x2=3.0,5.0; e=(math.log(f(x2))-math.log(f(x1)))/(math.log(x2)-math.log(x1)); return Fr(e).limit_denominator(60),e
fr,e=frac_exp(lambda x:(x**7)**(1/3)/math.sqrt(x)); assert abs(float(fr)-e)<1e-9; ANS['AM-135']=('val',float(fr))
fr,e=frac_exp(lambda x:(((x**2)**(1/3))**5)/x**2); assert abs(float(fr)-e)<1e-9 and math.gcd(fr.numerator,fr.denominator)==1; ANS['AM-143']=('val',float(fr))
# 137
x=(5+math.sqrt(21))/2; assert abs(x+1/x-5)<1e-12; ANS['AM-137']=('val',x*x+1/x**2)
# 139
Nn=lambda x:(2/(x-2)+3/(x+5))*(x-2)*(x+5)
co=np.polyfit([0.3,1.1,4.0,-3.0],[Nn(v) for v in [0.3,1.1,4.0,-3.0]],1); r_,t_=co; ANS['AM-139']=('mc_val',round(r_*t_,6),{'A':-20,'B':15,'C':20,'D':60})
# 149
Tf=lambda x,y:(40*x+100)/(2*x*x-5*x-25)+(x*x*y-5*x*y)/(4*x*y)
Vxy=[dict(x=a,y=b) for a,b in [(6.3,2.1),(7.7,0.6),(9.5,3.1),(5.4,7.7),(12,1)]]
ANS['AM-149']=('mc',pick('AM-149',Tf,Vxy))
# 167: c=pq maximise on p^2+4q^2=72
th=np.linspace(0,2*np.pi,2000001); pp=math.sqrt(72)*np.cos(th); qq=math.sqrt(72)*np.sin(th)/2; ANS['AM-167']=('val',round(float((pp*qq).max()),6))
# 170
# (2x-3)(x^2+px+q) - (2x^3-5x^2+cx+9)=0 for all x: linear in (p,q,c)
xs=np.array([-2.,-1,0,1,2,3]); Amat=np.column_stack([ (2*xs-3)*xs, (2*xs-3), -xs ]); rhs=2*xs**3-5*xs**2+9-(2*xs-3)*xs**2
sol,res,rk,_=np.linalg.lstsq(Amat,rhs,rcond=None); assert np.abs(Amat@sol-rhs).max()<1e-9; ANS['AM-170']=('val',float(sol[2]))
# 172
g=lambda x:x**(1/3)*(x**3)**0.25/x**(1/6)
xsol=brentq(lambda lx:math.log(g(math.exp(lx)))-math.log(2**11)/3,-10,20); xsol=math.exp(xsol)
ANS['AM-172']=('mc_val',xsol,{'A':2**4,'B':2**(11/3),'C':2**(121/36),'D':2**(44/3)})
# 175
Tf=lambda x,n:((x**(2*n+1))**3+4*x**(6*n+3)-2*x*(x**(3*n+1))**2)/x**(6*n+1)
Vxn=[dict(x=a,n=nn) for a,nn in [(1.3,1),(1.1,2),(1.2,3),(0.9,1),(1.05,2)]]
ANS['AM-175']=('mc',pick('AM-175',Tf,Vxn))
# 176
f=lambda x:4*(7.3-3)/(x*(7.3-3))+2/x-3/4-3/8; ANS['AM-176']=('val',brentq(f,0.5,100))
f2=lambda x:4*(-1.9-3)/(x*(-1.9-3))+2/x-3/4-3/8; assert abs(brentq(f2,0.5,100)-ANS['AM-176'][1])<1e-9
# 178
fn=lambda x:9**x*12**(x+1)/8**x
L=[]
for k,t in zip('ABCD',opts('AM-178')):
    f=compile_tex(t)
    if all(abs(call(f,x=v)-fn(v))<1e-7*fn(v) for v in (-1.5,0.3,1,2,3.4)):
        # must also DISPLAY f(2) as the coefficient: exponent is x-2 and coefficient equals f(2)
        sh=re.search(r'\^\{x([+-]\d+)\}',t); cf=compile_tex(t.split('\\left')[0])()
        if sh and int(sh.group(1))==-2 and abs(cf-fn(2))<1e-9: L.append(k)
ANS['AM-178']=('mc',L); ANS['AM-178_f2']=fn(2)
# 182
ks=set(); 
for a_,b_,c_,d_ in itertools.product(range(-30,31),repeat=4):
    if a_*c_==6 and b_*d_==5: ks.add(a_*d_+b_*c_)
I=all(k%2!=0 for k in ks); II=all(k%4==1 for k in ks); III=all(k%5!=0 for k in ks)
opt182={'A':(False,True,True),'B':(True,True,True),'C':(True,False,False),'D':(True,False,True)}
ANS['AM-182']=('mc',[k for k,v in opt182.items() if v==(I,II,III)]); ANS['AM-182_ks']=sorted(ks)

# ---------------- compare with item answers (bank / fixed)
def parse_val(s):
    s=s.split('(or')[0]
    s=s.replace('$','').replace('\\dfrac','\\frac').strip()
    m=re.match(r'^(-?)\\frac\{(-?\d+)\}\{(\d+)\}$',s)
    if m: return (-1 if m.group(1) else 1)*int(m.group(2))/int(m.group(3))
    s=s.replace('{,}','').replace(',','')
    if '/' in s: return float(Fr(s))
    return float(s)
bad=0; seen=0; COMP={}
for o in items:
    i=o['id']; kind=ANS[i]; mc=o['fmt']=='Multiple Choice'
    if mc:
        m=re.match(r'^\(?([A-D])',o['ans'].strip()); L=m.group(1); op=opts(i)
        if kind[0]=='mc': got=kind[1]
        elif kind[0]=='val':
            got=[k for k,t in zip('ABCD',op) if abs(call(compile_tex(t))-kind[1])<1e-6*max(1,abs(kind[1]))]
        elif kind[0]=='mc_val':
            tgt=kind[1]; mp=kind[2]; got=[k for k,v in mp.items() if (isinstance(v,str) and v==tgt) or (not isinstance(v,str) and not isinstance(tgt,str) and abs(v-tgt)<1e-6*max(1,abs(v)))]
        else: raise Exception(i)
        if i=='AM-266' or True: pass
        COMP[i]=got[0] if len(got)==1 else None
        ok=(got==[L]); 
        if not ok: bad+=1; print('MISMATCH',i,'mine',got,'bank',L)
        # mc_val option texts must correspond to value map (check option text numerically where numeric)
        if kind[0]=='mc_val':
            for k,t in zip('ABCD',op):
                v=kind[2][k]
                if isinstance(v,str): continue
                try:
                    tv=call(compile_tex(t)) if not compile_tex(t).names else None
                except Exception as e: tv=None
                if tv is not None and abs(tv-v)>1e-6*max(1,abs(v)): bad+=1; print('OPTTEXT MISMATCH',i,k,t,v,tv)
        # the 'A..D' polynomial options of 266 vs text
    else:
        got=kind[1]; want=parse_val(o['ans']); COMP[i]=got
        ok=abs(got-want)<1e-6*max(1,abs(want)); 
        if not ok: bad+=1; print('MISMATCH',i,'mine',got,'bank',want)
    seen+=1
# 266 option text check against my coefficient lists
for k,t in zip('ABCD',opts('AM-266')): print('266',k,t,OP266[k])
print('items',seen,'mismatches',bad)
print('100 candidates before fix',ANS['AM-100_orig_cands']); print('182 k set',ANS['AM-182_ks']); print('178 f(2)',ANS['AM-178_f2'])
json.dump(COMP,open('computed.json','w'))
json.dump({k:v for k,v in ANS.items() if not k.endswith(('_orig_cands','_ks','_f2'))},open('mine.json','w'),default=str)
