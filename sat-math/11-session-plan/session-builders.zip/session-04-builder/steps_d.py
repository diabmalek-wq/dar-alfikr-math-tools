"""Desmos-first solutions for Session 4: every problem gets 3-4 numbered steps with typed Desmos expressions.
Every 'it returns' value is computed by ev(); every tapped point is checked by a residual; FIN holds the claimed final answer for verification."""
import math, numpy as np
from steps import *
import steps as _s
S, T, ENV, CLAIMS = _s.S, _s.T, _s.ENV, _s.CLAIMS
FIN = {}
def R(iid, e, d=4): return ret(e, d, **ENV.get(iid, {}))
def RL(iid, e):
    arr = np.atleast_1d(ev(e, **ENV.get(iid, {})))
    return "Type %s: it returns $%s$" % (c(e), ',\\,'.join(n(x) for x in arr))
def low(s): return s[0].lower() + s[1:]
def tap(iid, x, y, *res):
    xr, yr = round(x, 4), round(y, 4)
    for r in res: assert abs(r(xr, yr)) < 3e-3, (iid, xr, yr, r(xr, yr))
    CLAIMS.append(('%s tap (%s,%s)' % (iid, n(xr), n(yr)), lambda res=res, xr=xr, yr=yr: all(abs(r(xr, yr)) < 3e-3 for r in res)))
    return pt(x, y)
PTS = [{'x': v} for v in (2.5, 3.7, 6.1, 8.3)]
def eqv(iid, orig, good, bad, x0, last, extra_env=None):
    env = dict(f=lambda x: ev(orig, x=x), g=lambda x: ev(good, x=x), h=lambda x: ev(bad, x=x)); ENV[iid] = env
    for p_ in PTS: assert abs(env['f'](p_['x']) - env['g'](p_['x'])) < 1e-9 * max(1, abs(env['f'](p_['x']))), (iid, p_)
    fx, gx, hx = env['f'](x0), env['g'](x0), env['h'](x0); assert abs(fx - gx) < 1e-9 and abs(fx - hx) > 1e-3
    CLAIMS.append(('%s equivalence' % iid, lambda: all(abs(env['f'](p_['x']) - env['g'](p_['x'])) < 1e-9 * max(1, abs(env['f'](p_['x']))) for p_ in PTS) and abs(env['h'](x0) - env['f'](x0)) > 1e-3))
    FIN[iid] = ('fn', lambda x, env=env: env['g'](x), PTS)
    S[iid] = ["Type the expression from the question as %s." % c('f(x)=' + orig),
              "Type the options as their own functions. Only %s lies exactly on the graph of $f$ (one curve); a wrong option such as %s leaves it." % (c('g(x)=' + good), c('h(x)=' + bad)),
              "Check at $x=%s$: " % n(x0) + R(iid, 'f(%s)' % n(x0)) + "; " + R(iid, 'g(%s)' % n(x0)) + " (same); " + R(iid, 'h(%s)' % n(x0)) + " (different).",
              last + " Option (@@L@@)."]
    T[iid] = 'D'

# ============================================================ PART A
# 245
p_, q_ = 6, -8; f245 = lambda x, y=0: 9 * (48 / x) ** 2 - 16 * x ** 2
S['AM-245'] = ["Exactly one real solution means the discriminant $(3q)^2-4(p)(4p)$ is $0$. Put $q=-\\dfrac{48}{p}$ (from $pq=-48$) and let $x$ stand for $p$: type %s." % c('y=9(48/x)^2-16x^2'),
               "Tap the zero with $x>0$ (we need $p>0$): %s. So $p=6$." % tap('AM-245', 6, 0, lambda x, y: f245(x) - y),
               R('AM-245', '-48/6') + ", so $q=-8$.",
               R('AM-245', '6+(-8)') + ". Option (@@L@@)."]
FIN['AM-245'] = ('val', -2.0); T['AM-245'] = 'D'
# 263
S['AM-263'] = ["For $x^2-9x+k=0$ the two solutions differ by $\\sqrt{81-4k}$. Let $x$ stand for $k$: type %s and %s." % (c('y=sqrt(81-4x)'), c('y=3')),
               "Tap the intersection: %s. So $k=18$." % tap('AM-263', 18, 3, lambda x, y: math.sqrt(81 - 4 * x) - y),
               "Check: type %s and tap its zeros %s and %s." % (c('y=x^2-9x+18'), tap('AM-263', 3, 0, lambda x, y: x * x - 9 * x + 18 - y), tap('AM-263', 6, 0, lambda x, y: x * x - 9 * x + 18 - y)),
               R('AM-263', '6-3') + ": the solutions differ by $3$."]
FIN['AM-263'] = ('val', 18.0); T['AM-263'] = 'D'
# 264
r2, r3 = 2, 3
S['AM-264'] = [R('AM-264', '6*2') + ": the product of the solutions is $\\dfrac c2=6$, so $c=12$.",
               "Type %s and tap the zeros %s and %s." % (c('y=2x^2-10x+12'), tap('AM-264', 2, 0, lambda x, y: 2 * x * x - 10 * x + 12 - y), tap('AM-264', 3, 0, lambda x, y: 2 * x * x - 10 * x + 12 - y)),
               R('AM-264', '1/2+1/3') + ", which is $\\dfrac56$ (the sum of the reciprocals).",
               "Check with sum over product: " + R('AM-264', '5/6') + " (the sum of solutions is $\\dfrac{10}{2}=5$ and the product is $6$). Option (@@L@@)."]
FIN['AM-264'] = ('val', 5 / 6); T['AM-264'] = 'D'
# 265
za, zb = (7 - math.sqrt(37)) / 2, (7 + math.sqrt(37)) / 2; assert 49 - 12 == 37
S['AM-265'] = ["Type %s." % c('y=x^2-7x+3'),
               "Tap the two zeros: %s and %s. These are $r$ and $s$." % (tap('AM-265', za, 0, lambda x, y: x * x - 7 * x + 3 - y), tap('AM-265', zb, 0, lambda x, y: x * x - 7 * x + 3 - y)),
               "For exact values (discriminant $49-12=37$): " + R('AM-265', '(7-sqrt(37))/2') + " and " + low(R('AM-265', '(7+sqrt(37))/2')) + ".",
               R('AM-265', '((7-sqrt(37))/2)^2+((7+sqrt(37))/2)^2') + "."]
FIN['AM-265'] = ('val', 43.0); T['AM-265'] = 'D'
# 266
w1, w2 = sorted(np.roots([1, -10, 12]).real)
S['AM-266'] = ["Type %s and tap the zeros %s and %s: $p=2$, $q=3$." % (c('y=x^2-5x+6'), tap('AM-266', 2, 0, lambda x, y: x * x - 5 * x + 6 - y), tap('AM-266', 3, 0, lambda x, y: x * x - 5 * x + 6 - y)),
               "Doubling them: " + R('AM-266', '2*2') + " and " + low(R('AM-266', '2*3')) + ".",
               "Type the options as graphs. %s has its zeros at %s and %s, which is what we want." % (c('y=x^2-10x+24'), tap('AM-266', 4, 0, lambda x, y: x * x - 10 * x + 24 - y), tap('AM-266', 6, 0, lambda x, y: x * x - 10 * x + 24 - y)),
               "A wrong option such as %s has zeros %s and %s instead. Option (@@L@@)." % (c('y=x^2-10x+12'), tap('AM-266', w1, 0, lambda x, y: x * x - 10 * x + 12 - y), tap('AM-266', w2, 0, lambda x, y: x * x - 10 * x + 12 - y))]
FIN['AM-266'] = ('text', 'x^2-10x+24'); T['AM-266'] = 'D'
# 267
S['AM-267'] = ["Call the solutions $r$ and $3r$; their product is $3r^2=27$. Let $x$ stand for $r$: type %s and %s." % (c('y=3x^2'), c('y=27')),
               "Tap the intersection with $x>0$: %s. So $r=3$." % tap('AM-267', 3, 27, lambda x, y: 3 * x * x - y),
               R('AM-267', '3+3*3') + ", so $b=r+3r=12$.",
               "Check: type %s and tap the zeros %s and %s ($9=3\\cdot3$)." % (c('y=x^2-12x+27'), tap('AM-267', 3, 0, lambda x, y: x * x - 12 * x + 27 - y), tap('AM-267', 9, 0, lambda x, y: x * x - 12 * x + 27 - y))]
FIN['AM-267'] = ('val', 12.0); T['AM-267'] = 'D'
# 179
S['AM-179'] = [R('AM-179', '(8-2)/2') + " (subtracting $f(1)=8$ and $f(-1)=2$ gives $2b$), so $b=3$ and $c=5-a$.",
               "One $x$-intercept means the discriminant is $0$. Let $x$ stand for $a$: type %s." % c('y=3^2-4x(5-x)'),
               "Tap the zeros: %s and %s. So $a=\\dfrac12$ or $a=\\dfrac92$." % (tap('AM-179', 0.5, 0, lambda x, y: 9 - 4 * x * (5 - x) - y), tap('AM-179', 4.5, 0, lambda x, y: 9 - 4 * x * (5 - x) - y)),
               "The greatest is $a=4.5$. Check: " + R('AM-179', '3^2-4*4.5*0.5') + ", so the graph of %s only touches the $x$-axis. Option (@@L@@)." % c('y=4.5x^2+3x+0.5')]
FIN['AM-179'] = ('val', 4.5); T['AM-179'] = 'D'
# 012, 023, 024
eqv('AM-012', '3/(x-4)-2/(x+1)', '(x+11)/(x^2-3x-4)', '(x-11)/(x^2-3x-4)', 2, "Algebra behind it: the numerator is $3(x+1)-2(x-4)=x+11$ over $(x-4)(x+1)=x^2-3x-4$.")
eqv('AM-023', '5/(x+2)+3x/(x^2+x-2)', '(8x-5)/(x^2+x-2)', '(3x+5)/(x^2+x-2)', 3, "Algebra behind it: $x^2+x-2=(x+2)(x-1)$, so $\\dfrac5{x+2}=\\dfrac{5x-5}{x^2+x-2}$ and the numerators add to $8x-5$.")
eqv('AM-024', '(x+3)/(x-1)-1', '4/(x-1)', '(x+2)/(x-1)', 3, "Algebra behind it: $(x+3)-(x-1)=4$.")
# 043
S['AM-043'] = ["Type %s (accept the slider for $a$) and set $a=3$." % c('f(x)=a(x-2)(x+6)'),
               "Tap the vertex: %s. Its $y$-value is $k$ for $a=3$." % tap('AM-043', -2, -48, lambda x, y: 3 * (x - 2) * (x + 6) - y),
               R('AM-043', '-48/3') + ", so $k=-16a$ (and the vertex is at $h=-2$).",
               "Check with $a=-2$: " + R('AM-043', '-2*(-2-2)*(-2+6)') + " is the vertex height, and " + low(R('AM-043', '-16*(-2)')) + " agrees. Option (@@L@@)."]
FIN['AM-043'] = ('fn', lambda a: -16 * a, [{'a': v} for v in (0.5, 2.3, -3.1)]); T['AM-043'] = 'D'
# 058
eqv('AM-058', 'x^4-2x^2-15', '(x^2-5)(x^2+3)', '(x^2+5)(x^2-3)', 2, "Algebra behind it: with $u=x^2$, $u^2-2u-15=(u-5)(u+3)$.")
# 081
S['AM-081'] = ["Equal powers of $x>1$ have equal exponents, so $a^2-b^2=20$, and $a^2-b^2=(a+b)(a-b)=4(a-b)$. Let $x$ stand for $a-b$: type %s and %s." % (c('y=4x'), c('y=20')),
               "Tap the intersection: %s. So $a-b=5$." % tap('AM-081', 5, 20, lambda x, y: 4 * x - y),
               "Check: " + R('AM-081', '(4+5)/2') + " is $a$, and " + low(R('AM-081', '(4-5)/2')) + " is $b$.",
               R('AM-081', '4.5^2-(-0.5)^2') + ", as required."]
FIN['AM-081'] = ('val', 5.0); T['AM-081'] = 'D'
# 089
S['AM-089'] = ["Type %s and %s." % (c('y=sqrt(x)'), c('y=x*sqrt(x)')),
               "Tap the intersections: %s and %s. Only $x=1$ has $x>0$." % (tap('AM-089', 0, 0, lambda x, y: math.sqrt(x) - y), tap('AM-089', 1, 1, lambda x, y: math.sqrt(x) - y, lambda x, y: x * math.sqrt(x) - y)),
               "Check the other two expressions at $x=1$: " + R('AM-089', '1^2') + " and " + low(R('AM-089', 'sqrt(1^2)')) + ".",
               "All four expressions equal $1$ at $x=1$, so $x=1$."]
FIN['AM-089'] = ('val', 1.0); T['AM-089'] = 'N'
# 090
S['AM-090'] = ["Test with $u=16$. From $t^{1/3}=u^{-1/2}$: " + R('AM-090', '(16^(-1/2))^3') + ", which is $t$.",
               "Then $s^2=\\dfrac1t$: " + R('AM-090', 'sqrt(1/((16^(-1/2))^3))') + ", so $s=8$.",
               "Try the options at $u=16$: " + R('AM-090', '16^(3/4)') + " matches, while " + low(R('AM-090', '16^(-3/4)')) + " does not.",
               "Also " + R('AM-090', '16^(1/2)') + " is not $8$. So $s=u^{3/4}$. Option (@@L@@)."]
FIN['AM-090'] = ('fn', lambda u: u ** 0.75, [{'u': v} for v in (2, 5, 9)]); T['AM-090'] = 'D'
# 097
eqv('AM-097', '(3x+1)/(x-2)-3', '7/(x-2)', '(6x-5)/(x-2)', 3, "Algebra behind it: $(3x+1)-3(x-2)=7$.")
# 098
S['AM-098'] = ["Test with $b=16$. From $a^4=b^3$: " + R('AM-098', '(16^3)^(1/4)') + ", so $a=8$.",
               "Then $a\\sqrt b$: " + R('AM-098', '8*sqrt(16)') + ".",
               "Try the options at $b=16$: " + R('AM-098', '16^(5/4)') + " matches.",
               "A wrong option such as " + low(R('AM-098', '16^(4/3)')) + " does not. Option (@@L@@)."]
FIN['AM-098'] = ('fn', lambda b: b ** 1.25, [{'b': v} for v in (2.5, 7, 16)]); T['AM-098'] = 'D'
# 106
S['AM-106'] = ["Type the expression with $x=2$ and $y=5$: " + R('AM-106', '(3*2/5)*(2^(-1)/(3*5)^(-1))') + ".",
               "Try other values, $x=4$ and $y=7$: " + R('AM-106', '(3*4/7)*(4^(-1)/(3*7)^(-1))') + ".",
               "The value does not depend on $x$ or $y$; in general " + R('AM-106', '(3*2/5)*(3*5/2)') + " (the negative exponents flip to $\\dfrac{3y}{x}$).",
               "The value is always $9$. Option (@@L@@)."]
FIN['AM-106'] = ('val', 9.0); T['AM-106'] = 'D'
# 109
ENV['AM-109'] = dict(c=9)
S['AM-109'] = ["Type %s." % c('c=9'),
               "Type the expression: " + R('AM-109', 'sqrt(c+7)/c*c*sqrt(c)') + ".",
               "Check by cancelling $c$: " + R('AM-109', 'sqrt(c+7)*sqrt(c)') + ".",
               "By hand: " + R('AM-109', 'sqrt(16)*3') + "."]
FIN['AM-109'] = ('val', 12.0); T['AM-109'] = 'N'
# 110
ENV['AM-110'] = dict(a=-3)
S['AM-110'] = ["Type %s." % c('a=-3'),
               "Type the bracket: " + R('AM-110', '5/a^2+4/(3a)') + ", which is $\\dfrac19$.",
               "Type the whole expression: " + R('AM-110', '(5/a^2+4/(3a))^a') + ".",
               "Check by hand: " + R('AM-110', '9^3') + " (a negative exponent flips $\\dfrac19$ to $9$)."]
FIN['AM-110'] = ('val', 729.0); T['AM-110'] = 'D'
# 115
ENV['AM-115'] = dict(f=lambda x: (x * x - 2 * x - 15) / (x * x + x - 6), g=lambda x: (x - 5) / (x - 2))
S['AM-115'] = ["Type %s and %s." % (c('f(x)=(x^2-2x-15)/(x^2+x-6)'), c('g(x)=(x-5)/(x-2)')),
               "The two graphs lie on top of each other (apart from the hole at $x=-3$), so $a=-5$ and $b=-2$.",
               "Check at $x=4$: " + R('AM-115', 'f(4)') + " and " + low(R('AM-115', 'g(4)')) + ".",
               R('AM-115', '-5-(-2)') + "."]
CLAIMS.append(('115 graphs agree', lambda: all(abs(ENV['AM-115']['f'](x) - ENV['AM-115']['g'](x)) < 1e-9 for x in (4, 5.5, -7, 0.3))))
FIN['AM-115'] = ('val', -3.0); T['AM-115'] = 'D'
# 118
ENV['AM-118'] = dict(a=5 ** (4 / 3))
S['AM-118'] = ["Solve for $a$: " + R('AM-118', '5^(4/3)') + ". Type %s." % c('a=5^(4/3)'),
               "Check the condition: " + R('AM-118', 'a^(3/4)') + ".",
               "Now the asked value: " + R('AM-118', 'a^(-3/2)') + ".",
               "As a fraction: " + R('AM-118', '1/25') + ", so the answer is $\\dfrac1{25}$."]
FIN['AM-118'] = ('val', 0.04); T['AM-118'] = 'D'
# 127
S['AM-127'] = ["Take $b=1$: the equation becomes $a^2+1=4a$. Type %s." % c('y=x^2-4x+1'),
               "Tap the zeros: %s and %s, which are $a=2\\pm\\sqrt3$." % (tap('AM-127', 2 - math.sqrt(3), 0, lambda x, y: x * x - 4 * x + 1 - y), tap('AM-127', 2 + math.sqrt(3), 0, lambda x, y: x * x - 4 * x + 1 - y)),
               "Evaluate $\\dfrac{a+b}{a-b}$ for each: " + R('AM-127', '(2+sqrt(3)+1)/(2+sqrt(3)-1)') + ", and " + low(R('AM-127', '(2-sqrt(3)+1)/(2-sqrt(3)-1)')) + ".",
               "Compare " + R('AM-127', 'sqrt(3)') + ": the values are $\\pm\\sqrt3$. Option (@@L@@)."]
FIN['AM-127'] = ('text', '\\pm\\sqrt{3}'); T['AM-127'] = 'D'
# 131
ENV['AM-131'] = dict(a=3, b=-5)
S['AM-131'] = ["Type %s." % c('f(x)=3-11/(x+2)'),
               "Type %s (accept the sliders for $a$ and $b$) and slide until $g$ lies exactly on $f$: $a=3$, $b=-5$." % c('g(x)=(ax+b)/(x+2)'),
               "Check at $x=1$: " + R('AM-131', '3-11/(1+2)') + " and " + low(R('AM-131', '(a*1+b)/(1+2)')) + ".",
               R('AM-131', 'a*b') + "."]
FIN['AM-131'] = ('val', -15.0); T['AM-131'] = 'D'
# 167
f167 = lambda x: x * math.sqrt((72 - x * x) / 4)
S['AM-167'] = ["Expand $(2x+p)(x+q)=2x^2+(2q+p)x+pq$, so $c=pq$. With $q=\\sqrt{\\dfrac{72-p^2}{4}}$ and $x$ standing for $p$, type %s." % c('y=x*sqrt((72-x^2)/4)'),
               "Tap the highest point: %s. So the greatest $c$ is $18$, at $p=6$." % tap('AM-167', 6, 18, lambda x, y: f167(x) - y),
               "Check: " + R('AM-167', 'sqrt((72-6^2)/4)') + " is $q$, and " + low(R('AM-167', '6^2+4*3^2')) + " confirms $p^2+4q^2=72$.",
               R('AM-167', '6*3') + "."]
CLAIMS.append(('167 maximum', lambda: max(f167(v) for v in np.linspace(0.01, 8.48, 20001)) <= 18 + 1e-6))
FIN['AM-167'] = ('val', 18.0); T['AM-167'] = 'D'
# 170
ENV['AM-170'] = dict(f=lambda x: (2 * x - 3) * (x * x - x - 3), g=lambda x: 2 * x ** 3 - 5 * x * x - 3 * x + 9)
S['AM-170'] = ["Matching the $x^2$ terms gives $2p-3=-5$: " + R('AM-170', '(-5+3)/2') + ", so $p=-1$. Matching constants gives $-3q=9$: " + low(R('AM-170', '9/(-3)')) + ", so $q=-3$.",
               "The $x$ terms give $c=2q-3p$: " + R('AM-170', '2*(-3)-3*(-1)') + ".",
               "Check: type %s and %s; the graphs coincide." % (c('y=(2x-3)(x^2-x-3)'), c('y=2x^3-5x^2-3x+9')),
               "At $x=2$: " + R('AM-170', 'f(2)') + " and " + low(R('AM-170', 'g(2)')) + "."]
CLAIMS.append(('170 identity', lambda: all(abs(ENV['AM-170']['f'](x) - ENV['AM-170']['g'](x)) < 1e-9 for x in (-2, 0.5, 2, 3.3))))
FIN['AM-170'] = ('val', -3.0); T['AM-170'] = 'D'
# 172
g172 = lambda x: x ** (1 / 3) * x ** (3 / 4) / x ** (1 / 6)
S['AM-172'] = ["Type %s and %s ($k^{1/3}=(2^{11})^{1/3}$)." % (c('y=x^(1/3)*x^(3/4)/x^(1/6)'), c('y=(2^11)^(1/3)')),
               "Tap the intersection: %s. So $x=16$." % tap('AM-172', 16, 2 ** (11 / 3), lambda x, y: g172(x) - y),
               "Check: " + R('AM-172', '16^(1/3)*16^(3/4)/16^(1/6)') + " and " + low(R('AM-172', '(2^11)^(1/3)')) + ".",
               R('AM-172', '2^4') + ". Option (@@L@@)."]
FIN['AM-172'] = ('val', 16.0); T['AM-172'] = 'D'
# 175
ENV['AM-175'] = dict(x=2, n=1)
E175 = '((x^(2n+1))^3+4x^(6n+3)-2x(x^(3n+1))^2)/x^(6n+1)'
S['AM-175'] = ["Test with numbers: type %s and %s." % (c('x=2'), c('n=1')),
               "Type the expression: " + R('AM-175', E175) + ".",
               "Try the options: " + R('AM-175', '3x^2') + " matches, while " + low(R('AM-175', '5x^2')) + " and " + low(R('AM-175', '3x^4')) + " do not.",
               "Repeat with $x=2$, $n=2$ if you like: the match with $3x^2$ stays. Option (@@L@@)."]
S['AM-175'][3] = "Repeat with $n=2$ (type %s): " % c('n=2') + R('AM-175', '3x^2') + " is still the value of the expression: " + low(ret(E175, 4, x=2, n=2)) + ". Option (@@L@@)."
FIN['AM-175'] = ('fn', lambda x, n: 3 * x ** 2, [{'x': 1.3, 'n': 1}, {'x': 1.1, 'n': 2}, {'x': 1.2, 'n': 3}]); T['AM-175'] = 'D'
# 176
ENV['AM-176'] = dict(k=7)
f176 = lambda x, k=7: 4 * (k - 3) / (x * (k - 3)) + 2 / x - 3 / 4
S['AM-176'] = ["Type %s (any $k\\ne3$ works), then %s and %s." % (c('k=7'), c('y=4(k-3)/(x(k-3))+2/x-3/4'), c('y=3/8')),
               "Tap the intersection: %s." % tap('AM-176', 16 / 3, 3 / 8, lambda x, y: f176(x) - y),
               "As a fraction: " + R('AM-176', '16/3') + ", so $x=\\dfrac{16}3$.",
               "Check with another $k$, say $k=-2$: " + ret('4(-2-3)/((16/3)(-2-3))+2/(16/3)-3/4', 4) + "."]
FIN['AM-176'] = ('val', 16 / 3); T['AM-176'] = 'D'
# 178
ENV['AM-178'] = dict(f=lambda x: 9 ** x * 12 ** (x + 1) / 8 ** x, g=lambda x: 2187 * 13.5 ** (x - 2), h=lambda x: 729 / 4 * 13.5 ** (x - 2))
S['AM-178'] = ["Type %s and %s." % (c('f(x)=9^x*12^(x+1)/8^x'), c('g(x)=2187(27/2)^(x-2)')),
               "The graphs coincide. Check: " + R('AM-178', 'f(2)') + " and " + low(R('AM-178', 'g(3)')) + " (the same as " + low(R('AM-178', 'f(3)')) + ").",
               "So $g$ shows $f(2)=2187$ as its coefficient (exponent $x-2$).",
               "A wrong option such as %s gives " % c('h(x)=729/4*(27/2)^(x-2)') + low(R('AM-178', 'h(2)')) + ", not $f(2)$. Also " + low(R('AM-178', 'f(1)')) + " is the coefficient of $162\\left(\\frac{27}{2}\\right)^{x-1}$, which shows $f(1)$. Option (@@L@@)."]
CLAIMS.append(('178 g=f', lambda: all(abs(ENV['AM-178']['f'](x) - ENV['AM-178']['g'](x)) < 1e-7 * ENV['AM-178']['f'](x) for x in (-1.5, 0.3, 2, 3.4))))
FIN['AM-178'] = ('text', '2187\\left(\\dfrac{27}{2}\\right)^{x-2}'); T['AM-178'] = 'D'
# 182
aL = np.array([1, 2, 3, 6]); cL = 6 / aL; ENV['AM-182'] = dict(a=aL, c=cL)
assert list(5 * aL + cL) == [11, 13, 17, 31]
S['AM-182'] = ["From $ac=6$ and $bd=5$ take $b=1$, $d=5$, so $k=ad+bc=5a+c$. Type the factor pairs as lists: %s and %s." % (c('a=[1,2,3,6]'), c('c=6/a')),
               RL('AM-182', '5a+c') + ". (Other choices of $b,d$ give these or their negatives.)",
               "Remainders: " + RL('AM-182', 'mod(5a+c,4)') + " (not always $1$, so II is false) and " + low(RL('AM-182', 'mod(5a+c,5)')) + " (never $0$, so III is true).",
               "Every value is odd: " + RL('AM-182', 'mod(5a+c,2)') + ", so I is true. Statements I and III only. Option (@@L@@)."]
FIN['AM-182'] = ('text', 'I and III only'); T['AM-182'] = 'D'

# ============================================================ PART B
eqv('AM-011', '(x^2-9)/(x-3)', 'x+3', 'x-3', 5, "Algebra behind it: $x^2-9=(x-3)(x+3)$ and $(x-3)$ cancels.")
T['AM-011'] = 'N'
eqv('AM-015', '(x^2+x-12)/(x+4)', 'x-3', 'x+3', 2, "Algebra behind it: $x^2+x-12=(x+4)(x-3)$ and $(x+4)$ cancels.")
T['AM-015'] = 'N'
# 025
S['AM-025'] = ["Test with $b=32$. From $a^5=b^2$: " + R('AM-025', '(32^2)^(1/5)') + ", so $a=4$.",
               "Then $b\\sqrt a$: " + R('AM-025', '32*sqrt(4)') + ".",
               "Try the options at $b=32$: " + R('AM-025', '32^(6/5)') + " matches, while " + low(R('AM-025', '32^(9/5)')) + " does not.",
               "Also " + R('AM-025', '32^(9/4)') + " is far too large. Option (@@L@@)."]
FIN['AM-025'] = ('fn', lambda b: b ** 1.2, [{'b': v} for v in (2.5, 7, 32)]); T['AM-025'] = 'D'
eqv('AM-038', '(2x^3-3x^2-11x+6)/(x-3)', '2x^2+3x-2', '2x^2-3x-2', 4, "Algebra behind it: synthetic division by $3$ leaves quotient $2x^2+3x-2$ and remainder $0$.")
eqv('AM-055', '4(2x+7)-5x', '3x+28', '13x+28', 2, "Algebra behind it: $8x+28-5x=3x+28$.")
T['AM-055'] = 'N'
eqv('AM-056', '(5x^2+3x-9)-(2x^2-7x+4)', '3x^2+10x-13', '3x^2-4x-13', 2, "Algebra behind it: subtracting the bracket changes every sign inside it.")
T['AM-056'] = 'N'
# 057
ENV['AM-057'] = dict(a=11)
S['AM-057'] = ["Type %s (accept the slider for $a$) and %s." % (c('f(x)=3x^2+ax'), c('g(x)=x(3x+11)')),
               "Slide $a$ until $f$ lies exactly on $g$: $a=11$.",
               "Check at $x=2$: " + R('AM-057', '3*2^2+a*2') + " and " + low(R('AM-057', '2*(3*2+11)')) + ".",
               "Also at $x=-1$: " + R('AM-057', '3*(-1)^2+a*(-1)') + " and " + low(R('AM-057', '-1*(3*(-1)+11)')) + ". Option (@@L@@)."]
FIN['AM-057'] = ('val', 11.0); T['AM-057'] = 'N'
# 059
ENV['AM-059'] = dict(f=lambda x: (-3 * x * x + 5 * x + 18) + (6 * x * x - 2 * x - 9))
S['AM-059'] = ["Type %s." % c('f(x)=(-3x^2+5x+18)+(6x^2-2x-9)'),
               "The value $a+b+c$ is $f(1)$: " + R('AM-059', 'f(1)') + ".",
               "Check by adding coefficients: " + R('AM-059', '-3+6') + " is $a$, " + low(R('AM-059', '5-2')) + " is $b$, " + low(R('AM-059', '18-9')) + " is $c$.",
               R('AM-059', '3+3+9') + "."]
FIN['AM-059'] = ('val', 15.0); T['AM-059'] = 'D'
eqv('AM-078', '(2x^2+8x)/(2x)', 'x+4', 'x+8', 3, "Algebra behind it: $2x^2+8x=2x(x+4)$ and $2x$ cancels.")
T['AM-078'] = 'N'
# 082
S['AM-082'] = ["Test with $x=16$: " + R('AM-082', 'sqrt(16*sqrt(16))') + ".",
               "Type %s and %s ($x$ stands for $a$)." % (c('y=16^x'), c('y=8')),
               "Tap the intersection: %s. So $a=0.75$." % tap('AM-082', 0.75, 8, lambda x, y: 16 ** x - y),
               "Exact: " + R('AM-082', 'ln(8)/ln(16)') + ", which is $\\dfrac34$."]
FIN['AM-082'] = ('val', 0.75); T['AM-082'] = 'D'
# 083
S['AM-083'] = ["$32=2^5$ and $a$ is prime, so $a=2$. Type %s and %s ($x$ stands for $b$)." % (c('y=2^(x/5)'), c('y=32')),
               "Tap the intersection: %s. So $b=25$." % tap('AM-083', 25, 32, lambda x, y: 2 ** (x / 5) - y),
               "Check: " + R('AM-083', '2^(25/5)') + ".",
               "Another prime fails: " + R('AM-083', '3^(25/5)') + " is not $32$."]
FIN['AM-083'] = ('val', 25.0); T['AM-083'] = 'D'
# 085
ENV['AM-085'] = dict(f=lambda x: (x * x - 9) * (x + 7))
S['AM-085'] = ["Type %s." % c('f(x)=(x^2-9)(x+7)'),
               "Tap the zeros: %s, %s and %s. A zero at $x=r$ means $x-r$ is a factor." % (tap('AM-085', -7, 0, lambda x, y: (x * x - 9) * (x + 7) - y), tap('AM-085', -3, 0, lambda x, y: (x * x - 9) * (x + 7) - y), tap('AM-085', 3, 0, lambda x, y: (x * x - 9) * (x + 7) - y)),
               "So the factors are $x+7$, $x+3$ and $x-3$. Check the zero $-3$: " + R('AM-085', 'f(-3)') + ".",
               "The other options' zeros are not zeros of $f$: " + R('AM-085', 'f(2)') + ", " + low(R('AM-085', 'f(4)')) + ", " + low(R('AM-085', 'f(-5)')) + ". Option (@@L@@)."]
FIN['AM-085'] = ('text', 'x+3'); T['AM-085'] = 'D'
# 095
ENV['AM-095'] = dict(m=2, n=5)
S['AM-095'] = ["Test with numbers: type %s and %s, then " % (c('m=2'), c('n=5')) + low(R('AM-095', 'm^2n^2')) + ".",
               "Triple both: " + R('AM-095', '(3m)^2(3n)^2') + ".",
               "The factor: " + R('AM-095', '8100/100') + ".",
               "Try other values, $m=1$ and $n=4$: " + ret('(3*1)^2*(3*4)^2/(1^2*4^2)', 4) + ". Option (@@L@@)."]
FIN['AM-095'] = ('val', 81.0); T['AM-095'] = 'N'
# 100
S['AM-100'] = ["Type the left side: " + R('AM-100', 'sqrt(200)+sqrt(200)') + ".",
               "Try $m=20$, $n=2$: " + R('AM-100', '20*sqrt(2)') + " (the same value).",
               "The other pair with $m>n$ is $m=10$, $n=8$: " + R('AM-100', '10*sqrt(8)') + ", but $8$ is divisible by $4$, so it is not allowed.",
               "Check squares: " + R('AM-100', '20^2*2') + " and " + low(R('AM-100', '(2*sqrt(200))^2')) + ". So $m=20$."]
FIN['AM-100'] = ('val', 20.0); T['AM-100'] = 'D'
# 103
S['AM-103'] = ["Write $y-5=k(x+3)$. With $y=7$, $x=1$: " + R('AM-103', '(7-5)/(1+3)') + ", so $k=0.5$.",
               "Type %s and %s." % (c('y=0.5(x+3)+5'), c('y=19')),
               "Tap the intersection: %s. So $x=25$." % tap('AM-103', 25, 19, lambda x, y: 0.5 * (x + 3) + 5 - y),
               "Check: " + R('AM-103', '0.5*(25+3)+5') + "."]
FIN['AM-103'] = ('val', 25.0); T['AM-103'] = 'D'
# 117
eqv('AM-117', 'sqrt((9x^2)^3*x^6)', '27x^6', '81x^6', 1.5, "Algebra behind it: $(9x^2)^3x^6=729x^{12}$ and $\\sqrt{729x^{12}}=27x^6$.")
# 119
S['AM-119'] = ["Type %s and %s ($q^{-3}=\\left(\\dfrac14\\right)^{-3}=64$), with $x$ standing for $p$." % (c('y=sqrt(x)^6'), c('y=(1/4)^(-3)')),
               "Tap the intersection: %s. So $p=4$." % tap('AM-119', 4, 64, lambda x, y: math.sqrt(x) ** 6 - y),
               "Check: " + R('AM-119', 'sqrt(4)^6') + " and " + low(R('AM-119', '(1/4)^(-3)')) + ".",
               "Also $\\left(\\sqrt p\\right)^6=p^3$: " + R('AM-119', '4^3') + "."]
FIN['AM-119'] = ('val', 4.0); T['AM-119'] = 'D'
# 135
ENV['AM-135'] = dict(f=lambda x: (x ** 7) ** (1 / 3) / math.sqrt(x), g=lambda x: x ** (11 / 6))
S['AM-135'] = ["Type %s and %s." % (c('f(x)=(x^7)^(1/3)/sqrt(x)'), c('g(x)=x^(11/6)')),
               "The graphs coincide. Check at $x=2$: " + R('AM-135', 'f(2)') + " and " + low(R('AM-135', 'g(2)')) + ".",
               "The exponent: " + R('AM-135', '7/3-1/2') + ", which is $\\dfrac{11}{6}$.",
               "Compare " + R('AM-135', '11/6') + ". The fraction $\\dfrac{11}{6}$ has no common factor."]
CLAIMS.append(('135 graphs agree', lambda: all(abs(ENV['AM-135']['f'](x) - ENV['AM-135']['g'](x)) < 1e-9 for x in (1.5, 2, 3.7))))
FIN['AM-135'] = ('val', 11 / 6); T['AM-135'] = 'D'
# 137
xr = (5 + math.sqrt(21)) / 2
S['AM-137'] = ["Type %s and %s." % (c('y=x+1/x'), c('y=5')),
               "Tap an intersection: %s." % tap('AM-137', xr, 5, lambda x, y: x + 1 / x - y),
               "Exact value (discriminant $25-4=21$): " + R('AM-137', '(5+sqrt(21))/2') + ".",
               R('AM-137', '((5+sqrt(21))/2)^2+1/((5+sqrt(21))/2)^2') + "."]
FIN['AM-137'] = ('val', 23.0); T['AM-137'] = 'N'
# 139
ENV['AM-139'] = dict(f=lambda x: 2 / (x - 2) + 3 / (x + 5), g=lambda x: (5 * x + 4) / ((x - 2) * (x + 5)))
S['AM-139'] = ["Type %s and %s ($r=5$, $t=4$ after combining over $(x-2)(x+5)$)." % (c('f(x)=2/(x-2)+3/(x+5)'), c('g(x)=(5x+4)/((x-2)(x+5))')),
               "The graphs coincide. Check at $x=1$: " + R('AM-139', 'f(1)') + " and " + low(R('AM-139', 'g(1)')) + ".",
               "The numerator: " + R('AM-139', '2*(1+5)+3*(1-2)') + " at $x=1$, which equals $5(1)+4$: " + low(R('AM-139', '5*1+4')) + ".",
               R('AM-139', '5*4') + ". Option (@@L@@)."]
CLAIMS.append(('139 graphs agree', lambda: all(abs(ENV['AM-139']['f'](x) - ENV['AM-139']['g'](x)) < 1e-9 for x in (1, 3.3, -1, 7))))
FIN['AM-139'] = ('val', 20.0); T['AM-139'] = 'D'
# 143
ENV['AM-143'] = dict(f=lambda x: ((x * x) ** (1 / 3)) ** 5 / x ** 2, g=lambda x: x ** (4 / 3))
S['AM-143'] = ["Type %s and %s." % (c('f(x)=((x^2)^(1/3))^5/x^2'), c('g(x)=x^(4/3)')),
               "The graphs coincide. Check at $x=8$: " + R('AM-143', 'f(8)') + " and " + low(R('AM-143', 'g(8)')) + ".",
               "The exponent: " + R('AM-143', '2/3*5-2') + ", which is $\\dfrac43$.",
               "Compare " + R('AM-143', '4/3') + ". The fraction $\\dfrac43$ has no common factor."]
CLAIMS.append(('143 graphs agree', lambda: all(abs(ENV['AM-143']['f'](x) - ENV['AM-143']['g'](x)) < 1e-9 for x in (1.5, 8, 3.7))))
FIN['AM-143'] = ('val', 4 / 3); T['AM-143'] = 'D'
# existing Desmos items from steps.py: final answers
FIN['AM-268'] = ('val', 6.0); FIN['AM-269'] = ('text', 'Zero'); FIN['AM-133'] = ('val', 5.6)
FIN['AM-149'] = ('fn', lambda x: ENV['AM-149']['g'](x), [{'x': v} for v in (6.3, 7.7, 9.5, 12)])
FIN['AM-111'] = ('text', 'p=-\\dfrac13$ or $p=-3')
