import re,json,csv
B=open('/home/claude/repo-check2/sat-bank/verified-item-bank/SAT_Bank_Verified_Item_Bank.md').read()
blocks=re.split(r'^### ',B,flags=re.M)
bank={}
for b in blocks[1:]:
    iid=b.split('\n')[0].strip()
    bank[iid]=b
rows=[r for r in csv.DictReader(open('/home/claude/cb/session_plan_11.csv')) if r['session']=='4']
out=[]
for r in rows:
    b=bank[r['id']]
    g=lambda k:(re.search(r'\*\*'+k+r':\*\*\s*(.*?)(?=\n\*\*|\Z)',b,re.S) or [None,''])[1].strip()
    q=g('Question'); 
    ans=g('Correct Answer'); rat=g('Rationale \\(worked solution\\)'); fmt=g('Format'); tool=g('Tool')
    q=re.sub(r'\n\n(?=\(?[A-D]\))','\n',q)
    out.append(dict(id=r['id'],part=r['part'],d=r['difficulty'],fmt=fmt,tool_bank=tool,q=q,ans=ans,rat=rat,skill=r['skill']))
json.dump(out,open('raw_items.json','w'),indent=1)
print(len(out))
