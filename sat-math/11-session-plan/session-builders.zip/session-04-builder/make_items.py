"""Builds s4_items.json from the bank extract (raw_items.json): neutral context + the fixes/changes listed in CHANGES."""
import json,re
raw=json.load(open('raw_items.json'))
CHANGES={}
def setq(i,q,ans,why): CHANGES[i]=(q,ans,why)
# --- FIX: ambiguous item (bank answer unique only with extra condition)
setq('AM-100',"In the equation $\\sqrt{200}+\\sqrt{200}=m\\sqrt{n}$, $m$ and $n$ are integers such that $m > n$ and $n$ is not divisible by the square of any integer greater than $1$. What is the value of $m$?",None,'FIX ambiguous: m=10,n=8 and m=20,n=2 both satisfy m>n')
# --- near-duplicate replacements (same trick as an earlier item in this session)
setq('AM-015',"Which of the following is equivalent to $\\dfrac{x^{2}+x-12}{x+4}$, for $x \\neq {-4}$?\nA) $x-3$\nB) $x+3$\nC) $x-4$\nD) $x^{2}-3$","A",'near-duplicate of AM-011 (difference of squares over a linear factor)')
setq('AM-023',"The expression $\\dfrac{5}{x+2} + \\dfrac{3x}{x^{2}+x-2}$ is equivalent to which of the following, for $x \\neq {-2}$ and $x \\neq 1$?\nA) $\\dfrac{3x+5}{x^{2}+x-2}$\nB) $\\dfrac{8x+5}{x^{2}+x-2}$\nC) $\\dfrac{8x-5}{x^{2}+x-2}$\nD) $\\dfrac{8x-5}{x^{2}-x-2}$","C",'near-duplicate of AM-012 (combine two simple fractions)')
setq('AM-025',"If $a$ and $b$ are positive numbers such that $a^{5} = b^{2}$, which of the following is equivalent to $b\\sqrt{a}$?\nA) $b^{1/5}$\nB) $b^{9/5}$\nC) $b^{6/5}$\nD) $b^{9/4}$","C",'near-duplicate of AM-098 (a^m=b^n, rewrite a product in powers of b)')
setq('AM-097',"Let $\\langle x \\rangle$ be defined by $\\langle x \\rangle = \\dfrac{3x+1}{x-2}$ for any $x$ such that $x \\neq 2$. Which of the following is equivalent to $\\langle x \\rangle - 3$?\n(A) $\\dfrac{3x-2}{x-2}$\n(B) $\\dfrac{7}{x-2}$\n(C) $\\dfrac{6x-5}{x-2}$\n(D) $\\dfrac{7}{x-2}-3$","B",'near-duplicate of AM-024 (subtract a constant from a rational function)')
setq('AM-143',"$\\dfrac{\\left(\\sqrt[3]{x^{2}}\\right)^{5}}{x^{2}}=x^{a/b}$ for $x>1$, where $a$ and $b$ are positive integers with no common factor. What is the value of $\\dfrac ab$?","$\\dfrac{4}{3}$",'near-duplicate of AM-135 (fractional-exponent radical quotient)')
CLEAN=[("An urban planner in Dammam models","An urban planner models")]
out=[]
for o in raw:
    q=o['q']
    for a,b in CLEAN: q=q.replace(a,b)
    ans=o['ans']; note=''
    if o['id'] in CHANGES:
        nq,na,note=CHANGES[o['id']]; q=nq
        if na is not None: ans=na
    if o['id']=='AM-057': note='context: removed place name'
    out.append(dict(id=o['id'],part=o['part'],d=o['d'],fmt=o['fmt'],q=q,ans=ans,rat=o['rat'],note=note,bank_ans=o['ans']))
json.dump(out,open('s4_items.json','w'),indent=1)
bad=re.compile(r'SAR|Riyadh|Jeddah|NEOM|Dammam|Makkah|Madinah|Saudi|riyal|Al-|Khobar|Tabuk|Abha|Arab|Ahmed|Mohammed|Fahad|Khalid|Sara|Noura|Omar|Ali\b|Aisha',re.I)
for o in out:
    if bad.search(o['q']): print('CONTEXT HIT',o['id'],bad.search(o['q']).group())
print(len(out),[o['id'] for o in out if o['note']])
