"""Tiny LaTeX-subset -> python-callable converter (floats), used only to test option text against independently computed truth."""
import re, math
def _tokens(s):
    s=s.replace('\\dfrac','\\frac').replace('\\left','').replace('\\right','').replace('\\,','').replace('\\ ','').replace('$','')
    s=s.replace('\\cdot','*').replace('\\pm','±')
    t=[];i=0
    while i<len(s):
        ch=s[i]
        if ch.isspace(): i+=1
        elif ch=='\\':
            m=re.match(r'\\[a-zA-Z]+',s[i:]); t.append(m.group()); i+=len(m.group())
        elif ch.isdigit() or ch=='.':
            m=re.match(r'\d+(\.\d+)?',s[i:]); t.append(m.group()); i+=len(m.group())
        else: t.append(ch); i+=1
    return t
class P:
    def __init__(s,text): s.t=_tokens(text); s.i=0
    def pk(s): return s.t[s.i] if s.i<len(s.t) else None
    def nx(s): v=s.t[s.i]; s.i+=1; return v
    def expect(s,x): v=s.nx(); assert v==x,(v,x,s.t)
    def arg(s):
        if s.pk()=='{': s.nx(); e=s.expr(); s.expect('}'); return e
        tk=s.nx()
        if tk[0].isdigit() and len(tk)>1: s.t.insert(s.i,tk[1:]); tk=tk[0]
        return tk
    def expr(s):
        v=s.term()
        while s.pk() in ('+','-'):
            op=s.nx(); r=s.term(); v='(%s%s%s)'%(v,op,r)
        return v
    def term(s):
        v=s.unary()
        while True:
            p=s.pk()
            if p in ('*',): s.nx(); v='(%s*%s)'%(v,s.unary())
            elif p=='/': s.nx(); v='(%s/%s)'%(v,s.unary())
            elif p is not None and (p[0].isdigit() or p[0].isalpha() or p in ('(','{','|') or p in ('\\frac','\\sqrt','\\langle')) and p not in (')','}'):
                if p=='|' : break
                v='(%s*%s)'%(v,s.power())
            else: break
        return v
    def unary(s):
        if s.pk()=='-': s.nx(); return '(-%s)'%s.unary()
        if s.pk()=='+': s.nx(); return s.unary()
        return s.power()
    def power(s):
        b=s.atom()
        while s.pk()=='^':
            s.nx()
            if s.pk()=='{': s.nx(); e=s.expr(); s.expect('}')
            else: e=s.atom()
            b='(%s**%s)'%(b,e)
        return b
    def atom(s):
        p=s.nx()
        if p=='\\frac':
            a=s.arg(); b=s.arg(); return '(%s/%s)'%(a,b)
        if p=='\\sqrt':
            n='2'
            if s.pk()=='[': s.nx(); n=s.expr(); s.expect(']')
            s.expect('{'); a=s.expr(); s.expect('}'); return '(%s**(1/%s))'%(a,n)
        if p=='(': e=s.expr(); s.expect(')'); return e
        if p=='{': e=s.expr(); s.expect('}'); return e
        if p=='|': e=s.expr(); s.expect('|'); return 'abs(%s)'%e
        if p[0].isdigit(): return p
        if p[0].isalpha(): return p
        raise ValueError((p,s.t))
def compile_tex(text):
    p=P(text); e=p.expr(); assert p.i==len(p.t),(text,p.t[p.i:])
    names=sorted(set(re.findall(r'[A-Za-z_]\w*',e))-{'abs'})
    f=eval('lambda %s: %s'%(','.join(names),e))
    f.names=names; f.src=e; return f
def call(f,**kw): return f(**{k:kw[k] for k in f.names})
if __name__=='__main__':
    f=compile_tex(r'\dfrac{x+11}{x^{2}-3x-4}'); print(call(f,x=2.0), 13/(4-6-4))
    f=compile_tex(r'2^{\frac{121}{36}}'); print(f(), 2**(121/36))
    f=compile_tex(r'\left(9x^{2}\right)^{3}'); print(call(f,x=1.0))
    f=compile_tex(r'\sqrt[3]{x^7}'); print(call(f,x=8.0))
