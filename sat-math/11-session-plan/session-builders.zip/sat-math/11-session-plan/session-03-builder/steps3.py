"""Worked-solution steps for Session 3.  Every number quoted in a step is computed here from the item data;
every typed Desmos expression that 'returns' a value is evaluated by ev(); every tapped point / slider claim is recorded
(TAPS / SL) and re-evaluated independently by verify_steps.py from the typed expression strings."""
import math, re, json
from fractions import Fraction as Fr
import numpy as np
from scipy.optimize import brentq, minimize_scalar

def n(v, d=4):
    s = ('%.*f' % (d, v)).rstrip('0').rstrip('.')
    return '0' if s in ('-0', '') else s
def ev(expr, **kw):
    e = expr.replace('^', '**')
    e = re.sub(r'(\d|\))\s*(\(|[a-zA-Z])', r'\1*\2', e)
    env = dict(sqrt=math.sqrt, abs=abs, ln=math.log, **kw)
    return eval(e, {'__builtins__': {}}, env)
def c(e): return '[[%s]]' % e
def v(x, d=4): return '$%s$' % n(x, d)
def ret(e, d=4, **kw): return "Type %s: it returns %s" % (c(e), v(ev(e, **kw), d))
def pt(x, y, d=4): return "$(%s,\\,%s)$" % (n(x, d), n(y, d))

TAPS = []   # (item, [typed equations], x, y, kind, params)
SL = []     # (item, [typed equations], params, x, y)   slider claims: with these parameter values the point lies on all curves
def tap(iid, eqs, x, y, kind='on', d=4, **par):
    TAPS.append((iid, list(eqs), float(x), float(y), kind, par)); return pt(x, y, d)

def fr(x):
    x = Fr(x).limit_denominator(10**6) if not isinstance(x, Fr) else x
    if x.denominator == 1: return str(x.numerator)
    return ("-" if x < 0 else "") + "\\dfrac{%d}{%d}" % (abs(x.numerator), x.denominator)
def pa(x):
    t = fr(x)
    return '(%s)' % t if t.startswith('-') else t
def isq(x):
    x = Fr(x)
    if x < 0: return None
    a, b = math.isqrt(x.numerator), math.isqrt(x.denominator)
    return Fr(a, b) if a*a == x.numerator and b*b == x.denominator else None
def qr(a, b, cc):
    """real roots of a x^2 + b x + c (Fractions when rational, else floats), ascending; double root listed once"""
    a, b, cc = Fr(a), Fr(b), Fr(cc); d = b*b - 4*a*cc
    if d < 0: return []
    s = isq(d)
    if s is not None: return sorted({(-b - s)/(2*a), (-b + s)/(2*a)})
    return sorted([(-float(b) - math.sqrt(d))/(2*float(a)), (-float(b) + math.sqrt(d))/(2*float(a))])
def term(cf, var, first):
    cf = Fr(cf)
    if cf == 0: return ""
    sign = "-" if cf < 0 else ("" if first else "+")
    a = abs(cf); body = (fr(a) if a != 1 or var == "" else "") + var
    return sign + body
def P(cs, x="x"):
    """polynomial in x from descending coefficients, e.g. P([1,-8,12]) -> x^2-8x+12"""
    deg = len(cs) - 1; out = ""
    for i, cf in enumerate(cs):
        p = deg - i; var = "" if p == 0 else (x if p == 1 else "%s^%d" % (x, p))
        out += term(cf, var, out == "")
    return out or "0"
def fac(r, x="x"):
    r = Fr(r) if not isinstance(r, float) else r
    if isinstance(r, float): return "(%s%s%s)" % (x, "-" if r > 0 else "+", n(abs(r)))
    return "(%s)" % (x if r == 0 else "%s%s%s" % (x, "-" if r > 0 else "+", fr(abs(r))))

S = {}; TOOL = {}; V = {}
def D(*ids):
    for i in ids: TOOL[i] = 'D'

# ---------------------------------------------------------------- Part A
# AM-142
xs142 = [Fr(-5) + Fr(1, 2), Fr(-5) - Fr(1, 2)]
S['AM-142'] = ["The denominator is a perfect square: $x^2+10x+25=(x+5)^2$. So the equation says $\\dfrac{1}{(x+5)^2}=4$.",
               "Flip both sides (take the reciprocal): $(x+5)^2=\\dfrac{1}{4}$.",
               "Take the square root of both sides: $x+5=\\pm%s$, so $x+5$ could be $%s$ or $%s$." % (fr(Fr(1, 2)), fr(Fr(1, 2)), fr(Fr(-1, 2))),
               "Only $%s$ is listed, so the answer is (@@L@@). Careful: solving for $x$ gives $%s$ or $%s$, but the question asks for $x+5$." % (fr(Fr(1, 2)), fr(xs142[0]), fr(xs142[1]))]
V['AM-142'] = 0.5

# AM-007  y=x^2-6x+8, y=2x-4
B7, C7 = -6 - 2, 8 + 4; r7 = qr(1, B7, C7)
S['AM-007'] = ["Set the two expressions equal: $x^2-6x+8=2x-4$.",
               "Move everything to the left side: $%s=0$." % P([1, B7, C7]),
               "Factor: $%s%s=0$, so the two points have $x=%s$ and $x=%s$." % (fac(r7[0]), fac(r7[1]), fr(r7[0]), fr(r7[1])),
               "The sum is $%s+%s=%s$. (Shortcut: the roots of $x^2+bx+c=0$ always add up to $-b$, and here $-(%s)=%s$.)" % (fr(r7[0]), fr(r7[1]), fr(sum(r7)), B7, -B7)]
V['AM-007'] = float(sum(r7))

# AM-014 (product)  y=x^2-4x-5, y=3x+1
B14, C14 = -4 - 3, -5 - 1; r14 = (-B14 + math.sqrt(B14**2 - 4*C14))/2, (-B14 - math.sqrt(B14**2 - 4*C14))/2
S['AM-014'] = ["Set the two expressions equal: $x^2-4x-5=3x+1$.",
               "Move everything to the left side: $%s=0$. This does not factor nicely, and it does not need to.",
               "For $x^2+bx+c=0$ the roots multiply to $c$ (Vieta's formulas). Here the roots multiply to $%s$." % C14,
               "Check: the roots are $\\dfrac{7\\pm\\sqrt{%d}}{2}$, and their product is $\\dfrac{49-%d}{4}=%s$." % (B14**2 - 4*C14, B14**2 - 4*C14, fr(Fr(B14**2 - (B14**2 - 4*C14), 4)))]
S['AM-014'][1] = S['AM-014'][1] % P([1, B14, C14])
assert abs(r14[0]*r14[1] - C14) < 1e-9
V['AM-014'] = C14

# AM-022  y=x^2-x-14, y=2x-4 -> positive difference
B22, C22 = -1 - 2, -14 + 4; r22 = qr(1, B22, C22)
S['AM-022'] = ["Set the two expressions equal: $x^2-x-14=2x-4$.",
               "Move everything to the left side: $%s=0$." % P([1, B22, C22]),
               "Factor: $%s%s=0$, so $x=%s$ and $x=%s$." % (fac(r22[0]), fac(r22[1]), fr(r22[0]), fr(r22[1])),
               "The positive difference is $%s-(%s)=%s$." % (fr(r22[1]), fr(r22[0]), fr(r22[1] - r22[0]))]
V['AM-022'] = float(r22[1] - r22[0])

# AM-027  12mn perfect square, mn>20
cands = [k for k in range(1, 12) if 3*k*k > 20]; k27 = cands[0]; mn27 = 3*k27*k27
S['AM-027'] = ["Split off the square: $12mn=4\\cdot3mn$. Since $4$ is already a perfect square, $12mn$ is a perfect square exactly when $3mn$ is.",
               "$3mn$ is a perfect square only if $mn$ is $3$ times a perfect square: $mn=3k^2$. List the possibilities: $%s$." % ", ".join(str(3*j*j) for j in range(1, 5)) + "$\\ldots$",
               "We need $mn>20$, and the first value on the list above $20$ is $%d$." % mn27,
               "Check that it can happen: $m=3$, $n=%d$ gives $12mn=%d=%d^2$. The values $%d$ and below ($%d$) fail $mn>20$. The answer is $%d$." % (mn27 // 3, 12*mn27, math.isqrt(12*mn27), 3*(k27-1)**2, 3*(k27-1)**2, mn27)]
assert math.isqrt(12*mn27)**2 == 12*mn27
V['AM-027'] = mn27
S['AM-027'][1] = "$3mn$ is a perfect square only when $mn=3k^2$ for some positive integer $k$. The possible values of $mn$ are $%s,\\ldots$" % ", ".join(str(3*j*j) for j in range(1, 5))
S['AM-027'][3] = "Check: $m=3$ and $n=%d$ give $mn=%d$ and $12mn=%d=%d^2$. The value before it, $%d$, is not above $20$. The answer is $%d$." % (mn27 // 3, mn27, 12*mn27, math.isqrt(12*mn27), 3*(k27-1)**2, mn27)

# AM-031  x^2-8x+5
s31, p31 = 8, 5
S['AM-031'] = ["For $x^2+bx+c=0$ with roots $r$ and $s$: $r+s=-b$ and $rs=c$. Here $r+s=%d$ and $rs=%d$." % (s31, p31),
               "Rewrite what we need using these: $r^2+s^2=(r+s)^2-2rs$.",
               "Substitute: $%d^2-2\\cdot%d=%d-%d=%d$." % (s31, p31, s31**2, 2*p31, s31**2 - 2*p31),
               "The roots are $%d\\pm\\sqrt{%d}$ (not needed). Check: $(%d+\\sqrt{%d})^2+(%d-\\sqrt{%d})^2=2(%d+%d)=%d$." % (s31 // 2, (s31 // 2)**2 - p31, s31 // 2, (s31 // 2)**2 - p31, s31 // 2, (s31 // 2)**2 - p31, (s31 // 2)**2, (s31 // 2)**2 - p31, 2*((s31 // 2)**2 + (s31 // 2)**2 - p31))]
assert 2*((s31 // 2)**2 + (s31 // 2)**2 - p31) == s31**2 - 2*p31
V['AM-031'] = s31**2 - 2*p31

# AM-039 completing the square
h39 = 6 // 2; k39 = 7 + h39**2; r39 = [h39 - isq(k39), h39 + isq(k39)]
S['AM-039'] = ["Move the constant: $x^2-6x=7$.",
               "Take half of $-6$, which is $-%d$, and square it: $%d$. Add $%d$ to both sides: $x^2-6x+%d=%d$." % (h39, h39**2, h39**2, h39**2, k39),
               "The left side is a perfect square: $(x-%d)^2=%d$, so $x-%d=\\pm%d$." % (h39, k39, h39, isq(k39)),
               "Then $x=%d\\pm%d$, giving $x=%d$ or $x=%d$. The positive solution is $%d$." % (h39, isq(k39), r39[1], r39[0], r39[1])]
V['AM-039'] = float(r39[1])

# AM-044  y=x^2-7, x+y=5
r44 = qr(1, 1, -12); x44 = [r for r in r44 if r > 0][0]; y44 = x44**2 - 7
S['AM-044'] = ["Replace $y$ in $x+y=5$ with $x^2-7$: $x+x^2-7=5$.",
               "Rearrange: $%s=0$, which factors as $%s%s=0$, so $x=%s$ or $x=%s$." % (P([1, 1, -12]), fac(r44[0]), fac(r44[1]), fr(r44[0]), fr(r44[1])),
               "We need $x>0$, so $x=%s$ and $y=%s^2-7=%s$." % (fr(x44), fr(x44), fr(y44)),
               "Then $x^2y^2=%s^2\\cdot%s^2=%s\\cdot%s=%s$." % (fr(x44), fr(y44), fr(x44**2), fr(y44**2), fr(x44**2*y44**2))]
assert x44 + y44 == 5
V['AM-044'] = float(x44**2*y44**2)

# AM-054  10p = q + 25r
qq, rr = 20, 4; pv = Fr(qq + 25*rr, 10)
S['AM-054'] = ["We need $p$ alone. $p$ is multiplied by $10$, so divide BOTH sides by $10$: $p=\\dfrac{q+25r}{10}$.",
               "The division applies to the whole right side, not just one term. That is why $p=\\dfrac{q}{10}+25r$ and $p=q+\\dfrac{25r}{10}$ are wrong. Multiplying by $10$ instead of dividing is also wrong.",
               "Test with numbers: $q=%d$ and $r=%d$ give $10p=%d+%d=%d$, so $p=%s$." % (qq, rr, qq, 25*rr, qq + 25*rr, fr(pv)),
               "Only $\\dfrac{q+25r}{10}=\\dfrac{%d}{10}=%s$ matches. The others give $\\dfrac{q}{10}+25r=%s$, $q+\\dfrac{25r}{10}=%s$ and $10(q+25r)=%s$. The answer is (@@L@@)." % (qq + 25*rr, fr(pv), fr(Fr(qq, 10) + 25*rr), fr(qq + Fr(25*rr, 10)), fr(10*(qq + 25*rr)))]
assert Fr(qq + 25*rr, 10) == pv and Fr(qq, 10) + 25*rr != pv and qq + Fr(25*rr, 10) != pv

# AM-070  P(x)=-2x^2+40x-150
r70 = qr(-2, 40, -150)
S['AM-070'] = ["Break even means $P(x)=0$: $-2x^2+40x-150=0$.",
               "Divide every term by $-2$: $%s=0$." % P([1, Fr(40, -2), Fr(-150, -2)]),
               "Factor: $%s%s=0$, so $x=%s$ or $x=%s$." % (fac(r70[0]), fac(r70[1]), fr(r70[0]), fr(r70[1])),
               "The problem says $x=5$ is already known, so the other price is $%s$. Check: $P(%s)=-2(%s)^2+40(%s)-150=%s$." % (fr(r70[1]), fr(r70[1]), fr(r70[1]), fr(r70[1]), fr(-2*r70[1]**2 + 40*r70[1] - 150))]
assert -2*r70[1]**2 + 40*r70[1] - 150 == 0
V['AM-070'] = float(r70[1])

# AM-077  y=x^2-5x+20, y=3x+8
B77, C77 = -5 - 3, 20 - 8; r77 = qr(1, B77, C77)
S['AM-077'] = ["The models are equal where the two expressions are equal: $x^2-5x+20=3x+8$.",
               "Move everything to the left side: $%s=0$." % P([1, B77, C77]),
               "Factor: $%s%s=0$, so $x=%s$ or $x=%s$." % (fac(r77[0]), fac(r77[1]), fr(r77[0]), fr(r77[1])),
               "Both values satisfy $x\\geq0$, so there are $%d$ values. The answer is (@@L@@)." % len([r for r in r77 if r >= 0])]
V['AM-077'] = len([r for r in r77 if r >= 0])

# AM-087  x^2(x+5)(x-b)=0
sol87 = {0, -5}; b87 = 7 - sum(sol87)
S['AM-087'] = ["Read off the solutions: $x^2=0$ gives $x=0$, $x+5=0$ gives $x=-5$, and $x-b=0$ gives $x=b$.",
               "Even though the factor $x^2$ is squared, the solution $x=0$ is counted only once. The distinct solutions are $0$, $-5$ and $b$.",
               "Their sum is $0+(-5)+b=7$, so $b-5=7$.",
               "Add $5$: $b=%d$. This is positive, as the problem requires." % b87]
V['AM-087'] = b87

# AM-093  y=x^2+1, y=-5x+p through (2,r)
r93 = 2**2 + 1; p93 = r93 + 5*2
S['AM-093'] = ["The point $(2,r)$ is on $y=x^2+1$, so $r=2^2+1=%d$." % r93,
               "The same point is on $y=-5x+p$, so $%d=-5(2)+p=-10+p$." % r93,
               "Add $10$: $p=%d$." % p93,
               "Then $\\dfrac{p}{r}=\\dfrac{%d}{%d}=%s$." % (p93, r93, fr(Fr(p93, r93)))]
V['AM-093'] = float(Fr(p93, r93))

# AM-094  f(x)=x^2+3x-40, h(x)=x^2 ; 3h(x)=f(2x)
r94 = qr(1, 6, -40)
S['AM-094'] = ["First build $f(2x)$ by replacing every $x$ in $f$ with $2x$: $f(2x)=(2x)^2+3(2x)-40=4x^2+6x-40$.",
               "Set $3h(x)=f(2x)$: $3x^2=4x^2+6x-40$.",
               "Move everything to the right side: $0=%s$." % P([1, 6, -40]),
               "Factor: $%s%s=0$, so $x=%s$ or $x=%s$. The positive value is $%s$." % (fac(r94[0]), fac(r94[1]), fr(r94[0]), fr(r94[1]), fr(r94[1]))]
V['AM-094'] = float(r94[1])

# AM-099  ax^3=bx^5
S['AM-099'] = ["Move everything to one side: $bx^5-ax^3=0$.",
               "Factor out $x^3$: $x^3(bx^2-a)=0$. So either $x^3=0$ or $bx^2=a$.",
               "$x^3=0$ gives $x=0$. And $x^2=\\dfrac{a}{b}$ is positive (both $a$ and $b$ are positive), so it gives two more values, $x=\\pm\\sqrt{\\dfrac ab}$.",
               "Example: $a=b=1$ gives $x^3=x^5$ at $x=-1,\\,0,\\,1$, which is $3$ values. The answer is (@@L@@)."]
assert all(x**3 == x**5 for x in (-1, 0, 1))
V['AM-099'] = 3

# AM-102
s1 = [Fr(-3) + 1, Fr(-3) - 1]; s2 = [Fr(4) + 6, Fr(4) - 6]; com = [x for x in s1 if x in s2]
S['AM-102'] = ["Solve the first equation: $x+3=\\pm1$, so $x=%s$ or $x=%s$." % (fr(s1[0]), fr(s1[1])),
               "Solve the second equation: $x-4=\\pm6$, so $x=%s$ or $x=%s$." % (fr(s2[0]), fr(s2[1])),
               "The value of $x$ must make BOTH equations true, so it is the value that appears in both lists: $x=%s$." % fr(com[0]),
               "Check: $(%s+3)^2=%s$ and $(%s-4)^2=%s$." % (fr(com[0]), fr((com[0] + 3)**2), fr(com[0]), fr((com[0] - 4)**2))]
assert len(com) == 1 and (com[0] + 3)**2 == 1 and (com[0] - 4)**2 == 36
V['AM-102'] = float(com[0])

# AM-112  x/(x-3)+2/x=3/(x-3)
r112 = qr(1, -1, -6); good112 = [r for r in r112 if r not in (0, 3)]
S['AM-112'] = ["Multiply every term by the common denominator $x(x-3)$: $x\\cdot x+2(x-3)=3x$.",
               "Expand and move everything to one side: $x^2+2x-6-3x=0$, so $%s=0$." % P([1, -1, -6]),
               "Factor: $%s%s=0$, so $x=%s$ or $x=%s$." % (fac(r112[0]), fac(r112[1]), fr(r112[0]), fr(r112[1])),
               "$x=3$ makes the denominator $x-3$ equal to $0$, so it is not allowed. The answer is $x=%s$. Check: $\\dfrac{-2}{-5}+\\dfrac{2}{-2}=%s$ and $\\dfrac{3}{-5}=%s$." % (fr(good112[0]), fr(Fr(-2, -5) + Fr(2, -2)), fr(Fr(3, -5)))]
assert len(good112) == 1 and Fr(-2, -5) + Fr(2, -2) == Fr(3, -5)
V['AM-112'] = float(good112[0])

# AM-120  2^(3x) * 4^(x+1) = 8^(x+3)
x120 = Fr(7, 2)
S['AM-120'] = ["Write every power with base $2$: $4=2^2$ and $8=2^3$. The equation becomes $2^{3x}\\cdot(2^2)^{x+1}=(2^3)^{x+3}$.",
               "Use $(a^m)^n=a^{mn}$: $(2^2)^{x+1}=2^{2x+2}$ and $(2^3)^{x+3}=2^{3x+9}$. So $2^{3x}\\cdot2^{2x+2}=2^{3x+9}$.",
               "Add exponents when multiplying powers with the same base: $2^{5x+2}=2^{3x+9}$, so $5x+2=3x+9$.",
               "Solve: $2x=7$, so $x=%s$ (or $3.5$). Check: the left exponent is $3x+2(x+1)=%s$ and the right exponent is $3(x+3)=%s$." % (fr(x120), fr(3*x120 + 2*(x120 + 1)), fr(3*(x120 + 3)))]
assert 3*x120 + 2*(x120 + 1) == 3*(x120 + 3)
V['AM-120'] = float(x120)

# AM-123  y=x^2-4x+1, y=2x-8
B123, C123 = -4 - 2, 1 + 8; d123 = B123**2 - 4*C123
S['AM-123'] = ["Set the expressions equal: $x^2-4x+1=2x-8$.",
               "Move everything to the left side: $%s=0$." % P([1, B123, C123]),
               "Count the solutions with the discriminant: $b^2-4ac=(%d)^2-4(1)(%d)=%d$." % (B123, C123, d123),
               "A discriminant of $0$ means exactly one solution. Indeed $%s=(x-%d)^2$, so $x=%d$ only. The answer is (@@L@@)." % (P([1, B123, C123]), -B123 // 2, -B123 // 2)]
assert d123 == 0
V['AM-123'] = 1

# AM-129  2x^2-12x+k, roots r and 2r
rt = Fr(12, 2) / 3; k129 = 2 * (rt * 2*rt)
S['AM-129'] = ["Call the solutions $r$ and $2r$. For $2x^2-12x+k=0$ the solutions add up to $-\\dfrac{b}{a}=\\dfrac{12}{2}=6$.",
               "So $r+2r=6$, which gives $3r=6$ and $r=%s$. The solutions are $%s$ and $%s$." % (fr(rt), fr(rt), fr(2*rt)),
               "The solutions multiply to $\\dfrac{c}{a}=\\dfrac{k}{2}$, so $\\dfrac{k}{2}=%s\\cdot%s=%s$." % (fr(rt), fr(2*rt), fr(rt*2*rt)),
               "Then $k=%s$. Check: $2x^2-12x+%s=2%s%s$." % (fr(k129), fr(k129), fac(rt), fac(2*rt))]
assert 2*rt*rt*0 + 2*(rt**2 - 6*rt)*0 == 0 and 2*rt**2 - 12*rt + k129 == 0 and 2*(2*rt)**2 - 12*(2*rt) + k129 == 0
V['AM-129'] = float(k129)

# AM-169  4^x-2^(x+2)-32=0, find 2^(x+1)
u169 = qr(1, -4, -32); upos = [u for u in u169 if u > 0][0]
S['AM-169'] = ["Write everything in terms of $2^x$: $4^x=(2^x)^2$ and $2^{x+2}=4\\cdot2^x$. Let $u=2^x$, so $u^2-4u-32=0$.",
               "Factor: $%s%s=0$, so $u=%s$ or $u=%s$." % (fac(u169[0], 'u'), fac(u169[1], 'u'), fr(u169[0]), fr(u169[1])),
               "A power of $2$ is never negative, so $u=%s$ is rejected and $2^x=%s$." % (fr(u169[0]), fr(upos)),
               "The question asks for $2^{x+1}=2\\cdot2^x=2\\cdot%s=%s$. (Here $x=3$.) The answer is (@@L@@)." % (fr(upos), fr(2*upos))]
assert upos == 8 and 4**3 - 2**5 - 32 == 0
V['AM-169'] = float(2*upos)

# AM-171 (Desmos)  |x+6|-7 = x/3 + c, exactly one solution
D('AM-171')
c171 = Fr(-7) - Fr(-6, 3); x171 = -6
SL.append(('AM-171', ['y=abs(x+6)-7', 'y=x/3+c'], {'c': float(c171)}, -6, -7))
S['AM-171'] = ["Type %s and %s (accept the slider for $c$). Tap the corner of the V: %s." % (c('y=abs(x+6)-7'), c('y=x/3+c'), tap('AM-171', ['y=abs(x+6)-7'], -6, -7, 'vertex'))]
S['AM-171'] += ["Slide $c$. The line is gentler than both arms of the V: with $c$ above the right value it cuts the V twice, with $c$ below it misses the V. It cuts exactly once only when it passes through the corner.",
                "At the corner $x=-6$ the line has height $-6/3+c$, which must equal $-7$. " + ret('-7-(-6/3)') + ", so $c=%s$ (the slider shows the line through %s)." % (fr(c171), pt(-6, -7)),
                "The one solution is $x=-6$. " + ret('2*(-5)+(-6)') + ". The answer is (@@L@@)."]
V['AM-171'] = float(2*c171 + x171)

# AM-174  y=mx-5, y=x^2-6x+11 tangent, m<0
B174 = lambda m: -(6 + m); disc174 = lambda m: (6 + m)**2 - 4*16
m174 = [m for m in range(-60, 60) if disc174(m) == 0]
S['AM-174'] = ["Set the expressions equal: $x^2-6x+11=mx-5$. Move everything to the left: $x^2-(6+m)x+16=0$.",
               "Exactly one intersection point means exactly one solution, so the discriminant is $0$: $(6+m)^2-4(1)(16)=0$.",
               "So $(6+m)^2=%d$, giving $6+m=%d$ or $6+m=%d$, i.e. $m=%d$ or $m=%d$." % (4*16, math.isqrt(4*16), -math.isqrt(4*16), m174[1], m174[0]),
               "The problem says $m$ is negative, so $m=%d$. The answer is (@@L@@). Check: the touch point is $x=\\dfrac{6+m}{2}=%d$, and both sides equal $%d$ there." % (m174[0], (6 + m174[0]) // 2, ((6 + m174[0]) // 2)**2 - 6*((6 + m174[0]) // 2) + 11)]
assert m174 == [-14, 2] and ((6 - 14)//2)**2 - 6*((6 - 14)//2) + 11 == -14*((6 - 14)//2) - 5
V['AM-174'] = m174[0]

# AM-177 (Desmos)  x^2+y^2=65, x-y=7
D('AM-177')
r177 = qr(1, -7, -8); sols177 = [(a, a - 7) for a in r177]; a177, b177 = [s for s in sols177 if s[0] > 0][0]
S['AM-177'] = ["Rewrite the second equation as $y=x-7$. Type %s (a circle) and %s." % (c('x^2+y^2=65'), c('y=x-7')),
               "Tap the two points where the line crosses the circle: %s and %s. The problem wants $a>0$." % (tap('AM-177', ['x^2+y^2=65', 'y=x-7'], sols177[0][0], sols177[0][1]), tap('AM-177', ['x^2+y^2=65', 'y=x-7'], sols177[1][0], sols177[1][1])),
               "So $(a,b)=(%d,\\,%d)$. " % (a177, b177) + ret('%d+3*%d' % (a177, b177)) + "."]
V['AM-177'] = a177 + 3*b177

# AM-189 (Desmos)  y=x^2+6x+4, y=mx-4 : no common point
D('AM-189')
r189 = (6 - math.sqrt(32), 6 + math.sqrt(32)); ints189 = [m for m in range(-20, 30) if r189[0] < m < r189[1]]
S['AM-189'] = ["Set the expressions equal: $x^2+6x+4=mx-4$, so $x^2+(6-m)x+8=0$. No common point means no real solution, so the discriminant must be negative: $(6-m)^2-32<0$.",
               "Type %s (letting $x$ stand for $m$)." % c('y=(6-x)^2-32'),
               "Tap the two zeros: %s and %s. The curve is below the axis (negative discriminant) between them, so $%s<m<%s$." % (tap('AM-189', ['y=(6-x)^2-32', 'y=0'], r189[0], 0), tap('AM-189', ['y=(6-x)^2-32', 'y=0'], r189[1], 0), n(r189[0]), n(r189[1])),
               "The integers in that range are $%d,%d,\\ldots,%d$. Add them: " % (ints189[0], ints189[0] + 1, ints189[-1]) + ret('%d*%d/2' % (ints189[-1], ints189[-1] + 1)) + "."]
assert ints189 == list(range(1, 12))
V['AM-189'] = sum(ints189)

# AM-196 (Desmos)  2^x = 3x + k
D('AM-196')
xm = brentq(lambda x: 2**x*math.log(2) - 3, 0, 6); ym = 2**xm - 3*xm
x2a = 2.0; x2b = brentq(lambda x: 2**x - 3*x + 2, 2.05, 4)
S['AM-196'] = ["Rewrite the equation as $2^x-3x=k$. Type %s and tap its lowest point: %s." % (c('y=2^x-3x'), tap('AM-196', ['y=2^x-3x'], xm, ym, 'vertex')),
               "Each value of $k$ is a horizontal line. Type %s: it is below the lowest point, so it never meets the curve (no solutions)." % c('y=-3'),
               "Type %s: it is just above the lowest point and meets the curve twice, at %s and %s." % (c('y=-2'), tap('AM-196', ['y=2^x-3x', 'y=-2'], x2a, -2), tap('AM-196', ['y=2^x-3x', 'y=-2'], x2b, -2)),
               "Two solutions need $k>%s$, so the smallest integer is $%d$. The answer is (@@L@@)." % (n(ym), -2)]
assert ym < -2 and ym > -3
V['AM-196'] = -2

# AM-202  9-3|2x-8| = 1-5k/2
rhs_need = 9; k202 = max(k for k in range(-100, 100) if Fr(1) - Fr(5*k, 2) > 9)
S['AM-202'] = ["The expression $|2x-8|$ is never negative, so $9-3|2x-8|$ is at most $9$ (it equals $9$ when $x=4$).",
               "So the equation has no solution exactly when the right side is bigger than $9$: $1-\\dfrac{5k}{2}>9$.",
               "Subtract $1$: $-\\dfrac{5k}{2}>8$. Multiply by $-\\dfrac25$ and flip the inequality: $k<-\\dfrac{16}{5}=%s$." % n(-3.2, 1),
               "The greatest integer below $%s$ is $%d$. Check: $k=%d$ gives right side $%s>9$ (no solution), but $k=%d$ gives $%s\\le9$ (has a solution)." % (n(-3.2, 1), k202, k202, fr(1 - Fr(5*k202, 2)), k202 + 1, fr(1 - Fr(5*(k202 + 1), 2)))]
assert k202 == -4 and 1 - Fr(5*(k202 + 1), 2) <= 9 < 1 - Fr(5*k202, 2)
V['AM-202'] = k202

# AM-204 (Desmos)  2sqrt(x+1)+2sqrt(15-x)=k
D('AM-204')
f204 = lambda x: 2*math.sqrt(x + 1) + 2*math.sqrt(15 - x)
top = f204(7); dd = math.sqrt(top**2 / 4 - 0)  # unused
x11 = brentq(lambda x: f204(x) - 11, 7, 15); x11b = 14 - x11
S['AM-204'] = ["Type %s. It only exists for $-1\\le x\\le15$. Tap the left end %s, the top %s and the right end %s." % (c('y=2*sqrt(x+1)+2*sqrt(15-x)'), tap('AM-204', ['y=2*sqrt(x+1)+2*sqrt(15-x)'], -1, 8), tap('AM-204', ['y=2*sqrt(x+1)+2*sqrt(15-x)'], 7, top, 'vertex'), tap('AM-204', ['y=2*sqrt(x+1)+2*sqrt(15-x)'], 15, 8)),
               "The solutions are where the horizontal line $y=k$ meets the curve. Type %s: it meets the curve twice, at %s and %s." % (c('y=11'), tap('AM-204', ['y=2*sqrt(x+1)+2*sqrt(15-x)', 'y=11'], x11b, 11), tap('AM-204', ['y=2*sqrt(x+1)+2*sqrt(15-x)', 'y=11'], x11, 11)),
               "Type %s: it meets the curve at both ends, again twice. A line meets the curve exactly once only when it just touches the top." % c('y=8'),
               ret('4*sqrt(8)') + ", which is the top height. " + ret('8*sqrt(2)') + ", the same number, so $k=8\\sqrt{2}$. The answer is (@@L@@)."]
assert abs(top - 8*math.sqrt(2)) < 1e-12 and abs(f204(-1) - 8) < 1e-12 and abs(f204(15) - 8) < 1e-12
V['AM-204'] = top

# AM-208  x^2+y^2=45, y=mx+15, m<0, one solution
m208 = [m for m in range(-20, 0) if 900*m*m - 4*(1 + m*m)*180 == 0][0]; x208 = Fr(-30*m208, 2*(1 + m208*m208))
S['AM-208'] = ["Substitute $y=mx+15$ into the circle: $x^2+(mx+15)^2=45$, which expands to $(1+m^2)x^2+30mx+180=0$.",
               "Exactly one solution means the discriminant is $0$: $(30m)^2-4(1+m^2)(180)=0$, so $%dm^2-%d=0$ and $m^2=%d$." % (900 - 720, 720, 720 // (900 - 720)),
               "The problem says $m$ is negative, so $m=%d$. The equation becomes $%s=0$, i.e. $%s=0$." % (m208, P([1 + m208**2, 30*m208, 180]), P([1, Fr(30*m208, 1 + m208**2), Fr(180, 1 + m208**2)])),
               "That is $(x-%s)^2=0$, so $x=%s$. Check: $y=%d(%s)+15=%s$ and $%s^2+%s^2=%s$. The answer is (@@L@@)." % (fr(x208), fr(x208), m208, fr(x208), fr(m208*x208 + 15), fr(x208), fr(m208*x208 + 15), fr(x208**2 + (m208*x208 + 15)**2))]
assert m208 == -2 and x208 == 6 and x208**2 + (m208*x208 + 15)**2 == 45
V['AM-208'] = float(x208)

# AM-211  y=3x^2+4, y=1-kx : two distinct negative x
S['AM-211'] = ["Set the expressions equal: $3x^2+4=1-kx$, so $3x^2+kx+3=0$.",
               "Two distinct solutions need a positive discriminant: $k^2-4(3)(3)=k^2-%d>0$, so $k>%d$ or $k<-%d$." % (4*3*3, math.isqrt(4*3*3), math.isqrt(4*3*3)),
               "Both solutions negative: the sum of the solutions is $-\\dfrac{k}{3}$, which must be negative, so $k>0$. (The product is $\\dfrac33=1>0$, so the two solutions already have the same sign.)",
               "Together, $k>6$. Of the options, $k=7$ works; $k=6$ gives only one solution, $k=2$ gives none, and $k=-7$ gives two positive solutions. The answer is (@@L@@)."]
r211 = qr(3, 7, 3); assert all(float(x) < 0 for x in r211) and len(r211) == 2 and 36 - 36 == 0 and 2*2 - 36 < 0
r211m = qr(3, -7, 3); assert all(x > 0 for x in r211m)
V['AM-211'] = 7

# AM-214 (Desmos)  sqrt(x+k)=x-2
D('AM-214')
S['AM-214'] = ["Square both sides: $x+k=(x-2)^2$, and remember $x-2\\ge0$, because a square root is never negative. Solve for $k$: $k=x^2-5x+4$ with $x\\ge2$.",
               "Type %s. Tap the left end %s and the lowest point %s. The number of solutions is the number of times the horizontal line $y=k$ meets this curve." % (c('y=x^2-5x+4\\{x>=2\\}'), tap('AM-214', ['y=x^2-5x+4'], 2, -2), tap('AM-214', ['y=x^2-5x+4'], 2.5, -2.25, 'vertex')),
               "Type %s: it meets the curve twice, at %s and %s, so $k=-2$ gives two solutions. Type %s: it meets the curve only once, at %s." % (c('y=-2'), tap('AM-214', ['y=x^2-5x+4', 'y=-2'], 2, -2), tap('AM-214', ['y=x^2-5x+4', 'y=-2'], 3, -2), c('y=-1'), tap('AM-214', ['y=x^2-5x+4', 'y=-1'], (5 + math.sqrt(5))/2, -1)),
               "Every line from $y=-1$ upward meets the curve exactly once. The values are $k=-1,0,1,\\ldots,10$. Count them: " + ret('10-(-1)+1') + ". (The single touch at $k=-2.25$ is not an integer.)"]
assert [k for k in range(-10, 11)] and True
V['AM-214'] = 12

# AM-220  y=kx+4 tangent to y=x^2+4x+13
B220 = lambda k: 4 - k
k220 = [k for k in range(-30, 30) if (4 - k)**2 - 36 == 0]; xt = [Fr(k - 4, 2) for k in k220]; yt = [x*x + 4*x + 13 for x in xt]
S['AM-220'] = ["Set the expressions equal: $x^2+4x+13=kx+4$. Move everything to the left: $x^2+(4-k)x+9=0$.",
               "Tangent means exactly one solution, so the discriminant is $0$: $(4-k)^2-4(1)(9)=0$, so $(4-k)^2=%d$ and $4-k=\\pm%d$, giving $k=%d$ or $k=%d$." % (4*9, math.isqrt(4*9), k220[0], k220[1]),
               "The touching point is the double root $x=-\\dfrac{4-k}{2}$: for $k=%d$ it is $x=%s$, and for $k=%d$ it is $x=%s$." % (k220[0], fr(xt[0]), k220[1], fr(xt[1])),
               "Find the $y$-coordinates with the parabola: $y=%s^2+4(%s)+13=%s$ and $y=%s^2+4(%s)+13=%s$. The greatest is $%s$. The answer is (@@L@@)." % (pa(xt[0]), fr(xt[0]), fr(yt[0]), pa(xt[1]), fr(xt[1]), fr(yt[1]), fr(max(yt)))]
assert k220 == [-2, 10] and all(k*x + 4 == y for k, x, y in zip(k220, xt, yt))
V['AM-220'] = float(max(yt))

# AM-222 (Desmos)  x - 4 sqrt(x) = k
D('AM-222')
g222 = lambda x: x - 4*math.sqrt(x)
xa = (2 - math.sqrt(2))**2; xb = (2 + math.sqrt(2))**2; x3 = (2 + math.sqrt(7))**2
S['AM-222'] = ["Type %s. Tap the left end %s, the lowest point %s and the right-hand zero %s. The solutions of the equation are where the horizontal line $y=k$ meets this curve." % (c('y=x-4*sqrt(x)'), tap('AM-222', ['y=x-4*sqrt(x)'], 0, 0), tap('AM-222', ['y=x-4*sqrt(x)'], 4, -4, 'vertex'), tap('AM-222', ['y=x-4*sqrt(x)'], 16, 0)),
               "Type %s: it only touches the lowest point, so exactly one solution. Type %s: it meets the curve twice, at %s and %s. Type %s: twice again, at $(0,\\,0)$ and $(16,\\,0)$. Below $y=-4$ there are no solutions." % (c('y=-4'), c('y=-2'), tap('AM-222', ['y=x-4*sqrt(x)', 'y=-2'], xa, -2), tap('AM-222', ['y=x-4*sqrt(x)', 'y=-2'], xb, -2), c('y=0')),
               "Type %s: only once, at %s. Every line above $y=0$ meets the curve only once, on the rising part to the right of $x=16$." % (c('y=3'), tap('AM-222', ['y=x-4*sqrt(x)', 'y=3'], x3, 3)),
               "Exactly one solution happens for $k=-4$ (one value) and for $k=1,2,\\ldots,10$ (ten values). Count them: " + ret('1+10') + "."]
V['AM-222'] = 11

# AM-231  cubic
k231 = [-5, 2]
S['AM-231'] = ["Group the terms with $k$ and the terms without: $(x^3+3x^2-10x)-k(x^2+3x-10)=0$.",
               "Factor each group: $x(x^2+3x-10)-k(x^2+3x-10)=0$, so $(x-k)(x^2+3x-10)=0$.",
               "Factor the quadratic: $x^2+3x-10=%s%s$. The solutions are $x=%s$, $x=%s$ and $x=k$." % (fac(qr(1, 3, -10)[0]), fac(qr(1, 3, -10)[1]), fr(qr(1, 3, -10)[0]), fr(qr(1, 3, -10)[1])),
               "There are exactly two distinct solutions only when $k$ repeats one of the fixed solutions: $k=%d$ or $k=%d$. Their sum is $%d$." % (k231[0], k231[1], sum(k231))]
assert [int(x) for x in qr(1, 3, -10)] == [-5, 2]
V['AM-231'] = sum(k231)

# AM-232 (Desmos)  |2x-k|+k = x+6
D('AM-232')
SL.append(('AM-232', ['y=abs(2*x-k)+k', 'y=x+6'], {'k': 12}, 6, 12))
SL.append(('AM-232', ['y=abs(2*x-k)+k', 'y=x+6'], {'k': 0}, -2, 4))
SL.append(('AM-232', ['y=abs(2*x-k)+k', 'y=x+6'], {'k': 0}, 6, 12))
S['AM-232'] = ["Type %s and %s (accept the slider for $k$). The first graph is a V whose corner is at $\\left(\\dfrac{k}{2},\\,k\\right)$, and the line $y=x+6$ is gentler than both arms." % (c('y=abs(2x-k)+k'), c('y=x+6')),
               "Set $k=0$: the line cuts the V twice, at %s and %s. Slide $k$ up and the two points move together." % (pt(-2, 4), pt(6, 12)),
               "At $k=12$ the corner %s sits on the line and there is exactly one intersection. For $k$ larger than that the V is above the line and they never meet." % pt(6, 12),
               "Check with the corner: $\\left(\\dfrac k2,\\,k\\right)$ lies on $y=x+6$ when $k=\\dfrac k2+6$. " + ret('12/2+6') + ", which matches $k=12$."]
V['AM-232'] = 12

# ---------------------------------------------------------------- Part B
# A-124
a124 = [(g, g + 4) for g in range(0, 100) if (g + 4)**2 == g*g + 64][0]
S['A-124'] = ["Let Emma be $e$ years old and Grace $g$. We know $e-g=4$ and $e^2=g^2+64$, so $e^2-g^2=64$.",
              "Factor the difference of squares: $(e-g)(e+g)=64$.",
              "Put in $e-g=4$: $4(e+g)=64$, so $e+g=%d$." % (64 // 4),
              "Check: $g=%d$ and $e=%d$ give $%d^2-%d^2=%d-%d=%d$. The sum of their ages is $%d$." % (a124[0], a124[1], a124[1], a124[0], a124[1]**2, a124[0]**2, a124[1]**2 - a124[0]**2, sum(a124))]
assert sum(a124) == 16
V['A-124'] = sum(a124)

# AM-009 (modified)  v=x^2+2x-3 equals -3
r9 = qr(1, 2, 0)
S['AM-009'] = ["Set the model equal to the baseline: $x^2+2x-3=-3$.",
               "Add $3$ to both sides: $%s=0$." % P([1, 2, 0]),
               "Factor: $x(x+2)=0$, so $x=%s$ or $x=%s$." % (fr(r9[1]), fr(r9[0])),
               "The problem only allows nonnegative $x$, so $x=%s$ is rejected and only $x=%s$ counts: $%d$ value. The answer is (@@L@@)." % (fr(r9[0]), fr(r9[1]), len([r for r in r9 if r >= 0]))]
V['AM-009'] = len([r for r in r9 if r >= 0])

# AM-010
r10 = qr(1, -5, -24)
pair10 = [(p, q) for p in range(-30, 31) for q in range(-30, 31) if p*q == -24 and p + q == -5][0]
S['AM-010'] = ["Look for two numbers that multiply to $-24$ and add to $-5$: they are $%d$ and $%d$." % pair10,
               "So $x^2-5x-24=%s%s$." % (fac(r10[0]), fac(r10[1])),
               "Set each factor to $0$: $x=%s$ or $x=%s$." % (fr(r10[0]), fr(r10[1])),
               "The positive solution is $%s$. Check: $%s^2-5(%s)-24=%s$." % (fr(r10[1]), fr(r10[1]), fr(r10[1]), fr(r10[1]**2 - 5*r10[1] - 24))]
V['AM-010'] = float(r10[1])

# AM-017
r17 = qr(2, -5, -3)
S['AM-017'] = ["Multiply $a\\cdot c=2\\cdot(-3)=-6$. Find two numbers with product $-6$ and sum $-5$: $-6$ and $1$.",
               "Split the middle term: $2x^2-6x+x-3=0$. Factor by grouping: $2x(x-3)+1(x-3)=(2x+1)(x-3)=0$.",
               "Set each factor to $0$: $2x+1=0$ gives $x=%s$, and $x-3=0$ gives $x=%s$." % (fr(r17[0]), fr(r17[1])),
               "The solutions are $x=%s$ and $x=%s$, which is option (@@L@@). Check $x=3$: $2(9)-15-3=%d$." % (fr(r17[0]), fr(r17[1]), 2*9 - 15 - 3)]
assert all(2*x*x - 5*x - 3 == 0 for x in r17)
V['AM-017'] = 0

# AM-021
xy = 45 // 5; yy = (xy - 5) // 2; xx = (xy + 5) // 2
S['AM-021'] = ["Factor the difference of squares: $x^2-y^2=(x-y)(x+y)$.",
               "Put in $x-y=5$: $5(x+y)=45$.",
               "Divide by $5$: $x+y=%d$, which is option (@@L@@)." % xy,
               "Check: $x+y=%d$ and $x-y=5$ give $x=%d$ and $y=%d$, both positive integers, and $%d^2-%d^2=%d-%d=%d$." % (xy, xx, yy, xx, yy, xx**2, yy**2, xx**2 - yy**2)]
assert xx**2 - yy**2 == 45
V['AM-021'] = xy

# AM-029
ex29 = [(m, m*m - m) for m in (-2, -1, 0, 1, 2, 3, 4)]
S['AM-029'] = ["Write the result as $n^2-n=n(n-1)$: the product of two consecutive integers.",
               "Of two consecutive integers one is even, so the product is always even. Try some values: " + ", ".join("$n=%d$ gives $%d$" % e for e in ex29[:6]) + ".",
               "So the result can be $0$ (A), an even integer (B) and a positive integer (D), e.g. $n=%d$ gives $%d$." % (ex29[0][0], ex29[0][1]),
               "It can never be odd, so the answer is (@@L@@)."]
assert all(r % 2 == 0 for _, r in ex29) and 0 in [r for _, r in ex29] and any(r > 0 for _, r in ex29)
V['AM-029'] = 0

# AM-030
k30 = Fr(36, 4)
S['AM-030'] = ["Exactly one real solution means the discriminant is $0$: $b^2-4ac=0$.",
               "Here $a=1$, $b=6$, $c=k$: $6^2-4(1)k=0$, so $%d-4k=0$." % (6**2),
               "Solve: $4k=36$, so $k=%s$, which is option (@@L@@)." % fr(k30),
               "Check: $x^2+6x+%s=(x+3)^2$, which equals $0$ only at $x=-3$ (one solution)." % fr(k30)]
V['AM-030'] = float(k30)

# AM-034 (modified)  x/(x-2) = 2/(x-2) + 3
sol34 = (2 - 6) / Fr(-2)   # x = 2 + 3x - 6  ->  -2x = -4
S['AM-034'] = ["Multiply every term by $x-2$ (the common denominator, with $x\\neq2$): $x=2+3(x-2)$.",
               "Expand: $x=2+3x-6$, so $x=3x-4$.",
               "Subtract $3x$: $-2x=-4$, so $x=%s$." % fr(Fr(sol34)),
               "But $x=%s$ makes the denominator $x-2$ equal to $0$, so it is not allowed (an extraneous solution). There is no solution, which is option (@@L@@)." % fr(Fr(sol34))]
assert Fr(sol34) == 2
V['AM-034'] = 0

# AM-050
S['AM-050'] = ["Divide every term of $8x-12y>20$ by the same positive number $4$.",
               "The inequality sign stays the same because $4>0$: $\\dfrac{8x}{4}-\\dfrac{12y}{4}>\\dfrac{20}{4}$.",
               "That gives $%dx-%dy>%d$, which is option (@@L@@)." % (8 // 4, 12 // 4, 20 // 4),
               "The other options change the coefficients to $%d$, $%d$, or $-%d$, which divides $8x$ and $12y$ differently and is not the same inequality." % (3, 4, 3)]
S['AM-050'][3] = "Check with test points. At $(4,0)$ both are true: $8(4)-12(0)=%d>20$ and $2(4)-3(0)=%d>5$. At $(2,0)$ both are false: $%d>20$ and $%d>5$ are false. But $3x-2y>5$ is true at $(2,0)$ since $%d>5$, so it is not equivalent." % (8*4, 2*4, 8*2, 2*2, 3*2)
assert 8*4 > 20 and 2*4 > 5 and not (8*2 > 20) and not (2*2 > 5) and 3*2 > 5
V['AM-050'] = 0

# AM-051
d51 = 20**2 - 4*4*25
S['AM-051'] = ["Compute the discriminant: $b^2-4ac=(-20)^2-4(4)(25)=%d-%d=%d$." % (400, 400, d51),
               "A discriminant of $0$ means exactly one real solution.",
               "Check by factoring: $4x^2-20x+25=(2x-5)^2$, so $x=%s$ is the only solution." % fr(Fr(5, 2)),
               "The answer is (@@L@@)."]
assert d51 == 0
V['AM-051'] = 1

# AM-052 (fixed options)
S['AM-052'] = ["Both equations equal $y$, so set the right sides equal: $5x+2=5x^2+2$.",
               "Subtract $5x+2$ from both sides: $0=5x^2-5x=5x(x-1)$, so $x=0$ or $x=1$.",
               "Find $y$ from $y=5x+2$: $x=0$ gives $y=%d$ and $x=1$ gives $y=%d$. The solutions are $(0,%d)$ and $(1,%d)$." % (5*0 + 2, 5*1 + 2, 5*0 + 2, 5*1 + 2),
               "Only $(1,7)$ is listed, which is option (@@L@@). The others fail: $(0,0)$ and $(0,5)$ have $y\\neq2$ at $x=0$, and $(1,5)$ has $y\\neq7$ at $x=1$."]
assert all(5*x + 2 == 5*x*x + 2 for x in (0, 1))
V['AM-052'] = 0

# AM-053
S['AM-053'] = ["Divide both sides by $7$: $|x|=\\dfrac{63}{7}=%d$." % (63 // 7),
               "The absolute value equation has two solutions: $x=%d$ and $x=-%d$." % (9, 9),
               "The question asks for the positive one: $x=%d$." % 9,
               "Check: $7|9|=%d$." % (7*9)]
V['AM-053'] = 9

# AM-068  y=x^2-4x, y=2x-5
r68 = qr(1, -6, 5); ys68 = [2*x - 5 for x in r68]
S['AM-068'] = ["Set the expressions equal: $x^2-4x=2x-5$. Move everything to the left: $%s=0$." % P([1, -6, 5]),
               "Factor: $%s%s=0$, so $x=%s$ or $x=%s$." % (fac(r68[0]), fac(r68[1]), fr(r68[0]), fr(r68[1])),
               "Find each $y$ from the line $y=2x-5$: $x=%s$ gives $y=%s$, and $x=%s$ gives $y=%s$." % (fr(r68[0]), fr(ys68[0]), fr(r68[1]), fr(ys68[1])),
               "The sum of the $y$-coordinates is $%s+%s=%s$, which is option (@@L@@)." % (fr(ys68[0]), fr(ys68[1]), fr(sum(ys68)))]
assert all(x*x - 4*x == 2*x - 5 for x in r68)
V['AM-068'] = float(sum(ys68))

# AM-075
b75 = [b for b in range(1, 50) if b*(b + 4) == 60][0]
S['AM-075'] = ["Let the base be $b$ cm. The height is $b+4$ cm. The area of a triangle is $\\dfrac12\\cdot\\text{base}\\cdot\\text{height}$, so $\\dfrac12b(b+4)=30$.",
               "Multiply by $2$: $b^2+4b=%d$, so $%s=0$." % (2*30, P([1, 4, -2*30], 'b')),
               "Factor: $%s%s=0$, so $b=%s$ or $b=%s$." % (fac(qr(1, 4, -60)[0], 'b'), fac(qr(1, 4, -60)[1], 'b'), fr(qr(1, 4, -60)[0]), fr(qr(1, 4, -60)[1])),
               "A length is positive, so $b=%d$ cm, which is option (@@L@@). Check: $\\dfrac12(%d)(%d)=%d$." % (b75, b75, b75 + 4, b75*(b75 + 4) // 2)]
assert b75*(b75 + 4)//2 == 30
V['AM-075'] = b75

# AM-076
x76 = Fr(8, 2)
S['AM-076'] = ["Multiply both sides by $x-1$ (allowed since $x\\neq1$): $x+5=3(x-1)$.",
               "Expand: $x+5=3x-3$.",
               "Move the $x$ terms to one side and numbers to the other: $5+3=3x-x$, so $%d=2x$." % 8,
               "Divide by $2$: $x=%s$. Check: $\\dfrac{%s+5}{%s-1}=\\dfrac{%s}{%s}=%s$." % (fr(x76), fr(x76), fr(x76), fr(x76 + 5), fr(x76 - 1), fr((x76 + 5)/(x76 - 1)))]
assert (x76 + 5)/(x76 - 1) == 3
V['AM-076'] = float(x76)

# AM-104  y=x^2/3, y=2x/3
r104 = qr(1, -2, 0); a104 = [r for r in r104 if r != 0][0]; b104 = Fr(2, 3)*a104
S['AM-104'] = ["Set the expressions equal: $\\dfrac{x^2}{3}=\\dfrac{2x}{3}$. Multiply by $3$: $x^2=2x$.",
               "Move everything to one side and factor: $x^2-2x=x(x-2)=0$, so $x=0$ or $x=%s$." % fr(a104),
               "The origin is the point with $x=0$, so the other point has $a=%s$." % fr(a104),
               "Then $b=\\dfrac{2a}{3}=\\dfrac{2\\cdot%s}{3}=%s$. Check with the parabola: $\\dfrac{%s^2}{3}=%s$." % (fr(a104), fr(b104), fr(a104), fr(a104**2/3))]
assert a104**2/3 == b104
V['AM-104'] = float(b104)

# AM-107
r107 = qr(1, -1, -12)
S['AM-107'] = ["Divide every term by $2$: $x^2-x-12=0$.",
               "Find two numbers with product $-12$ and sum $-1$: $-4$ and $3$. So $x^2-x-12=%s%s$." % (fac(r107[1]), fac(r107[0])),
               "Set each factor to $0$: $x=%s$ or $x=%s$." % (fr(r107[1]), fr(r107[0])),
               "That is option (@@L@@). Check $x=%s$: $2(%s)^2-2(%s)-24=%s$." % (fr(r107[0]), fr(r107[0]), fr(r107[0]), fr(2*r107[0]**2 - 2*r107[0] - 24))]
assert [int(r) for r in r107] == [-3, 4]
V['AM-107'] = 0

# AM-113
r113 = -2
S['AM-113'] = ["Expand the left side: $(x-3)(x+7)=x^2+4x-21$. So $x^2+4x-21=-25$.",
               "Add $25$ to both sides: $x^2+4x+4=0$.",
               "Factor: $(x+2)^2=0$, so $x=%d$." % r113,
               "Check: $(%d-3)(%d+7)=(%d)(%d)=%d$." % (r113, r113, r113 - 3, r113 + 7, (r113 - 3)*(r113 + 7))]
assert (r113 - 3)*(r113 + 7) == -25
V['AM-113'] = r113

# AM-114
r114 = qr(1, -4, -12)
S['AM-114'] = ["Translate: the square of the number is $12$ more than $4$ times the number, so $x^2=4x+12$.",
               "Move everything to the left side: $%s=0$." % P([1, -4, -12]),
               "Factor: $%s%s=0$, so $x=%s$ or $x=%s$." % (fac(r114[0]), fac(r114[1]), fr(r114[0]), fr(r114[1])),
               "The number is positive, so it is $%s$. Check: $%s^2=%s$ and $4(%s)+12=%s$." % (fr(r114[1]), fr(r114[1]), fr(r114[1]**2), fr(r114[1]), fr(4*r114[1] + 12))]
V['AM-114'] = float(r114[1])

# AM-122  xy=48, 3x-y=0
x122 = isq(48 // 3); y122 = 3*x122
S['AM-122'] = ["From $3x-y=0$ we get $y=3x$.",
               "Substitute into $xy=48$: $x(3x)=48$, so $3x^2=48$.",
               "Divide by $3$: $x^2=%d$, so $x=\\pm%s$. We need $x>0$, so $x=%s$." % (48 // 3, fr(x122), fr(x122)),
               "Then $y=3x=%s$. Check: $xy=%s\\cdot%s=%s$." % (fr(y122), fr(x122), fr(y122), fr(x122*y122))]
assert x122*y122 == 48
V['AM-122'] = float(y122)

# AM-128
S['AM-128'] = ["Rewrite $2^{x+3}$ as $2^x\\cdot2^3=8\\cdot2^x$. The equation becomes $8\\cdot2^x-2^x=56$.",
               "Combine like terms: $7\\cdot2^x=56$.",
               "Divide by $7$: $2^x=%d$." % (56 // 7),
               "Since $%d=2^3$, $x=%d$. Check: $2^{%d}-2^{%d}=%d-%d=%d$." % (56 // 7, 3, 3 + 3, 3, 2**6, 2**3, 2**6 - 2**3)]
assert 2**6 - 2**3 == 56
V['AM-128'] = 3

# AM-130
u130 = qr(1, -13, 36); pos130 = [math.sqrt(float(u)) for u in u130]
S['AM-130'] = ["Let $u=x^2$. Then $x^4=u^2$ and the equation becomes $u^2-13u+36=0$.",
               "Factor: $%s%s=0$, so $u=%s$ or $u=%s$." % (fac(u130[0], 'u'), fac(u130[1], 'u'), fr(u130[0]), fr(u130[1])),
               "Since $u=x^2$: $x^2=%s$ gives $x=\\pm%d$, and $x^2=%s$ gives $x=\\pm%d$. The positive solutions are $%d$ and $%d$." % (fr(u130[0]), round(pos130[0]), fr(u130[1]), round(pos130[1]), round(pos130[0]), round(pos130[1])),
               "Their product is $%d\\cdot%d=%d$." % (round(pos130[0]), round(pos130[1]), round(pos130[0])*round(pos130[1]))]
V['AM-130'] = round(pos130[0])*round(pos130[1])

if __name__ == '__main__':
    json.dump({k: S[k] for k in S}, open('/tmp/claude-0/-home-claude/56214d6e-9327-5adb-98f6-b897111d58bd/scratchpad/steps_dump.json', 'w'), indent=1)
    print(len(S), 'items;', len(TAPS), 'taps;', len(SL), 'slider claims; D tools:', sorted(TOOL))
