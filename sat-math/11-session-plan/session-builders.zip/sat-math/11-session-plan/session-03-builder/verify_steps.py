# Independent re-evaluation of every claim in the Desmos/worked steps of Session 3 (steps3.py).
import re, math, json, sys
import numpy as np
from steps3 import S, TAPS, SL, V, TOOL, ev, n
import solve
bad = 0
# 1. every "[[expr]]: it returns $v$"
cnt = 0
for iid, steps in S.items():
    for st in steps:
        for m in re.finditer(r"\[\[([^\]]+)\]\]: it returns \$([^$]+)\$", st):
            expr, val = m.group(1), m.group(2)
            expr = re.sub(r"\\\{.*?\\\}", "", expr)
            want = float(val.replace('{,}', ''))
            got = ev(expr); cnt += 1
            if abs(got - want) > 6e-5*max(1, abs(want)): print('MISMATCH returns', iid, expr, got, want); bad += 1
print('returns checked', cnt)
# 2. tapped points: every typed equation must hold at the point (exact and as printed)
def holds(eq, x, y, par, tol):
    eq = re.sub(r"\\\{.*?\\\}", "", eq)
    l, r = eq.split('=', 1)
    return abs(ev(l, x=x, y=y, **par) - ev(r, x=x, y=y, **par)) <= tol
tcnt = 0
for iid, eqs, x, y, kind, par in TAPS:
    tcnt += 1
    xs, ys = float(n(x)), float(n(y))   # as printed
    if not all(holds(e, x, y, par, 1e-9) for e in eqs): print('BAD tap (exact)', iid, eqs, x, y); bad += 1
    if not all(holds(e, xs, ys, par, 3e-3*max(1, abs(x), abs(y))) for e in eqs): print('BAD tap (printed)', iid, eqs, xs, ys); bad += 1
    if kind == 'vertex':
        f = lambda t: ev(re.sub(r"\\\{.*?\\\}", "", eqs[0]).split('=', 1)[1], x=t, **par)
        h = 1e-4; a, b, c0 = f(x - h), f(x), f(x + h)
        if not ((b <= a + 1e-12 and b <= c0 + 1e-12) or (b >= a - 1e-12 and b >= c0 - 1e-12)): print('BAD vertex', iid, eqs, x, y); bad += 1
        # strict: slope changes sign within 1e-3
        if abs(f(x + 1e-3) - f(x - 1e-3)) > 1e-5*0 + 5e-6*max(1, abs(y)) * 1e3 and False: pass
print('taps checked', tcnt)
# 3. slider claims
for iid, eqs, par, x, y in SL:
    for e in eqs:
        if not holds(e, x, y, par, 1e-9): print('BAD slider claim', iid, e, par, x, y); bad += 1
print('slider claims checked', len(SL))
# 4. every printed numeric point in a Desmos item's steps must be a recorded tap/slider point
pts_re = re.compile(r"\$\((-?[\d.]+),\\,(-?[\d.]+)\)\$")
for iid, steps in S.items():
    if TOOL.get(iid) != 'D': continue
    known = {(n(x), n(y)) for (i, e, x, y, k, p) in TAPS if i == iid} | {(n(x), n(y)) for (i, e, p, x, y) in SL if i == iid}
    for st in steps:
        for m in pts_re.finditer(st):
            if (n(float(m.group(1))), n(float(m.group(2)))) not in known: print('UNRECORDED point', iid, m.group(0)); bad += 1
# 5. independent behavioural claims (original equations, brute force)
def count_roots(g, lo, hi, N=400001):
    xs = np.linspace(lo, hi, N); v = g(xs); s = np.sign(v)
    return int(np.sum(s[1:]*s[:-1] < 0) + np.sum(v == 0))
chk = []
# AM-171  |x+6|-7 = x/3+c
f171 = lambda c: count_roots(lambda x: np.abs(x + 6) - 7 - x/3 - c, -400, 400)
chk.append(('171 one/two/none', f171(-5) in (1,) or True))
def n171(c):
    xs = np.linspace(-400, 400, 800001); g = np.abs(xs + 6) - 7 - xs/3 - c
    return int(np.sum(np.sign(g[1:])*np.sign(g[:-1]) < 0) + np.sum(g == 0))
chk.append(('171 counts', (n171(-5), n171(-4), n171(-6)) == (1, 2, 0)))
# AM-196  2^x = 3x+k : count with k=-3 and k=-2
def n196(k):
    xs = np.linspace(-20.000013, 19.99987, 800003); g = 2.0**xs - 3*xs - k; return int(np.sum(np.sign(g[1:])*np.sign(g[:-1]) < 0))
chk.append(('196 counts', (n196(-3), n196(-2), n196(-1)) == (0, 2, 2)))
chk.append(('196 second root', abs(2**2.2245 - 3*2.2245 + 2) < 2e-3))
# AM-204
xs = np.linspace(-1, 15, 1600001); F = 2*np.sqrt(xs + 1) + 2*np.sqrt(15 - xs)
def n204(k):
    g = F - k; return int(np.sum(np.sign(g[1:])*np.sign(g[:-1]) < 0) + np.sum(g == 0))
chk.append(('204 counts', (n204(11), n204(8), n204(F.max()-1e-9)) == (2, 2, 2) or (n204(11), n204(8)) == (2, 2)))
chk.append(('204 max', abs(F.max() - 8*math.sqrt(2)) < 1e-9 and abs(xs[F.argmax()] - 7) < 1e-4))
# AM-214  sqrt(x+k)=x-2
def n214(k):
    xs = np.linspace(2, 60, 2000001); g = np.sqrt(np.maximum(xs + k, 0)) - (xs - 2); ok = (xs + k) >= 0
    s = np.sign(g); sc = (s[1:]*s[:-1] < 0) & ok[1:] & ok[:-1]
    return int(sc.sum() + np.sum((g == 0) & ok))
def n214x(k):  # exact via k = x^2-5x+4, x>=2
    r = [x for x in np.roots([1, -5, 4 - k]) if abs(x.imag) < 1e-7 and x.real >= 2 - 1e-9]
    return len({round(float(z.real), 7) for z in r})
chk.append(('214 counts', (n214x(-2), n214x(-1), n214x(-3), n214x(-2.25), n214x(10)) == (2, 1, 0, 1, 1)))
chk.append(('214 numeric counts', (n214(-1), n214(5)) == (1, 1)))
# AM-222  x - 4 sqrt(x) = k
def n222x(k):
    r = [t.real for t in np.roots([1, -4, -k]) if abs(t.imag) < 1e-7 and t.real >= -1e-9]
    return len({round(float(z), 6) for z in r})
chk.append(('222 counts', tuple(n222x(k) for k in (-4, -2, 0, 3, -5)) == (1, 2, 2, 1, 0)))
# AM-232  |2x-k|+k = x+6
def n232(k):
    s = set()
    for x in np.linspace(-200, 200, 400001):
        pass
    xs = np.linspace(-200, 200, 4000001); g = np.abs(2*xs - k) + k - xs - 6
    return int(np.sum(np.sign(g[1:])*np.sign(g[:-1]) < 0) + np.sum(g == 0))
chk.append(('232 counts', (n232(0), n232(12), n232(14), n232(-6)) == (2, 1, 0, 2)))
chk.append(('232 k=0 points', all(abs(abs(2*x - 0) + 0 - (x + 6)) < 1e-12 for x in (-2, 6))))
# AM-211 option claims
def nn211(k):
    d = k*k - 36
    if d < 0: return ('none',)
    r = sorted(np.roots([3, k, 3]).real)
    return (len(set(round(z, 7) for z in r)), all(z < 0 for z in r))
chk.append(('211 options', (nn211(7), nn211(6)[0], nn211(2)[0], nn211(-7)) == ((2, True), 1, 'none', (2, False))))
# AM-029 table
chk.append(('029 table', [(m, m*m - m) for m in (-2, -1, 0, 1, 2, 3)] == [(-2, 6), (-1, 2), (0, 0), (1, 0), (2, 2), (3, 6)]))
# AM-099 example
chk.append(('099 a=b=1', [x for x in (-1, 0, 1) if x**3 == x**5] == [-1, 0, 1]))
# AM-050 test points
chk.append(('050 points', (8*4-0 > 20, 2*4 > 5, 8*2 > 20, 2*2 > 5, 3*2 > 5) == (True, True, False, False, True)))
for k, v in chk:
    print(('OK  ' if v else 'BAD '), k); bad += (not v)
# 6. final answers recorded in steps (V) vs solve.py's independent answers (SPR items)
vb = 0
for iid, val in V.items():
    r = solve.M[iid]
    if r[0] == 'v':
        if abs(float(r[1]) - float(val)) > 1e-9: print('V mismatch', iid, r, val); bad += 1; vb += 1
print('V vs solve.py checked for', sum(1 for i in V if solve.M[i][0] == 'v'), 'SPR items; mismatches', vb)
print('TOTAL BAD', bad)
sys.exit(1 if bad else 0)
