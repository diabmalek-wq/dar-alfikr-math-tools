# Re-evaluates every "[[expr]]: it returns $v$" in the steps, checks tapped-point claims, and checks that every SPR final answer
# appears in its steps and every MCQ step set names a letter; compares keyed.json (final PDF key) with mykeys.json (independent solve.py).
import re,math,json,sys
sys.path.insert(0,'.')
from helpers import ev
from steps11 import S
bad=0;cnt=0
for iid,steps in S.items():
    for st in steps:
        for m in re.finditer(r"\[\[([^\]]+)\]\]: it returns \$([^$]+)\$",st):
            expr,val=m.group(1),m.group(2).replace('{,}','')
            got=ev(expr);want=float(val);cnt+=1
            if abs(got-want)>6e-5*max(1,abs(want)): print('MISMATCH',iid,expr,got,want);bad+=1
print('returns checked',cnt,'mismatches',bad)
# tapped points / claims
r=sorted(__import__('numpy').roots([1,0,-28,48]).real); f=lambda x:x*x+48/x
chk=[('130 pts',abs(f(2)-28)<1e-9 and abs(f(4)-28)<1e-9 and abs(f(-6)-28)<1e-9),
 ('130 heights',48/2**2==12 and 48/4**2==3 and 12>4 and not 3>8),
 ('153 trap',abs(math.pi*9*4*7.8-882.1)<0.1),('153 ans',round(ev('(pi*3^2*4-pi*1^2*2.5)*7.8'))==821),
 ('142',abs(240/27*45-400)<1e-9),('165',abs(400*1.2**2-576)<1e-9 and abs((432/250)**(1/3)-1.2)<1e-12),
 ('059 closest',min([2400,6100,12200,24400],key=lambda o:abs(o-2/3*math.pi*18**3))==12200),
 ('158 tangent',abs(abs(5*(10/3)-60)/13-10/3)<1e-12),('171',abs(math.sqrt(169-25)-12)<1e-12),
 ('139 slants',math.hypot(12,5)==13 and math.hypot(12,16)==20)]
for k,vv in chk: print('OK ' if vv else 'BAD',k); bad+=(not vv)
# answers in steps
items={o['id']:o for o in json.load(open('s11_items.json'))}; keys=json.load(open('mykeys.json'))
for iid,o in items.items():
    txt=' '.join(S[iid])
    if o['mcq']: ok='(@@L@@)' in txt
    else:
        a=o['ans'].replace('$','').strip()
        ok=(a in txt.replace('{,}','')) or ('\\dfrac' in a and a in txt)
    if not ok: print('NO ANSWER IN STEPS',iid,o['ans']); bad+=1
kd=dict(json.load(open('keyed.json')))
for iid,o in items.items():
    if o['mcq']: pass
    else: assert abs(kd[iid]-keys[iid])<1e-9,iid
print('steps checked',len(S),'bad',bad)
