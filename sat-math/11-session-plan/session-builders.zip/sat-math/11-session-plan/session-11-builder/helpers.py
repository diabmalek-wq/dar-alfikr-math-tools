import math, re
def n(v, d=4):
    s = '%.*f' % (d, v)
    if '.' in s: s = s.rstrip('0').rstrip('.')
    return '0' if s in ('-0', '') else s
def ev(expr, **kw):
    e = expr.replace('^', '**')
    e = re.sub(r'(\d|\))\s*(\(|[a-zA-Z])', r'\1*\2', e)
    env = dict(sqrt=math.sqrt, abs=abs, ln=math.log, pi=math.pi, **kw)
    return eval(e, {'__builtins__': {}}, env)
def c(e): return '[[%s]]' % e
def v(x, d=4): return '$%s$' % n(x, d)
def ret(e, d=4, **kw): return "Type %s: it returns %s" % (c(e), v(ev(e, **kw), d))
def pt(x, y, d=4): return "$(%s,\\,%s)$" % (n(x, d), n(y, d))
def Pi(k): return "%s\\pi" % n(k)   # plain, used inside $...$
def th(x): return format(int(round(x)),",").replace(",","{,}")
def lc(s): return s[0].lower()+s[1:]
