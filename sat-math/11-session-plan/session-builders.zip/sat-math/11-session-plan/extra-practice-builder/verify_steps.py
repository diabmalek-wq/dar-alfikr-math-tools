import re,math,json
import numpy as np
from steps import S,ev
bad=0;cnt=0
for iid,steps in S.items():
    for st in steps:
        for m in re.finditer(r"\[\[([^\]]+)\]\]: it returns \$([^$]+)\$",st):
            expr,val=m.group(1),m.group(2).replace('{,}','')
            got=ev(expr); want=float(val); cnt+=1
            if abs(got-want)>6e-5*max(1,abs(want)): print('MISMATCH',iid,expr,got,want); bad+=1
print('returns checked',cnt,'mismatches',bad)
def chk(name,ok):
    global bad
    print('OK ' if ok else 'BAD',name); bad+=(not ok)
# 153: the Desmos regression claim, recomputed (and as exact normal equations)
x=np.arange(1,12.0); y=np.append(2*np.arange(1,11)+1,40.0)
n_=11; m=(n_*(x*y).sum()-x.sum()*y.sum())/(n_*(x*x).sum()-x.sum()**2); b=(y.sum()-m*x.sum())/n_
chk('153 slope/intercept %.3f %.3f'%(m,b),abs(m-2.5)<1 and m>2 and b<1 and abs(m-np.polyfit(x,y,1)[0])<1e-9)
chk('153 steps quote',any('%.3f'%m in s for s in S['PS-153']))
chk('229 20/sqrt2',abs(20/math.sqrt(2)-14.1421)<5e-5 and round(20/math.sqrt(2),1)==14.1)
chk('143 decimals',round(35/71,4)==0.4930 and int(35/71*1e4)/1e4==0.4929)
chk('148 decimals',int(24/59*1e4)/1e4==0.4067 and round(24/59,4)==0.4068)
chk('146 1/9',round(1/9,4)==0.1111); chk('293 16/3',round(16/3,3)==5.333)
chk('227 figure ratio 2:3',abs(0.4/0.6-2/3)<1e-12)
chk('229 figure t^2=1/2',abs((1/math.sqrt(2))**2-0.5)<1e-12)
print('total bad',bad); assert bad==0
