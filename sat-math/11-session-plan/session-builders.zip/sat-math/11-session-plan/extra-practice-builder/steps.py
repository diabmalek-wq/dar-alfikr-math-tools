"""Worked-solution steps for Session 7. Every number quoted in a step is computed here (not typed by hand);
every typed expression that 'returns' a value is evaluated by ev() and re-checked in verify_steps.py."""
import math, re, statistics as st
from fractions import Fraction as Fr
import numpy as np

def n(v, d=4):
    s = ('%.*f' % (d, v)).rstrip('0').rstrip('.')
    if s in ('-0', ''): s = '0'
    if re.fullmatch(r'-?\d{4,}', s):
        neg = s.startswith('-'); s = s.lstrip('-'); s = '{,}'.join([s[:len(s) % 3 or 3]] + [s[i:i+3] for i in range(len(s) % 3 or 3, len(s), 3)]) if False else s
        out = ''; r = s
        while len(r) > 3: out = '{,}' + r[-3:] + out; r = r[:-3]
        s = ('-' if neg else '') + r + out
    return s
def ev(expr, **kw):
    e = expr.replace('^', '**')
    e = re.sub(r'(\d|\))\s*(\(|[a-zA-Z])', r'\1*\2', e)
    env = dict(sqrt=math.sqrt, abs=abs, **kw)
    return eval(e, {'__builtins__': {}}, env)
def c(e): return '[[%s]]' % e
def v(x, d=4): return '$%s$' % n(x, d)
def ret(e, d=4, **kw): return "Type %s: it returns %s" % (c(e), v(ev(e, **kw), d))
def pt(x, y, d=4): return "$(%s,\\,%s)$" % (n(x, d), n(y, d))
def L(_t, **kw): return re.sub(r"@(\w+)@", lambda m: str(kw[m.group(1)]), _t)

S = {}; T = {}; V = {}; CLAIMS = []
def TOOL(t, *ids):
    for i in ids: T[i] = t

# ---------------- 116 (Desmos)
def _a116(x): x = Fr(x); a = x - x/3; b = 72 + x/3; return a + b/4, b - b/4
x116 = 36; a116, b116 = _a116(x116)
import statistics as st
# ---------------- evaluating statistical claims
S['PS-133']=[
 L("The $@a@$ volunteers were randomly assigned, $@h@$ to each method. Random assignment is what allows a cause-and-effect conclusion.",a=n(60+60),h=n(60)),
 "The difference was larger than random assignment alone would produce, so the difference is real: method $X$ caused the higher scores.",
 "But the people were volunteers who answered an advertisement, not a random sample of all students. The conclusion applies only to volunteers like them, so \"all students\" is too broad, and \"no causal conclusion\" ignores the random assignment."]
S['PS-134']=[
 L("The $@a@$ adults were chosen at random from the city, so the result can be generalized to adults in the city.",a=n(500)),
 "Nobody was assigned to exercise more or less: people just reported what they do. That makes it an observational study, which can show association only, never cause.",
 "So the best supported conclusion is a positive association among adults in the city, without a claim that exercise causes more sleep. Choices A and B claim causation; C refuses to generalize even though the sample was random."]
S['PS-135']=[
 "The poll was posted on a cycling club's website and people chose whether to answer. That is a voluntary-response sample.",
 L("People who choose to answer a bike-lane poll on a cycling club's site mostly like bike lanes, which is why $91\\%$ of $@a@$ responses said yes.",a=n(1850)),
 "A large number of responses does not fix bias from self-selection, so the main problem is that respondents selected themselves."]
S['PS-136']=[
 "In the study the adults chose for themselves whether to drink coffee, so other differences between the groups (age, lifestyle) could explain the lower rate.",
 "A cause-and-effect conclusion needs an experiment: randomly assigning who drinks coffee balances those other factors across the groups.",
 L("A bigger sample ($@a@$), restricting by age, or collecting more habits does not remove the problem. Only random assignment does.",a=n(5000))]
lo137,hi137=51-2.5,51+2.5
S['PS-137']=[
 L("Plausible values for the population percent run from $51-2.5=@l@$ to $51+2.5=@h@$ percent.",l=n(lo137),h=n(hi137)),
 "The interval contains $50\\%$, so both a majority (above $50\\%$) and less than half (below $50\\%$) are plausible.",
 "That matches the statement saying a majority is plausible but less than half is also plausible. Statements A and C claim more than the poll shows, and D claims the exact value."]
S['PS-138']=[
 L("Plausible values for the mean run from $3.2-0.4=@l@$ to $3.2+0.4=@h@$ hours per day.",l=n(3.2-0.4),h=n(3.2+0.4)),
 "The greatest total comes from the greatest plausible mean.",
 L("Multiply by the number of students: $@h@\\times@N@=@t@$ hours per day.",h=n(3.6),N=n(18000),t=n(3.6*18000))]
S['PS-139']=[
 "The margin of error is proportional to $\\dfrac{1}{\\sqrt n}$, so only the change in $n$ matters.",
 L("The sample grows from $@a@$ to $@b@$, which is $@r@$ times as large, and $\\sqrt{@r@}=@s@$.",a=n(400),b=n(1600),r=n(4),s=n(2)),
 L("Divide the margin of error by $@s@$: $\\dfrac{6}{@s@}=@m@$ percent. (Dividing by $4$ is the common trap.)",s=n(2),m=n(6/2))]
S['PS-140']=[
 L("Town $P$: $30\\pm4$ gives $@a@$ to $@b@$ percent. Town $Q$: $38\\pm4$ gives $@c@$ to $@d@$ percent.",a=n(26),b=n(34),c=n(34),d=n(42)),
 L("The intervals overlap: both contain $@o@$ percent, so the same value for both towns is plausible.",o=n(34)),
 "So it is plausible that the percent in favor is the same in both towns. The estimates differ, but the margins of error mean that difference is not established."]
S['PS-141']=[
 L("The interval is $62\\pm5$, which gives $@a@\\%$ to $@b@\\%$.",a=n(57),b=n(67)),
 L("But the sample of $@s@$ was drawn only from the $@N@$ seniors, so the interval describes seniors at the school, not all $@T@$ students.",s=n(300),N=n(1200),T=n(1200+2800)),
 "A margin of error gives plausible values for the population, not an exact value and not the percent of the sample, so only the statement about seniors fits."]
S['PS-142']=[
 L("The tagged fraction of the sample should match the tagged fraction of the lake: $\\dfrac{9}{60}=\\dfrac{150}{N}$, where $N$ is the number of fish."),
 L("The sample fraction is $\\dfrac{9}{60}=@f@$.",f=n(9/60)),
 L("Solve $@f@\\,N=150$: $N=\\dfrac{150}{@f@}=@N@$ fish.",f=n(9/60),N=n(150/(9/60)))]
# ---------------- probability
S['PS-143']=[
 L("Only the customers who did not renew count: $@a@+@b@=@t@$ customers.",a=n(36),b=n(35),t=n(36+35)),
 L("Of these, @b@ were on Plan $B$, so the probability is $\\dfrac{@b@}{@t@}$.",b=n(35),t=n(71)),
 L("As a decimal, $\\dfrac{35}{71}\\approx@d@$. (Dividing by all $200$ customers is the trap.)",d=n(35/71,4))]
S['PS-144']=[
 "For independent events $P(A\\text{ or }B)=P(A)+P(B)-P(A)P(B)$. Let $P(B)=p$.",
 L("$0.4+p-0.4p=0.7$, so $0.6p=@d@$.",d=n(0.7-0.4)),
 L("$p=\\dfrac{@d@}{0.6}=@p@$.",d=n(0.3),p=n(0.3/0.6))]
S['PS-145']=[
 L("Both red: $\\dfrac58\\cdot\\dfrac47=\\dfrac{@a@}{@t@}$.",a=n(5*4),t=n(8*7)),
 L("Both blue: $\\dfrac38\\cdot\\dfrac27=\\dfrac{@b@}{@t@}$.",b=n(3*2),t=n(8*7)),
 L("Add the two ways: $\\dfrac{@s@}{@t@}=\\dfrac{@n@}{@d@}$.",s=n(5*4+3*2),t=n(56),n=n(13),d=n(28))]
S['PS-146']=[
 L("Count all outcomes with at least one even die: $@all@-@odd@=@c@$ (the $@odd@$ all-odd outcomes are removed from $@all@$).",all=n(36),odd=n(9),c=n(27)),
 "Sums of $8$: $(2,6),(6,2),(3,5),(5,3),(4,4)$. The pairs $(3,5)$ and $(5,3)$ have two odd dice, so they are not in the condition.",
 L("Three outcomes remain, so the probability is $\\dfrac{3}{@c@}=\\dfrac19\\approx@d@$.",c=n(27),d=n(1/9,4))]
S['PS-147']=[
 L("Own a car or a bicycle: $240+180-70=@u@$ (subtract the $70$ counted twice).",u=n(240+180-70)),
 L("Own neither: $500-@u@=@z@$ residents.",u=n(350),z=n(150)),
 L("Probability: $\\dfrac{@z@}{500}=@p@$.",z=n(150),p=n(150/500))]
S['PS-148']=[
 L("Voters over $60$: $0.3\\times0.8=@a@$ of all residents. Voters not over $60$: $0.7\\times0.5=@b@$.",a=n(0.24),b=n(0.35)),
 L("All voters: $@a@+@b@=@t@$ of all residents.",a=n(0.24),b=n(0.35),t=n(0.59)),
 L("Probability: $\\dfrac{@a@}{@t@}=\\dfrac{24}{59}\\approx@p@$.",a=n(0.24),t=n(0.59),p=n(24/59,4))]
S['PS-149']=[
 L("Drug $X$: $\\dfrac{90}{120}=@a@$ improved.",a=n(90/120)),
 L("Drug $Y$: $\\dfrac{60}{100}=@b@$ improved.",b=n(60/100)),
 L("Compare: $\\dfrac{@a@}{@b@}=@r@$ times as likely.",a=n(.75),b=n(.6),r=n(.75/.6))]
# ---------------- two-variable data
S['PS-150']=[
 "In $\\hat y=82-1.6x$ the number $82$ is the constant term, the $y$-intercept.",
 L("It is the value of $\\hat y$ when $x=0$: $82-1.6(0)=@v@$.",v=n(82)),
 "Here $x$ is the number of days absent, so $x=0$ means no absences: the predicted score of a student with no absences is $82$. The slope $-1.6$ is the change per day, and $82$ is not a class mean."]
S['PS-151']=[
 L("Look at $x$ up by $1$: $y$ goes $8,12,18,27,40.5$. The differences ($@a@,@b@,@c@,@d@$) are not constant, so it is not linear and (B) fails.",a=n(4),b=n(6),c=n(9),d=n(13.5)),
 L("Ratios of consecutive $y$-values: $\\dfrac{12}{8}=@r1@$, $\\dfrac{18}{12}=@r2@$, $\\dfrac{27}{18}=@r3@$, $\\dfrac{40.5}{27}=@r4@$. The ratio is constant, so the growth is exponential with $b=1.5$ and $a=8$.",r1=n(12/8),r2=n(18/12),r3=n(27/18),r4=n(40.5/27)),
 L("Check (C) at $x=2$: $2(4)+2(2)+8=@c@\\ne18$, and (D) at $x=1$: $8(1.2)=@d@\\ne12$. Only $y=8(1.5)^x$ fits all five.",c=n(2*4+2*2+8),d=n(8*1.2))]
S['PS-152']=[
 L("Predicted value at $x=10$: $3.2(10)+14=@p@$.",p=n(3.2*10+14)),
 L("Residual = actual $-$ predicted $=51-@p@$.",p=n(46)),
 L("That equals $@r@$ (positive, so the point is above the line).",r=n(51-46))]
x153=list(range(1,11))+[11]; y153=[2*t+1 for t in range(1,11)]+[40]; m153,b153=np.polyfit(x153,y153,1)
S['PS-153']=[
 L("The line $y=2x+1$ predicts $2(11)+1=@p@$ at $x=11$. The new point is $40$, which is $@d@$ above the line, at the far right end.",p=n(23),d=n(40-23)),
 "A high point at the right end pulls the right side of the line up. Predict that the slope gets greater, and since the line has to tilt up around the middle of the data, the intercept gets smaller.",
 "Check in Desmos: make a table with columns $x_1$ and $y_1$ holding the eleven points, then type %s."%c('y_1~mx_1+b'),
 L("It gives $m\\approx@m@$ and $b\\approx@b@$: the slope is greater than $2$ and the intercept is smaller than $1$.",m=n(m153,3),b=n(b153,3))]
S['PS-154']=[
 L("The model was fitted for $x$ from $20$ to $80$, and the prediction is for $x=150$.",),
 "Using a model outside the range of its data is extrapolation. The linear pattern may not continue.",
 L("The calculation is possible ($0.85(150)+12=@y@$), but it is less reliable because $150$ is outside the range of the data.",y=n(0.85*150+12))]
S['PS-155']=[
 "A least-squares line always passes through the point $(\\bar x,\\bar y)$, the means.",
 L("Put $\\bar x=10$ into the line: $\\bar y=1.5(10)+4$.",),
 L("$\\bar y=@a@+4=@b@$.",a=n(15),b=n(19))]
S['PS-156']=[
 "For a least-squares line the residuals add to $0$.",
 L("The first four add to $-2+3+1-4=@s@$.",s=n(-2+3+1-4)),
 L("So the fifth residual is $0-(@s@)=@r@$.",s=n(-2),r=n(2))]
# ---------------- functions
S['AM-288']=[
 "$g(x)=f(2x)$ is zero when the input $2x$ is a zero of $f$, so $2x=-2$ or $2x=5$.",
 L("Divide by $2$: $x=\\dfrac{-2}{2}=@a@$ and $x=\\dfrac52=@b@$.",a=n(-1),b=n(2.5)),
 "Replacing $x$ by $2x$ squeezes the graph horizontally by a factor of $2$, so the intercepts move toward the $y$-axis (not out to $-4$ and $10$)."]
S['AM-289']=[
 L("First $g(3)$: the table gives $@a@$.",a=n(2)),
 L("Next $f^{-1}(2)$: find the $x$ with $f(x)=2$. The table gives $f(4)=2$, so $f^{-1}(2)=@b@$.",b=n(4)),
 L("Finally $g(4)=@c@$.",c=n(3))]
S['AM-290']=[
 "Test each option by replacing $x$ with $-x$ and using $f(-x)=-f(x)$.",
 "(A) $[f(-x)]^2=[-f(x)]^2=[f(x)]^2$: unchanged, so it is even. (B) $f(f(-x))=f(-f(x))=-f(f(x))$: odd.",
 "(C) $f(-x)+1=-f(x)+1$: neither. (D) $f(-x)+(-x)=-(f(x)+x)$: odd. Only (A) must be even."]
S['AM-291']=[
 "Reflection across the $y$-axis replaces $x$ by $-x$, and shifting up $4$ adds $4$: $g(x)=f(-x)+4$.",
 L("Then $g(2)=f(-2)+4$, and $f(-2)=(-2-1)(-2-5)=(-3)(-7)=@a@$.",a=n(21)),
 L("$g(2)=@a@+4=@b@$.",a=n(21),b=n(25))]
S['AM-292']=[
 "$f(g(x))=\\sqrt{g(x)-1}=\\sqrt{x^2-5-1}=\\sqrt{x^2-6}$.",
 "It is defined when $x^2-6\\ge0$, so $x^2\\ge6$.",
 L("That means $|x|\\ge\\sqrt6\\approx@r@$: $x\\le-\\sqrt6$ or $x\\ge\\sqrt6$. (Not $-\\sqrt6\\le x\\le\\sqrt6$: that is where it is undefined.)",r=n(math.sqrt(6),3))]
S['AM-293']=[
 "$f^{-1}(5)$ is the input $x$ for which $f(x)=5$, so there is no need to find the whole inverse function.",
 "Solve $\\dfrac{2x+1}{x-3}=5$: $2x+1=5(x-3)=5x-15$.",
 L("Then $16=3x$, so $x=\\dfrac{16}{3}\\approx@a@$, and $x\\ne3$ is satisfied.",a=n(16/3,3))]
S['AM-294']=[
 "$f(x-1)$ shifts the graph right $1$, so the point $(4,-2)$ becomes $(5,-2)$.",
 L("Multiplying by $3$ and adding $5$ changes the $y$-value: $3(-2)+5=@y@$.",y=n(3*-2+5)),
 "So the point is $(5,-1)$. Check: $3f(5-1)+5=3f(4)+5=3(-2)+5=-1$."]
S['AM-295']=[
 L("By Vieta, $r+s=\\dfrac72=@a@$ and $rs=\\dfrac k2$.",a=n(3.5)),
 L("Use $r^2+s^2=(r+s)^2-2rs$: $9=@b@-k$, because $(3.5)^2=@b@$ and $2rs=k$.",b=n(3.5**2)),
 L("So $k=@b@-9=@k@$. (The discriminant $49-8k=@d@>0$, so the roots are real.)",b=n(12.25),k=n(12.25-9),d=n(49-8*3.25))]
S['AM-296']=[
 "Treat it as a quadratic in $x^2$: $(x^2-1)(x^2-4)=0$.",
 L("So $x^2=1$ or $x^2=4$, giving $x=\\pm1$ and $x=\\pm2$.",),
 L("The product is $(1)(-1)(2)(-2)=@p@$. (Vieta for the whole quartic gives the same: the constant term is $@p@$.)",p=n(4))]
S['AM-297']=[
 "Let $u=2^x$. Then $2^{2x}=u^2$ and the equation becomes $u^2-6u+8=0$.",
 "Factor: $(u-2)(u-4)=0$, so $u=2$ or $u=4$.",
 L("Then $2^x=2$ gives $x=@a@$ and $2^x=4$ gives $x=@b@$.",a=n(1),b=n(2)),
 L("The sum of the solutions is $@a@+@b@=@s@$.",a=n(1),b=n(2),s=n(3))]
# ---------------- similar triangles
S['GT-226']=[
 L("The ratio of the areas is $\\dfrac{100}{36}=\\dfrac{25}{9}$, so the scale factor (the square root) is $\\dfrac{@a@}{@b@}$.",a=n(5),b=n(3)),
 "Perimeters scale by the scale factor itself, not its square.",
 L("Perimeter of $DEF$: $24\\times\\dfrac53=@p@$.",p=n(24*5/3))]
S['GT-227']=[
 L("$AD:DB=2:3$ means $AD:AB=2:5$, so the small triangle $ADE$ is similar to $ABC$ with scale factor $\\dfrac25$.",),
 L("Areas scale by the square: $\\dfrac{4}{25}$. So area $ABC=20\\times\\dfrac{25}{4}=@a@$.",a=n(20*25/4)),
 L("Quadrilateral $DBCE$ is the rest: $@a@-20=@q@$.",a=n(125),q=n(105))]
S['GT-228']=[
 L("The ratio of areas is $\\dfrac{18}{50}=\\dfrac{9}{25}$, so the ratio of corresponding lengths is $\\dfrac{3}{5}$.",),
 "Corresponding altitudes are corresponding lengths, so they have the same ratio.",
 L("Smaller altitude: $15\\times\\dfrac35=@a@$.",a=n(9))]
S['GT-229']=[
 "$\\triangle ADE\\sim\\triangle ABC$, and $\\triangle ADE$ has half the area of $\\triangle ABC$ (the two regions are equal).",
 L("Area ratio $\\dfrac12$, so the length ratio is $\\dfrac{AD}{AB}=\\dfrac{1}{\\sqrt2}$.",),
 "Multiply by $AB=20$: $AD=\\dfrac{20}{\\sqrt2}$. "+ret('20/sqrt(2)',4)+L(", which is @a@ to the nearest tenth.",a=n(20/math.sqrt(2),1))]
S['GT-230']=[
 L("The small triangle is a $6$-$8$-$10$ right triangle with area $\\dfrac12(6)(8)=@a@$.",a=n(24)),
 L("Area ratio $\\dfrac{150}{@a@}=\\dfrac{25}{4}$, so the scale factor is $\\dfrac52=@k@$.",a=n(24),k=n(2.5)),
 L("The hypotenuse $10$ scales to $10\\times@k@=@h@$.",k=n(2.5),h=n(25))]
S['GT-231']=[
 "The cross-section is similar to the base, with the scale factor equal to the ratio of the distances from the apex.",
 L("The plane is one-third of the way down, so the scale factor is $\\dfrac13$ and the area factor is $\\dfrac19$.",),
 L("Area: $144\\times\\dfrac19=@a@$.",a=n(16))]
S['AM-298']=[
 "Write the vertex form $f(x)=a(x-4)^2-8$.",
 L("Use $(0,8)$: $8=a(0-4)^2-8$, so $16a=@s@$ and $a=@a@$.",s=n(16),a=n(1)),
 L("$g(1)=f(2)=(2-4)^2-8=@b@-8=@r@$.",b=n(4),r=n(4-8))]
S['AM-299']=[
 "$g(x)=f(3-x)$ equals zero when $3-x$ is a zero of $f$: $3-x=1$ or $3-x=6$.",
 L("So $x=3-1=@a@$ or $x=3-6=@b@$.",a=n(2),b=n(-3)),
 L("The greatest $x$-intercept is $@a@$.",a=n(2))]
S['AM-300']=[
 "Because $f$ is even, $f(-x)=f(x)$, so $g(x)=f(x)+f(-x)=2f(x)$.",
 L("$g(3)=2f(3)=@a@$.",a=n(14)),
 L("$f(5)=f(-5)=2$, so $g(5)=2(2)=@b@$. Total $@a@+@b@=@t@$.",a=n(14),b=n(4),t=n(18))]
S['AM-301']=[
 L("By Vieta, $r+s=@a@$ and $rs=@b@$.",a=n(5),b=n(2)),
 L("Combine the fractions: $\\dfrac rs+\\dfrac sr=\\dfrac{r^2+s^2}{rs}$, and $r^2+s^2=(r+s)^2-2rs=@c@-@d@=@e@$.",c=n(25),d=n(4),e=n(21)),
 L("So the value is $\\dfrac{@e@}{@b@}=@v@$.",e=n(21),b=n(2),v=n(10.5))]
S['AM-302']=[
 L("By Vieta for the cubic, the zeros have sum $@a@$ and the sum of the products of pairs is $@b@$.",a=n(7),b=n(14)),
 "Use $a^2+b^2+c^2=(a+b+c)^2-2(ab+ac+bc)$.",
 L("$@s@-2(@b@)=@s@-@c@=@r@$. (The zeros are $1,2,4$, and $1+4+16=@r@$.)",s=n(49),b=n(14),c=n(28),r=n(21))]
T={i:'N' for i in S}
T['GT-229']='C'; T['PS-153']='D'
