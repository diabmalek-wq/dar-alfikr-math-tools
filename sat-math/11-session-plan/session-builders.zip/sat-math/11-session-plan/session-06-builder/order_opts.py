# Put every MCQ's options in monotone numeric order (ascending or descending, as on the real test) and
# choose the orientation per item so the correct letters are balanced and no letter repeats 3 times in a row.
import json,random
from itemparse import *
def plan(items):
    LET=json.load(open('letters.json'))
    info=[]
    for o in items:
        stem,opts=parse(o)
        if not opts: continue
        vals=[optnum(t) for t in opts]
        order=sorted(range(4),key=lambda i:vals[i])      # ascending
        asc=[opts[i] for i in order]; corr=order.index(LET[o['id']])
        info.append((o['id'],asc,corr))
    best=None
    rnd=random.Random(6)
    for _ in range(200000):
        fl=[rnd.random()<0.5 for _ in info]
        L=[(3-c if f else c) for (_,_,c),f in zip(info,fl)]
        cnt=[L.count(k) for k in range(4)]
        run=sum(1 for i in range(2,len(L)) if L[i]==L[i-1]==L[i-2])+sum(1 for i in range(1,len(L)) if L[i]==L[i-1])*0.25
        sc=(max(cnt)-min(cnt))*3+run
        if best is None or sc<best[0]: best=(sc,fl,L,cnt)
    res={}
    for (iid,asc,corr),f in zip(info,best[1]):
        opts=asc[::-1] if f else asc
        res[iid]=(opts,(3-corr) if f else corr)
    return res,best
if __name__=='__main__':
    items=json.load(open('s6_items_raw.json')); res,best=plan(items)
    print(best[3],best[2])
