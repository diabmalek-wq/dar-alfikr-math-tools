# Re-evaluates every "type [[expr]]: it returns $v$" in the steps and every tapped-point / quoted-number claim,
# and checks each item's final value (V) against solve.py's independent value.
import re,json,math,sys
sys.path.insert(0,'.')
from steps import S,V,ev,n
solved=json.load(open('solved.json'))
bad=0;cnt=0
for iid,steps in S.items():
    for st in steps:
        for m in re.finditer(r"\[\[([^\]]+)\]\]: it returns \$([^$]+)\$",st):
            expr,val=m.group(1),m.group(2).replace('{,}','')
            if '=' in expr: continue
            want=float(val); got=ev(expr); cnt+=1
            if abs(got-want)>6e-5*max(1,abs(want)): print('MISMATCH',iid,expr,got,want); bad+=1
# 122 : the two tapped intersections, and the graph expression
f=lambda x:(1+x/100)*(1-(x-13)/100)
for x0 in (-12,25):
    if abs(f(x0)-1.1)>1e-12: print('BAD 122 root',x0); bad+=1
assert '$(-12,\\,1.1)$' in ''.join(S['PS-122']) and '$(25,\\,1.1)$' in ''.join(S['PS-122'])
# final values agree with independent solutions
for iid,v in V.items():
    if abs(v-solved[iid])>1e-9*max(1,abs(v)): print('VALUE MISMATCH',iid,v,solved[iid]); bad+=1
assert set(V)==set(S)==set(solved)
# every item has 3-4 steps (PS-072 etc. may have 4; PS-061/067 3)
for iid,st in S.items():
    if not 3<=len(st)<=4: print('STEP COUNT',iid,len(st)); bad+=1
# hand-checked inline claims not produced by the typed boxes
chk=[('097 check 40%',abs((30+30+40)/(150+60+40)-0.4)<1e-12),
 ('083 check',abs(200*1.4*0.75-210)<1e-12),('084 check',abs(10000*0.8*1.15-9200)<1e-9),
 ('103 equation',abs(1.3*1+0.9*1.5-1.06*2.5)<1e-12),
 ('115 check',abs((0.3*70+15+0.1*25)/(70+15+25)-0.35)<1e-12),
 ('121 check',abs((36+36+130)-1.01*200)<1e-9 and abs(1.2*30-0.9*40)<1e-12),
 ('125 chain',abs(100*1.5/0.75/1.6-125)<1e-12),
 ('126 check',(39+17+28)==84 and 39==2*17+5 and 28==(39+17)/2),
 ('104 check',abs((48*5+120)/3-24*5)<1e-12 and 4*12*5==240),
 ('108 check',30+70+40==140 and 70*4==40*7 and 30*11==3*(70+40)),
 ('072 check',abs((7*8-8)/(5*8-8)-1.5)<1e-12),
 ('114 check',abs(18000/90000-0.20)<1e-12 and abs(25200/90000-0.28)<1e-12),
 ('112 areas',abs(4*5*0.3**2-1.8)<1e-12),
 ('093 slips',22*3600==79200 and abs(22/5280-1/240)<1e-15),
 ('110 slip',(7.5*40)*(5*40)/10000==6.0),
 ('089 check',abs(60*5280/3600-88)<1e-12 and abs(88*45/60-66)<1e-12),
 ('063 sanity',15000/2==7500),
 ('069 wrong base',abs(48/480*100-10)<1e-12),
 ('025 wrong base',round(38.2/378.2*100,1)==10.1),
 ('064 wrong base',abs(80/640*100-12.5)<1e-12),
 ('067 pieces',abs(850*0.1*3+850*0.04-289)<1e-9),
 ('095 root',math.isqrt(36)**2==36 and 36*10==360 and 540/1.5==360)]
for k,v in chk:
    if not v: print('BAD',k); bad+=1
print('returns checked',cnt,'inline checks',len(chk),'total bad',bad)
