import json,re,sys,subprocess,os,math,shutil
HERE=os.path.dirname(os.path.abspath(__file__)); os.chdir(HERE); sys.path.insert(0,HERE)
from fractions import Fraction as Fr
from lib import *
from steps import S,V,TOOLT
from itemparse import parse,optnum,bank_letter
items=json.load(open('s6_items_raw.json'))
LET=json.load(open('letters.json'))            # letters from my independent solve (solve.py), in bank option order
LINES_OVERRIDE=json.load(open('lines.json')) if os.path.exists('lines.json') else {}
ESC={'\\':r'\textbackslash{}','{':r'\{','}':r'\}','^':r'\textasciicircum{}','_':r'\_','~':r'\textasciitilde{}','#':r'\#','%':r'\%','&':r'\&','$':r'\$'}
def code(m):
    c=m.group(1).replace('\\{','{').replace('\\}','}')
    return r"\dzc{"+"".join(ESC.get(ch,ch) for ch in c)+"}"
def conv(s): return re.sub(r"\[\[(.+?)\]\]",code,s)
def vis_len(t):
    t=re.sub(r"\[\[(.+?)\]\]",lambda m:'x'*len(m.group(1)),t); t=re.sub(r'\\[a-zA-Z]+','x',t); t=re.sub(r'[${}]','',t); return len(t)
P=[]
for o in items:
    stem,opts=parse(o)
    p=dict(lv='M' if o['d']=='Medium' else 'H',tool=TOOLT[o['id']],q=stem,id=o['id'])
    if opts:
        assert len(opts)==4 and len(set(opts))==4,o['id']
        bl=bank_letter(o['ans'],opts)
        assert bl==LET[o['id']],(o['id'],bl,LET[o['id']])        # key in the item == independently solved letter
        p['opts']=opts;p['correct']=bl;p['norot']=False
        p['chk']=lambda c=LET[o['id']]:('idx',c)
    else:
        a=o['ans'].replace('$','').replace('{,}','').strip(); val=float(Fr(a))
        p['val']=val;p['ans']=a;p['chk']=lambda v=val:v
    steps=[conv(x) for x in S[o['id']]]; p['steps']=steps
    tot=sum(math.ceil(vis_len(x)/92)+0.15 for x in S[o['id']])+1.3
    base={'M':5,'H':6}[p['lv']]
    p['lines']=LINES_OVERRIDE.get(o['id'],max(base,math.ceil(tot*0.43/0.74)+1))
    P.append(p)
P=prep(P)
nA=sum(1 for o in items if o['part']=='In class'); assert [o['part'] for o in items]==['In class']*nA+['Self-assessment']*(len(items)-nA)
json.dump([[p['id'],"ABCD"[p['correct']] if p.get('opts') else p['val']] for p in P],open('keyed.json','w'))
meta=dict(title='Percentages, Ratios and Rates',code='SAT-M \\textperiodcentered\\ Session 6',headfull='Session 6 \\textemdash\\ Percentages, Ratios and Rates',
 time='3 hours: Part A in class (about 2 hours of solving), then Part B, the self-assessment, done independently (about 50 minutes), and a short error log.',
 topics='percent of a quantity \\textperiodcentered\\ percent increase and decrease \\textperiodcentered\\ successive and reverse percent changes \\textperiodcentered\\ percent error \\textperiodcentered\\ mixtures and weighted percents \\textperiodcentered\\ percent chains and parameters \\textperiodcentered\\ ratios and proportions \\textperiodcentered\\ rates and direct variation \\textperiodcentered\\ unit conversion, including squared and cubed units \\textperiodcentered\\ scale and relative speed \\textperiodcentered\\ solving with a given total')
OVER=r"""\renewcommand{\keyspace}[2]{\par\nopagebreak
 \setbox0\vbox{\hsize\linewidth\color{SOLGREEN}\small #2\par}%
 \setbox1\vbox{\foreach \i in {1,...,#1}{\par\vspace{0.74cm}{\color{LINE}\hrule height 0.4pt}}}%
 \ifdim\ht0>\ht1 \typeout{KEYOVER}\dimen2=\ht0 \else \dimen2=\ht1 \fi
 \vbox to \dimen2{\nointerlineskip\vbox to 0pt{\box1\vss}\nointerlineskip\box0\vss}\par\vspace{4pt}}"""
def build_s6(mode,out):
    key=(mode=='key')
    L=[PRE.replace("@@CODE@@",meta['code']).replace("@@HEAD@@",meta['headfull']).replace("\\begin{document}",EXTRA+OVER+r"\setmonofont[Scale=0.9]{DejaVu Sans Mono}\newcommand{\dzc}[1]{\colorbox{black!8}{\texttt{\small\textcolor{black}{#1}}}}"+"\n\\begin{document}")]
    L.append(r"""
\begin{tcolorbox}[enhanced,colback=NAVY!4,colframe=NAVY,boxrule=0.8pt,arc=3pt]
{\Large\bfseries\color{NAVY} SAT Math Mastery \textperiodcentered\ Session 6}\\[2pt]
{\large\bfseries %s}\\[3pt]
\begin{tabular}{@{}p{0.2\linewidth}p{0.75\linewidth}@{}}
\textbf{Time} & %s\\
\textbf{Topics} & %s\\
\textbf{Name / Date} & \rule{5.5cm}{0.3pt}\ \ \rule{3cm}{0.3pt}\\
\end{tabular}
\end{tcolorbox}
"""%(meta['title'],meta['time'],meta['topics']))
    L.append(r"\banner{Part A \textperiodcentered\ In class \textemdash\ %d problems}"%nA)
    L.append(r"\small Each problem states its tool. Write your work in the space below. Multiple choice: one correct option. Student-produced response (SPR): enter an exact value (fraction or decimal)."+(r" Grey boxes show exactly what to type into your calculator or Desmos, one expression per line; for the graphing problem, tap a grey dot to read an intersection. Where a letter such as $x$ stands for another quantity, the step says so." if key else "")+r"\normalsize\par\vspace{4pt}")
    for i,p in enumerate(P,1):
        if i==nA+1: L.append(r"\par\needspace{9cm}\banner{Part B \textperiodcentered\ Self-assessment \textemdash\ %d problems}"%(len(P)-nA))
        t=problem_tex(i,p,mode).replace(r"\begin{minipage}{\linewidth}",r"\typeout{PROB %d}\begin{minipage}{\linewidth}\label{pr%d}"%(i,i),1)
        L.append(t)
    L.append(r"\end{document}")
    open(out,'w').write("\n".join(L))
res={}
for mode,out in (('ws','S6_ws.tex'),('key','S6_key.tex')):
    build_s6(mode,out)
    for _ in range(2): r=subprocess.run(['xelatex','-interaction=nonstopmode',out],capture_output=True,text=True)
    log=open(out[:-4]+'.log').read()
    errs=len(re.findall(r'^!',log,re.M)); ov=re.findall(r'Overfull \\[hv]box \(([\d.]+)pt too',log)
    # which problems overflow their key space
    over=[];cur=None
    for ln in r.stdout.split('\n') if False else []: pass
    for mm in re.finditer(r'PROB (\d+)|KEYOVER',open(out[:-4]+'.log').read()):
        if mm.group(1): cur=int(mm.group(1))
        else: over.append(cur)
    aux=open(out[:-4]+'.aux').read(); pages={int(a):int(b) for a,b in re.findall(r'\\newlabel\{pr(\d+)\}\{\{[^}]*\}\{(\d+)\}',aux)}
    res[mode]=dict(err=errs,overfull=ov,keyover=over,pages=pages)
    print(out,'errors',errs,'overfull',[float(x) for x in ov],'key-overflow problems',over)
print('pagination identical:',res['ws']['pages']==res['key']['pages'],len(res['ws']['pages']))
json.dump(res['key']['keyover'],open('keyover.json','w'))
