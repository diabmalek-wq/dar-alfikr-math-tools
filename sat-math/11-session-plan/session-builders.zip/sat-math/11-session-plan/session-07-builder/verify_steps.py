import re,math,json
import numpy as np
from scipy.optimize import brentq,minimize_scalar
from steps import S,ev
bad=0;cnt=0
for iid,steps in S.items():
    for st in steps:
        for m in re.finditer(r"\[\[([^\]]+)\]\]: it returns \$([^$]+)\$",st):
            expr,val=m.group(1),m.group(2).replace('{,}','')
            got=ev(expr); want=float(val); cnt+=1
            if abs(got-want)>6e-5*max(1,abs(want)): print('MISMATCH',iid,expr,got,want); bad+=1
print('returns checked',cnt,'mismatches',bad)
def chk(name,ok):
    global bad
    print('OK ' if ok else 'BAD',name); bad+=(not ok)
# tapped points / typed claims, recomputed independently
f1=lambda x:7*(3*x/4+18); f2=lambda x:5*(54+x/4); x0=brentq(lambda x:f1(x)-f2(x),0,500)
chk('116 intersection (36,315)',abs(x0-36)<1e-9 and abs(f1(x0)-315)<1e-9)
chk('116 check 45:63',(lambda a,b:(a,b)==(45,63))(3*36/4+18+0,54+36/4) and 45*7==63*5)
def var(x):
    v=[5,8,17,x,x];m=sum(v)/5;return sum((a-m)**2 for a in v)/5
r=minimize_scalar(var,bounds=(-50,50),method='bounded',options={'xatol':1e-10}); chk('094 vertex (10,15.6)',abs(r.x-10)<1e-4 and abs(var(10)-15.6)<1e-9)
# 094 typed expression equals var
e='((5-(30+2*x)/5)**2+(8-(30+2*x)/5)**2+(17-(30+2*x)/5)**2+2*(x-(30+2*x)/5)**2)/5'
chk('094 typed expr',all(abs(eval(e)-var(x))<1e-9 for x in (-3,0,4.5,10,20)))
g=lambda b:(3*b/5)/(3*b/5+(240-b)/4)-12/19; b0=brentq(g,1,239); chk('113 intersection (100,12/19)',abs(b0-100)<1e-8 and abs(12/19-0.6316)<5e-5)
chk('116 steps eq: 7A=5B typed',all(abs(f1(x)-7*((x-x/3)+(72+x/3)/4))<1e-9 for x in (6,36,50)))
chk('113 helmet count',3*100/5+(240-100)/4==95)
chk('102 SSD 1266/1248, var 126.6/156',sum((a-50)**2 for a in [31,38,42,45,47,52,53,58,65,69])==1266 and 1266-18==1248 and 1266/10==126.6 and 1248/8==156)
chk('118 median 14 vs 8.5',np.median([6,7,9,14,16,22,24])==14)
chk('078 mean 118/6',abs(118/6-19.6667)<1e-4)
chk('109 example',(lambda L:(sum(L)==108 and sorted(L)[4]==9))([1,1,1,1,9,9,9,9,68]))
chk('111 example',(lambda L:(sum(L)==101 and sorted(L)[3]==11))([1,1,1,11,11,11,65]))
chk('096 ME values',abs(math.sqrt(.25/625)-0.02)<1e-12 and abs(.09/1e-4-900)<1e-9)
chk('099',abs((27.8-24.2)/2/3-0.6)<1e-12 and 5625/625==9)
chk('034 96',abs(0.64*150-96)<1e-9)
print('total bad',bad); assert bad==0
