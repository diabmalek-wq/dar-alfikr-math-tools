import json,re,sys,subprocess,os
HERE=os.path.dirname(os.path.abspath(__file__)); os.chdir(HERE); sys.path.insert(0,HERE)
from lib import *
import lib as _lib
_orig_pt=_lib.problem_tex
def problem_tex(n,p,mode):
    t=_orig_pt(n,p,mode)
    if mode=='ws':   # same fixed-height work space as the key, so both PDFs paginate identically
        t,k=re.subn(r'\\par\\nopagebreak\\foreach \\i in \{1,\.\.\.,(\d+)\}\{.*?\\par\\vspace\{4pt\}',lambda m:r'\keyspace{%s}{}'%m.group(1),t,flags=re.S); assert k==1
    return t
import steps
from steps import S,T
ESC={'\\':r'\textbackslash{}','{':r'\{','}':r'\}','^':r'\textasciicircum{}','_':r'\_','~':r'\textasciitilde{}','#':r'\#','%':r'\%','&':r'\&','$':r'\$'}
def code(m):
    c=m.group(1).replace('\\{','{').replace('\\}','}')
    return r"\dzc{"+"".join(ESC.get(ch,ch) for ch in c)+"}"
def conv(s): return re.sub(r"\[\[(.+?)\]\]",code,s)
items=json.load(open('s7_items.json')); solved=json.load(open('solved.json'))
ANS_TEX={'PS-019':r"\dfrac{1}{5}\ \text{(or } 0.2\text{)}",'PS-022':r"\dfrac{1}{2}\ \text{(or } 0.5\text{)}"}
A=[o for o in items if o['part']=='In class']; B=[o for o in items if o['part']!='In class']
order=A+B; nA=len(A)
P=[]
for o in order:
    p=dict(lv='M' if o['d']=='Medium' else 'H',tool=T[o['id']],q=o['q'],id=o['id'])
    kind,val=solved[o['id']]
    if o['opts']:
        assert kind=='opt' and "ABCD"[val]==o['letter'],o['id']
        p['opts']=o['opts'];p['correct']="ABCD".index(o['letter']);p['norot']=True
        p['chk']=lambda c=p['correct']:('idx',c)
    else:
        assert kind=='val'
        p['val']=float(val); p['ans']=ANS_TEX.get(o['id']) or o['sans'].replace('{,}','{,}')
        p['chk']=lambda v=float(val):v
    p['steps']=[conv(x) for x in S[o['id']]]; p['lines']={'M':5,'H':6}[p['lv']]
    P.append(p)
P=prep(P)
meta=dict(title='Data Analysis and Statistics',code='SAT-M \\textperiodcentered\\ Session 7',headfull='Session 7 \\textemdash\\ Data Analysis and Statistics',
 time='3 hours: Part A in class (about 2 hours of solving), then Part B, the self-assessment, done independently (about 50 minutes), and a short error log.',
 topics='ratios, rates and unit conversion \\textperiodcentered\\ mean, median and mode from tables \\textperiodcentered\\ how adding, removing or changing values changes the mean and standard deviation \\textperiodcentered\\ box plots and spread \\textperiodcentered\\ sampling and study design \\textperiodcentered\\ margin of error and estimates \\textperiodcentered\\ probability and two-way tables \\textperiodcentered\\ scatterplots, slope and residuals')
MEASURE=r"""
\newcount\ksn
\renewcommand{\keyspace}[2]{\par\nopagebreak\global\advance\ksn by 1
 \setbox0\vbox{\hsize\linewidth\color{SOLGREEN}\small #2\par}%
 \setbox1\vbox{\foreach \i in {1,...,#1}{\par\vspace{0.74cm}{\color{LINE}\hrule height 0.4pt}}}%
 \typeout{KSP \the\ksn\space\the\ht0\space\the\ht1\space #1}%
 \ifdim\ht0>\ht1 \dimen2=\ht0 \else \dimen2=\ht1 \fi
 \vbox to \dimen2{\nointerlineskip\vbox to 0pt{\box1\vss}\nointerlineskip\box0\vss}\par\vspace{4pt}}
"""
def build_s(mode,out):
    key=(mode=='key')
    L=[PRE.replace("@@CODE@@",meta['code']).replace("@@HEAD@@",meta['headfull']).replace("\\begin{document}",EXTRA+MEASURE+r"\setmonofont[Scale=0.9]{DejaVu Sans Mono}\newcommand{\dzc}[1]{\colorbox{black!8}{\texttt{\small\textcolor{black}{#1}}}}"+"\n\\begin{document}")]
    L.append(r"""
\begin{tcolorbox}[enhanced,colback=NAVY!4,colframe=NAVY,boxrule=0.8pt,arc=3pt]
{\Large\bfseries\color{NAVY} SAT Math Mastery \textperiodcentered\ Session 7}\\[2pt]
{\large\bfseries %s}\\[3pt]
\begin{tabular}{@{}p{0.2\linewidth}p{0.75\linewidth}@{}}
\textbf{Time} & %s\\
\textbf{Topics} & %s\\
\textbf{Name / Date} & \rule{5.5cm}{0.3pt}\ \ \rule{3cm}{0.3pt}\\
\end{tabular}
\end{tcolorbox}
"""%(meta['title'],meta['time'],meta['topics']))
    L.append(r"\banner{Part A \textperiodcentered\ In class \textemdash\ %d problems}"%nA)
    L.append(r"\small Each problem states its tool. Write your work in the space below. Multiple choice: one correct option. Student-produced response (SPR): enter an exact value (fraction or decimal)."+(r" Grey boxes show exactly what to type in Desmos (or a calculator), one expression per line; tap a grey dot to read an intersection or a vertex." if key else "")+r"\normalsize\par\vspace{4pt}")
    for i,p in enumerate(P,1):
        if i==nA+1: L.append(r"\par\needspace{9cm}\banner{Part B \textperiodcentered\ Self-assessment \textemdash\ %d problems}"%(len(P)-nA))
        L.append(problem_tex(i,p,mode))
    L.append(r"\end{document}")
    open(out,'w').write("\n".join(L))
def fit_lines():
    """size the work space of every problem so the solution always fits inside it (identical pagination in both PDFs)"""
    import math
    for it in range(4):
        build_s('key','S7_key.tex')
        r=subprocess.run(['xelatex','-interaction=nonstopmode','S7_key.tex'],capture_output=True,text=True)
        rows=re.findall(r'KSP (\d+) ([\d.]+)pt\s*([\d.]+)pt\s*(\d+)',open('S7_key.log').read())
        assert len(rows)==len(P),(len(rows),len(P))
        changed=False
        for (i,h0,h1,k),p in zip(rows,P):
            unit=float(h1)/int(k)
            need=math.ceil(float(h0)/unit-1e-6)+0
            if need>p['lines']: p['lines']=need; changed=True
        if not changed: break
if __name__=='__main__':
    fit_lines()
    for mode,out in (('ws','S7_ws.tex'),('key','S7_key.tex')):
        build_s(mode,out)
        for _ in range(2): r=subprocess.run(['xelatex','-interaction=nonstopmode',out],capture_output=True,text=True)
        log=open(out[:-4]+'.log').read();print(out,'overfull',log.count('Overfull'),'err',len(re.findall(r'^!',log,re.M)))
    json.dump([[p['id'],p['correct'] if p.get('opts') else p['val']] for p in P],open('keyed.json','w'))
