"""Worked-solution steps for Session 4. Every number quoted in a step is computed here (Fractions / numpy / ev), never typed by hand.
[[expr]] = text typed in Desmos (grey box). ret()/pt()/c() as in Session 2."""
import math, re
from fractions import Fraction as Fr
import numpy as np

def n(v, d=4):
    s = ('%.*f' % (d, v)).rstrip('0').rstrip('.')
    return '0' if s in ('-0', '') else s
def ev(expr, **kw):
    e = expr.replace('^', '**')
    e = re.sub(r'(\d|\))\s*(\(|[a-zA-Z])', r'\1*\2', e)
    env = dict(sqrt=math.sqrt, abs=abs, ln=math.log, **kw)
    return eval(e, {'__builtins__': {}}, env)
def c(e): return '[[%s]]' % e
def v(x, d=4): return '$%s$' % n(x, d)
def ret(e, d=4, **kw): return "Type %s: it returns %s" % (c(e), v(ev(e, **kw), d))
def pt(x, y, d=4): return "$(%s,\\,%s)$" % (n(x, d), n(y, d))
def L(x):
    """latex for int / Fraction / float"""
    if isinstance(x, float):
        f = Fr(x).limit_denominator(1000)
        x = f if abs(float(f) - x) < 1e-12 else None
        if x is None: raise ValueError('float not rational')
    x = Fr(x)
    if x.denominator == 1: return str(x.numerator)
    s = '-' if x < 0 else ''
    return '%s\\dfrac{%d}{%d}' % (s, abs(x.numerator), x.denominator)
def t(s, /, **kw):
    for k, val in kw.items(): s = s.replace('@%s@' % k, str(val))
    assert '@' not in s.replace('@@L@@', ''), s
    return s
def _trim(co):
    co = [int(round(x)) for x in co]
    while len(co) > 1 and co[0] == 0: co = co[1:]
    return co
def poly_mul(a, b): return _trim(np.polymul(a, b))
def psub(a, b): return _trim(np.polysub(a, b))
def padd(a, b): return _trim(np.polyadd(a, b))
def pstr(co, var='x'):
    """latex for polynomial with integer coeffs (highest first)"""
    out = ''; deg = len(co) - 1
    for i, a in enumerate(co):
        a = Fr(a); e = deg - i
        if a == 0: continue
        sgn = '-' if a < 0 else '+'; m = abs(a)
        body = ('' if (m == 1 and e > 0) else (str(m.numerator) if m.denominator == 1 else '\\dfrac{%d}{%d}' % (m.numerator, m.denominator)))
        xx = '' if e == 0 else (var if e == 1 else '%s^{%d}' % (var, e))
        if e == 0 and body == '': body = '1'
        term = body + xx
        out += (('-' if sgn == '-' else '') if not out else (' - ' if sgn == '-' else ' + ')) + term
    return out or '0'

S = {}; T = {}; ENV = {}; CLAIMS = []

# ---------------------------------------------------------------- 245
b_sq, four_ac = 3 ** 2, 4 * 1 * 4
p245 = math.sqrt(Fr(48 * 3, 4)); p245 = int(p245); q245 = -Fr(4 * p245, 3)
assert p245 ** 2 == 36 and q245 == -8
S['AM-245'] = [t("Exactly one real solution means the discriminant is zero: $(3q)^2-4(p)(4p)=0$, which is $@a@q^2=@b@p^2$. So $3q=\\pm4p$, that is $q=\\pm\\dfrac{4p}{3}$.", a=b_sq, b=four_ac),
               t("The product $pq=-48$ is negative and $p>0$, so $q<0$. Take $q=-\\dfrac{4p}{3}$: then $pq=-\\dfrac{4p^2}{3}=-48$, so $p^2=@p2@$.", p2=p245 ** 2),
               t("Since $p>0$, $p=@p@$, and $q=-\\dfrac{4\\cdot@p@}{3}=@q@$.", p=p245, q=L(q245)),
               t("$p+q=@p@+(@q@)=@s@$. Option (@@L@@).", p=p245, q=L(q245), s=p245 + q245)]
T['AM-245'] = 'N'

# ---------------------------------------------------------------- 263
r263 = Fr(9 - 3, 2)
S['AM-263'] = ["Call the solutions $r$ and $r+3$. Their sum is the opposite of the $x$-coefficient, so it is $9$.",
               t("$r+(r+3)=9$ gives $2r=@a@$, so $r=@r@$. The solutions are $@r@$ and $@r3@$.", a=9 - 3, r=r263, r3=r263 + 3),
               t("The constant term is the product of the solutions: $k=@r@\\cdot@r3@=@k@$.", r=r263, r3=r263 + 3, k=r263 * (r263 + 3)),
               t("Check: $(x-@r@)(x-@r3@)=x^2-@s@x+@k@$.", r=r263, r3=r263 + 3, s=2 * r263 + 3, k=r263 * (r263 + 3))]
T['AM-263'] = 'N'

# ---------------------------------------------------------------- 264
sum264 = Fr(10, 2); c264 = 6 * 2; disc264 = 10 ** 2 - 4 * 2 * c264; assert disc264 == 4
S['AM-264'] = [t("For $ax^2+bx+c=0$ the solutions have sum $-\\dfrac ba$ and product $\\dfrac ca$. Here the sum is $\\dfrac{10}{2}=@s@$.", s=sum264),
               t("The product is $\\dfrac c2=6$, so $c=@c@$. The solutions are real because the discriminant is $10^2-4\\cdot2\\cdot@c@=@d@>0$.", c=c264, d=disc264),
               t("Add the reciprocals over a common denominator: $\\dfrac1r+\\dfrac1s=\\dfrac{r+s}{rs}$.", ),
               t("$\\dfrac{r+s}{rs}=\\dfrac{@s@}{6}=\\dfrac56$. Option (@@L@@).", s=sum264)]
T['AM-264'] = 'N'

# ---------------------------------------------------------------- 265
s265, p265 = 7, 3
S['AM-265'] = [t("For $x^2-7x+3=0$ the sum of the solutions is $r+s=@s@$ and the product is $rs=@p@$.", s=s265, p=p265),
               "Square the sum: $(r+s)^2=r^2+2rs+s^2$, so $r^2+s^2=(r+s)^2-2rs$.",
               t("$r^2+s^2=@s@^2-2\\cdot@p@=@a@-@b@=@r@$.", s=s265, p=p265, a=s265 ** 2, b=2 * p265, r=s265 ** 2 - 2 * p265)]
T['AM-265'] = 'N'

# ---------------------------------------------------------------- 266
p2, q2 = 2, 3; assert p2 + q2 == 5 and p2 * q2 == 6
S['AM-266'] = [t("Factor: $x^2-5x+6=(x-@p@)(x-@q@)$, so $p=@p@$ and $q=@q@$.", p=p2, q=q2),
               t("The new solutions are $2p=@a@$ and $2q=@b@$. Their sum is $@s@$ and their product is $@m@$.", a=2 * p2, b=2 * q2, s=2 * p2 + 2 * q2, m=4 * p2 * q2),
               t("An equation with sum $S$ and product $P$ is $x^2-Sx+P=0$, so it is $x^2-@s@x+@m@=0$.", s=2 * p2 + 2 * q2, m=4 * p2 * q2),
               t("Check: $(x-@a@)(x-@b@)=x^2-@s@x+@m@$. Option (@@L@@).", a=2 * p2, b=2 * q2, s=2 * p2 + 2 * q2, m=4 * p2 * q2)]
T['AM-266'] = 'N'

# ---------------------------------------------------------------- 267
r267 = int(math.sqrt(27 // 3)); b267 = 4 * r267; assert 3 * r267 ** 2 == 27
S['AM-267'] = ["Call the solutions $r$ and $3r$. The product of the solutions is the constant term, and the sum is $b$.",
               t("Product: $r\\cdot3r=3r^2=27$, so $r^2=@a@$ and $r=\\pm@r@$.", a=27 // 3, r=r267),
               t("Sum: $b=r+3r=4r$. Since $b$ is positive, take $r=@r@$: $b=@b@$.", r=r267, b=b267),
               t("Check: $x^2-@b@x+27=(x-@r@)(x-@r3@)$.", b=b267, r=r267, r3=3 * r267)]
T['AM-267'] = 'N'

# ---------------------------------------------------------------- 268 (Desmos)
u268 = 1 + math.sqrt(10); xa, xb = 3 - u268, 3 + u268; y268 = 2 * abs(xa - 3)
assert abs(xa * xa - 6 * xa - y268) < 1e-9 and abs(xb * xb - 6 * xb - y268) < 1e-9
S['AM-268'] = ["Type %s and %s." % (c('y=x^2-6x'), c('y=2abs(x-3)')),
               "Tap both intersections: %s and %s." % (pt(xa, y268), pt(xb, y268)),
               ret('%s+%s' % (n(xa), n(xb))) + ", so the sum of the solutions is $6$.",
               "Why: the parabola and the V both have their axis at $x=3$, so the two points are the same distance from $3$ and their $x$-values add to $2\\cdot3$. Option (@@L@@)."]
T['AM-268'] = 'D'
CLAIMS.append(('268 intersections', lambda: abs(xa * xa - 6 * xa - 2 * abs(xa - 3)) < 1e-9 and abs(xb * xb - 6 * xb - 2 * abs(xb - 3)) < 1e-9 and abs(round(xa, 4) + round(xb, 4) - 6) < 1e-9))

# ---------------------------------------------------------------- 269 (Desmos)
S['AM-269'] = ["Type %s and %s." % (c('y=x/(x-4)'), c('y=2+4/(x-4)')),
               "The curves never touch. The second is always above the first: " + ret('2+4/(5-4)') + " and " + ret('5/(5-4)')[0].lower() + ret('5/(5-4)')[1:] + " at $x=5$, and " + ret('2+4/(8-4)') + " and " + ret('8/(8-4)')[0].lower() + ret('8/(8-4)')[1:] + " at $x=8$.",
               t("Algebra agrees. Multiply by $x-4$: $x=2(x-4)+4$, so $x=2x-@a@$ and $x=@x@$.", a=2 * 4 - 4, x=4),
               "But $x=4$ makes the denominator $0$, so it is not allowed. The equation has no solution. Option (@@L@@)."]
T['AM-269'] = 'D'

# ---------------------------------------------------------------- 179
b179 = Fr(8 - 2, 2); a179_roots = sorted([Fr(1, 2), Fr(9, 2)])
qa = poly_mul([2, -1], [2, -9]); assert qa == [4, -20, 9]
S['AM-179'] = [t("$f(1)=a+b+c=8$ and $f(-1)=a-b+c=2$. Subtract: $2b=@d@$, so $b=@b@$. Then $a+c=@s@$, so $c=@s@-a$.", d=8 - 2, b=b179, s=8 - b179),
               t("One $x$-intercept means the discriminant is zero: $b^2-4ac=0$, so $@b2@-4a(@s@-a)=0$, which is $@A@a^2-@B@a+@C@=0$.", b2=b179 ** 2, s=8 - b179, A=qa[0], B=-qa[1], C=qa[2]),
               t("Factor: $(2a-1)(2a-9)=@A@a^2-@B@a+@C@$, so $a=\\dfrac12$ or $a=\\dfrac92$.", A=qa[0], B=-qa[1], C=qa[2]),
               t("The greatest possible value is $a=\\dfrac92$. Option (@@L@@).")]
T['AM-179'] = 'N'

# ---------------------------------------------------------------- 012
d12 = poly_mul([1, -4], [1, 1]); num12 = psub(poly_mul([3], [1, 1]), poly_mul([2], [1, -4]))
assert num12 == [1, 11] and d12 == [1, -3, -4]
S['AM-012'] = [t("Use the common denominator $(x-4)(x+1)=@d@$.", d=pstr(d12)),
               "Rewrite each fraction: $\\dfrac{3(x+1)}{(x-4)(x+1)}-\\dfrac{2(x-4)}{(x-4)(x+1)}$.",
               t("The numerator is $3(x+1)-2(x-4)=3x+3-2x+8=@n@$. Watch the sign on $-2\\cdot(-4)$.", n=pstr(num12)),
               t("Check at $x=0$: $\\dfrac3{-4}-\\dfrac21=@l@$ and $\\dfrac{11}{-4}=@r@$. Option (@@L@@).", l=L(Fr(3, -4) - 2), r=L(Fr(11, -4)))]
assert Fr(3, -4) - 2 == Fr(11, -4)
T['AM-012'] = 'N'

# ---------------------------------------------------------------- 023 (changed)
den23 = poly_mul([1, 2], [1, -1]); assert den23 == [1, 1, -2]
num23 = padd(poly_mul([5], [1, -1]), [3, 0]); assert num23 == [8, -5]
S['AM-023'] = [t("Factor the second denominator: $x^2+x-2=(x+2)(x-1)$. This is the common denominator.", ),
               t("Only the first fraction needs rewriting: $\\dfrac{5}{x+2}=\\dfrac{5(x-1)}{(x+2)(x-1)}=\\dfrac{@a@}{x^2+x-2}$.", a=pstr(list(poly_mul([5], [1, -1])))),
               t("Add the numerators: $(@a@)+3x=@n@$. So the sum is $\\dfrac{@n@}{x^2+x-2}$.", a=pstr(list(poly_mul([5], [1, -1]))), n=pstr(num23)),
               t("Check at $x=0$: $\\dfrac52+0=@l@$ and $\\dfrac{-5}{-2}=@r@$. Option (@@L@@).", l=L(Fr(5, 2)), r=L(Fr(-5, -2)))]
T['AM-023'] = 'N'

# ---------------------------------------------------------------- 024
num24 = psub([1, 3], [1, -1]); assert num24 == [4]
S['AM-024'] = ["Write $1$ with the same denominator: $1=\\dfrac{x-1}{x-1}$.",
               t("Subtract the numerators and keep the brackets: $(x+3)-(x-1)=x+3-x+1=@n@$.", n=int(num24[0])),
               t("So $x^{\\odot}-1=\\dfrac{@n@}{x-1}$.", n=int(num24[0])),
               t("Check at $x=3$: $\\dfrac{6}{2}-1=@l@$ and $\\dfrac{4}{2}=@r@$. Option (@@L@@).", l=Fr(6, 2) - 1, r=Fr(4, 2))]
T['AM-024'] = 'N'

# ---------------------------------------------------------------- 043
h43 = Fr(2 + (-6), 2); k43coef = (h43 - 2) * (h43 + 6)
assert h43 == -2 and k43coef == -16
S['AM-043'] = ["The expression $a(x-2)(x+6)$ has zeros $2$ and $-6$; the vertex form $a(x-h)^2+k$ has its vertex halfway between them.",
               t("$h=\\dfrac{2+(-6)}{2}=@h@$.", h=h43),
               t("$k$ is the value at the vertex: $a(@h@-2)(@h@+6)=a(@p@)(@q@)=@k@a$.", h=h43, p=h43 - 2, q=h43 + 6, k=k43coef),
               t("Check: $a(x+2)^2-16a=a(x^2+4x+4)-@m@a=a(x^2+4x-12)=a(x-2)(x+6)$. Option (@@L@@).", m=-k43coef)]
T['AM-043'] = 'N'

# ---------------------------------------------------------------- 058
fac58 = [(p_, q_) for p_ in range(-15, 16) for q_ in range(-15, 16) if p_ * q_ == -15 and p_ + q_ == -2 and p_ < q_]; assert fac58 == [(-5, 3)]
S['AM-058'] = ["Let $u=x^2$. The expression becomes $u^2-2u-15$.",
               t("Find two numbers with product $-15$ and sum $-2$: they are $@p@$ and $@q@$. So $u^2-2u-15=(u-5)(u+3)$.", p=fac58[0][0], q=fac58[0][1]),
               "Put $x^2$ back: $(x^2-5)(x^2+3)$.",
               t("Check the middle term: $x^4+3x^2-5x^2-15=x^4+(@m@)x^2-15$. Option (@@L@@).", m=3 - 5)]
T['AM-058'] = 'N'

# ---------------------------------------------------------------- 081
S['AM-081'] = ["For $x>1$, equal powers have equal exponents. Dividing powers subtracts exponents: $a^2-b^2=20$.",
               t("Factor the difference of squares: $(a-b)(a+b)=20$.", ),
               t("Substitute $a+b=4$: $(a-b)\\cdot4=20$, so $a-b=@r@$.", r=20 // 4),
               t("Check: $a=\\dfrac{4+5}{2}=@a@$, $b=\\dfrac{4-5}{2}=@b@$, and $a^2-b^2=@x@-@y@=@z@$.", a=L(Fr(9, 2)), b=L(Fr(-1, 2)), x=L(Fr(81, 4)), y=L(Fr(1, 4)), z=Fr(81, 4) - Fr(1, 4))]
assert Fr(81, 4) - Fr(1, 4) == 20
T['AM-081'] = 'N'

# ---------------------------------------------------------------- 089
S['AM-089'] = ["Take the first equality, $\\sqrt x=x\\sqrt x$. Since $x>0$, divide both sides by $\\sqrt x$: $1=x$.",
               t("Check the whole chain at $x=1$: $\\sqrt1=@a@$, $1\\cdot\\sqrt1=@b@$, $1^2=@c@$, $\\sqrt{1^2}=@d@$.", a=1, b=1, c=1, d=1),
               "All four are equal, so $x=1$."]
T['AM-089'] = 'N'

# ---------------------------------------------------------------- 090
te = Fr(-1, 2) * 3; se = -te / 2; assert se == Fr(3, 4)
S['AM-090'] = [t("Cube both sides of $t^{1/3}=u^{-1/2}$: $t=u^{-1/2\\cdot3}=u^{@e@}$.", e=L(te)),
               t("Then $s^2=t^{-1}=\\left(u^{@e@}\\right)^{-1}=u^{@f@}$.", e=L(te), f=L(-te)),
               t("Take the positive square root ($s>0$): halve the exponent, $s=u^{@g@}$. Option (@@L@@).", g=L(se))]
T['AM-090'] = 'N'

# ---------------------------------------------------------------- 097 (changed)
num97 = psub([3, 1], poly_mul([3], [1, -2])); assert num97 == [7]
S['AM-097'] = ["Write $3$ with the same denominator: $3=\\dfrac{3(x-2)}{x-2}$.",
               t("Subtract the numerators and keep the brackets: $(3x+1)-3(x-2)=3x+1-3x+6=@n@$.", n=int(num97[0])),
               t("So $\\langle x\\rangle-3=\\dfrac{@n@}{x-2}$.", n=int(num97[0])),
               t("Check at $x=3$: $\\dfrac{10}{1}-3=@l@$ and $\\dfrac{7}{1}=@r@$. Option (@@L@@).", l=Fr(10, 1) - 3, r=Fr(7, 1))]
T['AM-097'] = 'N'

# ---------------------------------------------------------------- 098
e98 = Fr(3, 4) + Fr(1, 2); assert e98 == Fr(5, 4)
S['AM-098'] = [t("From $a^4=b^3$, take the fourth root: $a=b^{@e@}$.", e=L(Fr(3, 4))),
               t("Also $\\sqrt b=b^{@e@}$.", e=L(Fr(1, 2))),
               t("Multiply, adding exponents: $a\\sqrt b=b^{@x@+@y@}=b^{@z@}$. Option (@@L@@).", x=L(Fr(3, 4)), y=L(Fr(1, 2)), z=L(e98))]
T['AM-098'] = 'N'

# ---------------------------------------------------------------- 106
S['AM-106'] = ["A negative exponent flips the base: $x^{-1}=\\dfrac1x$ and $(3y)^{-1}=\\dfrac1{3y}$.",
               "Dividing by $\\dfrac1{3y}$ means multiplying by $3y$: $\\dfrac{x^{-1}}{(3y)^{-1}}=\\dfrac{1}{x}\\cdot3y=\\dfrac{3y}{x}$.",
               t("Multiply: $\\dfrac{3x}{y}\\cdot\\dfrac{3y}{x}=\\dfrac{@a@xy}{xy}=@a@$. Option (@@L@@).", a=9)]
T['AM-106'] = 'N'

# ---------------------------------------------------------------- 109
S['AM-109'] = ["The two $c$'s cancel: $\\dfrac{\\sqrt{c+7}}{c}\\cdot c\\sqrt c=\\sqrt{c+7}\\cdot\\sqrt c$.",
               t("Put in $c=9$: $\\sqrt{9+7}\\cdot\\sqrt9=\\sqrt{@a@}\\cdot@b@$.", a=16, b=3),
               t("$@r@\\cdot@b@=@p@$.", r=4, b=3, p=12)]
assert math.isqrt(16) == 4 and math.isqrt(9) == 3 and 4 * 3 == 12
T['AM-109'] = 'N'

# ---------------------------------------------------------------- 110 (calculator)
in1, in2 = Fr(5, 9), Fr(4, 3 * -3); sm = in1 + in2; assert sm == Fr(1, 9)
S['AM-110'] = [t("Put $a=-3$ inside: $\\dfrac{5}{a^2}=\\dfrac{5}{9}$ and $\\dfrac{4}{3a}=\\dfrac{4}{-9}=-\\dfrac{4}{9}$.", ),
               t("The sum is $\\dfrac59-\\dfrac49=\\dfrac19$, so the expression is $\\left(\\dfrac19\\right)^{-3}$.", ),
               "Enter all of it, with brackets round the negative exponent: " + ret('(5/9+4/(3*(-3)))^(-3)') + ".",
               t("By hand: a negative exponent flips the fraction, so $\\left(\\dfrac19\\right)^{-3}=9^3=@r@$.", r=9 ** 3)]
T['AM-110'] = 'C'

# ---------------------------------------------------------------- 115
f1 = [(p_, q_) for p_ in range(-15, 16) for q_ in range(-15, 16) if p_ * q_ == -15 and p_ + q_ == -2 and p_ < q_][0]
f2 = [(p_, q_) for p_ in range(-15, 16) for q_ in range(-15, 16) if p_ * q_ == -6 and p_ + q_ == 1 and p_ < q_][0]
assert f1 == (-5, 3) and f2 == (-2, 3)
S['AM-115'] = [t("Factor the top: two numbers with product $-15$ and sum $-2$ are $@p@$ and $@q@$, so $x^2-2x-15=(x-5)(x+3)$.", p=f1[0], q=f1[1]),
               t("Factor the bottom: product $-6$ and sum $1$ give $@p@$ and $@q@$, so $x^2+x-6=(x-2)(x+3)$.", p=f2[0], q=f2[1]),
               "Cancel $(x+3)$ (allowed since $x\\ne-3$): $\\dfrac{x-5}{x-2}=\\dfrac{x+a}{x+b}$, so $a=-5$ and $b=-2$.",
               t("$a-b=-5-(-2)=@r@$.", r=-5 - (-2))]
T['AM-115'] = 'N'

# ---------------------------------------------------------------- 118
S['AM-118'] = ["Look for a way to turn the exponent $\\dfrac34$ into $-\\dfrac32$: multiply by $-2$.",
               t("$a^{-3/2}=\\left(a^{3/4}\\right)^{-2}$ because $\\dfrac34\\cdot(-2)=@e@$.", e=L(Fr(3, 4) * -2)),
               t("So $a^{-3/2}=5^{-2}=\\dfrac1{@s@}=\\dfrac1{25}$, which is $@d@$ as a decimal.", s=5 ** 2, d=n(1 / 25))]
T['AM-118'] = 'N'

# ---------------------------------------------------------------- 127
ra = [2 + math.sqrt(3), 2 - math.sqrt(3)]; vals127 = [(x + 1) / (x - 1) for x in ra]
S['AM-127'] = ["Add and subtract $2ab$: $(a+b)^2=a^2+b^2+2ab=4ab+2ab=6ab$ and $(a-b)^2=a^2+b^2-2ab=4ab-2ab=2ab$.",
               t("Divide: $\\left(\\dfrac{a+b}{a-b}\\right)^2=\\dfrac{@x@ab}{@y@ab}=@z@$ ($ab\\ne0$ because $b\\ne0$ and $a=0$ would force $b=0$).", x=6, y=2, z=3),
               t("So $\\dfrac{a+b}{a-b}=\\pm\\sqrt3$. Both signs happen: with $b=1$, $a=2\\pm\\sqrt3$ gives $@p@$ and $@q@$.", p=n(vals127[0]), q=n(vals127[1])),
               "The only option that lists both is (@@L@@)."]
assert abs(vals127[0] - math.sqrt(3)) < 1e-9 and abs(vals127[1] + math.sqrt(3)) < 1e-9
T['AM-127'] = 'N'

# ---------------------------------------------------------------- 131
S['AM-131'] = ["Put the right side over the denominator $x+2$: $3-\\dfrac{11}{x+2}=\\dfrac{3(x+2)-11}{x+2}$.",
               t("The numerator is $3x+6-11=@n@$.", n=pstr([3, 6 - 11])),
               t("Match $ax+b$ with $3x-5$: $a=3$ and $b=-5$.", ),
               t("$ab=3\\cdot(-5)=@r@$.", r=3 * -5)]
T['AM-131'] = 'N'

# ---------------------------------------------------------------- 133 (Desmos)
a133, b133 = 4, 5; roots133 = sorted(np.roots([2, -33, 100]).real); d133 = 20 / roots133[1]
assert abs(roots133[0] - 4) < 1e-9 and abs(roots133[1] - 12.5) < 1e-9 and abs(d133 - 1.6) < 1e-9
S['AM-133'] = ["Expand $(5x^2+c)(2x^2+d)=10x^4+(5d+2c)x^2+cd$. Matching gives $cd=20$ and $5d+2c=33$ (the same for $a,b$).",
               "Put $d=\\dfrac{20}{c}$ into $5d+2c=33$ and multiply by $c$: $100+2c^2=33c$, so $2c^2-33c+100=0$. Type %s (letting $x$ stand for $c$)." % c('y=2x^2-33x+100'),
               "Tap the zeros: %s and %s. The whole-number one gives $a=4$ (with $b=5$). The other, $c=12.5$, gives %s." % (pt(roots133[0], 0), pt(roots133[1], 0), ret('20/12.5')[ret('20/12.5').index('it returns'):].replace('it returns', 'd=') .replace('$', '$') ),
               ret('4+1.6') + ", which is $\\dfrac{28}{5}$."]
S['AM-133'][2] = "Tap the zeros: %s and %s. The whole-number zero $4$ is $a$ (with $b=5$). The other zero is $c=12.5$, and then " % (pt(roots133[0], 0), pt(roots133[1], 0)) + ret('20/12.5').replace('Type', 'type', 1) + ", so $d=1.6$ is a positive nonintegral value."
T['AM-133'] = 'D'
CLAIMS.append(('133 roots', lambda: abs(2 * 4 ** 2 - 33 * 4 + 100) < 1e-9 and abs(2 * 12.5 ** 2 - 33 * 12.5 + 100) < 1e-9 and abs(5 * 1.6 + 2 * 12.5 - 33) < 1e-9 and abs(4 * 5 - 20) < 1e-9 and 5 * 5 + 2 * 4 == 33))

# ---------------------------------------------------------------- 149 (Desmos)
f149 = lambda x: (40 * x + 100) / (2 * x * x - 5 * x - 25) + (2 * x * x - 10 * x) / (8 * x)
g149 = lambda x: (x * x - 10 * x + 105) / (4 * (x - 5))
h149 = lambda x: (x * x - 10 * x + 105) / (4 * (2 * x + 5))
ENV['AM-149'] = dict(f=f149, g=g149, h=h149)
S['AM-149'] = ["The letter $y$ cancels in the second fraction (since $y>0$), so test with $y=2$. Type %s and look at $x>5$." % c('f(x)=(40x+100)/(2x^2-5x-25)+(2x^2-10x)/(8x)'),
               "Type each option as its own graph, for example %s and %s. Graph $g$ lies exactly on $f$; graph $h$ does not." % (c('g(x)=(x^2-10x+105)/(4(x-5))'), c('h(x)=(x^2-10x+105)/(4(2x+5))')),
               "Confirm at $x=7$: " + ret('f(7)', **ENV['AM-149']) + "; " + ret('g(7)', **ENV['AM-149']) + " (same); " + ret('h(7)', **ENV['AM-149']) + " (different). Option (@@L@@).",
               t("Algebra: $\\dfrac{40x+100}{2x^2-5x-25}=\\dfrac{20(2x+5)}{(2x+5)(x-5)}=\\dfrac{20}{x-5}$ and the second fraction is $\\dfrac{x-5}{4}$. Over $4(x-5)$ the numerator is $@a@+(x-5)^2=x^2-10x+@b@$.", a=4 * 20, b=80 + 25)]
T['AM-149'] = 'D'

# ---------------------------------------------------------------- 167
u167 = math.sqrt(72 / 2); p167 = u167; q167 = u167 / 2
assert abs(p167 ** 2 + 4 * q167 ** 2 - 72) < 1e-9 and abs(p167 * q167 - 18) < 1e-9
S['AM-167'] = ["Expand: $(2x+p)(x+q)=2x^2+(2q+p)x+pq$, so $c=pq$.",
               t("Let $u=2q$, so $p^2+u^2=@s@$ and $c=pq=\\dfrac{pu}{2}$. Since $(p-u)^2\\ge0$, we have $2pu\\le p^2+u^2=@s@$, so $pu\\le@h@$.", s=72, h=72 // 2),
               t("Therefore $c=\\dfrac{pu}{2}\\le\\dfrac{@h@}{2}=@m@$, with equality when $p=u$.", h=36, m=36 // 2),
               t("That happens at $p=@p@$ and $q=@q@$: $p^2+4q^2=@x@+@y@=72$ and $pq=@m@$.", p=int(p167), q=int(q167), x=int(p167 ** 2), y=int(4 * q167 ** 2), m=int(round(p167 * q167))), ]
T['AM-167'] = 'N'

# ---------------------------------------------------------------- 170
pp = Fr(-5 + 3, 2); qq_ = Fr(9, -3); cc170 = 2 * qq_ - 3 * pp
assert pp == -1 and qq_ == -3 and cc170 == -3
S['AM-170'] = ["Expand the left side: $(2x-3)(x^2+px+q)=2x^3+(2p-3)x^2+(2q-3p)x-3q$.",
               t("Match the $x^2$ terms: $2p-3=-5$, so $p=@p@$. Match the constant terms: $-3q=9$, so $q=@q@$.", p=pp, q=qq_),
               t("Match the $x$ terms: $c=2q-3p=2(@q@)-3(@p@)=@a@+@b@=@c@$.", p=pp, q=qq_, a=2 * qq_, b=-3 * pp, c=cc170)]
T['AM-170'] = 'N'

# ---------------------------------------------------------------- 172
e172 = Fr(1, 3) + Fr(3, 4) - Fr(1, 6); assert e172 == Fr(11, 12)
x172 = Fr(11, 3) / e172; assert x172 == 4
S['AM-172'] = [t("Combine the exponents of $x$: $\\dfrac13+\\dfrac34-\\dfrac16=\\dfrac{@a@+@b@-@c@}{12}=@e@$.", a=4, b=9, c=2, e=L(e172)),
               t("So the left side is $x^{@e@}$, and the right side is $\\sqrt[3]{k}=\\left(2^{11}\\right)^{1/3}=2^{@r@}$.", e=L(e172), r=L(Fr(11, 3))),
               t("Raise both sides to the power $\\dfrac{12}{11}$: $x=2^{\\frac{11}{3}\\cdot\\frac{12}{11}}=2^{@x@}$. Option (@@L@@).", x=L(x172))]
T['AM-172'] = 'N'

# ---------------------------------------------------------------- 175
coef175 = 1 + 4 - 2
chk175 = Fr(((2 ** 3) ** 3 + 4 * 2 ** 9 - 2 * 2 * (2 ** 4) ** 2), 2 ** 7); assert chk175 == 3 * 4
S['AM-175'] = ["Simplify each power: $\\left(x^{2n+1}\\right)^3=x^{6n+3}$, and $2x\\left(x^{3n+1}\\right)^2=2x\\cdot x^{6n+2}=2x^{6n+3}$.",
               t("The numerator is $x^{6n+3}+4x^{6n+3}-2x^{6n+3}=(1+4-2)x^{6n+3}=@c@x^{6n+3}$.", c=coef175),
               t("Divide by $x^{6n+1}$: $@c@x^{(6n+3)-(6n+1)}=@c@x^{@d@}$.", c=coef175, d=2),
               t("Check with $n=1$, $x=2$: the fraction is $\\dfrac{512+2048-1024}{128}=@r@$ and $3x^2=@r@$. Option (@@L@@).", r=chk175)]
T['AM-175'] = 'N'

# ---------------------------------------------------------------- 176
x176 = Fr(6) / (Fr(3, 8) + Fr(3, 4)); assert x176 == Fr(16, 3)
S['AM-176'] = ["Since $k\\ne3$, the factor $(k-3)$ cancels: $\\dfrac{4(k-3)}{x(k-3)}=\\dfrac4x$.",
               t("Add the terms with $x$: $\\dfrac4x+\\dfrac2x=\\dfrac6x$, so $\\dfrac6x-\\dfrac34=\\dfrac38$.", ),
               t("$\\dfrac6x=\\dfrac38+\\dfrac34=\\dfrac{@a@}{8}$.", a=3 + 6),
               t("Cross-multiply: $x=\\dfrac{6\\cdot8}{9}=\\dfrac{@n@}{@d@}$.", n=x176.numerator, d=x176.denominator)]
T['AM-176'] = 'N'

# ---------------------------------------------------------------- 178 (calculator)
base178 = 9 * 12 / 8; f2_178 = 12 * base178 ** 2
S['AM-178'] = ["Combine the powers: $\\dfrac{9^x\\cdot12^{x+1}}{8^x}=12\\left(\\dfrac{9\\cdot12}{8}\\right)^x$. " + ret('9*12/8') + ", which is $\\dfrac{27}{2}$. So $f(x)=12\\left(\\dfrac{27}{2}\\right)^x$.",
               "Find $f(2)$: " + ret('12*13.5^2') + ".",
               "To show $f(2)$ as the coefficient, write $f(x)=f(2)\\left(\\dfrac{27}{2}\\right)^{x-2}$, that is $2187\\left(\\dfrac{27}{2}\\right)^{x-2}$.",
               "Why not the others: " + ret('13.5^2') + " is only $\\left(\\dfrac{27}{2}\\right)^2$ (the factor $12$ is missing), and " + ret('12*13.5') + " is $f(1)$, not $f(2)$. Option (@@L@@)."]
assert abs(f2_178 - 2187) < 1e-9
T['AM-178'] = 'C'

# ---------------------------------------------------------------- 182
ks182 = sorted({a * d + b * cc for a in range(-6, 7) for cc in range(-6, 7) for b in (-5, -1, 1, 5) for d in (-5, -1, 1, 5) if a * cc == 6 and b * d == 5})
pos182 = [k for k in ks182 if k > 0]; assert pos182 == [11, 13, 17, 31]
S['AM-182'] = ["Matching the constants: $bd=5$, so $b,d$ are odd (one of $\\pm1,\\pm5$). Matching the $x^2$ terms: $ac=6$. The middle coefficient is $k=ad+bc$.",
               t("Try $b=1$, $d=5$ and the pairs $(a,c)=(1,6),(2,3),(3,2),(6,1)$: $k=5a+c$ gives $@k@$. The other choices of $b,d$ give these values or their negatives.", k=', '.join(str(5 * a_ + c_) for a_, c_ in [(1, 6), (2, 3), (3, 2), (6, 1)])),
               t("I: exactly one of $a,c$ is even and $b,d$ are odd, so $k=ad+bc$ is always odd (true). II: $@a@$ divided by $4$ leaves remainder $@b@$, not $1$ (false). III: none of $@s@$ is divisible by $5$ (true).", a=11, b=11 % 4, s=', '.join(map(str, pos182))),
               "Statements I and III only. Option (@@L@@)."]
assert [5 * a_ + c_ for a_, c_ in [(1, 6), (2, 3), (3, 2), (6, 1)]] == [11, 13, 17, 31] and all(k % 5 for k in ks182) and all(k % 2 for k in ks182) and 11 % 4 == 3
T['AM-182'] = 'N'

# ================================================================ PART B
# 011
S['AM-011'] = ["Factor the top as a difference of squares: $x^2-9=(x-3)(x+3)$.",
               "Cancel $(x-3)$, which is allowed because $x\\ne3$: the result is $x+3$.",
               t("Check at $x=5$: $\\dfrac{25-9}{5-3}=@l@$ and $5+3=@r@$. Option (@@L@@).", l=Fr(25 - 9, 5 - 3), r=5 + 3)]
T['AM-011'] = 'N'
# 015 (changed)
f15 = [(p_, q_) for p_ in range(-12, 13) for q_ in range(-12, 13) if p_ * q_ == -12 and p_ + q_ == 1 and p_ < q_][0]; assert f15 == (-3, 4)
S['AM-015'] = [t("Factor the top: two numbers with product $-12$ and sum $1$ are $@p@$ and $@q@$, so $x^2+x-12=(x+4)(x-3)$.", p=f15[0], q=f15[1]),
               "Cancel $(x+4)$, which is allowed because $x\\ne-4$: the result is $x-3$.",
               t("Check at $x=2$: $\\dfrac{4+2-12}{2+4}=@l@$ and $2-3=@r@$. Option (@@L@@).", l=Fr(4 + 2 - 12, 2 + 4), r=2 - 3)]
T['AM-015'] = 'N'
# 025 (changed)
e25 = Fr(1, 5) + 1
S['AM-025'] = [t("From $a^5=b^2$, take the fifth root: $a=b^{@e@}$.", e=L(Fr(2, 5))),
               t("Then $\\sqrt a=\\left(b^{@e@}\\right)^{1/2}=b^{@f@}$.", e=L(Fr(2, 5)), f=L(Fr(1, 5))),
               t("Multiply by $b=b^1$ and add exponents: $b\\sqrt a=b^{1+@f@}=b^{@g@}$. Option (@@L@@).", f=L(Fr(1, 5)), g=L(e25))]
assert e25 == Fr(6, 5)
T['AM-025'] = 'N'
# 038
q38 = []; acc = 0
for co in [2, -3, -11, 6]:
    acc = co + acc * 3; q38.append(acc)
assert q38 == [2, 3, -2, 0]
S['AM-038'] = ["Use synthetic division with the root $3$ and the coefficients $2,\\ -3,\\ -11,\\ 6$.",
               t("Bring down $2$. Then multiply by $3$ and add to the next coefficient each time: $-3+@a@=@b@$, then $-11+@c@=@d@$, then $6+(@e@)=@f@$.", a=2 * 3, b=q38[1], c=3 * 3, d=q38[2], e=-2 * 3, f=q38[3]),
               t("The remainder is $@r@$, as the question says, and the quotient is $@q@$.", r=q38[3], q=pstr(q38[:3])),
               t("Check: $(x-3)(@q@)=@e@$. Option (@@L@@).", q=pstr(q38[:3]), e=pstr(poly_mul([1, -3], q38[:3])))]
assert poly_mul([1, -3], q38[:3]) == [2, -3, -11, 6]
T['AM-038'] = 'N'
# 055
S['AM-055'] = [t("Distribute the $4$: $4(2x+7)=@a@$.", a=pstr(poly_mul([4], [2, 7]))),
               t("Subtract $5x$: $@a@-5x=@r@$. Option (@@L@@).", a=pstr(poly_mul([4], [2, 7])), r=pstr((psub(poly_mul([4], [2, 7]), [5, 0]))))]
assert (psub(poly_mul([4], [2, 7]), [5, 0])) == [3, 28]
S['AM-055'].append(t("Check at $x=1$: $4(9)-5=@l@$ and $3+28=@r@$.", l=4 * 9 - 5, r=3 + 28))
T['AM-055'] = 'N'
# 056
d56 = (psub([5, 3, -9], [2, -7, 4])); assert d56 == [3, 10, -13]
S['AM-056'] = ["Subtracting a bracket changes every sign inside it: $5x^2+3x-9-2x^2+7x-4$.",
               t("Combine like terms: $x^2$: $5-2=@a@$. $x$: $3+7=@b@$. Constants: $-9-4=@c@$.", a=d56[0], b=d56[1], c=d56[2]),
               t("The result is $@r@$. Option (@@L@@).", r=pstr(d56)),
               t("Check at $x=1$: $(5+3-9)-(2-7+4)=@l@$ and $3+10-13=@r@$.", l=(5 + 3 - 9) - (2 - 7 + 4), r=3 + 10 - 13)]
T['AM-056'] = 'N'
# 057
S['AM-057'] = [t("Expand $x(3x+11)=@e@$.", e=pstr([3, 11, 0])),
               t("Match with $3x^2+ax$: the $x$-coefficients must be equal, so $a=@a@$.", a=11),
               t("Check at $x=1$: $3(1)^2+11(1)=@l@$ and $1\\cdot(3+11)=@r@$. Option (@@L@@).", l=3 + 11, r=1 * (3 + 11))]
T['AM-057'] = 'N'
# 059
s59 = (padd([-3, 5, 18], [6, -2, -9])); assert s59 == [3, 3, 9] and sum(s59) == 15
S['AM-059'] = [t("Add like terms: $x^2$: $-3+6=@a@$. $x$: $5+(-2)=@b@$. Constants: $18+(-9)=@c@$.", a=s59[0], b=s59[1], c=s59[2]),
               t("So $a=@a@$, $b=@b@$, $c=@c@$ and $a+b+c=@a@+@b@+@c@=@s@$.", a=s59[0], b=s59[1], c=s59[2], s=sum(s59)),
               t("Shortcut: $a+b+c$ is the value of the sum at $x=1$: $(-3+5+18)+(6-2-9)=@u@+(@w@)=@s@$.", u=-3 + 5 + 18, w=6 - 2 - 9, s=(-3 + 5 + 18) + (6 - 2 - 9))]
T['AM-059'] = 'N'
# 078
S['AM-078'] = ["Factor the top: $2x^2+8x=2x(x+4)$.",
               "Cancel $2x$ (allowed since $x\\ne0$): the result is $x+4$.",
               t("Check at $x=1$: $\\dfrac{2+8}{2}=@l@$ and $1+4=@r@$. Option (@@L@@).", l=Fr(2 + 8, 2), r=1 + 4)]
T['AM-078'] = 'N'
# 082
inner = 1 + Fr(1, 2); half = inner / 2; assert half == Fr(3, 4)
S['AM-082'] = [t("Inside the root: $x\\sqrt x=x^1\\cdot x^{1/2}=x^{@i@}$.", i=L(inner)),
               t("Take the square root (halve the exponent): $\\sqrt{x^{@i@}}=x^{@h@}$.", i=L(inner), h=L(half)),
               t("So $a=\\dfrac34$ (or $@d@$ as a decimal).", d=n(float(half)))]
T['AM-082'] = 'N'
# 083
S['AM-083'] = ["Write $32$ as a power of a prime: $32=2^5$.",
               t("The base $a$ is prime, and $a^{b/5}=2^5$ only works for $a=@a@$ (a different prime would give a different prime factor).", a=2),
               t("Then $\\dfrac b5=@e@$, so $b=@b@$.", e=5, b=5 * 5),
               t("Check: $2^{@b@/5}=2^{@e@}=@v@$.", b=25, e=5, v=2 ** 5)]
T['AM-083'] = 'N'
# 085
roots85 = [2, -3, 4, -5]; vals85 = [(r_ * r_ - 9) * (r_ + 7) for r_ in roots85]; assert vals85 == [-45, 0, 77, 32]
S['AM-085'] = ["Factor the difference of squares: $(x^2-9)(x+7)=(x-3)(x+3)(x+7)$.",
               "So the factors are $x-3$, $x+3$ and $x+7$. Only $x+3$ is in the list.",
               t("Check the others by putting in their zeros: at $x=2$ the polynomial is $@a@$, at $x=4$ it is $@c@$, at $x=-5$ it is $@d@$ (none is $0$), while at $x=-3$ it is $@b@$. Option (@@L@@).", a=vals85[0], b=vals85[1], c=vals85[2], d=vals85[3])]
T['AM-085'] = 'N'
# 095
S['AM-095'] = ["Triple both: $k_{\\text{new}}=(3m)^2(3n)^2$.",
               t("Square each: $(3m)^2=@a@m^2$ and $(3n)^2=@a@n^2$.", a=9),
               t("So $k_{\\text{new}}=@a@\\cdot@a@\\,m^2n^2=@r@k$. The factor is $@r@$. Option (@@L@@).", a=9, r=81)]
T['AM-095'] = 'N'
# 100 (fix)
mx = max(m for m in range(1, 20) if 200 % (m * m) == 0); assert mx == 10 and 200 // 100 == 2
S['AM-100'] = [t("Simplify one root: $\\sqrt{200}=\\sqrt{@s@\\cdot@r@}=@m@\\sqrt{@r@}$ (@s@ is the largest perfect square dividing $200$).", s=mx * mx, r=200 // (mx * mx), m=mx),
               t("Add the two equal roots: $@m@\\sqrt{@r@}+@m@\\sqrt{@r@}=@t@\\sqrt{@r@}$.", m=mx, r=200 // (mx * mx), t=2 * mx),
               t("So $m=@t@$ and $n=@r@$: $n$ has no square factor and $m>n$.", t=2 * mx, r=200 // (mx * mx)),
               t("Check: $@t@^2\\cdot@r@=@a@$ and $(2\\sqrt{200})^2=4\\cdot200=@a@$.", t=2 * mx, r=2, a=(2 * mx) ** 2 * 2)]
assert (2 * mx) ** 2 * 2 == 4 * 200 == 800
T['AM-100'] = 'N'
# 103
k103 = Fr(7 - 5, 1 + 3); x103 = Fr(19 - 5) / k103 - 3; assert x103 == 25
S['AM-103'] = ["Write the statement as an equation: $y-5=k(x+3)$.",
               t("Use $y=7$ when $x=1$: $7-5=k(1+3)$, so $@a@=@b@k$ and $k=@k@$.", a=7 - 5, b=1 + 3, k=L(k103)),
               t("Now $y=19$: $19-5=@k@(x+3)$, so $@d@=@k@(x+3)$ and $x+3=@e@$.", k=L(k103), d=19 - 5, e=Fr(19 - 5) / k103),
               t("$x=@e@-3=@x@$.", e=Fr(19 - 5) / k103, x=x103)]
T['AM-103'] = 'N'
# 111 (Desmos)
z111 = sorted(np.roots([9, 30, 9]).real); assert abs(z111[0] + 3) < 1e-9 and abs(z111[1] + 1 / 3) < 1e-9
S['AM-111'] = ["A fraction is undefined when its denominator is $0$. The numerator does not matter, and the denominator has only $p$ in it, so $q$ cannot make it undefined.",
               "Type %s (letting $x$ stand for $p$) and tap the zeros." % c('y=9x^2+30x+9'),
               "The zeros are %s and %s, so $p=-3$ or $p=-\\dfrac13$." % (pt(z111[0], 0), pt(z111[1], 0)),
               t("Check by factoring: $9p^2+30p+9=3(3p+1)(p+3)$, and $3(3p+1)(p+3)=@e@$. Option (@@L@@).", e=pstr(list(poly_mul([3], poly_mul([3, 1], [1, 3])))))]
assert list(poly_mul([3], poly_mul([3, 1], [1, 3]))) == [9, 30, 9]
T['AM-111'] = 'D'
CLAIMS.append(('111 zeros', lambda: abs(9 * 9 - 90 + 9) < 1e-9 and abs(9 / 9 - 10 + 9) < 1e-9))
# 117
S['AM-117'] = ["Cube the first bracket: $\\left(9x^2\\right)^3=9^3x^6=@a@x^6$.",
               t("Multiply by $x^6$: $@a@x^6\\cdot x^6=@a@x^{12}$.", a=9 ** 3),
               t("Take the square root ($x>0$): $\\sqrt{@a@}=@s@$ and $\\sqrt{x^{12}}=x^{6}$. Result: $@s@x^6$. Option (@@L@@).", a=9 ** 3, s=math.isqrt(9 ** 3))]
assert math.isqrt(729) ** 2 == 729
T['AM-117'] = 'N'
# 119
S['AM-119'] = [t("Simplify the left side: $\\left(\\sqrt p\\right)^6=\\left(p^{1/2}\\right)^6=p^{@e@}$.", e=3),
               t("Simplify the right side with $q=\\dfrac14$: $q^{-3}=\\left(\\dfrac14\\right)^{-3}=4^3=@v@$.", v=4 ** 3),
               t("So $p^3=@v@$ and $p=@p@$. Check: $\\left(\\sqrt{@p@}\\right)^6=2^6=@c@$.", v=64, p=4, c=2 ** 6)]
T['AM-119'] = 'N'
# 135
e135 = Fr(7, 3) - Fr(1, 2); assert e135 == Fr(11, 6) and math.gcd(11, 6) == 1
S['AM-135'] = [t("Write both as powers: $\\sqrt[3]{x^7}=x^{@a@}$ and $\\sqrt x=x^{@b@}$.", a=L(Fr(7, 3)), b=L(Fr(1, 2))),
               t("Dividing subtracts exponents: $\\dfrac73-\\dfrac12=\\dfrac{@x@-@y@}{6}=@e@$.", x=14, y=3, e=L(e135)),
               t("So $\\dfrac ab=\\dfrac{@n@}{@d@}$, and $@n@$ and $@d@$ have no common factor.", n=11, d=6)]
T['AM-135'] = 'N'
# 137
S['AM-137'] = ["Square both sides of $x+\\dfrac1x=5$.",
               t("$\\left(x+\\dfrac1x\\right)^2=x^2+2\\cdot x\\cdot\\dfrac1x+\\dfrac1{x^2}=x^2+@t@+\\dfrac1{x^2}$, and the left side is $5^2=@f@$.", t=2, f=25),
               t("So $x^2+\\dfrac1{x^2}=@f@-@t@=@r@$.", f=25, t=2, r=25 - 2)]
T['AM-137'] = 'N'
# 139
num139 = padd(poly_mul([2], [1, 5]), poly_mul([3], [1, -2])); assert num139 == [5, 4]
S['AM-139'] = ["Use the common denominator $(x-2)(x+5)$: $\\dfrac{2(x+5)+3(x-2)}{(x-2)(x+5)}$.",
               t("The numerator is $2x+10+3x-6=@n@$.", n=pstr(num139)),
               t("Match with $rx+t$: $r=@r@$ and $t=@t@$.", r=int(num139[0]), t=int(num139[1])),
               t("$rt=@r@\\cdot@t@=@p@$. Option (@@L@@).", r=int(num139[0]), t=int(num139[1]), p=int(num139[0] * num139[1]))]
T['AM-139'] = 'N'
# 143 (changed)
e143 = Fr(2, 3) * 5 - 2; assert e143 == Fr(4, 3)
S['AM-143'] = [t("Write the root as a power: $\\sqrt[3]{x^2}=x^{@a@}$.", a=L(Fr(2, 3))),
               t("Raise to the fifth power, multiplying exponents: $\\left(x^{@a@}\\right)^5=x^{@b@}$.", a=L(Fr(2, 3)), b=L(Fr(10, 3))),
               t("Divide by $x^2$, subtracting exponents: $\\dfrac{@b@}{}-2$ gives $x^{@c@}$. So $\\dfrac ab=\\dfrac{@n@}{@d@}$, with no common factor.", b=L(Fr(10, 3)), c=L(e143), n=4, d=3)]
S['AM-143'][2] = t("Divide by $x^2$, subtracting exponents: $\\dfrac{10}{3}-2=\\dfrac{@x@-@y@}{3}=@c@$. So $\\dfrac ab=\\dfrac{@n@}{@d@}$, with no common factor.", x=10, y=6, c=L(e143), n=4, d=3)
T['AM-143'] = 'N'
