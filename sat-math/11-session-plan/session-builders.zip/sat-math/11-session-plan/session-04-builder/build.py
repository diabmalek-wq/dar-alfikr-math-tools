import json,re,sys,subprocess,os
HERE=os.path.dirname(os.path.abspath(__file__)); os.chdir(HERE); sys.path.insert(0,HERE)
from fractions import Fraction as Fr
from lib import *
from steps import S,T as TOOLT
ESC={'\\':r'\textbackslash{}','{':r'\{','}':r'\}','^':r'\textasciicircum{}','_':r'\_','~':r'\textasciitilde{}','#':r'\#','%':r'\%','&':r'\&','$':r'\$'}
def code(m):
    c=m.group(1).replace('\\{','{').replace('\\}','}')
    return r"\dzc{"+"".join(ESC.get(ch,ch) for ch in c)+"}"
def sup_frac(s):
    out=[];i=0
    while i<len(s):
        if s.startswith('^{',i):
            d=0;j=i+1
            while True:
                d+= s[j]=='{'; d-= s[j]=='}'
                if d==0: break
                j+=1
            out.append(s[i:j+1].replace('\\dfrac','\\frac')); i=j+1
        else: out.append(s[i]); i+=1
    return ''.join(out)
def conv(s):
    s=sup_frac(s)
    s=re.sub(r'(and |; |: |, )Type \[\[',r'\1type [[',s)
    return re.sub(r"\[\[(.+?)\]\]",code,s)
items=json.load(open('s4_items.json'))
COMP=json.load(open('computed.json'))   # answers computed independently by solve.py
CLEAN=[("°C","$^\\circ$C"),("°","$^\\circ$")]
def tab(md):
    rows=[r.strip().strip('|').split('|') for r in md.strip().split('\n') if r.strip().startswith('|') and not re.match(r'^\|\s*-',r.strip())]
    n=len(rows[0]);t=r"\begin{center}\renewcommand{\arraystretch}{2.1}\begin{tabular}{|"+"c|"*n+"}\hline "
    for r in rows: t+=" & ".join(c.strip() for c in r)+r" \\ \hline "
    return t+r"\end{tabular}\end{center}"
def parse(o):
    q=o['q']
    for a,b in CLEAN: q=q.replace(a,b)
    # leading math followed by a sentence: put the math on its own display line
    q=re.sub(r'^\$\$([^$]+)\$\$\s+(?=[A-Z])',r'$$\1$$\n\n',q)
    q=re.sub(r'^\$([^$]+)\$ (?=(The equation|Which|What|In the|How|Find))',r'$$\1$$\n\n',q)
    lines=q.split('\n');stem=[];opts=[]
    for ln in lines:
        m=re.match(r'^\(?([A-D])\)\s*(.*)$',ln.strip())
        if m and (opts or m.group(1)=='A'): opts.append(m.group(2).strip())
        elif opts and ln.strip()=='' : continue
        elif opts: opts[-1]+=' '+ln.strip()
        else: stem.append(ln)
    stem='\n'.join(stem).strip()
    stem=re.sub(r'\n\s*\n','\n\n',stem)
    return stem,(opts if len(opts)==4 else None)
ANS_DISP={'AM-118':r"\dfrac{1}{25}\ \text{(or }0.04\text{)}",'AM-133':r"\dfrac{28}{5}\ \text{(or }5.6\text{)}"}
NOROT={'AM-269'}
LINES_OVR={}
if os.path.exists('lines_ovr.json'): LINES_OVR=json.load(open('lines_ovr.json'))
def parse_val(s):
    s=s.split('(or')[0].replace('$','').replace('\\dfrac','\\frac').strip()
    m=re.match(r'^(-?)\\frac\{(-?\d+)\}\{(\d+)\}$',s)
    if m: return (-1 if m.group(1) else 1)*int(m.group(2))/int(m.group(3))
    return float(s.replace('{,}','').replace(',',''))
P=[]
order=[o for o in items if o['part']=='In class']+[o for o in items if o['part']!='In class']
nA=sum(1 for o in items if o['part']=='In class')
for o in order:
    stem,opts=parse(o)
    p=dict(lv='M' if o['d']=='Medium' else 'H',tool=TOOLT[o['id']],q=stem,id=o['id'])
    if opts:
        m_=re.match(r'^\(?([A-D])(?:\)|$|\s)',o['ans'].strip()); assert m_,o['id']; L_=m_.group(1)
        assert o['fmt']=='Multiple Choice',o['id']
        p['opts']=opts;p['correct']="ABCD".index(L_);p['norot']=o['id'] in NOROT
        mine=COMP[o['id']]; assert mine==L_,(o['id'],mine,L_)   # independent computation equals item key
        assert len(set(opts))==4,o['id']
        p['chk']=lambda c="ABCD".index(mine):('idx',c)
    else:
        assert o['fmt']!='Multiple Choice',o['id']
        a=o['ans'].replace('$','').strip()
        val=parse_val(o['ans']); p['val']=val
        p['ans']=ANS_DISP.get(o['id'],a)
        mine=COMP[o['id']]; assert abs(mine-val)<1e-6*max(1,abs(val)),(o['id'],mine,val)
        p['chk']=lambda v=val:v
    p['steps']=[conv(x) for x in S[o['id']]];p['lines']=LINES_OVR.get(o['id'],{'M':5,'H':6}[p['lv']])
    P.append(p)
P=prep(P)
for p in P:
    p['steps']=[x.replace('@@L@@',"ABCD"[p['correct']] if p.get('opts') else '?') for x in p['steps']]
    assert '@@' not in ''.join(p['steps'])
    if not p.get('opts'): assert '(?)' not in ''.join(p['steps']) and 'Option (?)' not in ''.join(p['steps']),p['id']
json.dump([[p['id'],p['correct'] if p.get('opts') else p['val']] for p in P],open('keyed.json','w'))
meta=dict(title='Equivalent Expressions and Nonlinear Equations',code='SAT-M \\textperiodcentered\\ Session 4',headfull='Session 4 \\textemdash\\ Equivalent Expressions and Nonlinear Equations',
 time='3 hours: Part A in class (about 2 hours 20 minutes of solving), then Part B, the self-assessment, done independently (about 45 minutes), and a short error log.',
 topics='quadratic equations: discriminant, sum and product of solutions \\textperiodcentered\\ absolute-value and rational equations \\textperiodcentered\\ equivalent rational expressions \\textperiodcentered\\ exponent rules and radicals \\textperiodcentered\\ factoring and polynomial division \\textperiodcentered\\ matching coefficients \\textperiodcentered\\ undefined values')
def build_s(mode,out):
    key=(mode=='key')
    L=[PRE.replace("@@CODE@@",meta['code']).replace("@@HEAD@@",meta['headfull']).replace("\\begin{document}",EXTRA+r"\setmonofont[Scale=0.9]{DejaVu Sans Mono}\newcommand{\dzc}[1]{\colorbox{black!8}{\texttt{\small\textcolor{black}{#1}}}}"+"\n\\begin{document}")]
    L.append(r"""
\begin{tcolorbox}[enhanced,colback=NAVY!4,colframe=NAVY,boxrule=0.8pt,arc=3pt]
{\Large\bfseries\color{NAVY} SAT Math Mastery \textperiodcentered\ Session 4}\\[2pt]
{\large\bfseries %s}\\[3pt]
\begin{tabular}{@{}p{0.2\linewidth}p{0.75\linewidth}@{}}
\textbf{Time} & %s\\
\textbf{Topics} & %s\\
\textbf{Name / Date} & \rule{5.5cm}{0.3pt}\ \ \rule{3cm}{0.3pt}\\
\end{tabular}
\end{tcolorbox}
"""%(meta['title'],meta['time'],meta['topics']))
    L.append(r"\banner{Part A \textperiodcentered\ In class \textemdash\ %d problems}"%nA)
    L.append(r"\small Each problem states its tool. Write your work in the space below. Multiple choice: one correct option. Student-produced response (SPR): enter an exact value (fraction or decimal)."+(r" Grey boxes show exactly what to type in Desmos, one expression per line; tap a grey dot to read an intersection, intercept or vertex. A letter such as $a$, $c$ or $k$ becomes a slider when you accept Desmos's offer to add one." if key else "")+r"\normalsize\par\vspace{4pt}")
    for i,p in enumerate(P,1):
        if i==nA+1: L.append(r"\par\needspace{9cm}\banner{Part B \textperiodcentered\ Self-assessment \textemdash\ %d problems}"%(len(P)-nA))
        L.append(problem_tex(i,p,mode))
    L.append(r"\end{document}")
    open(out,'w').write("\n".join(L))
for mode,out in (('ws','S4_ws.tex'),('key','S4_key.tex')):
    build_s(mode,out)
    for _ in range(2): r=subprocess.run(['xelatex','-interaction=nonstopmode',out],capture_output=True,text=True)
    log=open(out[:-4]+'.log').read();print(out,'overfull',log.count('Overfull'),'err',len(re.findall(r'^!',log,re.M)))
