# Re-evaluates every "[[expr]]: it returns $v$" in the steps and the tapped-point / typed-claim checks (independent of steps.py's own asserts).
import re,math,sys
sys.path.insert(0,'.')
import numpy as np
from steps import S,ev,n,ENV,CLAIMS
bad=0;cnt=0
for iid,steps in S.items():
    for st in steps:
        for m in re.finditer(r"\[\[([^\]]+)\]\]: it returns \$([^$]+)\$",st):
            expr,val=m.group(1),m.group(2).replace('{,}','').replace('\\,','')
            want=float(val); e=ENV.get(iid,{})
            got=ev(expr,**e); cnt+=1
            if abs(got-want)>6e-5*max(1,abs(want)): print('MISMATCH',iid,expr,got,want); bad+=1
print('returns checked',cnt,'mismatches',bad)
for name,f in CLAIMS:
    ok=f(); print('OK ' if ok else 'BAD',name); bad+=(not ok)
# tapped points "(x, y)" in Desmos steps: recompute independently
f268=lambda x:x*x-6*x; g268=lambda x:2*abs(x-3)
for st in S['AM-268']:
    for m in re.finditer(r"\$\(([-\d.]+),\\,([-\d.]+)\)\$",st):
        x,y=float(m.group(1)),float(m.group(2)); 
        if abs(f268(x)-y)>2e-4 or abs(g268(x)-y)>2e-4: print('BAD pt 268',x,y); bad+=1
        cnt+=1
for st in S['AM-133']:
    for m in re.finditer(r"\$\(([-\d.]+),\\,([-\d.]+)\)\$",st):
        x,y=float(m.group(1)),float(m.group(2)); cnt+=1
        if abs(2*x*x-33*x+100-y)>1e-3 or y!=0: print('BAD pt 133',x,y); bad+=1
for st in S['AM-111']:
    for m in re.finditer(r"\$\(([-\d.]+),\\,([-\d.]+)\)\$",st):
        x,y=float(m.group(1)),float(m.group(2)); cnt+=1
        if abs(9*x*x+30*x+9)>1e-3 or y!=0: print('BAD pt 111',x,y); bad+=1
print('points checked (incl returns)',cnt,'total bad',bad)
# every typed Desmos expression must at least be balanced
for iid,steps in S.items():
    for st in steps:
        for m in re.finditer(r"\[\[([^\]]+)\]\]",st):
            e=m.group(1)
            if e.count('(')!=e.count(')'): print('UNBALANCED',iid,e); bad+=1
print('FINAL bad',bad)
