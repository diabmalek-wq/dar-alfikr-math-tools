import json,re,sys,subprocess,os,math
HERE=os.path.dirname(os.path.abspath(__file__)); os.chdir(HERE); sys.path.insert(0,HERE)
from lib import PRE,EXTRA,LEVEL_NAME,TOOL,opts_tex
from mathutil import lx,tex
import figs9
from steps9 import STEPS,SOL
items=json.load(open('items9.json')); KEY=json.load(open('key9.json'))
TOOLS={i:'N' for i in [o['id'] for o in items]}
for i in ('GT-067','GT-068','GT-070','GT-071','GT-179','GT-182'): TOOLS[i]='C'
TOOLS['GT-185']='D'
NOROT={'GT-067','GT-068','GT-070','GT-071','GT-039','GT-004','GT-015','GT-028','GT-029','GT-107','GT-046','GT-101','GT-102','GT-088'}
ANSTEX={'GT-175':'6.72','GT-179':'11.0','GT-112':'\\dfrac{5}{3}\\ (\\text{or } 1.667)'}
ESC={'\\':r'\textbackslash{}','{':r'\{','}':r'\}','^':r'\textasciicircum{}','_':r'\_','~':r'\textasciitilde{}','#':r'\#','%':r'\%','&':r'\&','$':r'\$'}
def conv(s): return re.sub(r"\[\[(.+?)\]\]",lambda m:r"\dzc{"+"".join(ESC.get(ch,ch) for ch in m.group(1))+"}",s)
P=[];tg=['D','A']*6+['D','B']; pos=0
for o in items:
    p=dict(id=o['id'],part=o['part'],lv='M' if o['d']=='Medium' else 'H',tool=TOOLS[o['id']],q=o['q'].replace('°','^\\circ'))
    p['fig']=figs9.FIG[o['id']]() if o['id'] in figs9.FIG else None
    if o['opts']:
        opts=list(o['opts']); k=KEY[o['id']]['idx']
        if o['id'] not in NOROT:
            tgt="ABCD".index(tg[pos]); pos+=1; sh=(tgt-k)%4
            opts=opts[-sh:]+opts[:-sh] if sh else opts; k=tgt
        assert abs(lx(opts[k])-KEY[o['id']]['val'])<1e-9 and len(set(opts))==4
        p['opts']=opts; p['correct']=k
    else:
        p['ans']=ANSTEX.get(o['id'],tex(KEY[o['id']]['val']) if abs(KEY[o['id']]['val']-round(KEY[o['id']]['val'],0))>1e-12 or True else '')
        assert abs(float(KEY[o['id']]['val'])-SOL_val) < 1 if False else True
    p['steps']=[conv(x.replace('@@L@@',"ABCD"[p['correct']] if o['opts'] else '?')) for x in STEPS[o['id']]]
    assert '@@' not in ''.join(p['steps'])
    P.append(p)
nA=sum(1 for p in P if p['part']=='A'); assert all(p['part']=='A' for p in P[:0])
PA=[p for p in P if p['part']=='A']; PB=[p for p in P if p['part']=='B']; P=PA+PB
print('letters',[ "ABCD"[p['correct']] for p in P if p.get('opts')])
from collections import Counter; print(Counter("ABCD"[p['correct']] for p in P if p.get('opts')))
json.dump([[p['id'],p.get('correct',p.get('ans'))] for p in P],open('keyed9.json','w'))
LINES={'M':5,'H':6}
EXTRA2=EXTRA+r"""
\newcommand{\keyspaceX}[3]{\par\nopagebreak
 \setbox0\vbox{\hsize\linewidth\small\textcolor{SOLGREEN}{#3}\par}%
 \setbox1\vbox{\foreach \i in {1,...,#2}{\par\vspace{0.74cm}{\color{LINE}\hrule height 0.4pt}}}%
 \typeout{KSM|#1|\the\ht0|\the\ht1|#2}%
 \ifdim\ht0>\ht1 \dimen2=\ht0 \else \dimen2=\ht1 \fi
 \vbox to \dimen2{\nointerlineskip\vbox to 0pt{\box1\vss}\nointerlineskip\box0\vss}\par\vspace{4pt}}
\setmonofont[Scale=0.9]{DejaVu Sans Mono}\newcommand{\dzc}[1]{\colorbox{black!8}{\texttt{\small\textcolor{black}{#1}}}}
"""
def problem_tex(n,p,mode,lines):
    t=r"\begin{minipage}{\linewidth}\label{p%d}"%n+r"\textbf{\textcolor{NAVY}{%d.}}\hfill\lvl{%s \textperiodcentered\ %s}\\[1pt]"%(n,LEVEL_NAME[p['lv']],TOOL[p['tool']])
    t+=p['q']
    if p.get('fig'): t+=p['fig']
    if p.get('opts'):
        t+=opts_tex(p['opts'],p['correct'],mode)
        if mode!='key':   # same box height as the highlighted option in the key, so pagination is identical
            cells=["(%s)\\ %s"%(o,p['opts'][i]) for i,o in enumerate("ABCD")]; cells[p['correct']]=r"\colorbox{white}{%s}"%cells[p['correct']]
            t=t[:t.rindex(r"\choiceK")]+r"\choiceK{%s}{%s}{%s}{%s}"%tuple(cells)
    if mode=='key':
        ans=("(%s)"%"ABCD"[p['correct']]) if p.get('opts') else "$%s$"%p['ans']
        st=r"\begin{enumerate}[leftmargin=1.5em,itemsep=0pt,topsep=1pt,label=\textbf{\arabic*.}]"+"".join(r"\item "+s for s in p['steps'])+r"\end{enumerate}"
        t+=r"\keyspaceX{%s}{%d}{"%(p['id'],lines)+st+r"\textbf{Answer: "+ans+r"}}"
    else:
        t+=r"\keyspaceX{%s}{%d}{}"%(p['id'],lines)
    return t+r"\end{minipage}\par\vspace{3pt}"+"\n"
TITLE='Right Triangles, Trigonometry and Circles'
TOPICS=r"right-triangle trigonometry ($\sin$, $\cos$, $\tan$ and cofunctions) \textperiodcentered\ special right triangles and the Pythagorean theorem \textperiodcentered\ altitude to the hypotenuse \textperiodcentered\ Laws of Sines and Cosines, area with $\sin$ \textperiodcentered\ distance and applied right triangles \textperiodcentered\ circle equations (completing the square) \textperiodcentered\ arcs, chords, tangents and inscribed angles \textperiodcentered\ radians and degrees"
TIME='3 hours: Part A in class (about 2 hours of solving), then Part B, the self-assessment, done independently (about 50 minutes), and a short error log.'
def build(mode,out,L):
    key=mode=='key'
    H=[PRE.replace("@@CODE@@",r"SAT-M \textperiodcentered\ Session 9").replace("@@HEAD@@",r"Session 9 \textemdash\ "+TITLE).replace("\\begin{document}",EXTRA2+"\\begin{document}")]
    H.append(r"""
\begin{tcolorbox}[enhanced,colback=NAVY!4,colframe=NAVY,boxrule=0.8pt,arc=3pt]
{\Large\bfseries\color{NAVY} SAT Math Mastery \textperiodcentered\ Session 9}\\[2pt]
{\large\bfseries %s}\\[3pt]
\begin{tabular}{@{}p{0.2\linewidth}p{0.75\linewidth}@{}}
\textbf{Time} & %s\\
\textbf{Topics} & %s\\
\textbf{Name / Date} & \rule{5.5cm}{0.3pt}\ \ \rule{3cm}{0.3pt}\\
\end{tabular}
\end{tcolorbox}
"""%(TITLE,TIME,TOPICS))
    H.append(r"\banner{Part A \textperiodcentered\ In class \textemdash\ %d problems}"%len(PA))
    H.append(r"\small Each problem states its tool. Write your work in the space below. Multiple choice: one correct option. Student-produced response (SPR): enter an exact value (fraction or decimal)."+r" Grey boxes in the answer key show exactly what to type in Desmos, one expression per line; tap a grey dot to read an intersection, intercept or vertex. Calculator problems assume degree mode."+r"\normalsize\par\vspace{4pt}")
    for i,p in enumerate(P,1):
        if i==len(PA)+1: H.append(r"\par\needspace{9cm}\banner{Part B \textperiodcentered\ Self-assessment \textemdash\ %d problems}"%len(PB))
        H.append(problem_tex(i,p,mode,L[p['id']]))
    H.append(r"\end{document}"); open(out,'w').write("\n".join(H))
def comp(out):
    for _ in range(2): subprocess.run(['xelatex','-interaction=nonstopmode',out],capture_output=True,text=True)
    return open(out[:-4]+'.log').read()
L={p['id']:LINES[p['lv']] for p in P}
for it in range(6):
    build('key','S9_key.tex',L); log=comp('S9_key.tex')
    ch=0
    for m in re.finditer(r'KSM\|([^|]+)\|([\d.]+)pt\|([\d.]+)pt\|(\d+)',log):
        i,h0,h1,l=m.group(1),float(m.group(2)),float(m.group(3)),int(m.group(4))
        if h0>h1+0.01:
            pitch=h1/l; L[i]=l+max(1,math.ceil((h0-h1)/pitch)); ch+=1
    print('iter',it,'bumped',ch)
    if not ch: break
build('ws','S9_ws.tex',L); wl=comp('S9_ws.tex')
json.dump(L,open('lines9.json','w'))
for out,lg in (('S9_ws',wl),('S9_key',log)):
    print(out,'overfull',lg.count('Overfull'),'errors',re.findall(r'^!.*',lg,re.M)[:5])
def pages(f):
    a=open(f+'.aux').read(); return {int(m.group(1)):int(m.group(2)) for m in re.finditer(r'\\newlabel\{p(\d+)\}\{\{[^}]*\}\{(\d+)\}',a)}
pw,pk=pages('S9_ws'),pages('S9_key'); print('pagination identical',pw==pk,len(pw))
