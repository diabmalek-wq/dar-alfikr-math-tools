import re,math
from steps9 import STEPS,SOL
from mathutil import *
ok=True
def chk(name,cond):
    global ok
    print(('OK  ' if cond else 'BAD '),name); ok&=bool(cond)
# Desmos expressions: evaluate and check the tapped intersection claims (GT-185)
f=lambda x:x**2+(x+5)**2
xs=roots_in(lambda x:f(x)-625,-100,100); chk('185 intersections x=-20,15',[round(x) for x in xs]==[-20,15] and f(15)==625)
txt=' '.join(STEPS['GT-185']); chk('185 text mentions (15, 625)','(15,\\,625)' in txt)
# every [[expr]] in steps is accounted for
exprs=[(i,m) for i,s in STEPS.items() for st in s for m in re.findall(r'\[\[(.+?)\]\]',st)]; print('typed Desmos expressions:',exprs)
# typed numerals in steps checked against geometry
chk('044 hyp 34',round(math.hypot(16,30))==34 and Fraction(30,16)==Fraction(15,8))
chk('045 B=(0,48)',math.hypot(36,48)==60)
chk('069 AC=12',math.sqrt(169-25)==12)
chk('100 expand',all(abs((x+1)**2+(x+8)**2-(x+9)**2-(x*x-16))<1e-9 for x in range(-5,6)) and (4+1,4+8,4+9)==(5,12,13))
chk('101 s',abs(3*6+6*math.sqrt(3)-(18+6*math.sqrt(3)))<1e-9 and abs(6*(3+math.sqrt(3))-(18+6*math.sqrt(3)))<1e-9)
chk('107 check',3**2+6**2==45 and 12**2+6**2==180 and 45+180==225)
chk('112 QS',abs(18*24/30-14.4)<1e-12 and abs(24/14.4-5/3)<1e-12 and 30**2-18**2==576)
chk('118 ratio',48/108==4/9 and 0.5*18*12==108)
chk('121 k',16*5**2==16*5*5 and 15**2==9*25 and 4*5==20 and math.hypot(20,15)==25)
chk('125 sums',2*96==192 and 400+384==784 and 28**2==784 and 12*16==192 and 12**2+16**2==400)
chk('133 80',8**2+4**2==80 and abs(2*math.sqrt(5)/5-2/math.sqrt(5))<1e-12)
chk('136 s',abs(10/(math.sqrt(3)-1)-(5+5*math.sqrt(3)))<1e-12 and abs((5+5*math.sqrt(3))*math.sqrt(3)-(15+5*math.sqrt(3)))<1e-12)
chk('143 k',30*2**2==120 and 12*2==24 and 13*2==26 and abs(576/26-288/13)<1e-12)
chk('154',36==4*9 and 4+5==9 and 4+9==13 and 9*13==117 and 4*13==52 and abs(6/(3*math.sqrt(13))-2*math.sqrt(13)/13)<1e-12)
chk('168 height',14*sind(30)==7 or abs(14*sind(30)-7)<1e-12)
chk('174 k',math.hypot(8,15)==17 and 17*3==51 and 8*3+15*3+51==120)
chk('175',7**2+24**2==25**2 and 7*24==168 and 168/25==6.72)
chk('180',8**2+15**2==17**2 and 8*15==120)
chk('176',abs(14/math.sqrt(2)-7*math.sqrt(2))<1e-12)
chk('178',abs(0.6+0.75-1.35)<1e-12)
chk('179',169-49==120)
chk('184',50*7/25==14 and 50**2-14**2==2304 and 48**2==2304)
chk('186',12**2+35**2==1369 and 37**2==1369 and 37*2==74)
chk('087',(3+5)**2+(4+2)**2==100)
chk('028 base angles',(180-60)/2==60)
chk('029',15**2-9**2==144)
chk('038',abs((10*math.sqrt(3)/3)/(40*math.sqrt(3))-1/12)<1e-12 and abs(20*math.sqrt(3)/math.sqrt(3)-20)<1e-12)
chk('039 quad',90+90+100==280 and 360-280==80)
chk('018/005/004/015',16+1+19==36 and 29-20==9 and 9+16==25 and 25+4-13==16)
chk('173',27+2*27+9==90 and 2*27+9==63)
chk('043',25*2+25+15==90)
chk('071 F',180-40-65==75)
chk('151 branches',abs(sind(5*16-20)-cosd(16+14))<1e-12 and abs(sind(5*31-20)-cosd(31+14))<1e-12 and 5*31-20==104+31)
chk('047',abs(20*(2+math.sqrt(2))-(40+20*math.sqrt(2)))<1e-12)
chk('128',abs(1+2*0.25-1.5)<1e-12)
chk('183',6*2**2==24)
# calculator numbers quoted
for i,ex in [('GT-067',dec(tand(35),4)),('GT-068',dec(cosd(62),4)),('GT-070',dec(tand(58),4)),('GT-071',dec(sind(75),4)),('GT-182',dec(sind(38),4))]:
    chk(i+' quotes '+ex,ex in ' '.join(STEPS[i]))
print('ALL OK' if ok else 'FAILURES')
