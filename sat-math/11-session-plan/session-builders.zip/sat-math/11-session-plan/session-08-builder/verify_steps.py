import re,math,sys,numpy as np
sys.path.insert(0,'.')
from steps import S,ev
from scipy.optimize import brentq
bad=0;cnt=0
for iid,st in S.items():
    for s in st:
        for m in re.finditer(r"\[\[([^\]]+)\]\]: it returns \$([^$]+)\$",s):
            cnt+=1;got=ev(m.group(1));want=float(m.group(2))
            if abs(got-want)>6e-5*max(1,abs(want)): print('MISMATCH',iid,m.group(1),got,want);bad+=1
# regression claim PS-043
mm,bb=np.polyfit([1,2,3,4,5],[3.5,6,8.6,11,13.4],1)
t=' '.join(S['PS-043']); assert ('m=%s'%('%.2f'%mm).rstrip('0').rstrip('.')) in t and ('b=%s'%('%.2f'%bb).rstrip('0').rstrip('.')) in t, t
# tapped intersection PS-046
g=lambda x:800*1.05**x-1500-40*x
xc=brentq(g,5,60);xn=brentq(g,-80,-5);assert xn<0
t=' '.join(S['PS-046']);assert ('%.2f'%xc).rstrip('0') in t.replace(',\\,',' ') or ('%.1f'%xc) in t
print('PS-046 cross',xc,xn,'PS-043',mm,bb)
print('returns checked',cnt,'bad',bad)
