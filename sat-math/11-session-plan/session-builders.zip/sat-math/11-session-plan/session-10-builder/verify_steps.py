"""Re-evaluates every 'Type [[expr]]: it returns $v$' in the Session 10 steps, and every tapped-point / slider claim."""
import re,math,sys
sys.path.insert(0,'.')
from steps import S,ev,n,ANS
bad=0;cnt=0
for iid,steps in S.items():
    for st in steps:
        for m in re.finditer(r"\[\[([^\]]+)\]\]: it returns \$([^$]+)\$",st):
            expr,val=m.group(1),m.group(2).replace('{,}','').replace('\\,','')
            want=float(val); got=ev(expr); cnt+=1
            if abs(got-want)>6e-5*max(1,abs(want)): print('MISMATCH',iid,expr,got,want); bad+=1
print('returns checked',cnt,'mismatches',bad)
chk=[]
# GT-122: typed circle passes through all three points; the failing option really misses (6,3)
P=[(-1,2),(7,2),(6,3)]
chk.append(('122 circle through pts',all((x-3)**2+(y+1)**2==25 for x,y in P)))
chk.append(('122 option B misses (6,3)',(6-3)**2+(3-2)**2!=16 and all((x-3)**2+(y-2)**2==16 for x,y in P[:2])))
# GT-123: tapped intersection points lie on both the circle and the line, and are the only ones
pts=[(x,4-x) for x in range(-30,31) if x*x+(4-x)**2-4*x+2*(4-x)-24==0]
chk.append(('123 tapped pts',pts==[(0,4),(7,-3)]))
# GT-127: tangency point (4,28); slider k=10 touches, k=-2 touches, others do not (discriminant)
disc=lambda k:(2-k)**2-4*(6+k)
chk.append(('127 tangency',disc(10)==0 and disc(-2)==0 and 10*(4-1)-2==4**2+2*4+4==28))
# GT-148: x-intercepts of typed parabola are the two radii, each really giving an 8-long chord
from fractions import Fraction as Fr
for r in (Fr(5),Fr(20,3)):
    d=abs(7*r-20)/5; chk.append(('148 chord r=%s'%r,3*r*r-35*r+100==0 and 2*math.sqrt(float(r*r-d*d))-8<1e-9 and abs(2*math.sqrt(float(r*r-d*d))-8)<1e-9))
chk.append(('148 sum',Fr(5)+Fr(20,3)==Fr(35,3)))
# GT-144 tangent points claimed in steps
chk.append(('144 pts',all(3*x-4*y+4*b==0 and (x-2)**2+(y+3)**2==25 for (x,y,b) in ((Fr(-1),Fr(1),Fr(7,4)),(Fr(5),Fr(-7),Fr(-43,4))))))
for k,v in chk: print(('OK ' if v else 'BAD'),k); bad+=(not v)
print('TOTAL BAD',bad)
