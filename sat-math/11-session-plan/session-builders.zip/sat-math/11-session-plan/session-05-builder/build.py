import json,re,sys,subprocess,os,math
HERE=os.path.dirname(os.path.abspath(__file__)); os.chdir(HERE); sys.path.insert(0,HERE)
from fractions import Fraction as Fr
from lib import *
import steps
from steps import S,KEY,RES,fm,fr
ESC={'\\':r'\textbackslash{}','{':r'\{','}':r'\}','^':r'\textasciicircum{}','_':r'\_','~':r'\textasciitilde{}','#':r'\#','%':r'\%','&':r'\&','$':r'\$'}
def code(m):
    c=m.group(1).replace('\\{','{').replace('\\}','}')
    return r"\dzc{"+"".join(ESC.get(ch,ch) for ch in c)+"}"
def conv(s): return re.sub(r"\[\[(.+?)\]\]",code,s)
items=json.load(open('s5_items.json')); solved=json.load(open('solved.json'))
# tool tag per problem: N = no calculator, C = calculator, D = Desmos
TOOLS={i:'N' for i in solved}
for i in ('AM-008','AM-091','AM-200','AM-233'): TOOLS[i]='D'
for i in ('AM-002','AM-004','AM-061','AM-065','AM-072','PS-001','PS-002','PS-014','PS-016'): TOOLS[i]='C'
# answer-letter balance: rotate the options of items whose options have no natural order (target letter)
TARGET={'AM-203':0,'AM-225':3,'AM-229':0,'AM-063':3,'AM-207':0,'AM-250':3}
LEAK=re.compile(r"SAR|Riyadh|Jeddah|NEOM|Saudi|Makkah|Mecca|Umrah|Yanbu|Vision 2030|Red Sea|Al-[A-Z]|Dammam|Tabuk|Abha|riyal|Mohammed|Ahmed",re.I)
def has(k,o): return norm(o)==k[1:] if k.startswith('=') else norm(k) in norm(o)
def norm(x): return x.replace(' ','').replace('$','').replace('\\left','').replace('\\right','')
A=[o for o in items if o['part']=='In class']; B=[o for o in items if o['part']!='In class']
order=A+B; nA=len(A)
P=[]
for o in order:
    iid=o['id']; kind,sv=solved[iid]
    p=dict(id=iid,lv=o['lv'],tool=TOOLS[iid],q=o['stem'])
    assert not LEAK.search(o['stem']+' '.join(o['opts'] or [])+' '.join(S[iid])),iid
    if o['fmt']=='MC':
        assert kind=='mc' and len(set(o['opts']))==4
        opts=list(o['opts']);cor=sv
        k=KEY[iid]; assert has(k,opts[cor]) and not any(has(k,x) for j,x in enumerate(opts) if j!=cor),(iid,k,opts,cor)
        if iid in TARGET:
            sh=(TARGET[iid]-cor)%4; opts=opts[-sh:]+opts[:-sh] if sh else opts; cor=TARGET[iid]
            assert has(k,opts[cor])
        p['opts']=opts;p['correct']=cor
        L="ABCD"[cor]
    else:
        assert kind=='val'; val=sv
        if iid in RES: assert abs(float(RES[iid])-val)<1e-9,(iid,RES[iid],val)
        else: raise SystemExit('no RES for '+iid)
        F=Fr(val).limit_denominator(1000); assert abs(float(F)-val)<1e-9
        ans=fr(F) if F.denominator!=1 else fm(F)
        if F.denominator==3 or F.denominator==9: ans+=r"\ \text{ or } 0.2222" if iid=='AM-227' else ""
        if iid=='AM-226': ans+=r"\ \text{ or } 5.5"
        p['ans']=ans;L='?'
    p['steps']=[conv(x.replace('@@L@@',L)) for x in S[iid]]
    assert '@@' not in ''.join(p['steps'])
    p['lines']={'M':5,'H':6}[p['lv']]
    P.append(p)
LINESFILE='lines.json'
lines_extra=json.load(open(LINESFILE)) if os.path.exists(LINESFILE) else {}
for p in P: p['lines']=max(p['lines'],lines_extra.get(p['id'],0))
meta=dict(title='Equivalent Expressions and Exponential Functions',code='SAT-M \\textperiodcentered\\ Session 5',headfull='Session 5 \\textemdash\\ Equivalent Expressions and Exponential Functions',
 time='3 hours: Part A in class (about 2 hours of solving), then Part B, the self-assessment, done independently (about 50 minutes), and a short error log.',
 topics='equivalent expressions: exponent rules, rational expressions, factoring and identities \\textperiodcentered\\ radical equations \\textperiodcentered\\ systems with exponents and radicals \\textperiodcentered\\ radical functions and domain \\textperiodcentered\\ exponential growth and decay models \\textperiodcentered\\ interpreting exponential models \\textperiodcentered\\ recursive and geometric sequences \\textperiodcentered\\ successive percent changes')
KS=r"""\renewcommand{\keyspace}[2]{\par\nopagebreak
 \setbox0\vbox{\hsize\linewidth\color{SOLGREEN}\small ##2\par}%
 \setbox1\vbox{\foreach \i in {1,...,##1}{\par\vspace{0.74cm}{\color{LINE}\hrule height 0.4pt}}}%
 \typeout{KSMEASURE \curprob\space\the\ht0\space\the\ht1\space##1}%
 \ifdim\ht0>\ht1 \dimen2=\ht0 \else \dimen2=\ht1 \fi
 \vbox to \dimen2{\nointerlineskip\vbox to 0pt{\box1\vss}\nointerlineskip\box0\vss}\par\vspace{4pt}}""".replace('##','#')
def build_s5(mode,out):
    key=(mode=='key')
    L=[PRE.replace("@@CODE@@",meta['code']).replace("@@HEAD@@",meta['headfull']).replace("\\begin{document}",EXTRA+KS+r"\setmonofont[Scale=0.9]{DejaVu Sans Mono}\newcommand{\dzc}[1]{\colorbox{black!8}{\texttt{\small\textcolor{black}{#1}}}}\def\curprob{x}"+"\n\\begin{document}")]
    L.append(r"""
\begin{tcolorbox}[enhanced,colback=NAVY!4,colframe=NAVY,boxrule=0.8pt,arc=3pt]
{\Large\bfseries\color{NAVY} SAT Math Mastery \textperiodcentered\ Session 5}\\[2pt]
{\large\bfseries %s}\\[3pt]
\begin{tabular}{@{}p{0.2\linewidth}p{0.75\linewidth}@{}}
\textbf{Time} & %s\\
\textbf{Topics} & %s\\
\textbf{Name / Date} & \rule{5.5cm}{0.3pt}\ \ \rule{3cm}{0.3pt}\\
\end{tabular}
\end{tcolorbox}
"""%(meta['title'],meta['time'],meta['topics']))
    L.append(r"\banner{Part A \textperiodcentered\ In class \textemdash\ %d problems}"%nA)
    L.append(r"\small Each problem states its tool. Write your work in the space below. Multiple choice: one correct option. Student-produced response (SPR): enter an exact value (fraction or decimal)."+(r" Grey boxes show exactly what to type in Desmos or on your calculator, one expression per line; tap a grey dot to read an intersection, intercept or vertex. A letter such as $a$, $c$ or $k$ becomes a slider when you accept Desmos's offer to add one." if key else "")+r"\normalsize\par\vspace{4pt}")
    for i,p in enumerate(P,1):
        if i==nA+1: L.append(r"\par\banner{Part B \textperiodcentered\ Self-assessment \textemdash\ %d problems}"%(len(P)-nA))
        L.append(r"\def\curprob{%s}"%p['id'])
        L.append(problem_tex(i,p,mode))
    L.append(r"\end{document}")
    open(out,'w').write("\n".join(L))
def compile_(out):
    for _ in range(2): subprocess.run(['xelatex','-interaction=nonstopmode',out],capture_output=True,text=True)
    log=open(out[:-4]+'.log').read()
    return log
if __name__=='__main__':
    # pass 1: measure solution heights so that the answer-key space (= worksheet work space) fits every solution
    for it in range(3):
        build_s5('key','S5_key.tex'); log=compile_('S5_key.tex')
        need={}
        for m in re.finditer(r'KSMEASURE (\S+?) ([\d.]+)pt\s*([\d.]+)pt\s*(\d+)',log):
            pid,h0,h1,ln=m.group(1),float(m.group(2)),float(m.group(3)),int(m.group(4))
            pitch=h1/ln
            if h0>h1+0.5: need[pid]=math.ceil(h0/pitch-1e-9)
        if not need: break
        for pid,nl in need.items(): lines_extra[pid]=max(lines_extra.get(pid,0),nl)
        json.dump(lines_extra,open(LINESFILE,'w'))
        for p in P: p['lines']=max(p['lines'],lines_extra.get(p['id'],0))
    for mode,out in (('ws','S5_ws.tex'),('key','S5_key.tex')):
        build_s5(mode,out); log=compile_(out)
        print(out,'overfull',log.count('Overfull'),'err',len(re.findall(r'^!',log,re.M)))
    json.dump([[p['id'],p['correct'] if p.get('opts') else p['val'] if 'val' in p else p['ans']] for p in P],open('keyed.json','w'))
