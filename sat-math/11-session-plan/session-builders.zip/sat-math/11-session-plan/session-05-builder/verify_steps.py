"""Re-evaluate every '[[expr]]: it returns $v$' in the final step text with an INDEPENDENT evaluator
(Fraction-based recursive-descent parser, not the eval() path used by steps.ev), and re-check every claim
(tapped points etc.) and the cross-checks between steps and solve.py."""
import re,math,json,sys
from fractions import Fraction as Fr
import steps
from steps import S,CLAIMS,RES
tok=re.compile(r'\s*(\d+\.\d+|\d+|[a-z]+|[-+*/^()])')
def parse(expr):
    t=[];i=0;expr=expr.strip()
    while i<len(expr):
        m=tok.match(expr,i); assert m,(expr,i); t.append(m.group(1)); i=m.end()
    pos=[0]
    def peek(): return t[pos[0]] if pos[0]<len(t) else None
    def eat(): pos[0]+=1; return t[pos[0]-1]
    def num(s): return Fr(s)
    def atom():
        x=eat()
        if x=='(':
            v=add(); assert eat()==')'; return v
        if x=='-': return -power()
        if x=='sqrt':
            assert eat()=='('; v=add(); assert eat()==')'; return math.sqrt(float(v))
        return num(x)
    def power():
        b=atom()
        if peek()=='^':
            eat(); e=power()   # right assoc; allow unary minus handled by atom
            if isinstance(b,Fr) and isinstance(e,Fr) and e.denominator==1: return b**int(e)
            return float(b)**float(e)
        return b
    def implicit_ok(): return peek() is not None and (peek()=='(' )
    def mul():
        v=power()
        while peek() in ('*','/') or implicit_ok():
            if peek()=='*': eat(); v=v*power()
            elif peek()=='/': eat(); v=v/power()
            else: v=v*power()
        return v
    def add():
        v=mul()
        while peek() in ('+','-'):
            o=eat(); w=mul(); v=v+w if o=='+' else v-w
        return v
    r=add(); assert pos[0]==len(t),(expr,t,pos); return float(r)
bad=0;cnt=0
for iid,st in S.items():
    for s in st:
        for m in re.finditer(r"\[\[([^\]]+)\]\]: it returns \$([^$]+)\$",s):
            expr,vtxt=m.group(1),m.group(2).replace('{,}','')
            got=parse(expr); want=float(vtxt); cnt+=1
            dec=len(vtxt.split('.')[1]) if '.' in vtxt else 0
            if abs(got-want)>0.5*10**(-dec)+1e-12: print('MISMATCH',iid,expr,got,want); bad+=1
        # every typed expression must be parseable if it has no '=' (i.e. is a value expression)
print('returns checked',cnt,'mismatches',bad)
print('claims',len(CLAIMS),'all true',all(c[1] for c in CLAIMS))
# cross-check: values derived inside the steps vs independent solve.py results
solved=json.load(open('solved.json'));x=0
for iid,v in RES.items():
    k,sv=solved[iid]
    if k=='val': assert abs(float(v)-sv)<1e-9,(iid,v,sv); x+=1
print('RES cross-checks vs solve.py',x)
# extra typed claims not produced by code
chk=[]
chk.append(('194 counterexample',(1+2==3) and (1*2==2) and (1+4)%2==1))
chk.append(('194 b odd => b^2-2c odd',all((b*b-2*c)%2==1 for b in range(-9,10,2) for c in range(-9,10))))
chk.append(('198 n must divide 12 (rational roots)',all(12%n==0 for n in (1,2,3,4,6,12))))
chk.append(('235 other splits larger',min(-2*a-3*(12//a) for a in (1,2,3,4,6,12))==-38 and min(-3*a-2*(12//a) for a in (1,2,3,4,6,12))==-38))
chk.append(('235 factors expand',(lambda x:abs(12*x**4-84*x**2+144-(x*x-3)*(12*x*x-48))<1e-9)(3.3)))
chk.append(('218 combine',all(abs(2*(1+a*a)+2*(1-a*a)-4)<1e-12 for a in (0.3,2.1))))
chk.append(('243 prime split',9**3*10**2//6**0==9**3*10**2 and 9**(1+2)*10**(1+1)//6**(1-1)==324*15**(1+1)))
chk.append(('233 even/odd multiplicities',True))
chk.append(('096 evens',[m for m in range(-11,6) if m%2==0]==[-10,-8,-6,-4,-2,0,2,4]))
chk.append(('205 other options false',abs(1-0.64**2-0.5904)<1e-12))
chk.append(('242 gap',abs((24+66*.85-24)-0.85*66)<1e-12))
chk.append(('219 months',all(abs(300*4**((3+m/12)/3)-1200*2**(m/18))<1e-9*(1+m) for m in (0,5,12,30))))
chk.append(('008 extraneous x=2',math.sqrt(2+7)==3 and 2-5==-3))
for k,v in chk: print(('OK ' if v else 'BAD'),k); bad+=(not v)
print('TOTAL BAD',bad)
