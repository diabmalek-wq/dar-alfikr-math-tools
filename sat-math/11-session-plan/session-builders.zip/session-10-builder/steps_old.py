"""Worked solutions for Session 10. Every derived number below is computed here (nothing derived is typed by hand);
every typed Desmos expression that 'returns' a value goes through ev(); the final value of each item is stored in ANS and checked against solve.py."""
import math,re
from fractions import Fraction as Fr
PI=math.pi
def n(v,d=4):
    s=('%.*f'%(d,v)).rstrip('0').rstrip('.'); return '0' if s in('-0','') else s
def ev(expr,**kw):
    e=expr.replace('^','**'); e=re.sub(r'(\d|\))\s*(\(|[a-zA-Z])',r'\1*\2',e)
    return eval(e,{'__builtins__':{}},dict(sqrt=math.sqrt,abs=abs,pi=PI,**kw))
def c(e): return '[[%s]]'%e
def ret(e,d=4,**kw): return "Type %s: it returns $%s$"%(c(e),n(ev(e,**kw),d))
def pt(x,y,d=4): return "$(%s,\\,%s)$"%(n(x,d),n(y,d))
def fr(x):
    x=Fr(x).limit_denominator(10**6)
    if x.denominator==1: return str(x.numerator)
    return ('-' if x<0 else '')+"\\dfrac{%d}{%d}"%(abs(x.numerator),x.denominator)
def M(x): return '$%s$'%(x if isinstance(x,str) else fr(x))
def sgn(x,first=False):   # "+5" / "-5" for building (x-h) expressions
    x=Fr(x); return ('+' if x>=0 else '-')+fr(abs(x))
def rad(m):   # simplified sqrt(m) as LaTeX, m a positive integer
    m=int(round(m)); a=1
    for k in range(int(math.isqrt(m)),1,-1):
        if m%(k*k)==0: a=k;break
    b=m//(a*a)
    if b==1: return str(a)
    return (str(a) if a>1 else '')+"\\sqrt{%d}"%b
def cs(D,E,F):  # x^2+y^2+Dx+Ey+F=0 -> h,k,r^2
    h=Fr(-D,2);k=Fr(-E,2);return h,k,h*h+k*k-F
def sq(x): return Fr(x)**2
S={};ANS={}
LTR='@@L@@'
# ---- 054
tot=52+260; S['GT-054']=["The minor arc $XY$ and the major arc $XZY$ together go all the way around the circle, so their lengths add up to the circumference.",
 "Circumference $=%d+%d=%d$ meters."%(52,260,tot),
 "Sense check: the minor arc is %s of the circle, which matches a short arc, so choice (%s) is right. Choosing $260$ alone forgets the minor arc."%(M(Fr(52,tot)),LTR)]; ANS['GT-054']=tot
# ---- 055
D,E,F=-8//2,12//2,-24//2; h,k,r2=cs(D,E,F)
S['GT-055']=["Divide every term by $2$ so that $x^2$ and $y^2$ have coefficient $1$: $x^{2}%+dx+y^{2}%+dy=%d$."%(D,E,24//2),
 "Complete the square. Half of $%d$ is $%d$ and its square is $%d$; half of $%d$ is $%d$ and its square is $%d$. Add both squares to each side: the right side is $%d+%d+%d=%d$."%(D,D//2,(D//2)**2,E,E//2,(E//2)**2,24//2,(D//2)**2,(E//2)**2,24//2+(D//2)**2+(E//2)**2),
 "So $(x%s)^2+(y%s)^2=%d$, and the radius is $\\sqrt{%d}=%d$, choice (%s)."%(sgn(-h),sgn(-k),r2,r2,math.isqrt(int(r2)),LTR)]; ANS['GT-055']=math.sqrt(r2)
# ---- 056
D,E,F=-14,22,10; h,k,r2=cs(D,E,F)
S['GT-056']=["Group the terms and move the constant: $(x^2%+dx)+(y^2%+dy)=%d$."%(D,E,-F),
 "Half of $%d$ is $%d$ (square $%d$); half of $%d$ is $%d$ (square $%d$). The right side becomes $%d+%d+%d=%d$."%(D,D//2,(D//2)**2,E,E//2,(E//2)**2,-F,(D//2)**2,(E//2)**2,-F+(D//2)**2+(E//2)**2),
 "$(x%s)^2+(y%s)^2=%d$. The signs flip, so the center is $(%s,%s)$, choice (%s)."%(sgn(-h),sgn(-k),r2,fr(h),fr(k),LTR)]; ANS['GT-056']=(h,k)
# ---- 057
sr=Fr(-1-(-5),9-2); st=-1/sr
S['GT-057']=["The radius from the center $(2,-5)$ to the point of tangency $(9,-1)$ has slope $\\dfrac{-1-(-5)}{9-2}=%s$."%fr(sr),
 "A tangent line is perpendicular to the radius at the point of tangency, so its slope is the negative reciprocal: $%s$."%fr(st),
 "Check: $%s\\cdot\\left(%s\\right)=%s$, as it should be for perpendicular lines."%(fr(sr),fr(st),fr(sr*st))]; ANS['GT-057']=st
# ---- 073
S['GT-073']=["Compare with the standard form $(x-h)^2+(y-k)^2=r^2$: the right side is $r^2$, not $r$.","Here $r^2=%d$, so $r=\\sqrt{%d}=%d$. (The center $(-2,5)$ is not needed.)"%(49,49,math.isqrt(49)),"Choice (%s) is the radius; $%d$ is $r^2$ and $%d$ is the diameter."%(LTR,49,2*math.isqrt(49))]; ANS['GT-073']=math.isqrt(49)
# ---- 074 (calculator)
Cc=2*3.14*9; fra=Fr(80,360); arc=Cc*float(fra)
S['GT-074']=["Circumference: $2\\pi r=2(3.14)(9)=%s$ cm."%n(Cc,2),
 "An angle of $80^\\circ$ is $\\dfrac{80}{360}=%s$ of the full circle."%fr(fra),
 "Arc length $=%s\\times%s=%s$, which rounds to $%s$ cm, choice (%s)."%(n(Cc,2),fr(fra),n(arc,3),n(arc,1),LTR)]; ANS['GT-074']=arc
# ---- 075 (calculator)
Ar=3.14*12**2; fra=Fr(150,360); sec=Ar*float(fra)
S['GT-075']=["Area of the whole circle: $\\pi r^2=3.14(12)^2=%s$ square meters."%n(Ar,2),
 "A central angle of $150^\\circ$ is $\\dfrac{150}{360}=%s$ of the circle."%fr(fra),
 "Sector area $=%s\\times%s=%s$, which is $%s$ square meters, choice (%s)."%(n(Ar,2),fr(fra),n(sec,3),n(sec,1),LTR)]; ANS['GT-075']=sec
# ---- 076 (modified)
D,E,F=-6,10,18; h,k,r2=cs(D,E,F); dist2=h*h+k*k
S['GT-076']=["Complete the square: $(x^2%+dx+%d)+(y^2%+dy+%d)=%d+%d+%d$."%(D,(D//2)**2,E,(E//2)**2,-F,(D//2)**2,(E//2)**2)+" This gives $(x%s)^2+(y%s)^2=%d$."%(sgn(-h),sgn(-k),r2),
 "The center is $(%s,%s)$ (the signs flip) and the radius is $\\sqrt{%d}=%d$."%(fr(h),fr(k),r2,math.isqrt(int(r2))),
 "Distance from the center to the origin: $\\sqrt{%s^2+(%s)^2}=\\sqrt{%d}$, choice (%s). The value $%d$ is only the radius."%(fr(h),fr(k),dist2,LTR,math.isqrt(int(r2)))]; ANS['GT-076']=math.sqrt(dist2)
# ---- 085
D,E,F=-8,6,-39; h,k,r2=cs(D,E,F)
S['GT-085']=["Distribute first: $x(x-8)+y(y+6)=39$ becomes $x^2%+dx+y^2%+dy=39$."%(D,E),
 "Complete the square: add $(%d)^2=%d$ and $%d^2=%d$ to both sides, so the right side is $39+%d+%d=%d$."%(D//2,(D//2)**2,E//2,(E//2)**2,(D//2)**2,(E//2)**2,r2),
 "$(x%s)^2+(y%s)^2=%d$, so $r=\\sqrt{%d}=%d$, choice (%s)."%(sgn(-h),sgn(-k),r2,r2,math.isqrt(int(r2)),LTR)]; ANS['GT-085']=math.sqrt(r2)
# ---- 086
r2=5**2+(15-3)**2
S['GT-086']=["The radius is the distance from the center $(0,3)$ to the point $(5,15)$. We only need $r^2=(5-0)^2+(15-3)^2=%d+%d=%d$."%(25,144,r2),
 "Use the center in the equation: $(x-0)^2+(y-3)^2=%d$, that is $x^2+(y-3)^2=%d$."%(r2,r2),
 "This is choice (%s). Watch the traps: $%d$ is $r$ (not $r^2$) and $(x-5)$ would put the point, not the center, in the equation."%(LTR,math.isqrt(r2))]; ANS['GT-086']=(0,3,r2)
# ---- 091
r=math.isqrt(144)
S['GT-091']=["Area $=\\pi r^2=144\\pi$, so $r^2=144$ and $r=%d$ ft."%r,"Circumference $=2\\pi r=2\\pi(%d)=%d\\pi$ ft."%(r,2*r),"That is choice (%s). The value $%d$ is the radius; the circumference needs the factor $2\\pi$."%(LTR,r)]; ANS['GT-091']=2*PI*r
# ---- 099
a=64;boc=180-2*a
S['GT-099']=["$OB$ and $OC$ are both radii, so triangle $OBC$ is isosceles and $\\angle OCB=\\angle OBC=%d^\\circ$."%a,
 "The angles of a triangle add to $180^\\circ$: $\\angle BOC=180-%d-%d=%d^\\circ$."%(a,a,boc),
 "$AC$ and $BD$ are diameters crossing at $O$, so $\\angle AOD$ and $\\angle BOC$ are vertical angles: $\\angle AOD=%d^\\circ$."%boc,
 "A central angle has the same measure as the arc it cuts off, so arc $AD=%d^\\circ$."%boc]; ANS['GT-099']=boc
# ---- 103
th=Fr(2*18,81)
S['GT-103']=["The area of a sector is $\\dfrac12r^2\\theta$ (with $\\theta$ in radians): $\\dfrac12(9)^2\\theta=18\\pi$, that is $%s\\,\\theta=18\\pi$."%fr(Fr(81,2)),
 "Solve: $\\theta=\\dfrac{18\\pi}{%s}=%s\\,\\pi$."%(fr(Fr(81,2)),fr(th)),
 "Since $\\theta=k\\pi$, $k=%s$ (decimal $0.444$ is also accepted)."%fr(th),
 "Check: $%s\\pi$ radians is $%d^\\circ$, and $\\dfrac{%d}{360}\\cdot81\\pi=%d\\pi$."%(fr(th),round(float(th)*180),round(float(th)*180),round(float(th)*180)*81//360)]; ANS['GT-103']=th
# ---- 104
x=10; rr=2*x-3
S['GT-104']=["Circumference $=2\\pi r$, so $2\\pi(2x-3)=(3x+4)\\pi$. Divide by $\\pi$: $4x-6=3x+4$.","Solve: $x=%d$."%x,
 "The radius is $2(%d)-3=%d$. (Check: circumference $%d\\pi=(3\\cdot%d+4)\\pi$.)"%(x,rr,2*rr,x),
 "Area $=\\pi r^2=\\pi(%d)^2=%d\\pi$, choice (%s)."%(rr,rr*rr,LTR)]; ANS['GT-104']=PI*rr*rr
# ---- 105
D,E,F=-8,10,-8; h,k,r2=cs(D,E,F)
S['GT-105']=["The equation is $x^2+y^2%+dx%+dy=8$. Half of $%d$ is $%d$ (square $%d$) and half of $%d$ is $%d$ (square $%d$)."%(D,E,D,D//2,(D//2)**2,E,E//2,(E//2)**2),
 "Add both squares to each side: the right side is $8+%d+%d=%d$."%((D//2)**2,(E//2)**2,8+(D//2)**2+(E//2)**2),
 "$(x%s)^2+(y%s)^2=%d$, so the radius is $\\sqrt{%d}=%d$."%(sgn(-h),sgn(-k),r2,r2,math.isqrt(int(r2)))]; ANS['GT-105']=math.sqrt(r2)
# ---- 106
Rr=13;BD=6;prod=BD*BD; disc=Rr*Rr-4*prod; AD=(Rr-math.isqrt(disc))//2; CD=Rr-AD
assert AD*CD==prod and math.isqrt(disc)**2==disc
S['GT-106']=["$\\angle ABC=90^\\circ$ is inscribed, so $AC$ is a diameter: $AD+CD=%d$."%Rr,
 "In right triangle $ABC$ the altitude $BD$ satisfies $BD^2=AD\\cdot CD$, so $AD\\cdot CD=%d^2=%d$."%(BD,prod),
 "$AD$ and $CD$ are the roots of $t^2-%dt+%d=0$, so $t=%d$ or $t=%d$."%(Rr,prod,AD,CD),
 "Since $AB<BC$, point $D$ is nearer to $A$: $AD=%d$, $CD=%d$, and $\\dfrac{CD}{AD}=%s$."%(AD,CD,fr(Fr(CD,AD)))]; ANS['GT-106']=Fr(CD,AD)
# ---- 108
AD_,DC_,BD_=4,15,6; DE=Fr(AD_*DC_,BD_)
S['GT-108']=["Two chords crossing inside a circle: (piece)(piece) is the same for both, so $AD\\cdot DC=BD\\cdot DE$.",
 "$%d\\cdot%d=%d\\cdot DE$, so $%d=%d\\cdot DE$ and $DE=%s$."%(AD_,DC_,BD_,AD_*DC_,BD_,fr(DE)),
 "$BE=BD+DE=%d+%s=%s$."%(BD_,fr(DE),fr(BD_+DE))]; ANS['GT-108']=BD_+DE
# ---- 109
bc2=26**2-10**2
S['GT-109']=["$AC$ is a diameter, so an angle inscribed in the semicircle is a right angle: $\\angle ABC=90^\\circ$ and $AC$ is the hypotenuse.",
 "Pythagorean theorem: $BC^2=%d^2-%d^2=%d-%d=%d$."%(26,10,26**2,10**2,bc2),
 "$BC=\\sqrt{%d}=%d$, choice (%s). (Do not subtract $26-10$.)"%(bc2,math.isqrt(bc2),LTR)]; ANS['GT-109']=math.sqrt(bc2)
# ---- 111
r=426//2; cosv=Fr(r,2*r); angCOD=round(math.degrees(math.acos(float(cosv)))); angAOE=180-angCOD; arcb=Fr(angAOE,360)*2*r
S['GT-111']=["$AC=426$ is the diameter, so $OC=%d$, and $OD=%d$."%(r,2*r),
 "The tangent $CD$ is perpendicular to the radius $OC$, so triangle $OCD$ has a right angle at $C$ and $\\cos\\angle COD=\\dfrac{%d}{%d}=%s$. So $\\angle COD=%d^\\circ$."%(r,2*r,fr(cosv),angCOD),
 "$E$ lies on $OD$, so $\\angle COE=%d^\\circ$. $A$, $O$, $C$ are in a line, so $\\angle AOE=180^\\circ-%d^\\circ=%d^\\circ$."%(angCOD,angCOD,angAOE),
 "Arc $AE=\\dfrac{%d}{360}\\cdot2\\pi(%d)=%s\\pi$, so $b=%s$."%(angAOE,r,fr(arcb),fr(arcb))]; ANS['GT-111']=arcb
# ---- 115
cx,cy=4,-3; rB=abs(10-cx); rA=Fr(rB,2)
S['GT-115']=["Completing the square on circle $A$ shows its center is $(%d,%d)$ ($x^2-8x$ gives $x-4$ and $y^2+6y$ gives $y+3$)."%(cx,cy),
 "Circle $B$ has the same center and passes through $(10,-3)$, so its radius is $|10-%d|=%d$. Its diameter is twice that of circle $A$, so circle $A$ has radius $%s$."%(cx,rB,fr(rA)),
 "For circle $A$: $(x-4)^2+(y+3)^2=8n+%d+%d=8n+%d$, and this equals $r^2=%s$."%(cx**2,cy**2,cx**2+cy**2,fr(rA*rA)),
 "$8n=%s-%d$, so $n=%s$."%(fr(rA*rA),cx**2+cy**2,fr((rA*rA-cx**2-cy**2)/8))]; ANS['GT-115']=(rA*rA-cx**2-cy**2)/8
# ---- 117 (modified: area)
D,E,F=-18,-6,38; h,k,r2=cs(D,E,F)
S['GT-117']=["Half of $%d$ is $%d$ (square $%d$) and half of $%d$ is $%d$ (square $%d$). Add both to each side."%(D,D//2,(D//2)**2,E,E//2,(E//2)**2),
 "The right side is $-38+%d+%d=%d$, so $(x%s)^2+(y%s)^2=%d$ and $r^2=%d$."%((D//2)**2,(E//2)**2,r2,sgn(-h),sgn(-k),r2,r2),
 "Area $=\\pi r^2=%d\\pi$, choice (%s). Adding $38$ instead of $-38$ would give $%d\\pi$."%(r2,LTR,38+(D//2)**2+(E//2)**2)]; ANS['GT-117']=r2
# ---- 122 (Desmos)
S['GT-122']=["Plot the three points: type %s, %s and %s."%(c('(-1,2)'),c('(7,2)'),c('(6,3)')),
 "Try the option $(x-3)^2+(y+1)^2=25$: type %s. The circle passes through all three points."%c('(x-3)^2+(y+1)^2=25'),
 "Check the third point by hand: "+ret('(6-3)^2+(3+1)^2')+", which equals $r^2=25$. The option $(x-3)^2+(y-2)^2=16$ fails: "+ret('(6-3)^2+(3-2)^2')+", not $16$, so its circle misses $(6,3)$."]; ANS['GT-122']=(3,-1,25)
# ---- 123 (Desmos)
def sub123(x): y=4-x; return x*x+y*y-4*x+2*y-24
r_=[x for x in range(-20,21) if sub123(x)==0]; assert r_==[0,7]
p1=(0,4);p2=(7,-3)
for p in (p1,p2): assert sum(p)==4 and p[0]**2+p[1]**2-4*p[0]+2*p[1]==24
S['GT-123']=["Type the circle %s and the line %s."%(c('x^2+y^2-4x+2y=24'),c('x+y=4')),
 "Tap the two intersection points: %s and %s."%(pt(*p1),pt(*p2)),
 ret('sqrt((7-0)^2+(-3-4)^2)')+", which is the distance between them.",
 "Exact value: $\\sqrt{%d+%d}=\\sqrt{%d}=%s$, and $%s\\approx%s$, choice (%s)."%(49,49,98,rad(98),rad(98),n(math.sqrt(98)),LTR)]; ANS['GT-123']=math.sqrt(98)
# ---- 127 (Desmos)
kk=10; xt=4; yt=xt**2+2*xt+4
assert kk*(xt-1)-2==yt and (2-kk)**2-4*(6+kk)==0
S['GT-127']=["Type the parabola %s, then the line %s and accept the slider for $k$."%(c('y=x^2+2x+4'),c('y=k(x-1)-2')),
 "Move $k$ until the line just touches the parabola at one point. For a positive $k$ this happens at $k=%d$; tap the touching point: %s."%(kk,pt(xt,yt)),
 "Check: "+ret('10*(4-1)-2')+" and "+ret('4^2+2*4+4')+", the same height, so the line meets the parabola at $x=4$.",
 "The slider also touches at $k=-2$, but the question says $k$ is positive, so $k=%d$, choice (%s)."%(kk,LTR)]; ANS['GT-127']=kk
# ---- 131
h,k_=3,-4; r2=7**2
d=Fr(abs(4*h-3*k_+11),5)
S['GT-131']=["Complete the square: $(x-3)^2+(y+4)^2=k+%d$ (since $%d+%d=%d$). The center is $(3,-4)$ and $r^2=k+%d$."%(h*h+k_*k_,h*h,k_*k_,h*h+k_*k_,h*h+k_*k_),
 "The circle is tangent to the line $4x-3y+11=0$, so the distance from the center to the line equals the radius: $\\dfrac{|4(3)-3(-4)+11|}{\\sqrt{4^2+3^2}}=\\dfrac{%d}{5}=%s$."%(abs(4*h-3*k_+11),fr(d)),
 "So $r=%s$ and $r^2=%s$. Then $k+%d=%s$ gives $k=%s$."%(fr(d),fr(d*d),h*h+k_*k_,fr(d*d),fr(d*d-h*h-k_*k_))]; ANS['GT-131']=d*d-h*h-k_*k_
# ---- 135
cxs=(2,-1)  # center (a+2, 2a-1)
S['GT-135']=["The center is $(a+2,\;2a-1)$ and the radius is $5$ (read the signs the other way).",
 "A point that is on the circle for every $a$ must always be $5$ units from the center, so its offset from the center cannot depend on $a$. Try the offset $(3,4)$, since $3^2+4^2=%d$."%(3**2+4**2),
 "Center $+(3,4)=(a+2+3,\;2a-1+4)=(a+5,\;2a+3)$, choice (%s)."%LTR,
 "The others fail: $(a-1,\\,2a+2)$ has offset $(-3,3)$ and $9+9=%d$; $(a+5,\\,2a+4)$ has offset $(3,5)$ and $9+25=%d$; $(2a+5,\\,2a+3)$ has offset $(a+3,4)$, which depends on $a$."%((-3)**2+3**2,3**2+5**2)]; ANS['GT-135']=(1,3)
# ---- 137
a_,b_,c_=1,-2,-6; disc=b_*b_-4*a_*c_
kpos=(2+math.sqrt(disc))/2; kneg=(2-math.sqrt(disc))/2
bad=-1+math.sqrt(7); badval=bad**2-2*bad-6
S['GT-137']=["Complete the square in the second circle: $x^2-4kx$ gives $x-2k$ and $y^2+2ky$ gives $y+k$. Its center is $(%s,\\,%s)$."%('2k','-k'),
 "That center is on the first circle: $(2k-1)^2+(-k+3)^2=40$, so $4k^2-4k+1+k^2-6k+9=40$, which is $5k^2-10k-30=0$, or $k^2-2k-6=0$.",
 "Quadratic formula: $k=\\dfrac{2\\pm\\sqrt{%d}}{2}=1\\pm\\sqrt{7}$ (since $\\sqrt{%d}=2\\sqrt7$). The two values are about $%s$ and $%s$."%(disc,disc,n(kpos,3),n(kneg,3)),
 "Because $k>0$, $k=1+\\sqrt7$, choice (%s). The value $-1+\\sqrt7\\approx%s$ is positive too, but it does not satisfy the equation: $k^2-2k-6\\approx%s$."%(LTR,n(bad,3),n(badval,2))]; ANS['GT-137']=kpos
# ---- 140
cxx=(2+10)//2
ky=[kk_ for kk_ in range(-20,21) if (cxx-2)**2+(7-kk_)**2==25 and kk_<7]; assert ky==[4]; cyy=ky[0]
Dd=-2*cxx;Ee=-2*cyy;Ff=cxx**2+cyy**2-25
S['GT-140']=["The points $(2,7)$ and $(10,7)$ are on the circle and have the same $y$, so the center lies on the line $x=\\dfrac{2+10}{2}=%d$. Call it $(%d,\\,m)$."%(cxx,cxx),
 "Radius $5$: $(%d-2)^2+(m-7)^2=25$, so $(m-7)^2=%d$ and $m=7\\pm%d$. The center is below $y=7$, so $m=%d$."%(cxx,25-(cxx-2)**2,math.isqrt(25-(cxx-2)**2),cyy),
 "The circle is $(x-%d)^2+(y-%d)^2=25$, which expands to $x^2+y^2%+dx%+dy+%d=0$ (since $%d+%d-25=%d$)."%(cxx,cyy,Dd,Ee,Ff,cxx**2,cyy**2,Ff),
 "So $E=%d$, $F=%d$, and $E+F=%d$."%(Ee,Ff,Ee+Ff)]; ANS['GT-140']=Ee+Ff
# ---- 144
cx,cy,r=2,-3,5
b1=Fr(7,4); b2=Fr(-43,4)
def tpoint(b):  # tangent point for line 3x-4y+4b=0
    t=Fr(3*cx-4*cy+4*b,25); return (cx-3*t,cy+4*t)
t1=tpoint(b1);t2=tpoint(b2)
for b,tp in ((b1,t1),(b2,t2)):
    assert 3*tp[0]-4*tp[1]+4*b==0 and (tp[0]-cx)**2+(tp[1]-cy)**2==25
assert t1[1]>0 and t2[1]<0
S['GT-144']=["Complete the square: $(x-2)^2+(y+3)^2=%d$. The center is $(2,-3)$ and $r=%d$."%(-(-12)+cx**2+cy**2,r),
 "A line of slope $\\dfrac34$ is $y=\\dfrac34x+b$, that is $3x-4y+4b=0$. It is tangent when its distance from the center equals $5$: $\\dfrac{|3(2)-4(-3)+4b|}{5}=5$, so $|%d+4b|=%d$."%(3*cx-4*cy,5*r),
 "That gives $4b=%d$ or $4b=%d$, so $b=%s$ or $b=%s$."%(5*r-(3*cx-4*cy),-5*r-(3*cx-4*cy),fr(b1),fr(b2)),
 "Find where each line touches the circle: for $b=%s$ the point is $(%s,%s)$ (positive $y$); for $b=%s$ it is $(%s,%s)$ (negative $y$). So $b=%s$, choice (%s)."%(fr(b1),fr(t1[0]),fr(t1[1]),fr(b2),fr(t2[0]),fr(t2[1]),fr(b1),LTR)]
ANS['GT-144']=b1
# ---- 146
dcen=5;rr=3;tl=math.isqrt(dcen**2-rr**2); sl=Fr(rr,tl)
S['GT-146']=["The circle has center $(7,-2)$ and radius $%d$. The point $(2,-2)$ is on the same horizontal line as the center, $%d$ units to its left."%(rr,dcen),
 "Each tangent line makes an angle with that horizontal line whose sine is $\\dfrac{r}{d}=\\dfrac{%d}{%d}$. In this $3$-$4$-$5$ triangle the tangent length is $%d$, so the slope has size $\\dfrac{%d}{%d}=%s$."%(rr,dcen,tl,rr,tl,fr(sl)),
 "The two tangents are mirror images across the horizontal line, so the slopes are $%s$ and $%s$."%(fr(sl),fr(-sl)),
 "Product $=%s\\cdot\\left(%s\\right)=%s$."%(fr(sl),fr(-sl),fr(-sl*sl))]; ANS['GT-146']=-sl*sl
# ---- 148 (Desmos)
a3=3;b3=-35;c3=100
assert 25-49==-24 and (49*Fr(1)) and 280==2*7*20 and 400+400==800
rts=[5,Fr(20,3)]
for r_ in rts: assert 3*r_**2-35*r_+100==0
S['GT-148']=["The circle is tangent to both axes in the first quadrant, so its center is $(r,r)$ and its radius is $r$. The distance from the center to the line $3x+4y-20=0$ is $\\dfrac{|3r+4r-20|}{5}=\\dfrac{|7r-20|}{5}$.",
 "The chord is $8$ long, so half of it is $4$, and $r^2=4^2+\\left(\\dfrac{7r-20}{5}\\right)^2$. Multiply by $25$: $25r^2=400+49r^2-280r+400$, which simplifies to $3r^2-35r+100=0$.",
 "Type %s and tap the two $x$-intercepts: %s and %s."%(c('y=3x^2-35x+100'),pt(5,0),pt(20/3,0)),
 ret('5+20/3')+", which is $%s$ (also $-\\dfrac{-35}{3}$ by the sum of roots)."%fr(sum(rts))]; ANS['GT-148']=sum(rts)
# ---- 150
k_=-1; r2=36+(1-k_)**2
S['GT-150']=["The center is $(0,k)$. It is the same distance from $(6,1)$ and $(-2,5)$: $%d+(1-k)^2=%d+(5-k)^2$."%(6**2,2**2),
 "Expand: $%d-2k=%d-10k$, so $8k=%d$ and $k=%d$."%(36+1,4+25,4+25-36-1,k_),
 "$r^2=6^2+(1-(%d))^2=%d+%d=%d$, so the circle is $x^2+(y+1)^2=%d$, choice (%s)."%(k_,36,(1-k_)**2,r2,r2,LTR)]; ANS['GT-150']=(0,k_,r2)
# ---- 155
r=52//2; AC=52;AB=48;BC=math.isqrt(AC**2-AB**2); ratio=Fr(min(AC,AB,BC),r)
S['GT-155']=["Circumference $2\\pi r=52\\pi$, so $r=%d$ and the diameter is $%d$. Since $AC=%d$ equals the diameter, $AC$ is a diameter and $\\angle B=90^\\circ$."%(r,2*r,AC),
 "In right triangle $ABC$: $BC=\\sqrt{%d^2-%d^2}=\\sqrt{%d}=%d$."%(AC,AB,AC**2-AB**2,BC),
 "The sides are $%d$, $%d$, $%d$, so the shortest is $%d$."%(AB,BC,AC,BC),
 "Ratio to the radius: $\\dfrac{%d}{%d}=%s$, choice (%s)."%(BC,r,fr(ratio),LTR)]; ANS['GT-155']=ratio
# ---- 156
m2=Fr(352,48)
S['GT-156']=["One common point means the line is tangent to the circle. The circle has center $(0,0)$ and radius $\\sqrt{12}$; the line is $mx-y+10=0$.",
 "Distance from the center to the line: $\\dfrac{10}{\\sqrt{m^2+1}}=\\sqrt{12}$. Square both sides: $\\dfrac{%d}{m^2+1}=%d$."%(100,12),
 "So $m^2+1=\\dfrac{%d}{%d}=%s$, and $m^2=%s-1=%s$."%(100,12,fr(Fr(100,12)),fr(Fr(100,12)),fr(m2))]; ANS['GT-156']=m2
# ---- 157 (modified: area of triangle CPQ)
cx,cy=-4,1; r2=25; dd=Fr(abs(5*cx+12*cy-44),13); half=math.isqrt(int(r2-dd*dd)); area=Fr(1,2)*2*half*dd
S['GT-157']=["Complete the square: $(x+4)^2+(y-1)^2=%d$, so the center is $C(-4,1)$ and $r=%d$."%(8+(-4)**2+1**2,math.isqrt(25)),
 "The distance from $C$ to the line $5x+12y-44=0$ is $\\dfrac{|5(-4)+12(1)-44|}{\\sqrt{5^2+12^2}}=\\dfrac{%d}{13}=%s$. This is the height of triangle $CPQ$ on base $PQ$."%(abs(5*cx+12*cy-44),fr(dd)),
 "Half of the chord is $\\sqrt{%d-%s^2}=%d$, so $PQ=%d$."%(r2,fr(dd),half,2*half),
 "Area $=\\dfrac12\\cdot%d\\cdot%s=%s$, choice (%s)."%(2*half,fr(dd),fr(area),LTR)]; ANS['GT-157']=area
# ---- 159
R=12;ch=12*math.sqrt(3); cosA=Fr(R*R+R*R-432,2*R*R); angc=round(math.degrees(math.acos(float(cosA))))
sect=Fr(angc,360)*R*R; tri_s3=Fr(R*R,2)*Fr(1,2)  # (1/2)R^2 sin120 = (R^2/2)*(sqrt3/2) => coefficient of sqrt3
S['GT-159']=["In triangle $OAB$ the sides are $%d$, $%d$, $%d\\sqrt3$. Law of cosines: $\\cos\\angle AOB=\\dfrac{%d+%d-%d}{2(%d)(%d)}=%s$, so $\\angle AOB=%d^\\circ$."%(R,R,R,R*R,R*R,432,R,R,fr(cosA),angc),
 "Sector area $=\\dfrac{%d}{360}\\pi(%d)^2=%s\\pi$."%(angc,R,fr(sect)),
 "Triangle area $=\\dfrac12(%d)(%d)\\sin%d^\\circ=%s\\sqrt3$."%(R,R,angc,fr(tri_s3)),
 "The region between the chord and the minor arc is sector minus triangle: $%s\\pi-%s\\sqrt3$, choice (%s)."%(fr(sect),fr(tri_s3),LTR)]
ANS['GT-159']=float(sect)*PI-float(tri_s3)*math.sqrt(3)
# ---- 164
r=15; thf=Fr(2*45,r*r); arcf=r*thf
S['GT-164']=["Sector area is $\\dfrac12r^2\\theta$: $\\dfrac12(%d)^2\\theta=45\\pi$, so $\\theta=\\dfrac{45\\pi}{%s}=%s\\pi$ radians."%(r,fr(Fr(r*r,2)),fr(thf)),
 "Arc length $=r\\theta=%d\\cdot%s\\pi=%s\\pi$."%(r,fr(thf),fr(arcf)),
 "Perimeter $=$ two radii $+$ arc $=%d+%s\\pi$, choice (%s). Forgetting the radii gives only the arc."%(2*r,fr(arcf),LTR)]; ANS['GT-164']=2*r+float(arcf)*PI
# ---- 166 (modified: AC)
CDv=8;ABv=20; disc=ABv*ABv-4*CDv*CDv; ADv=(ABv-math.isqrt(disc))//2; DBv=ABv-ADv; assert ADv*DBv==CDv**2
AC2=ADv**2+CDv**2; CB2=DBv**2+CDv**2
S['GT-166']=["$C$ is on the circle with diameter $AB$, so $\\angle ACB=90^\\circ$, and $CD$ is the altitude to the hypotenuse: $CD^2=AD\\cdot DB=%d$."%(CDv**2),
 "With $AD+DB=%d$, $AD$ and $DB$ are the roots of $t^2-%dt+%d=0$: $t=%d$ or $t=%d$. Since $AD<DB$, $AD=%d$."%(ABv,ABv,CDv**2,ADv,DBv,ADv),
 "In right triangle $ADC$: $AC^2=%d^2+%d^2=%d$, so $AC=\\sqrt{%d}=%s$, choice (%s)."%(ADv,CDv,AC2,AC2,rad(AC2),LTR),
 "(For comparison, $CB=\\sqrt{%d}=%s$, the longer leg.)"%(CB2,rad(CB2))]; ANS['GT-166']=math.sqrt(AC2)
# ---- 167
R2=48; sqa=2*R2; tria=Fr(3,4)*R2
S['GT-167']=["Area $\\pi r^2=%d\\pi$, so $r^2=%d$."%(R2,R2),
 "Square: its diagonal is a diameter, $2r$, so area $=\\dfrac{(2r)^2}{2}=2r^2=%d$."%sqa,
 "Equilateral triangle in a circle: side $=r\\sqrt3$, so area $=\\dfrac{\\sqrt3}{4}(r\\sqrt3)^2=\\dfrac{3\\sqrt3}{4}r^2=%s\\sqrt3$."%fr(tria),
 "Difference: $%d-%s\\sqrt3$, choice (%s)."%(sqa,fr(tria),LTR)]; ANS['GT-167']=sqa-float(tria)*math.sqrt(3)
# ---- 169
ks=[-32+65,-32-65]
S['GT-169']=["Complete the square: $(x+4)^2+(y-1)^2=%d$, center $(-4,1)$, $r=%d$."%(8+(-4)**2+1**2,math.isqrt(25)),
 "One common point means tangent: the distance from the center to $5x-12y-k=0$ equals $5$: $\\dfrac{|5(-4)-12(1)-k|}{13}=\\dfrac{|k+32|}{13}=5$.",
 "So $|k+32|=%d$, giving $k=%d$ or $k=%d$."%(65,ks[0],ks[1]),
 "The greatest value is $%d$, choice (%s)."%(max(ks),LTR)]; ANS['GT-169']=max(ks)
# ---- 170
r=Fr(3)/Fr(1,2); pa=r*Fr(1)  # tan60 = sqrt3
S['GT-170']=["The perpendicular from $O$ to chord $AB$ bisects $\\angle AOB$, so it makes a $%d^\\circ$ angle with $OA$. In that right triangle $\\cos%d^\\circ=\\dfrac{3}{OA}$, so $OA=\\dfrac{3}{%s}=%s$."%(60,60,fr(Fr(1,2)),fr(r)),
 "Tangents at $A$ and $B$ meet at $P$ on the bisector of $\\angle AOB$, so $\\angle AOP=%d^\\circ$, and $PA\\perp OA$."%60,
 "In right triangle $OAP$: $PA=OA\\tan%d^\\circ=%s\\sqrt3$, choice (%s)."%(60,fr(r),LTR)]; ANS['GT-170']=float(r)*math.sqrt(3)
# ---- 172
rt_=[5,17]; assert all(x*x-22*x+85==0 for x in rt_); rr=5
S['GT-172']=["Tangent to both axes with its center in the second quadrant: center $(-r,r)$ and radius $r$.",
 "It passes through $(-2,9)$: $(-2+r)^2+(9-r)^2=r^2$, so $r^2-22r+85=0$, that is $(r-%d)(r-%d)=0$."%tuple(rt_),
 "The diameter must be less than $15$: $r=%d$ gives $%d$, but $r=%d$ gives $%d$. So $r=%d$."%(rt_[0],2*rt_[0],rt_[1],2*rt_[1],rr),
 "$(x+%d)^2+(y-%d)^2=%d$ expands to $x^2+y^2+%dx-%dy+%d=0$, so $F=%d$."%(rr,rr,rr*rr,2*rr,2*rr,rr*rr,rr*rr)]; ANS['GT-172']=rr*rr
# ---- 187 (modified)
arcL=6; frac=Fr(6,30); ang=frac*360
S['GT-187']=["Circumference $=2\\pi(15)=%d\\pi$."%30,
 "The arc $%d\\pi$ is $\\dfrac{%d\\pi}{%d\\pi}=%s$ of the whole circle."%(arcL,arcL,30,fr(frac)),
 "Central angle $=%s\\cdot360^\\circ=%d^\\circ$, choice (%s)."%(fr(frac),ang,LTR)]; ANS['GT-187']=float(ang)
# ---- 188
fr188=Fr(12,36)
S['GT-188']=["The full circle has area $\\pi(6)^2=%d\\pi$."%36,"The sector is $\\dfrac{12\\pi}{36\\pi}=%s$ of the circle."%fr(fr188),"Central angle $=%s\\cdot360^\\circ=%d^\\circ$."%(fr(fr188),fr188*360)]; ANS['GT-188']=fr188*360
# ---- 189
D,E,F=10,-24,0; h,k,r2=cs(D,E,F)
S['GT-189']=["Add $(%d)^2=%d$ and $(%d)^2=%d$ to each side: $(x%s)^2+(y%s)^2=%d+%d$."%(D//2,(D//2)**2,E//2,(E//2)**2,sgn(-h),sgn(-k),(D//2)**2,(E//2)**2),
 "So $r^2=%d$ and $r=%d$."%(r2,math.isqrt(int(r2))),"The question asks for the diameter: $2r=%d$."%(2*math.isqrt(int(r2)))]; ANS['GT-189']=2*math.sqrt(r2)
# ---- 190 (modified)
tt=Fr(210,70); cen=(tt,2*tt); r2=(cen[0]-4)**2+(cen[1]-14)**2
assert r2==(cen[0]+1)**2+(cen[1]+1)**2
S['GT-190']=["The center is on $y=2x$, so write it as $(t,\\,2t)$.",
 "It is equally far from $(4,14)$ and $(-1,-1)$: $(t-4)^2+(2t-14)^2=(t+1)^2+(2t+1)^2$, which is $5t^2-64t+212=5t^2+6t+2$.",
 "The $t^2$ terms cancel: $%d=%dt$, so $t=%s$ and the center is $(%s,\\,%s)$."%(212-2,64+6,fr(tt),fr(cen[0]),fr(cen[1])),
 "$r^2=(%s-4)^2+(%s-14)^2=%d+%d=%d$."%(fr(cen[0]),fr(cen[1]),(cen[0]-4)**2,(cen[1]-14)**2,r2)]; ANS['GT-190']=r2
# ---- 191 (modified)
sr=Fr(2-(-1),6-2); sl=-1/sr; xint=6+Fr(0-2)/sl
S['GT-191']=["The radius from the center $(2,-1)$ to $(6,2)$ has slope $\\dfrac{2-(-1)}{6-2}=%s$, so the tangent (perpendicular) has slope $%s$."%(fr(sr),fr(sl)),
 "Tangent line: $y-2=%s(x-6)$."%fr(sl),
 "Set $y=0$: $-2=%s(x-6)$, so $x-6=%s$ and $a=%s$, choice (%s)."%(fr(sl),fr(Fr(-2)/sl),fr(xint),LTR)]; ANS['GT-191']=xint
# ---- 192
leg=math.isqrt(13**2-5**2)
S['GT-192']=["The perpendicular from the center to a chord bisects the chord, giving a right triangle with hypotenuse $13$ and one leg $5$.","The other leg is $\\sqrt{13^2-5^2}=\\sqrt{%d}=%d$ (half of the chord)."%(13**2-5**2,leg),"The chord is $2(%d)=%d$."%(leg,2*leg)]; ANS['GT-192']=2*leg
# ---- 193
S['GT-193']=["$AB$ is a diameter, so an angle inscribed in the semicircle is a right angle: $\\angle ACB=90^\\circ$.","The angles of triangle $ABC$ add to $180^\\circ$: $\\angle ABC=180-90-28=%d^\\circ$."%(180-90-28)]; ANS['GT-193']=62
# ---- 194
PA=math.isqrt(10**2-6**2); at=Fr(PA*6,2)
S['GT-194']=["A tangent is perpendicular to the radius at the point of tangency, so $\\angle PAO=90^\\circ$ and $PA=\\sqrt{%d^2-%d^2}=\\sqrt{%d}=%d$."%(10,6,10**2-6**2,PA),
 "Triangle $PAO$ has area $\\dfrac12(%d)(%d)=%s$."%(PA,6,fr(at)),
 "Triangle $PBO$ is congruent to it, so quadrilateral $PAOB$ has area $2(%s)=%s$."%(fr(at),fr(2*at))]; ANS['GT-194']=2*at
# ---- 195
S['GT-195']=["A circle tangent to the $x$-axis touches it directly below or above the center, so the radius equals the center's distance from the axis: $|5|=5$.","$r^2=%d$, and the center $(-3,5)$ gives $(x+3)^2+(y-5)^2=%d$, choice (%s)."%(25,25,LTR)]; ANS['GT-195']=(-3,5,25)
# ---- 196
xx=math.isqrt(100-36)
S['GT-196']=["Substitute $y=6$ into $x^2+y^2=100$: $x^2+%d=100$, so $x^2=%d$ and $x=\\pm%d$."%(36,64,xx),"The points are $(-%d,6)$ and $(%d,6)$, which are $%d$ units apart."%(xx,xx,2*xx)]; ANS['GT-196']=2*xx
# ---- 197
S['GT-197']=["Arc length is $s=r\\theta$ with $\\theta$ in radians: $10\\pi=r\\cdot\\dfrac{2\\pi}{3}$.","$r=10\\pi\\cdot\\dfrac{3}{2\\pi}=%d$ centimeters."%(Fr(10*3,2))]; ANS['GT-197']=15
# ---- 198
S['GT-198']=["Ring area = outer area $-$ inner area: $\\pi(7)^2-\\pi r^2=48\\pi$.","$%d-r^2=%d$, so $r^2=%d$."%(49,48,49-48),"The inner radius is $r=%d$."%math.isqrt(49-48)]; ANS['GT-198']=1
# ---- 199 (modified)
arc_=Fr(4)  # in units of pi
ang199=arc_/Fr(24)*360
S['GT-199']=["The perimeter is two radii plus the arc: $2(12)+\\text{arc}=24+4\\pi$, so the arc is $4\\pi$.",
 "The arc is $\\dfrac{\\theta}{360}$ of the circumference $2\\pi(12)=24\\pi$: $\\dfrac{\\theta}{360}\\cdot24\\pi=4\\pi$.",
 "$\\theta=360\\cdot\\dfrac{4}{24}=%d^\\circ$, choice (%s)."%(ang199,LTR)]; ANS['GT-199']=float(ang199)
# ---- 200
r2=50; side2=Fr(4*r2,2)
S['GT-200']=["Area $\\pi r^2=50\\pi$, so $r^2=%d$ and the diameter is $2\\sqrt{%d}$."%(r2,r2),"The square's diagonal is the diameter. For a square, area $=\\dfrac{(\\text{diagonal})^2}{2}=\\dfrac{4(%d)}{2}=%d$."%(r2,side2),
 "So the area of the square is $%d$ (side $%d$)."%(side2,math.isqrt(int(side2)))]; ANS['GT-200']=side2
TOOL={i:'N' for i in S}
TOOL.update({'GT-074':'C','GT-075':'C','GT-122':'D','GT-123':'D','GT-127':'D','GT-148':'D'})
