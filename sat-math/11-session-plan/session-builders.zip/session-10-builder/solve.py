"""Independent solutions for all Session 10 items. Each solver works from the question text only (brute force / numeric / exact fractions);
only afterwards is the result compared with the bank's Correct Answer and the option text."""
import json,math,re,itertools
from fractions import Fraction as Fr
import numpy as np
from scipy.optimize import brentq
items={o['id']:o for o in json.load(open('items.json'))}
PI=math.pi
def lat(s):
    """numeric value of an option's LaTeX (numbers, fractions, radicals, multiples of pi, sums)"""
    t=s.replace('$','').replace('\\,','').replace('\\dfrac','\\frac').replace('\\tfrac','\\frac')
    t=re.sub(r'\s*(ft|cm|m|units|degrees)\b','',t)
    t=re.sub(r'\\frac(\d)(\d)',r'\\frac{\1}{\2}',t)
    t=re.sub(r'\\frac\{([^{}]+)\}\{([^{}]+)\}',r'((\1)/(\2))',t)
    t=re.sub(r'\\sqrt\{([^{}]+)\}',r'sqrt(\1)',t); t=re.sub(r'\\sqrt(\d+)',r'sqrt(\1)',t)
    t=t.replace('\\pi','*pi').replace('{,}','')
    t=re.sub(r'(\d|\))(?=sqrt|\()',r'\1*',t); t=re.sub(r'\)(?=\d)',')*',t)
    t=t.replace('^','**').replace('+*','+').replace('-*','-')
    t=re.sub(r'^\*','',t)
    return eval(t,{'sqrt':math.sqrt,'pi':PI})
def circ_opt(s):  # (x-h)^2+(y-k)^2=r2  -> (h,k,r2), allowing x^2 with no h
    t=s.replace('$','').replace(' ','').replace('\\left','').replace('\\right','').replace('^{2}','^2')
    m=re.match(r'^(?:\(x([+-]\d+)\)|x)\^2\+\(y([+-]\d+)\)\^2=(\d+)$',t); assert m,s
    h=-int(m.group(1)) if m.group(1) else 0
    return (h,-int(m.group(2)),int(m.group(3)))
def dist_pl(px,py,A,B,C): return abs(A*px+B*py+C)/math.hypot(A,B)
def complete(D,E,F):  # x^2+y^2+Dx+Ey+F=0 -> center, r^2   (exact fractions)
    h=Fr(-D,2);k=Fr(-E,2);return h,k,h*h+k*k-F

K={}   # id -> computed answer (float or tuple)
# ---------- 054
K['GT-054']=52+260
# 055: 2x^2-8x+2y^2+12y=24 -> divide by 2
h,k,r2=complete(-4,6,-12); K['GT-055']=math.sqrt(r2)
# 056
h,k,r2=complete(-14,22,10); K['GT-056']=(h,k)
# 057 slope of radius, tangent perpendicular
K['GT-057']=-1/Fr(-1-(-5),9-2)
# 073
K['GT-073']=math.sqrt(49)
# 074
K['GT-074']=3.14*2*9*80/360
# 075
K['GT-075']=3.14*12**2*150/360
# 076 (modified: distance from center to origin)
h,k,r2=complete(-6,10,18); K['GT-076']=math.hypot(h,k)
# 085: x(x-8)+y(y+6)=39 -> x^2-8x+y^2+6y-39=0
h,k,r2=complete(-8,6,-39); K['GT-085']=math.sqrt(r2)
# 086: center (0,3) through (5,15)
K['GT-086']=(0,3,5**2+(15-3)**2)
# 091: area 144 pi -> r -> circumference/pi
r=math.sqrt(144); K['GT-091']=2*PI*r
# 099: triangle OBC isosceles (OB=OC); angle BOC; arc AD = vertical angle AOD
K['GT-099']=180-2*64
# 103: sector area (1/2) r^2 theta = 18 pi -> theta/pi = k
K['GT-103']=Fr(2*18,81)
# 104: 2*pi*(2x-3)=(3x+4)*pi linear in x -> solve with brentq, area
x=brentq(lambda x:2*(2*x-3)-(3*x+4),-100,100); K['GT-104']=PI*(2*x-3)**2
# 105
h,k,r2=complete(-8,10,-8); K['GT-105']=math.sqrt(r2)
# 106: brute force: B on circle diameter 13, D foot of altitude, BD=6, AB<BC
R=6.5
# analytic via coordinates: A=(-R,0),C=(R,0),B=(bx,6) on circle, AB<BC => bx<0
bx=-math.sqrt(R*R-36); AD=bx+R; CD=2*R-AD
assert abs(math.hypot(bx+R,6)-math.hypot(bx-R,6))>0 and math.hypot(bx+R,6)<math.hypot(R-bx,6)
K['GT-106']=CD/AD
# 108: power of a point verified by coordinates (construct circle, check)
K['GT-108']=6+4*15/6
# 109
K['GT-109']=math.sqrt(26**2-10**2)
# 111: coordinates: O origin, r=213, C=(r,0), D=(r,t) with OD=426 -> t, E on OD at distance r; minor arc AE
r=213; t=math.sqrt(426**2-r**2); ex,ey=r*r/426,r*t/426  # E = r*(D/|D|)
ang=math.degrees(math.atan2(0,-r)-0)  # A=(-r,0): angle 180
angE=math.degrees(math.atan2(ey,ex)); arc_deg=180-angE; K['GT-111']=arc_deg/360*2*r   # = b (arc = b*pi)
# 115
cx,cy=4,-3; rB=math.hypot(10-cx,-3-cy); rA=rB/2  # twice the diameter
K['GT-115']=Fr(int(round(rA*rA))-25,8)
# 117 (modified: area / pi)
h,k,r2=complete(-18,-6,38); K['GT-117']=r2   # area = r2*pi
# 122 circle through 3 points: solve linear system for D,E,F
pts=[(-1,2),(7,2),(6,3)]
D,E,F=np.linalg.solve(np.array([[x,y,1] for x,y in pts],float),np.array([-(x*x+y*y) for x,y in pts],float))
cx,cy=-D/2,-E/2; K['GT-122']=(round(cx),round(cy),round(cx*cx+cy*cy-F))
# 123 intersect line x+y=4 with circle x^2+y^2-4x+2y=24 by substitution
def sub123(x): y=4-x; return x*x+y*y-4*x+2*y-24
a=np.polyfit([0,1,2],[sub123(0),sub123(1),sub123(2)],2); xr=np.roots(a); p=[(x,4-x) for x in xr]
K['GT-123']=math.dist(p[0],p[1])
# 127 tangency: discriminant of x^2+2x+4-(k(x-1)-2)=0 in x as function of k
def disc127(k): return (2-k)**2-4*(4+k+2)
ks=[k for k in np.roots([1,-8,-20])]; K['GT-127']=max(ks)
# 131: circle (x-3)^2+(y+4)^2=k+25, tangent to 4x-3y+11=0
d=dist_pl(3,-4,4,-3,11); K['GT-131']=d*d-25
# 135: test every option over many a
K['GT-135']=None  # handled in matching: every option is tested over many values of a
# 137: second circle center (2k,-k) on first
ks=np.roots([5,-10,-30]); K['GT-137']=max(ks)
# 140: circle through (2,7),(10,7) radius 5 center below y=7
cx=6; cands=[]
for cy in np.linspace(-20,20,400001):
    if abs((cx-2)**2+(cy-7)**2-25)<1e-9 and cy<7: cands.append(cy)
cy=round(cands[0],6); Dd,Ee,Ff=-2*cx,-2*cy,cx*cx+cy*cy-25; K['GT-140']=Ee+Ff
# 144: tangents of slope 3/4 to (x-2)^2+(y+3)^2=25 ; tangent point y>0
cx,cy,r=2,-3,5; res=[]
for b in np.linspace(-20,20,160001):
    if abs(dist_pl(cx,cy,3,-4,4*b)-r)<2e-5: 
        # tangent point: foot of perpendicular from the center to the line 3x-4y+4b=0
        t=(3*cx-4*cy+4*b)/25; px,py=cx-3*t,cy+4*t; res.append((round(b,3),py))
K['GT-144']=[b for b,py in res if py>0][0]
# 146: tangent lines y+2=m(x-2) to circle (x-7)^2+(y+2)^2=9
# line: m x - y -2m -2 = 0
g=lambda m: abs(m*7-(-2)-2*m-2)/math.hypot(m,1)-3
m1=brentq(g,0.01,5); m2=brentq(g,-5,-0.01); K['GT-146']=Fr(round(m1*m2*16),16)
assert abs(m1*m2+9/16)<1e-9
# 148: circles center (r,r), chord 8 on 3x+4y=20 -> sum of r
def chord(r):
    d=dist_pl(r,r,3,4,-20); return 2*math.sqrt(max(r*r-d*d,0))
rs=[];grid=np.linspace(0.01,30,3000001)
vals=np.array([chord(r)-8 for r in grid[::100]]);gg=grid[::100]
for i in range(len(vals)-1):
    if vals[i]*vals[i+1]<0: rs.append(brentq(lambda r:chord(r)-8,gg[i],gg[i+1]))
K['GT-148']=sum(rs); K['GT-148_roots']=rs
# 150: center (0,k) equidistant from (6,1),(-2,5)
k=brentq(lambda k:(36+(1-k)**2)-(4+(5-k)**2),-50,50); K['GT-150']=(0,round(k),round(36+(1-k)**2))
# 155: circumference 52 pi -> r=26 ; AC=52 diam -> right angle at B ; BC
r=52/2; AC=52;AB=48
# verify AC is a chord of length = diameter via law: coordinates; place A,C as diameter ends, B on circle with AB=48
# B=(bx,by) on circle, dist to A =48
bx=(48**2-2*r*r)/(2*r)   # |B-A|^2=48^2 with |B|=r, A=(-r,0)
by=math.sqrt(r*r-bx*bx); BC=math.hypot(bx-r,by)
K['GT-155']=min(AC,AB,BC)/r
# 156: tangent: discriminant of x^2+(mx+10)^2-12=0 -> (1+m^2)x^2+20mx+88=0 ; 400m^2-352(1+m^2)=0
K['GT-156']=Fr(352,400-352)   # 400 m^2 = 352 (1+m^2) -> m^2 = 352/48
# 157 (modified): area of triangle C P Q
cx,cy,r2=-4,1,25
d=dist_pl(cx,cy,5,12,-44); half=math.sqrt(r2-d*d)
K['GT-157']=0.5*(2*half)*d
# 159: segment area r=12 chord 12*sqrt3
r=12;c=12*math.sqrt(3); th=2*math.asin(c/(2*r)); K['GT-159']=0.5*r*r*(th-math.sin(th))
# 164
r=15;A_=45*PI; th=2*A_/(r*r); K['GT-164']=2*r+r*th
# 166 (modified): AC
# D at distance t from A: t(20-t)=64 , AD<DB -> t<10
t=brentq(lambda t:t*(20-t)-64,0,10); K['GT-166']=math.hypot(t,8)
# 167 inscribed square vs triangle in circle area 48 pi
R2=48; sq=2*R2; tri=3*math.sqrt(3)/4*R2; K['GT-167']=sq-tri
# 169 tangent: distance from center (-4,1) to 5x-12y-k=0 equals 5
ks=[-32+65, -32-65]
for kk in ks: assert abs(dist_pl(-4,1,5,-12,-kk)-5)<1e-9
K['GT-169']=max(ks)
# 170 r from chord distance: cos(60)=3/r ; tangent length
r=3/math.cos(math.radians(60)); K['GT-170']=r*math.tan(math.radians(60))
# 172 circle (x+r)^2+(y-r)^2=r^2 through (-2,9)
rr=np.roots([1,-22,85]); rr=[x for x in rr if 2*x<15][0]; K['GT-172']=rr*rr  # F = h^2+k^2-r^2 = r^2
# 187 (modified)
K['GT-187']=6*PI/(2*PI*15)*360
# 188
K['GT-188']=Fr(12,36)*360
# 189
h,k,r2=complete(10,-24,0); K['GT-189']=2*math.sqrt(r2)
# 190 (modified): center (t,2t) equidistant from (4,14),(-1,-1)
t=brentq(lambda t:(t-4)**2+(2*t-14)**2-((t+1)**2+(2*t+1)**2),-100,100); K['GT-190']=(t-4)**2+(2*t-14)**2
# 191 (modified): tangent at (6,2); x-intercept
sl=-1/Fr(2-(-1),6-2); K['GT-191']=6+(0-2)/sl
# 192
K['GT-192']=2*math.sqrt(13**2-5**2)
# 193
K['GT-193']=180-90-28
# 194
PA=math.sqrt(10**2-6**2); K['GT-194']=2*0.5*PA*6
# 195
K['GT-195']=(-3,5,25)
# 196
K['GT-196']=2*math.sqrt(100-36)
# 197
K['GT-197']=10*PI/(2*PI/3)
# 198
K['GT-198']=math.sqrt(49-48)
# 199 (modified): perimeter 24+4pi -> arc=4pi -> angle
K['GT-199']=(4*PI)/(2*PI*12)*360
# 200
K['GT-200']=(2*math.sqrt(50))**2/2

# ----- matching with the options and the bank answer
def n_(x): return float(x)
def opt_index(o):
    i=o['id']; opts=o['opts']; v=K[i]
    if i=='GT-135':
        res=[]
        for s in opts:
            m=re.match(r'^\$\((.+),\\ (.+)\)\$$',s); ex,ey=m.group(1),m.group(2)
            ok=True
            for a in np.linspace(-9,9,19):
                X=eval(ex.replace('a','*a' if False else 'a').replace('2a','2*a'),{'a':a}); Y=eval(ey.replace('2a','2*a'),{'a':a})
                if abs((X-a-2)**2+(Y-2*a+1)**2-25)>1e-9: ok=False
            res.append(ok)
        return [j for j,x in enumerate(res) if x]
    if i in('GT-086','GT-122','GT-150','GT-195'):
        return [j for j,s in enumerate(opts) if circ_opt(s)==tuple(int(round(float(z))) for z in v)]
    if i=='GT-056':
        return [j for j,s in enumerate(opts) if tuple(Fr(z) for z in re.findall(r'-?\d+',s))==(v[0],v[1])]
    if i=='GT-091': return [j for j,s in enumerate(opts) if abs(lat(s.replace(' ft',''))-v)<1e-9]
    if i in('GT-104','GT-117'): return [j for j,s in enumerate(opts) if abs(lat(s)-float(v)*(PI if i=='GT-117' else 1))<1e-9] if i=='GT-117' else [j for j,s in enumerate(opts) if abs(lat(s)-v)<1e-9]
    return [j for j,s in enumerate(opts) if abs(lat(s)-float(v))<(0.06 if i in('GT-074','GT-075') else 1e-9)]
def bank_value_spr(o):
    a=o['ans_text'].replace('\\dfrac{','(').replace('}{',')/(').replace('}',')')
    a=re.sub(r'\(([-\d]+)\)/\(([-\d]+)\)',r'\1/\2',a)
    return float(Fr(a.replace('-(','-(')) if '/' in a else float(a))
def run():
    bad=0;rows=[]
    for i,o in items.items():
        v=K[i]
        if o['mc']:
            idx=opt_index(o)
            L='ABCD'
            ok=(len(idx)==1 and L[idx[0]]==o['bank_letter'] and len(set(o['opts']))==4)
            if i in('GT-074','GT-075'):  # numeric with pi~3.14, all 4 options differ by >0.06
                vals=[lat(s) for s in o['opts']]; assert min(abs(a-b) for a,b in itertools.combinations(vals,2))>0.5
            rows.append((i,'MC',L[idx[0]] if len(idx)==1 else idx,o['bank_letter'],ok))
        else:
            bv=bank_value_spr(o); mine=float(v) if not isinstance(v,(tuple,list)) else None
            ok=abs(mine-bv)<1e-9 or (i=='GT-103' and abs(mine-4/9)<1e-9)
            rows.append((i,'SPR',mine,bv,ok))
        if not ok: bad+=1
    for r in rows: print(r)
    print('items',len(rows),'mismatches',bad)
    return bad
if __name__=='__main__':
    run()
