import json,re,sys,subprocess,os,math
HERE=os.path.dirname(os.path.abspath(__file__)); os.chdir(HERE); sys.path.insert(0,HERE)
from fractions import Fraction as Fr
from lib import *
import solve, steps, figs
items=json.load(open('items.json'))
ESC={'\\':r'\textbackslash{}','{':r'\{','}':r'\}','^':r'\textasciicircum{}','_':r'\_','~':r'\textasciitilde{}','#':r'\#','%':r'\%','&':r'\&','$':r'\$'}
def code(m):
    c=m.group(1).replace('\\{','{').replace('\\}','}')
    return r"\dzc{"+"".join(ESC.get(ch,ch) for ch in c)+"}"
def conv(s): return re.sub(r"\[\[(.+?)\]\]",code,s)
P=[]
order=[o for o in items if o['part']=='In class']+[o for o in items if o['part']!='In class']   # CSV order inside each part
nA=sum(1 for o in items if o['part']=='In class')
for o in order:
    i=o['id']; p=dict(lv='M' if o['d']=='Medium' else 'H',tool=steps.TOOL[i],q=o['q'],id=i)
    if o.get('fig'): p['fig']=figs.FIG[o['fig']]()
    if o['mc']:
        idx=solve.opt_index(o); assert len(idx)==1 and 'ABCD'[idx[0]]==o['bank_letter'],i
        p['opts']=o['opts'];p['correct']=idx[0];p['norot']=False
        p['chk']=lambda c=idx[0]:('idx',c)
    else:
        val=solve.bank_value_spr(o); mine=float(solve.K[i]); assert abs(mine-val)<1e-9,i
        assert abs(float(steps.ANS[i])-mine)<1e-9,(i,'steps vs solve')
        p['val']=val;p['ans']=o['ans_text'];p['chk']=lambda v=val:v
    if o['mc']:
        a=steps.ANS[i]
        if i not in('GT-056','GT-086','GT-122','GT-135','GT-150','GT-195'):
            assert abs(float(a)-float(solve.K[i]))<1e-9,(i,a,solve.K[i])
    p['steps']=[conv(x) for x in steps.S[i]];p['lines']={'M':5,'H':6}[p['lv']]
    P.append(p)
P=prep(P)
for p in P: p['steps']=[x.replace('@@L@@',"ABCD"[p['correct']] if p.get('opts') else '?') for x in p['steps']]
for p in P: assert '@@' not in ''.join(p['steps'])
for p in P:
    if not p.get('opts'): assert '(?)' not in ''.join(p['steps']),p['id']
json.dump([[p['id'],p['correct'] if p.get('opts') else p['val']] for p in P],open('keyed.json','w'))
meta=dict(title='Circles: Equations, Arcs and Tangents',code='SAT-M \\textperiodcentered\\ Session 10',headfull='Session 10 \\textemdash\\ Circles',
 time='3 hours: Part A in class (about 2 hours of solving), then Part B, the self-assessment, done independently (about 50 minutes), and a short error log.',
 topics='circle equations: completing the square, center and radius \\textperiodcentered\\ writing a circle\'s equation from conditions \\textperiodcentered\\ arc length and sector area \\textperiodcentered\\ chords, diameters and inscribed angles \\textperiodcentered\\ tangent lines and radii \\textperiodcentered\\ lines meeting circles \\textperiodcentered\\ inscribed polygons')
KSX=r"""
\newcommand{\keyspaceX}[3]{\par\nopagebreak
 \setbox0\vbox{\hsize\linewidth\small\textcolor{SOLGREEN}{#3}\par}%
 \setbox1\vbox{\foreach \i in {1,...,#2}{\par\vspace{0.74cm}{\color{LINE}\hrule height 0.4pt}}}%
 \typeout{KSM|#1|\the\ht0|\the\ht1|#2}%
 \ifdim\ht0>\ht1 \dimen2=\ht0 \else \dimen2=\ht1 \fi
 \vbox to \dimen2{\nointerlineskip\vbox to 0pt{\box1\vss}\nointerlineskip\box0\vss}\par\vspace{4pt}}
"""
def ptex(n,p,mode,lines):
    t=r"\begin{minipage}{\linewidth}\label{p%d}"%n+r"\textbf{\textcolor{NAVY}{%d.}}\hfill\lvl{%s \textperiodcentered\ %s}\\[1pt]"%(n,LEVEL_NAME[p['lv']],TOOL[p['tool']])
    t+=p['q']
    if p.get('fig'): t+=p['fig']
    if p.get('opts'):
        t+=opts_tex(p['opts'],p['correct'],mode)
        if mode!='key':
            cells=["(%s)\\ %s"%(o,p['opts'][i]) for i,o in enumerate("ABCD")]; cells[p['correct']]=r"\colorbox{white}{%s}"%cells[p['correct']]
            t=t[:t.rindex(r"\choiceK")]+r"\choiceK{%s}{%s}{%s}{%s}"%tuple(cells)
    if mode=='key':
        ans=("(%s)"%"ABCD"[p['correct']]) if p.get('opts') else "$%s$"%p['ans']
        st=r"\begin{enumerate}[leftmargin=1.5em,itemsep=0pt,topsep=1pt,label=\textbf{\arabic*.}]"+"".join(r"\item "+x for x in p['steps'])+r"\end{enumerate}"
        t+=r"\keyspaceX{%s}{%d}{"%(p['id'],lines)+st+r"\textbf{Answer: "+ans+r"}}"
    else:
        t+=r"\keyspaceX{%s}{%d}{}"%(p['id'],lines)
    return t+r"\end{minipage}\par\vspace{3pt}"+"\n"
def build_s(mode,out,LN):
    key=(mode=='key')
    L=[PRE.replace("@@CODE@@",meta['code']).replace("@@HEAD@@",meta['headfull']).replace("\\begin{document}",EXTRA+KSX+r"\setmonofont[Scale=0.9]{DejaVu Sans Mono}\newcommand{\dzc}[1]{\colorbox{black!8}{\texttt{\small\textcolor{black}{#1}}}}"+"\n\\begin{document}")]
    L.append(r"""
\begin{tcolorbox}[enhanced,colback=NAVY!4,colframe=NAVY,boxrule=0.8pt,arc=3pt]
{\Large\bfseries\color{NAVY} SAT Math Mastery \textperiodcentered\ Session 10}\\[2pt]
{\large\bfseries %s}\\[3pt]
\begin{tabular}{@{}p{0.2\linewidth}p{0.75\linewidth}@{}}
\textbf{Time} & %s\\
\textbf{Topics} & %s\\
\textbf{Name / Date} & \rule{5.5cm}{0.3pt}\ \ \rule{3cm}{0.3pt}\\
\end{tabular}
\end{tcolorbox}
"""%(meta['title'],meta['time'],meta['topics']))
    L.append(r"\banner{Part A \textperiodcentered\ In class \textemdash\ %d problems}"%nA)
    L.append(r"\small Each problem states its tool. Write your work in the space below. Multiple choice: one correct option. Student-produced response (SPR): enter an exact value (fraction or decimal)."+(r" Grey boxes show exactly what to type in Desmos, one expression per line; tap a grey dot to read an intersection, intercept or vertex. A letter such as $a$, $c$ or $k$ becomes a slider when you accept Desmos's offer to add one." if key else "")+r"\normalsize\par\vspace{4pt}")
    for i,p in enumerate(P,1):
        if i==nA+1: L.append(r"\par\needspace{9cm}\banner{Part B \textperiodcentered\ Self-assessment \textemdash\ %d problems}"%(len(P)-nA))
        L.append(ptex(i,p,mode,LN[p['id']]))
    L.append(r"\end{document}")
    open(out,'w').write("\n".join(L))
def comp(out):
    for _ in range(2): subprocess.run(['xelatex','-interaction=nonstopmode',out],capture_output=True,text=True)
    return open(out[:-4]+'.log').read()
if __name__=='__main__':
    LN={p['id']:p['lines'] for p in P}
    for it in range(8):
        build_s('key','S10_key.tex',LN); log=comp('S10_key.tex'); ch=0
        for m in re.finditer(r'KSM\|([^|]+)\|([\d.]+)pt\|([\d.]+)pt\|(\d+)',log):
            i,h0,h1,l=m.group(1),float(m.group(2)),float(m.group(3)),int(m.group(4))
            if h0>h1+0.01: LN[i]=l+max(1,math.ceil((h0-h1)/(h1/l))); ch+=1
        print('iter',it,'bumped',ch)
        if not ch: break
    build_s('ws','S10_ws.tex',LN); wl=comp('S10_ws.tex')
    json.dump(LN,open('lines10.json','w'))
    for o,lg in (('S10_ws',wl),('S10_key',log)): print(o,'overfull',lg.count('Overfull'),'errors',re.findall(r'^!.*',lg,re.M)[:5])
    def pages(f):
        a=open(f+'.aux').read(); return {int(m.group(1)):int(m.group(2)) for m in re.finditer(r'\\newlabel\{p(\d+)\}\{\{[^}]*\}\{(\d+)\}',a)}
    pw,pk=pages('S10_ws'),pages('S10_key'); print('pagination identical',pw==pk,len(pw))
