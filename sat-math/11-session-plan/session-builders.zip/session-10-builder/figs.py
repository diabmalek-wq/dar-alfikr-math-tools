"""TikZ figures for Session 10. Every coordinate is computed from the numbers in the item stem (nothing is hand-placed except label anchors)."""
import math
from figlib import fig
def f(x): return ('%.4f'%x).rstrip('0').rstrip('.') if abs(x)>1e-9 else '0'
def pol(r,a): return (r*math.cos(math.radians(a)),r*math.sin(math.radians(a)))
def C(name,p): return "\\coordinate (%s) at (%s,%s);"%(name,f(p[0]),f(p[1]))
def node(n,txt,anc): return "\\node[%s,font=\\small] at (%s) {%s};"%(anc,n,txt)
def rt(p,q,r,s=0.22):
    """right-angle square at q between rays q->p and q->r (s in cm-units of the picture)"""
    ux,uy=p[0]-q[0],p[1]-q[1];vx,vy=r[0]-q[0],r[1]-q[1]
    nu=math.hypot(ux,uy);nv=math.hypot(vx,vy);ux,uy,vx,vy=ux/nu*s,uy/nu*s,vx/nv*s,vy/nv*s
    return "\\draw[thin,INK] (%s,%s)--(%s,%s)--(%s,%s);"%(f(q[0]+ux),f(q[1]+uy),f(q[0]+ux+vx),f(q[1]+uy+vy),f(q[0]+vx),f(q[1]+vy))
def ang(q,p,r,rad,label,lr=None):
    a1=math.degrees(math.atan2(p[1]-q[1],p[0]-q[0]));a2=math.degrees(math.atan2(r[1]-q[1],r[0]-q[0]))
    d=(a2-a1+180)%360-180; a2=a1+d; mid=(a1+a2)/2; lr=lr or rad+0.33
    return ("\\draw[thin,INK] (%s,%s) arc (%s:%s:%s);"%(f(q[0]+rad*math.cos(math.radians(a1))),f(q[1]+rad*math.sin(math.radians(a1))),f(a1),f(a2),f(rad))
            +"\\node[font=\\scriptsize] at (%s,%s) {%s};"%(f(q[0]+lr*math.cos(math.radians(mid))),f(q[1]+lr*math.sin(math.radians(mid))),label))
def circ(c,r): return "\\draw[ln] (%s,%s) circle (%s);"%(f(c[0]),f(c[1]),f(r))
def seg(p,q,st="thick,INK"): return "\\draw[%s] (%s,%s)--(%s,%s);"%(st,f(p[0]),f(p[1]),f(q[0]),f(q[1]))
def lab(p,txt,anc,sz="\\small"): return "\\node[%s,font=%s] at (%s,%s) {%s};"%(anc,sz,f(p[0]),f(p[1]),txt)
def pt(p): return "\\fill (%s,%s) circle (1.5pt);"%(f(p[0]),f(p[1]))
def F(body,s=1.0): return fig(body,xu=s,yu=s)
def arcp(c,r,a1,a2,st="very thick,ORANGE"): return "\\draw[%s] (%s,%s) arc (%s:%s:%s);"%(st,f(c[0]+r*math.cos(math.radians(a1))),f(c[1]+r*math.sin(math.radians(a1))),f(a1),f(a2),f(r))
def mid(p,q): return ((p[0]+q[0])/2,(p[1]+q[1])/2)

def F054():
    arc_minor=360*52/(52+260); R=1.7
    X=pol(R,90+arc_minor/2);Y=pol(R,90-arc_minor/2);Z=pol(R,270)
    b=circ((0,0),R)+arcp((0,0),R,90-arc_minor/2,90+arc_minor/2)
    b+=pt(X)+pt(Y)+pt(Z)
    b+=lab(X,"$X$","above left")+lab(Y,"$Y$","above right")+lab(Z,"$Z$","below")
    b+=lab(pol(R+0.05,90),"$52$ m","above")+lab(pol(R+0.05,215),"$260$ m","below left")
    return F(b,1.0)
def F099():
    R=1.8; bo=64; boc=180-2*bo
    Cc=pol(R,0);B=pol(R,boc);A=pol(R,180);D=pol(R,180+boc);O=(0,0)
    b=circ(O,R)+seg(A,Cc)+seg(B,D)+seg(B,Cc)
    b+=arcp(O,R,180,180+boc)+pt(O)+pt(A)+pt(B)+pt(Cc)+pt(D)
    b+=ang(B,O,Cc,0.45,"$64^\\circ$",0.9)
    b+=lab(A,"$A$","left")+lab(B,"$B$","above right")+lab(Cc,"$C$","right")+lab(D,"$D$","below left")+lab(O,"$O$","above left")
    return F(b)
def F106():
    Rr=6.5;BD=6;s=0.42
    bx=-math.sqrt(Rr*Rr-BD*BD)
    A=(-Rr*s,0);Cc=(Rr*s,0);B=(bx*s,BD*s);D=(bx*s,0)
    b=circ((0,0),Rr*s)+seg(A,Cc)+seg(A,B)+seg(B,Cc)+seg(B,D)+pt(A)+pt(B)+pt(Cc)+pt(D)
    b+=rt(A,D,B,0.18)+rt(A,B,Cc,0.18)
    b+=lab(A,"$A$","left")+lab(B,"$B$","above")+lab(Cc,"$C$","right")+lab(D,"$D$","below")
    b+=lab(((bx*s),BD*s/2),"$6$","left",sz="\\footnotesize")+lab((0,-Rr*s-0.05),"$AC=13$","below")
    return F(b)
def F108():
    AD,DC,BD=4,15,6;phi=60;s=0.2
    u=(math.cos(math.radians(phi)),math.sin(math.radians(phi)))
    DE=AD*DC/BD
    A=(-AD,0);Cc=(DC,0);B=(BD*u[0],BD*u[1]);E=(-DE*u[0],-DE*u[1]);D=(0,0)
    cx=(DC-AD)/2
    k=((B[0]-cx)**2+B[1]**2-((AD+DC)/2)**2)/(2*B[1])
    R=math.hypot(A[0]-cx,k)
    assert abs(math.hypot(E[0]-cx,E[1]-k)-R)<1e-9 and abs(math.hypot(B[0]-cx,B[1]-k)-R)<1e-9
    S=lambda p:(p[0]*s,p[1]*s)
    b=circ(S((cx,k)),R*s)+seg(S(A),S(Cc))+seg(S(B),S(E))+pt(S(A))+pt(S(B))+pt(S(Cc))+pt(S(D))+pt(S(E))
    b+=lab(S(A),"$A$","above left")+lab(S(B),"$B$","above")+lab(S(Cc),"$C$","right")+lab(S(E),"$E$","below")+lab(S(D),"$D$","below right")
    b+=lab(S(mid(A,D)),"$4$","above",sz="\\footnotesize")+lab(S(mid(D,Cc)),"$15$","above",sz="\\footnotesize")
    b+=lab(S(mid(D,B)),"$6$","right",sz="\\footnotesize")
    return F(b)
def F109():
    s=0.2;AC=26;AB=10;r=AC/2
    bx=(AB**2-2*r*r)/(2*r);by=math.sqrt(r*r-bx*bx)
    A=(-r*s,0);Cc=(r*s,0);B=(bx*s,by*s)
    b=circ((0,0),r*s)+seg(A,Cc)+seg(A,B)+seg(B,Cc)+pt(A)+pt(B)+pt(Cc)
    b+=lab(A,"$A$","left")+lab(B,"$B$","above")+lab(Cc,"$C$","right")+lab(mid(A,B),"$10$","above left",sz="\\footnotesize")+lab((0,-0.02),"$26$","below",sz="\\footnotesize")
    return F(b)
def F111():
    r=2.2;O=(0,0);A=(-r,0);Cc=(r,0)
    t=math.sqrt(4*r*r-r*r);D=(r,t);E=(r*r/(2*r),r*t/(2*r))
    b=circ(O,r)+seg(A,Cc)+seg(O,D)+seg(Cc,D)+arcp(O,r,math.degrees(math.atan2(E[1],E[0])),180)
    b+=pt(A)+pt(O)+pt(Cc)+pt(D)+pt(E)+rt(O,Cc,D,0.2)
    b+=lab(A,"$A$","left")+lab(O,"$O$","below")+lab(Cc,"$C$","below right")+lab(D,"$D$","above")+lab(E,"$E$","above left")
    b+=lab((0,-r),"$AC=426$","below")+lab(mid(E,D),"$OD=426$","right",sz="\\footnotesize")
    return F(b,0.95)
def F155():
    s=0.085;r=26;AB=48
    bx=(AB**2-2*r*r)/(2*r);by=math.sqrt(r*r-bx*bx)
    A=(-r*s,0);Cc=(r*s,0);B=(bx*s,by*s)
    b=circ((0,0),r*s)+seg(A,Cc)+seg(A,B)+seg(B,Cc)+pt(A)+pt(B)+pt(Cc)
    b+=lab(A,"$A$","left")+lab(B,"$B$","above")+lab(Cc,"$C$","right")+lab(mid(A,B),"$48$","above left",sz="\\footnotesize")+lab((0,-0.0),"$52$","below",sz="\\footnotesize")
    return F(b)
def F159():
    R=2.0;s=2.0/12;ch=12*math.sqrt(3)*s/2;dy=math.sqrt(R*R-ch*ch)
    O=(0,0);A=(-ch,-dy);B=(ch,-dy)
    a1=math.degrees(math.atan2(-dy,ch));a0=math.degrees(math.atan2(-dy,-ch))  # B angle (-30), A angle (-150)
    b="\\fill[ORANGE!20] (%s,%s)--(%s,%s) arc (%s:%s:%s)--cycle;"%(f(A[0]),f(A[1]),f(B[0]),f(B[1]),f(a1),f(a0),f(R))
    b+=circ(O,R)+seg(A,B)+seg(O,A)+seg(O,B)+pt(O)+pt(A)+pt(B)
    b+=lab(O,"$O$","above")+lab(A,"$A$","below left")+lab(B,"$B$","below right")
    b+=lab(mid(O,A),"$12$","above left",sz="\\footnotesize")+lab((0,-dy),"$12\\sqrt3$","above",sz="\\footnotesize")
    return F(b)
def F166():
    s=0.25;AB=20;CD=8
    t=(AB-math.sqrt(AB*AB-4*CD*CD))/2   # AD, the smaller root of t(AB-t)=CD^2
    A=(-10*s,0);B=(10*s,0);D=((-10+t)*s,0);Cc=((-10+t)*s,CD*s)
    b=circ((0,0),10*s)+seg(A,B)+seg(A,Cc)+seg(Cc,B)+seg(Cc,D)+pt(A)+pt(B)+pt(Cc)+pt(D)+rt(A,D,Cc,0.18)
    b+=lab(A,"$A$","left")+lab(B,"$B$","right")+lab(Cc,"$C$","above")+lab(D,"$D$","below")
    b+=lab(mid(D,Cc),"$8$","right",sz="\\footnotesize")+lab((0,-0.05),"$AB=20$","below")
    return F(b)
def F170():
    s=0.42;d=3;r=d/math.cos(math.radians(60))
    A=pol(r*s,60);B=pol(r*s,-60);O=(0,0);P=(r/math.cos(math.radians(60))*s,0);M=(d*s,0)
    b=circ(O,r*s)+seg(O,A)+seg(O,B)+seg(A,B)+seg(O,M,"thin,INK,dashed")+seg(P,A)+seg(P,B)
    b+=pt(O)+pt(A)+pt(B)+pt(P)+rt(O,M,A,0.16)
    b+="\\draw[thin,INK] (%s,%s) arc (-60:60:%s);"%(f(0.5*math.cos(math.radians(60))),f(-0.5*math.sin(math.radians(60))),f(0.5))
    b+="\\node[font=\\scriptsize,fill=white,inner sep=1pt] at (0.95,0.3) {$120^\\circ$};"
    b+=lab(O,"$O$","left")+lab(A,"$A$","above")+lab(B,"$B$","below")+lab(P,"$P$","right")+lab((1.0,0),"$3$","below",sz="\\footnotesize")
    return F(b)
def F192():
    s=0.17;r=13;d=5;h=math.sqrt(r*r-d*d)
    O=(0,0);A=(-h*s,-d*s);B=(h*s,-d*s);M=(0,-d*s)
    b=circ(O,r*s)+seg(A,B)+seg(O,M,"thin,INK,dashed")+seg(O,A,"thin,INK")+pt(O)+pt(A)+pt(B)+rt(O,M,B,0.16)
    b+=lab(O,"$O$","above")+lab(mid(O,M),"$5$","right",sz="\\footnotesize")+lab(mid(O,A),"$13$","left",sz="\\footnotesize")
    return F(b)
def F193():
    r=1.9;A=(-r,0);B=(r,0);th=28;Cc=(A[0]+2*r*math.cos(math.radians(th))**2,2*r*math.cos(math.radians(th))*math.sin(math.radians(th)))
    assert abs(math.hypot(*Cc)-r)<1e-9
    b=circ((0,0),r)+seg(A,B)+seg(A,Cc)+seg(Cc,B)+pt(A)+pt(B)+pt(Cc)
    b+=ang(A,B,Cc,0.55,"$28^\\circ$",0.95)
    b+=lab(A,"$A$","left")+lab(B,"$B$","right")+lab(Cc,"$C$","above")
    return F(b)
def F194():
    s=0.28;r=6;OP=10
    xa=r*r/OP;ya=r*math.sqrt(OP*OP-r*r)/OP
    O=(0,0);P=(OP*s,0);A=(xa*s,ya*s);B=(xa*s,-ya*s)
    b=circ(O,r*s)+seg(O,P,"thin,INK,dashed")+seg(O,A)+seg(O,B)+seg(P,A)+seg(P,B)+pt(O)+pt(A)+pt(B)+pt(P)
    b+=lab(O,"$O$","left")+lab(A,"$A$","above")+lab(B,"$B$","below")+lab(P,"$P$","right")
    b+=lab(mid(O,A),"$6$","above left",sz="\\footnotesize")+lab(mid(O,P),"$10$","below",sz="\\footnotesize")
    return F(b)
FIG={k:v for k,v in globals().items() if k.startswith('F') and k[1:].isdigit()}
