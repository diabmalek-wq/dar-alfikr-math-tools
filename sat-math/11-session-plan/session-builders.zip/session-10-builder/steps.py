"""Desmos solutions for Session 10: every problem has 3-4 numbered steps that work it in Desmos.
Every quoted value is computed here (ev) and re-checked by verify_steps.py with a separate evaluator."""
import math,re
from fractions import Fraction as Fr
import steps_old as O
PI=math.pi
n=O.n; fr=O.fr; M=O.M
def ev(expr,**kw):
    e=expr.replace('^','**')
    e=re.sub(r'(\d+(?:\.\d+)?)\s*deg\b',r'(\1*pi/180)',e)
    e=re.sub(r'(\d|\))\s*(\(|[a-zA-Z])',r'\1*\2',e)
    return eval(e,{'__builtins__':{}},dict(sqrt=math.sqrt,abs=abs,pi=PI,sin=math.sin,cos=math.cos,tan=math.tan,arcsin=math.asin,arccos=math.acos,arctan=math.atan,**kw))
def c(e): return '[[%s]]'%e
def ret(e,d=4,**kw): return "Type %s: it returns $%s$"%(c(e),n(ev(e,**kw),d))
def pt(x,y,d=4): return "$(%s,\\,%s)$"%(n(x,d),n(y,d))
TAPS={}      # id -> list of (curves, (x,y)); re-checked independently in verify_steps.py
IDENT={}     # id -> list of (eq1,eq2) typed equations that must be the same curve
TANG={}      # id -> list of (circle, line) that must meet in exactly one point
def tap(i,curves,*pts):
    for p in pts: TAPS.setdefault(i,[]).append((list(curves),p))
    return " and ".join(pt(*p) for p in pts)
def rng(i,e,vals,d=4):   # value independent of a slider: shown once, checked at many slider values
    vs={round(ev(e,a=x),9) for x in vals}; assert len(vs)==1,(i,e,vs)
    RNG.setdefault(i,[]).append((e,list(vals)))
    return "Type %s: it returns $%s$ for every value of $a$"%(c(e),n(vs.pop(),d))
RNG={}
LTR='@@L@@'
S={};ANS=dict(O.ANS)
for k in ('GT-122','GT-123','GT-127','GT-148'): S[k]=list(O.S[k])
# tap registrations for the reused items
TAPS['GT-123']=[(['x^2+y^2-4x+2y=24','x+y=4'],(0,4)),(['x^2+y^2-4x+2y=24','x+y=4'],(7,-3))]
TAPS['GT-127']=[(['y=x^2+2x+4','y=10(x-1)-2'],(4,28))]
TAPS['GT-148']=[(['y=3x^2-35x+100','y=0'],(5,0)),(['y=3x^2-35x+100','y=0'],(20/3,0))]
TANG['GT-127']=[('y=x^2+2x+4','y=10(x-1)-2')]
TANG['GT-122']=[]
def circ_pts(h,k,r2): return (h,k,r2)

# ---- 054
tot=52+260
S['GT-054']=["The minor and major arcs together go once around the circle, so the circumference is their sum. Type "+c('52+260')+": it returns $%d$."%tot,
 ret('52/312')+", so the $52$ m arc is $\\dfrac16$ of the circle, which fits a short minor arc.",
 "The circumference is $%d$ meters, choice (%s)."%(tot,LTR)]
# ---- 055
S['GT-055']=["Type the circle exactly as given: %s. Desmos draws it."%c('2x^2-8x+2y^2+12y=24'),
 "Center: for $2x^2-8x$ the center's $x$ is $\\dfrac{8}{2\\cdot2}$: "+ret('8/(2*2)')+"; for $2y^2+12y$ it is $-\\dfrac{12}{2\\cdot2}$: "+ret('-12/(2*2)')+".",
 "Draw the horizontal line through the center, %s, and tap where it meets the circle: %s."%(c('y=-3'),tap('GT-055',['2x^2-8x+2y^2+12y=24','y=-3'],(-3,-3),(7,-3))),
 ret('(7-(-3))/2')+", the radius, choice (%s)."%LTR]
# ---- 056
S['GT-056']=["Type the circle: %s."%c('x^2+y^2-14x+22y+10=0'),
 "The center's coordinates are $-\\dfrac{D}{2}$ and $-\\dfrac{E}{2}$: "+ret('14/2')+" and "+ret('-22/2')+".",
 "Check: type %s (center $(7,-11)$, $r^2=7^2+11^2-10$). It lies exactly on top of the first circle."%c('(x-7)^2+(y+11)^2=7^2+11^2-10'),
 "The center is $(7,-11)$, choice (%s)."%LTR]
IDENT['GT-056']=[('x^2+y^2-14x+22y+10=0','(x-7)^2+(y+11)^2=7^2+11^2-10')]
# ---- 057
sr=Fr(-1-(-5),9-2)
S['GT-057']=["Type the center %s and the point of tangency %s."%(c('(2,-5)'),c('(9,-1)')),
 "Slope of the radius: "+ret('(-1-(-5))/(9-2)')+" (that is $\\dfrac47$).",
 "The tangent is perpendicular to the radius, so use the negative reciprocal: "+ret('-1/((-1-(-5))/(9-2))')+".",
 "Check: type the circle %s and the line %s. The line touches the circle only at $(9,-1)$. The slope is $-\\dfrac74$."%(c('(x-2)^2+(y+5)^2=(9-2)^2+(-1+5)^2'),c('y=-1.75(x-9)-1'))]
TANG['GT-057']=[('(x-2)^2+(y+5)^2=(9-2)^2+(-1+5)^2','y=-1.75(x-9)-1')]
# ---- 073
S['GT-073']=["Type the circle: %s."%c('(x+2)^2+(y-5)^2=49'),
 "Draw the horizontal line through the center, %s, and tap the two ends: %s."%(c('y=5'),tap('GT-073',['(x+2)^2+(y-5)^2=49','y=5'],(-9,5),(5,5))),
 ret('(5-(-9))/2')+", which is the radius.",
 "Check: "+ret('sqrt(49)')+". The radius is $7$, choice (%s)."%LTR]
# ---- 074
S['GT-074']=["Circumference: type "+c('2*3.14*9')+": it returns $%s$."%n(ev('2*3.14*9'),2),
 ret('80/360')+", the fraction of the circle for $80^\\circ$.",
 ret('2*3.14*9*80/360')+", so the arc is about $12.6$ cm, choice (%s)."%LTR]
# ---- 075
S['GT-075']=["Area of the whole circle: type "+c('3.14*12^2')+": it returns $%s$."%n(ev('3.14*12^2'),2),
 ret('150/360')+", the fraction of the circle for $150^\\circ$.",
 ret('3.14*12^2*150/360')+", so the sector area is $188.4$ square meters, choice (%s)."%LTR]
# ---- 076
S['GT-076']=["Type the circle: %s."%c('x^2+y^2-6x+10y+18=0'),
 "Center: "+ret('6/2')+" and "+ret('-10/2')+", so $C=(3,-5)$.",
 "Distance from $C$ to the origin: "+ret('sqrt(3^2+(-5)^2)')+".",
 "Check: "+ret('sqrt(34)')+", the same number, so the distance is $\\sqrt{34}$, choice (%s)."%LTR]
# ---- 085
S['GT-085']=["Type the equation exactly as given: %s. Desmos draws the circle."%c('x(x-8)+y(y+6)=39'),
 "Expanded, it is $x^2-8x+y^2+6y=39$, so the center is "+ret('8/2')+" and "+ret('-6/2')+".",
 "Radius: "+ret('sqrt(39+4^2+3^2)')+".",
 "Check: draw %s and tap its ends %s; "%(c('y=-3'),tap('GT-085',['x(x-8)+y(y+6)=39','y=-3'],(-4,-3),(12,-3)))+ret('(12-(-4))/2')+". The radius is $8$, choice (%s)."%LTR]
# ---- 086
S['GT-086']=["Type the center %s and the point %s."%(c('(0,3)'),c('(5,15)')),
 "The radius squared is the squared distance between them: "+ret('(5-0)^2+(15-3)^2')+".",
 "Type the circle %s: it passes through both points, so it is the correct option, choice (%s)."%(c('x^2+(y-3)^2=169'),LTR),
 "The option with $144$ on the right fails: $(5,15)$ is $5$ across and $12$ up from the center, so "+ret('5^2+(15-3)^2')+", not $144$."]
# ---- 091
S['GT-091']=["The area is $\\pi r^2=144\\pi$, so $r=$ "+ret('sqrt(144)')+".",
 "Circumference: "+ret('2*pi*12')+".",
 "Check against $24\\pi$: "+ret('24*pi')+". The circumference is $24\\pi$ ft, choice (%s)."%LTR]
# ---- 099
S['GT-099']=["Triangle $OBC$ is isosceles ($OB=OC$), so $\\angle OCB=64^\\circ$. Type "+c('180-2*64')+": it returns $%d$, the angle $BOC$."%(180-128),
 "$\\angle AOD$ is vertical to $\\angle BOC$, so it is also $52^\\circ$, and a central angle equals its arc.",
 "Check: "+ret('(180-52)/2')+", which is the $64^\\circ$ given in the base angles.",
 "Arc $AD=52^\\circ$."]
# ---- 103
S['GT-103']=["Sector area is $\\dfrac12r^2\\theta$. With $\\theta=k\\pi$ the area is $\\dfrac12(81)k\\pi=18\\pi$, so $k=\\dfrac{2\\cdot18}{81}$: "+ret('2*18/9^2')+".",
 "As a fraction: "+ret('4/9')+", so $k=\\dfrac49$.",
 "Check: type "+c('1/2*9^2*(4/9)*pi')+": it returns $%s$, and "%n(ev('1/2*9^2*(4/9)*pi'))+ret('18pi'),
 "Enter $\\dfrac49$ (or $0.444$)."]
# ---- 104
S['GT-104']=["Circumference $2\\pi r$ equals $(3x+4)\\pi$, so $2(2x-3)=3x+4$. Type %s and %s."%(c('y=2(2x-3)'),c('y=3x+4')),
 "Tap the intersection: %s, so $x=10$."%tap('GT-104',['y=2(2x-3)','y=3x+4'],(10,34)),
 "Radius: "+ret('2*10-3')+".",
 "Area: "+ret('pi*17^2')+", and "+ret('289pi')+" is the same value, choice (%s)."%LTR]
# ---- 105
S['GT-105']=["Type the circle: %s."%c('x^2+y^2-8x+10y=8'),
 "Center: "+ret('8/2')+" and "+ret('-10/2')+".",
 "Radius: "+ret('sqrt(8+4^2+5^2)')+".",
 "Check: the point "+tap('GT-105',['x^2+y^2-8x+10y=8'],(11,-5))+" (seven units right of the center) is on the circle, so the radius is $7$."]
# ---- 106
S['GT-106']=["$\\angle ABC=90^\\circ$ makes $AC=13$ a diameter, so $AD+CD=13$, and the altitude gives $AD\\cdot CD=BD^2$: "+ret('6^2')+".",
 "Type %s and %s ($x$ stands for $AD$)."%(c('y=x(13-x)'),c('y=36')),
 "Tap the two intersections: %s. Since $AB<BC$, $D$ is closer to $A$: $AD=4$, $CD=9$."%tap('GT-106',['y=x(13-x)','y=36'],(4,36),(9,36)),
 ret('9/4')+", so $\\dfrac{CD}{AD}=\\dfrac94$."]
# ---- 108
S['GT-108']=["Crossing chords: $AD\\cdot DC=BD\\cdot DE$, that is $4\\cdot15=6\\cdot DE$. Type %s and %s."%(c('y=6x'),c('y=4*15')),
 "Tap the intersection: %s, so $DE=10$."%tap('GT-108',['y=6x','y=4*15'],(10,60)),
 ret('6+10')+", the length $BE=BD+DE$."]
# ---- 109
S['GT-109']=["$AC$ is a diameter, so $\\angle ABC=90^\\circ$ and $AC$ is the hypotenuse.",
 "Type "+c('sqrt(26^2-10^2)')+": it returns $%s$."%n(ev('sqrt(26^2-10^2)')),
 "The wrong subtraction $26-10$ would give "+ret('26-10')+"; adding squares gives "+ret('sqrt(26^2+10^2)')+", which is not a choice.",
 "$BC=24$, choice (%s)."%LTR]
# ---- 111
S['GT-111']=["$OC=213$ and $OD=426$, and $CD\\perp OC$, so $\\cos\\angle COD=\\dfrac{213}{426}$. Type "+c('arccos(213/426)*180/pi')+": it returns $%s$ (degrees)."%n(ev('arccos(213/426)*180/pi')),
 "$E$ is on $OD$, so $\\angle AOE=180-60$: "+ret('180-60')+".",
 "Arc $AE=\\dfrac{120}{360}\\cdot2\\pi(213)$, so $b=$ "+ret('120/360*2*213')+".",
 "$b=142$."]
# ---- 115
S['GT-115']=["Circle $A$: center "+ret('8/2')+" and "+ret('-6/2')+", so $(4,-3)$.",
 "Circle $B$ has radius "+ret('10-4')+" (distance from $(4,-3)$ to $(10,-3)$), and twice the diameter, so $A$ has radius "+ret('6/2')+".",
 "Circle $A$ is $(x-4)^2+(y+3)^2=8n+25$ and $r^2=9$, so "+ret('(9-25)/8')+".",
 "Check: with $n=-2$ the circle is %s; its radius is "%c('x^2+y^2-8x+6y+16=0')+ret('sqrt(4^2+3^2-16)')+"."]
# ---- 117
S['GT-117']=["Type the circle: %s."%c('x^2-18x+y^2-6y=-38'),
 "Center: "+ret('18/2')+" and "+ret('6/2')+".",
 "$r^2=-38+9^2+3^2$: "+ret('-38+9^2+3^2')+".",
 "Area $=\\pi r^2$: "+ret('pi*52')+", which equals $52\\pi$, choice (%s)."%LTR]
# ---- 123 (reused), 127, 148 reused
# ---- 131
S['GT-131']=["Center of $x^2+y^2-6x+8y=k$: "+ret('6/2')+" and "+ret('-8/2')+", so $(3,-4)$.",
 "Radius = distance from the center to the line $4x-3y+11=0$: "+ret('abs(4*3-3*(-4)+11)/sqrt(4^2+3^2)')+".",
 "$r^2=k+3^2+4^2$, so $k=r^2-25$: "+ret('7^2-3^2-4^2')+".",
 "Check: type %s and %s; they touch at one point, %s."%(c('x^2+y^2-6x+8y=24'),c('4x-3y=-11'),tap('GT-131',['x^2+y^2-6x+8y=24','4x-3y=-11'],(-2.6,0.2)))]
TANG['GT-131']=[('x^2+y^2-6x+8y=24','4x-3y=-11')]
# ---- 135
S['GT-135']=["Type the circle %s and accept the slider for $a$; the circle slides as $a$ changes."%c('(x-a-2)^2+(y-2a+1)^2=25'),
 "Type the candidate point %s: it stays on the circle while you move $a$. Check the distance to the center $(a+2,2a-1)$: "%c('(a+5,2a+3)')+rng('GT-135','((a+5)-(a+2))^2+((2a+3)-(2a-1))^2',[-9,-3,0,2,7])+", which is $r^2$.",
 "The point %s leaves the circle: "%c('(a+5,2a+4)')+rng('GT-135','((a+5)-(a+2))^2+((2a+4)-(2a-1))^2',[-9,-3,0,2,7])+", not $25$.",
 "The point that always lies on the circle is the one in choice (%s)."%LTR]
# ---- 137
kp=1+math.sqrt(7); km=1-math.sqrt(7)
S['GT-137']=["Second circle: $x^2-4kx$ and $y^2+2ky$ give center $(2k,-k)$. It must lie on the first circle: $(2k-1)^2+(-k+3)^2=40$, i.e. $k^2-2k-6=0$.",
 "Type %s and tap the zeros: %s."%(c('y=x^2-2x-6'),tap('GT-137',['y=x^2-2x-6','y=0'],(kp,0),(km,0))),
 "Take the positive one: "+ret('1+sqrt(7)')+".",
 "$k=1+\\sqrt7$, choice (%s)."%LTR]
# ---- 140
S['GT-140']=["The points $(2,7)$ and $(10,7)$ share $y$, so the center's $x$ is "+ret('(2+10)/2')+".",
 "Center $(6,m)$, radius $5$: $m=7-\\sqrt{25-4^2}$ (below $y=7$): "+ret('7-sqrt(5^2-(6-2)^2)')+".",
 "$D=-12$, $E=-8$, $F=6^2+4^2-25$: "+ret('6^2+4^2-25')+"; type the circle %s: it passes through %s."%(c('x^2+y^2-12x-8y+27=0'),tap('GT-140',['x^2+y^2-12x-8y+27=0'],(2,7),(10,7))),
 "$E+F=$ "+ret('-8+27')+"."]
# ---- 144
S['GT-144']=["Type the circle %s; its center is $(2,-3)$ and its radius is "%c('x^2+y^2-4x+6y-12=0')+ret('sqrt(12+2^2+3^2)')+".",
 "A tangent of slope $\\frac34$ touches where the radius has slope $-\\frac43$, i.e. at center $\\pm5\\cdot\\dfrac{(-3,4)}{5}$. The point with positive $y$: "+ret('2-5*3/5')+" and "+ret('-3+5*4/5')+", so $(-1,1)$.",
 "$y$-intercept: "+ret('1-3/4*(-1)')+".",
 "Type %s: it touches the circle once, at %s. The $y$-intercept is $\\dfrac74$, choice (%s)."%(c('y=3/4x+7/4'),tap('GT-144',['x^2+y^2-4x+6y-12=0','y=3/4x+7/4'],(-1,1)),LTR)]
TANG['GT-144']=[('x^2+y^2-4x+6y-12=0','y=3/4x+7/4')]
# ---- 146
S['GT-146']=["Type the circle %s and the point %s: the point is $5$ units left of the center, so $\\sin\\theta=\\dfrac35$."%(c('(x-7)^2+(y+2)^2=9'),c('(2,-2)')),
 "Slope of each tangent: "+ret('tan(arcsin(3/5))')+" and its negative.",
 "Check with a slider: type %s; at $m=0.75$ the line touches the circle once (and at $m=-0.75$ as well)."%c('y+2=m(x-2)'),
 "Product: "+ret('(3/4)*(-3/4)')+", so $-\\dfrac{9}{16}$."]
TANG['GT-146']=[('(x-7)^2+(y+2)^2=9','y+2=0.75(x-2)'),('(x-7)^2+(y+2)^2=9','y+2=-0.75(x-2)')]
# ---- 150
S['GT-150']=["Type the points %s and %s. The center is $(0,k)$ with equal distances: $36+(1-k)^2=4+(5-k)^2$."%(c('(6,1)'),c('(-2,5)')),
 "This simplifies to $37-2k=29-10k$, so $k=$ "+ret('(29-37)/8')+".",
 "$r^2=36+(1-k)^2$: "+ret('6^2+(1-(-1))^2')+".",
 "Type %s: it passes through both points (%s). Choice (%s)."%(c('x^2+(y+1)^2=40'),tap('GT-150',['x^2+(y+1)^2=40'],(6,1),(-2,5)),LTR)]
# ---- 155
S['GT-155']=["Radius: "+ret('52/2')+", so the diameter is $52=AC$ and $\\angle B=90^\\circ$.",
 "$BC$: "+ret('sqrt(52^2-48^2)')+", the shortest side.",
 "Ratio: "+ret('20/26')+".",
 "Check: "+ret('10/13')+" is the same number, choice (%s)."%LTR]
# ---- 156
S['GT-156']=["One common point means the line $y=mx+10$ is tangent to $x^2+y^2=12$. Type %s and %s with a slider for $m$."%(c('x^2+y^2=12'),c('y=mx+10')),
 "Distance from the center to the line: $\\dfrac{10}{\\sqrt{m^2+1}}=\\sqrt{12}$, so $m^2=\\dfrac{100}{12}-1$: "+ret('100/12-1')+".",
 "As a fraction: "+ret('22/3')+". The slider touches at $m=\\pm$ "+ret('sqrt(22/3)')+".",
 "Check: "+ret('10/sqrt(22/3+1)')+" equals "+ret('sqrt(12)')+". So $m^2=\\dfrac{22}{3}$."]
# ---- 157
S['GT-157']=["Type %s and %s; tap the two intersections: %s."%(c('x^2+y^2+8x-2y-8=0'),c('5x+12y=44'),tap('GT-157',['x^2+y^2+8x-2y-8=0','5x+12y=44'],(-2.4615384615384617+36/13,4.6923076923076925-15/13),(-2.4615384615384617-36/13,4.6923076923076925+15/13))),
 "Center $C=(-4,1)$. Its distance to the line is the height of the triangle: "+ret('abs(5*(-4)+12*1-44)/sqrt(5^2+12^2)')+".",
 "Half the chord: "+ret('sqrt(25-4^2)')+", so $PQ=6$.",
 "Area: "+ret('1/2*6*4')+", choice (%s)."%LTR]
# ---- 159
S['GT-159']=["Angle at the center: "+ret('arccos((12^2+12^2-(12*sqrt(3))^2)/(2*12*12))*180/pi')+" degrees.",
 "Sector: "+ret('120/360*pi*12^2')+". Triangle: "+ret('1/2*12*12*sin(120 deg)')+".",
 "Segment = sector $-$ triangle: "+ret('120/360*pi*12^2-1/2*12*12*sin(120 deg)')+".",
 "Check: "+ret('48pi-36sqrt(3)')+" is the same, choice (%s)."%LTR]
# ---- 164
S['GT-164']=["Sector area $\\dfrac12r^2\\theta=45\\pi$, so $\\theta=\\dfrac{2\\cdot45\\pi}{15^2}$: "+ret('2*45*pi/15^2')+" radians.",
 "Arc length $r\\theta$: "+ret('15*2*45*pi/15^2')+" (that is $6\\pi$).",
 "Perimeter: "+ret('2*15+15*2*45*pi/15^2')+".",
 "Check: "+ret('30+6pi')+", choice (%s)."%LTR]
# ---- 166
S['GT-166']=["$\\angle ACB=90^\\circ$ and $CD$ is the altitude, so $AD\\cdot DB=CD^2$: "+ret('8^2')+", with $AD+DB=20$.",
 "Type %s and %s; tap the intersections: %s. $AD<DB$, so $AD=4$."%(c('y=x(20-x)'),c('y=64'),tap('GT-166',['y=x(20-x)','y=64'],(4,64),(16,64))),
 "$AC=\\sqrt{AD^2+CD^2}$: "+ret('sqrt(4^2+8^2)')+".",
 "Check: "+ret('4sqrt(5)')+", choice (%s)."%LTR]
# ---- 167
S['GT-167']=["$r^2=48$ (area $48\\pi$). The square has diagonal $2r$, so its area is "+ret('2*48')+".",
 "Equilateral triangle: area $\\dfrac{3\\sqrt3}{4}r^2$: "+ret('3*sqrt(3)/4*48')+".",
 "Difference: "+ret('96-3*sqrt(3)/4*48')+".",
 "Check: "+ret('96-36sqrt(3)')+", choice (%s)."%LTR]
# ---- 169
S['GT-169']=["Type the circle %s: center $(-4,1)$, radius "%c('x^2+y^2+8x-2y=8')+ret('sqrt(8+4^2+1^2)')+".",
 "Tangent means distance $=5$: $\\dfrac{|k+32|}{13}=5$. Type %s and %s and tap: %s."%(c('y=abs(x+32)/13'),c('y=5'),tap('GT-169',['y=abs(x+32)/13','y=5'],(33,5),(-97,5))),
 "The greatest $k$ is $33$. Check: type %s; it touches the circle once. "%c('5x-12y=33')+ret('abs(5*(-4)-12*1-33)/13'),
 "$k=33$, choice (%s)."%LTR]
TANG['GT-169']=[('x^2+y^2+8x-2y=8','5x-12y=33')]
# ---- 170
S['GT-170']=["Half of $\\angle AOB$ is "+ret('120/2')+" degrees; $\\cos60^\\circ=\\dfrac3r$, so $r=$ "+ret('3/cos(60 deg)')+".",
 "$PA\\perp OA$ and $\\angle AOP=60^\\circ$, so $PA=r\\tan60^\\circ$: "+ret('6*tan(60 deg)')+".",
 "Check: "+ret('6sqrt(3)')+", choice (%s)."%LTR]
# ---- 172
S['GT-172']=["Center $(-r,r)$, radius $r$, through $(-2,9)$: $(r-2)^2+(9-r)^2=r^2$. Type %s and tap the zeros: %s."%(c('y=x^2-22x+85'),tap('GT-172',['y=x^2-22x+85','y=0'],(5,0),(17,0))),
 "Diameter under $15$: "+ret('2*5')+" works, while $2\\cdot17=34$ does not, so $r=5$.",
 "$F=h^2+k^2-r^2$: "+ret('(-5)^2+5^2-5^2')+".",
 "Check: "+ret('(-2+5)^2+(9-5)^2')+" equals $r^2=25$, so $(-2,9)$ is on $(x+5)^2+(y-5)^2=25$."]
# ---- 187
S['GT-187']=["Circumference: "+ret('2*pi*15')+" (that is $30\\pi$).",
 "Fraction of the circle: "+ret('6*pi/(2*pi*15)')+".",
 "Central angle: "+ret('6*pi/(2*pi*15)*360')+" degrees, choice (%s)."%LTR]
# ---- 188
S['GT-188']=["Area of the circle: "+ret('pi*6^2')+".",
 "Fraction: "+ret('12*pi/(pi*6^2)')+".",
 "Angle: "+ret('12/36*360')+" degrees."]
# ---- 189
S['GT-189']=["Type the circle %s (it passes through the origin)."%c('x^2+y^2+10x-24y=0'),
 "Center: "+ret('-10/2')+" and "+ret('24/2')+".",
 "Radius: "+ret('sqrt(0+5^2+12^2)')+".",
 "Diameter: "+ret('2*13')+"."]
# ---- 190
S['GT-190']=["Type the points %s and %s and the line %s (the center lies on it)."%(c('(4,14)'),c('(-1,-1)'),c('y=2x')),
 "The center is on the perpendicular bisector of the two points (midpoint $(1.5,6.5)$, slope $-\\frac13$). Type %s."%c('y=-1/3(x-3/2)+13/2'),
 "Tap the intersection with the line: %s, the center."%tap('GT-190',['y=2x','y=-1/3(x-3/2)+13/2'],(3,6)),
 "$r^2$: "+ret('(3-4)^2+(6-14)^2')+"."]
# ---- 191
S['GT-191']=["Type the circle %s and the point %s."%(c('(x-2)^2+(y+1)^2=25'),c('(6,2)')),
 "Radius slope "+ret('(2+1)/(6-2)')+"; tangent slope "+ret('-1/((2+1)/(6-2))')+".",
 "Type the tangent %s and tap its $x$-intercept: %s."%(c('y=-4/3(x-6)+2'),tap('GT-191',['y=-4/3(x-6)+2','y=0'],(7.5,0))),
 "Check: "+ret('6+(0-2)/(-4/3)')+". $a=\\dfrac{15}{2}$, choice (%s)."%LTR]
TANG['GT-191']=[('(x-2)^2+(y+1)^2=25','y=-4/3(x-6)+2')]
# ---- 192
S['GT-192']=["Type the circle %s and the line %s (the chord is $5$ units from the center)."%(c('x^2+y^2=13^2'),c('y=-5')),
 "Tap the ends of the chord: %s."%tap('GT-192',['x^2+y^2=13^2','y=-5'],(-12,-5),(12,-5)),
 "Length: "+ret('12-(-12)')+"."]
# ---- 193
S['GT-193']=["$AB$ is a diameter, so $\\angle ACB=90^\\circ$.",
 "Type "+c('180-90-28')+": it returns $%d$."%(180-90-28),
 "Check: "+ret('28+62+90')+", so $\\angle ABC=62^\\circ$."]
# ---- 194
S['GT-194']=["$\\angle PAO=90^\\circ$, so $PA=$ "+ret('sqrt(10^2-6^2)')+".",
 "Triangle $PAO$: "+ret('1/2*8*6')+".",
 "Two congruent triangles: "+ret('2*(1/2*8*6)')+"."]
# ---- 195
S['GT-195']=["Type the center %s and think of the $x$-axis %s."%(c('(-3,5)'),c('y=0')),
 "The radius is the distance to the axis, $5$. Type %s: it touches the $x$-axis once, at %s."%(c('(x+3)^2+(y-5)^2=25'),tap('GT-195',['(x+3)^2+(y-5)^2=25','y=0'],(-3,0))),
 "$r^2=$ "+ret('5^2')+", so the equation is the one in choice (%s)."%LTR]
TANG['GT-195']=[('(x+3)^2+(y-5)^2=25','y=0')]
# ---- 196
S['GT-196']=["Type %s and %s."%(c('x^2+y^2=100'),c('y=6')),
 "Tap the two points: %s."%tap('GT-196',['x^2+y^2=100','y=6'],(-8,6),(8,6)),
 "Distance: "+ret('8-(-8)')+"."]
# ---- 197
S['GT-197']=["Arc length $=r\\theta$, so $r=\\dfrac{10\\pi}{2\\pi/3}$. Type "+c('10pi/(2pi/3)')+": it returns $15$.",
 "Check: "+ret('15*(2*pi/3)')+" equals "+ret('10pi')+".",
 "The radius is $15$ centimeters."]
# ---- 198
S['GT-198']=["Ring area: $\\pi\\cdot7^2-\\pi r^2=48\\pi$, so $r^2=7^2-48$: "+ret('7^2-48')+".",
 "Radius: "+ret('sqrt(1)')+".",
 "Check: "+ret('pi*7^2-pi*1^2')+" equals "+ret('48pi')+"."]
# ---- 199
S['GT-199']=["Perimeter minus the two radii gives the arc: "+ret('24+4pi-2*12')+" (that is $4\\pi$).",
 "Angle $=\\dfrac{\\text{arc}}{2\\pi r}\\cdot360$: "+ret('(24+4pi-2*12)/(2pi*12)*360')+".",
 "Check: "+ret('60/360*2pi*12')+" matches the arc, choice (%s)."%LTR]
# ---- 200
S['GT-200']=["Radius: "+ret('sqrt(50)')+". The square's diagonal is the diameter: "+ret('2*sqrt(50)')+".",
 "Square area $=\\dfrac{d^2}{2}$: "+ret('(2*sqrt(50))^2/2')+".",
 "Check: the circle's area "+ret('pi*50')+" is bigger than the square: the square is $100$."]
TOOL={i:'D' for i in S}
VERBAL=[]
