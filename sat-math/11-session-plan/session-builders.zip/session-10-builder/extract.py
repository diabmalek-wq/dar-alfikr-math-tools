import re,json,csv
B=open('/home/claude/repo-check2/sat-bank/verified-item-bank/SAT_Bank_Verified_Item_Bank.md').read()
blocks=re.split(r'\n### ',B)
d={}
for b in blocks[1:]:
    iid=b.split('\n')[0].strip(); d[iid]=b
rows=[r for r in csv.DictReader(open('/home/claude/cb/session_plan_11.csv')) if r['session']=='10']
out=[]
for r in rows:
    b=d[r['id']]
    q=re.search(r'\*\*Question:\*\*\s*(.*?)\n\n\*\*Correct Answer',b,re.S).group(1).strip()
    ans=re.search(r'\*\*Correct Answer:\*\*\s*(.*)',b).group(1).strip()
    m=re.search(r'\*\*Rationale:\*\*\s*(.*?)(\n\n\*\*|\Z)',b,re.S); rat=m.group(1).strip() if m else print('NORAT',r['id']) or ''
    fmt=re.search(r'\*\*Format:\*\*\s*([^\n]*)',b).group(1)
    out.append(dict(id=r['id'],part=r['part'],d=r['difficulty'],fmt=fmt,q=q,ans=ans,rat=rat))
json.dump(out,open('raw_items.json','w'),indent=1)
for o in out:
    print('=====',o['id'],o['part'],o['d'],o['fmt']);print(o['q']);print('ANS:',o['ans']);print('RAT:',o['rat'])
