"""raw bank items -> items.json (cleaned stems, parsed options, optional context/duplicate-avoidance edits)."""
import json,re
raw=json.load(open('raw_items.json'))
CLEAN=[(" in a Jeddah park",""),("A circular roundabout on the Jeddah Corniche has","A circular roundabout has"),("$64°$","$64^\\circ$")]
# edits made to avoid near-duplicate questions inside the session (math re-verified in solve.py)
MOD={}
MOD['GT-076']=dict(q="A circle in the $xy$-plane is defined by the equation $x^2 + y^2 - 6x + 10y + 18 = 0$. What is the distance, in units, from the center of the circle to the origin?",
  opts=["$\\sqrt{34}$","$34$","$4$","$2\\sqrt{34}$"],ans="A")
MOD['GT-117']=dict(q="The equation $x^2-18x+y^2-6y=-38$ represents a circle in the $xy$-plane. What is the area of the circle?",
  opts=["$43\\pi$","$52\\pi$","$128\\pi$","$2\\sqrt{13}\\,\\pi$"],ans="B")
MOD['GT-187']=dict(q="A circle has radius $15$. An arc of the circle has length $6\\pi$. What is the measure, in degrees, of the central angle that subtends the arc?",
  opts=["$18$","$72$","$36$","$144$"],ans="B")
MOD['GT-191']=dict(q="In the $xy$-plane, the circle $(x-2)^2+(y+1)^2=25$ passes through the point $(6,2)$. The line tangent to the circle at $(6,2)$ crosses the $x$-axis at the point $(a,0)$. What is the value of $a$?",
  opts=["$\\dfrac32$","$\\dfrac{10}{3}$","$\\dfrac{15}{2}$","$\\dfrac{26}{3}$"],ans="C")
MOD['GT-199']=dict(q="A sector of a circle has radius $12$ and perimeter $24+4\\pi$. What is the measure, in degrees, of the central angle of the sector?",
  opts=["$30$","$60$","$120$","$240$"],ans="B")
MOD['GT-157']=dict(q="In the $xy$-plane, the circle $x^{2}+y^{2}+8x-2y-8=0$ and the line $5x+12y=44$ intersect at two points, $P$ and $Q$. Let $C$ be the center of the circle. What is the area of triangle $CPQ$?",
  opts=["$6$","$12$","$24$","$\\dfrac{25}{2}$"],ans="B")
MOD['GT-166']=dict(q="Segment $\\overline{AB}$ is a diameter of a circle and has length $20$. Point $C$ lies on the circle, and point $D$ lies on $\\overline{AB}$ with $\\overline{CD}\\perp\\overline{AB}$ and $CD=8$. If $AD<DB$, what is the length of $\\overline{AC}$?",
  opts=["$4\\sqrt5$","$8\\sqrt5$","$4\\sqrt{17}$","$10$"],ans="A")
MOD['GT-190']=dict(q="In the $xy$-plane, a circle has its center on the line $y=2x$ and passes through the points $(4,14)$ and $(-1,-1)$. What is the square of the radius of the circle?",
  ans_text="65")
ANSTXT={'GT-057':'-\\dfrac{7}{4}','GT-103':'\\dfrac{4}{9}','GT-106':'\\dfrac{9}{4}','GT-146':'-\\dfrac{9}{16}','GT-148':'\\dfrac{35}{3}','GT-156':'\\dfrac{22}{3}'}
FIG={'GT-054':'F054','GT-099':'F099','GT-106':'F106','GT-108':'F108','GT-109':'F109','GT-111':'F111','GT-155':'F155','GT-159':'F159','GT-166':'F166','GT-170':'F170','GT-192':'F192','GT-193':'F193','GT-194':'F194'}
out=[]
for o in raw:
    q=o['q']
    q=re.sub(r'\*\*Figure.*?```\n\n','',q,flags=re.S)           # GT-159: bank's TikZ block is replaced by figs.py (same numbers)
    q=re.sub(r'\n*```latex.*?```','',q,flags=re.S)
    for a,b in CLEAN: q=q.replace(a,b)
    q=re.sub(r'^(\$\$.+?\$\$)\s*(?=\$\$)',r'\1\n\n',q,flags=re.S)
    q=re.sub(r'^(\$\$.+?\$\$)\s+(?=[A-Z])',r'\1\n\n',q,flags=re.S)
    q=re.sub(r'(\$\$.+?\$\$)\s+(?=In the)',r'\1\n\n',q,flags=re.S) if q.count('$$')>=4 else q
    stem=[];opts=[]
    for ln in q.split('\n'):
        m=re.match(r'^\(?([A-D])\)\s*(.*)$',ln.strip())
        if m and (opts or m.group(1)=='A'): opts.append(m.group(2).strip())
        elif ln.strip()=='':
            if not opts: stem.append(ln)
        elif opts: opts[-1]+=' '+ln.strip()
        else: stem.append(ln)
    stem='\n'.join(stem).strip()
    stem=re.sub(r'\n\s*\n+','\n\n',stem)
    mc=o['fmt'].startswith('Multiple')
    letter=re.match(r'^\(?([A-D])\)',o['ans']).group(1) if mc else None
    d=dict(id=o['id'],part=o['part'],d=o['d'],mc=mc,q=stem,opts=opts if mc else None,bank_letter=letter,bank_ans=o['ans'],fig=FIG.get(o['id']),mod=False)
    if o['id'] in MOD:
        m=MOD[o['id']]; d['mod']=True
        d['q']=m['q']
        if 'opts' in m: d['opts']=m['opts']; d['bank_letter']=m['ans']
        d['bank_ans']=(m.get('ans_text') or m.get('ans'))
    out.append(d)
for d in out:
    if not d['mc']:
        d['ans_text']=ANSTXT.get(d['id']) or re.sub(r'\$','',d['bank_ans']).split('(or')[0].strip()
    if d['mc']: assert len(d['opts'])==4 and len(set(d['opts']))==4,d['id']
json.dump(out,open('items.json','w'),indent=1)
for d in out: print(d['id'],d['part'][:2],d['mc'],d['fig'],'MOD' if d['mod'] else '','|',d['ans_text'] if not d['mc'] else d['bank_letter'])
