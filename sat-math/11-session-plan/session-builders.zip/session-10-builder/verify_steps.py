"""Independent verification of the Desmos steps. Uses a hand-written recursive-descent Desmos-syntax evaluator (not steps.ev)."""
import re,sys,math
sys.path.insert(0,'.')
import random
import numpy as np
import steps,solve
from steps import S,TAPS,IDENT,TANG,RNG,ANS
FN=dict(sqrt=math.sqrt,abs=abs,arcsin=math.asin,arccos=math.acos,arctan=math.atan,sin=math.sin,cos=math.cos,tan=math.tan,ln=math.log)
def tok(s):
    return re.findall(r"\d+\.?\d*|[A-Za-z]+|[-+*/^()]",s.replace(' ',''))
def dev(e,**env):
    """Desmos-syntax evaluator: recursive descent, implicit multiplication, ^, deg, pi."""
    t=tok(e);pos=[0];env=dict(env);env.update(pi=math.pi,deg=math.pi/180)
    def peek(): return t[pos[0]] if pos[0]<len(t) else None
    def nxt(): pos[0]+=1; return t[pos[0]-1]
    def starts_atom(p): return p is not None and (p[0].isdigit() or p[0].isalpha() or p=='(')
    def expr():
        v=term()
        while peek() in('+','-'):
            o=nxt(); w=term(); v=v+w if o=='+' else v-w
        return v
    def term():
        v=unary()
        while True:
            p=peek()
            if p=='*': nxt(); v=v*unary()
            elif p=='/': nxt(); v=v/unary()
            elif starts_atom(p): v=v*unary()
            else: return v
    def unary():
        if peek()=='-': nxt(); return -unary()
        return power()
    def power():
        b=atom()
        if peek()=='^': nxt(); return b**unary()
        return b
    def atom():
        p=nxt()
        if p=='(':
            v=expr(); assert nxt()==')'; return v
        if p[0].isdigit(): return float(p)
        if p in FN and peek()=='(':
            nxt(); v=expr(); assert nxt()==')'; return FN[p](v)
        return env[p]
    v=expr(); assert pos[0]==len(t),(e,t,pos); return v
def sides(eq):
    l,r=eq.split('='); return (lambda **kw:dev(l,**kw)),(lambda **kw:dev(r,**kw))
def g(eq,px,py): l,r=sides(eq); return l(x=px,y=py)-r(x=px,y=py)
def on(eq,p): return abs(g(eq,p[0],p[1]))<1e-9
def line_y(eq):   # y as a function of x for a line typed as an equation (linear in y)
    g0=lambda X:g(eq,X,0.0); g1=lambda X:g(eq,X,1.0)
    return lambda X:-g0(X)/(g1(X)-g0(X))
def ncommon(c1,c2):  # circle/parabola c1 with line c2: discriminant sign of h(x)=c1(x,y(x)) (quadratic in x)
    ly=line_y(c2); xs=[0.0,1.0,2.0]; A=np.polyfit(xs,[g(c1,X,ly(X)) for X in xs],2)
    assert abs(np.polyval(A,5.0)-g(c1,5.0,ly(5.0)))<1e-7
    disc=A[1]**2-4*A[0]*A[2]; scale=max(1,A[1]**2); return 1 if abs(disc)<1e-9*scale else (2 if disc>0 else 0)
bad=0;nbox=0;nret=0;prob_with=0
for i,st in S.items():
    boxes=re.findall(r"\[\[([^\]]+)\]\]"," ".join(st)); nbox+=len(boxes); prob_with+=bool(boxes)
    assert 3<=len(st)<=4,(i,len(st))
    for s in st:
        for mm in re.finditer(r"\[\[([^\]]+)\]\]: it returns \$([^$]+)\$",s):
            e,v=mm.group(1),mm.group(2).replace('\\,','')
            nret+=1
            if '=' in e: print('BAD returns on equation',i,e); bad+=1; continue
            got=dev(e,a=0.0)
            if abs(got-float(v))>6e-5*max(1,abs(float(v))): print('MISMATCH',i,e,got,v); bad+=1
# tapped points: on every curve, and quoted in the text
for i,L in TAPS.items():
    txt=" ".join(S[i])
    for curves,p in L:
        for c_ in curves:
            if not on(c_,p): print('TAP NOT ON CURVE',i,c_,p); bad+=1
        q="$(%s,\\,%s)$"%(steps.n(p[0]),steps.n(p[1]))
        if q not in txt and i not in('GT-123','GT-127','GT-148') : print('tap not quoted',i,q); bad+=1
# slider-independent claims
for i,L in RNG.items():
    for e,vals in L:
        vs={round(dev(e,a=v),9) for v in vals}
        if len(vs)!=1: print('RNG',i,e,vs); bad+=1
# identical curves (same function at many random points)
for i,L in IDENT.items():
    for e1,e2 in L:
        for _ in range(30):
            px,py=random.uniform(-9,9),random.uniform(-9,9)
            if abs(g(e1,px,py)-g(e2,px,py))>1e-8: print('NOT IDENT',i,e1,e2); bad+=1; break
# tangency: exactly one real common point; two-point claims
for i,L in TANG.items():
    for c1,c2 in L:
        if ncommon(c1,c2)!=1: print('NOT TANGENT',i,c1,c2); bad+=1
for i,cs_ in {'GT-123':('x^2+y^2-4x+2y=24','x+y=4'),'GT-196':('x^2+y^2=100','y=6'),'GT-192':('x^2+y^2=13^2','y=-5'),'GT-157':('x^2+y^2+8x-2y-8=0','5x+12y=44'),'GT-055':('2x^2-8x+2y^2+12y=24','y=-3'),'GT-166':('y=x(20-x)','y=64')}.items():
    if ncommon(*cs_)!=2: print('NOT 2 PTS',i); bad+=1
# final answers equal solve.py's independent answers (re-using the checks of build.py)
items={o['id']:o for o in solve.items.values()}
for i,o in items.items():
    v=solve.K[i]
    if o['mc']:
        idx=solve.opt_index(o); assert len(idx)==1 and 'ABCD'[idx[0]]==o['bank_letter'],i
        if i not in('GT-056','GT-086','GT-122','GT-135','GT-150','GT-195'):
            if abs(float(ANS[i])-float(v))>1e-9: print('ANS vs solve',i,ANS[i],v); bad+=1
    else:
        if abs(float(ANS[i])-float(v))>1e-9: print('ANS vs solve',i,ANS[i],v); bad+=1
print('problems',len(S),'with>=1 Desmos box',prob_with,'total boxes',nbox,'returns checked',nret,'tap points',sum(len(v) for v in TAPS.values()))
print('TOTAL BAD',bad)
